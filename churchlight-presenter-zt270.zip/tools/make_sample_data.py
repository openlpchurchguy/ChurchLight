#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Make placeholder songs, a Bible and a slide deck so you can try the program with no real files.

    python tools/make_sample_data.py --db test.db --media media

That builds the files in a folder called sample-data AND imports them into test.db, using only
what is already installed (no poppler needed). Then start the program with:

    python -m churchlight_presenter --db test.db --media media

All text is made-up placeholder text. The Bible is called DEMO and holds only a handful of verses.
Leave out --db to just make the files in sample-data and import them yourself.
"""
import argparse
import struct
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

OPENLYRICS = "http://openlyrics.info/namespace/2009/song"

SONGS = {
    "Placeholder Song One": ("Sample Author", [
        ("v1", "Placeholder verse one, line one<br/>Placeholder verse one, line two<br/>"
               "Placeholder verse one, line three<br/>Placeholder verse one, line four<br/>"
               "Placeholder verse one, line five"),
        ("c", "Placeholder chorus, line one<br/>Placeholder chorus, line two"),
        ("v2", "Placeholder verse two, line one<br/>Placeholder verse two, line two")], "v1 c v2 c"),
    "Placeholder Song Two": ("Sample Author", [
        ("v1", "Another placeholder line one<br/>Another placeholder line two"),
        ("b", "Placeholder bridge, line one<br/>Placeholder bridge, line two")], "v1 b v1"),
    "Placeholder Song Three": (None, [
        ("v1", "A short placeholder song<br/>with only one section")], "v1"),
}

# book number, chapter, verse, text (placeholders, not real Scripture)
VERSES = [
    (1, 1, 1, "[Demo Genesis 1:1] A short placeholder verse."),
    (1, 1, 2, "[Demo Genesis 1:2] Another short placeholder verse."),
    (19, 23, 1, "[Demo Psalm 23:1] Placeholder text for the first verse of this psalm."),
    (19, 23, 2, "[Demo Psalm 23:2] Placeholder text for the second verse of this psalm."),
    (19, 23, 3, "[Demo Psalm 23:3] Placeholder text for the third verse of this psalm."),
    (43, 3, 16, "[Demo John 3:16] This placeholder verse is deliberately long so that you can see "
                 "what happens when a verse has to be split across more than one slide, and check "
                 "that the verse number and reference stay correct on every piece of it."),
    (43, 3, 17, "[Demo John 3:17] A shorter placeholder verse."),
]


def png(width, height, rgb, stripe):
    """A plain PNG: a color with a lighter stripe for orientation."""
    from churchlight_presenter.importers.common import encode_png
    row = bytes(rgb) * width
    stripe_row = bytes(stripe) * width
    return encode_png(width, height, [stripe_row if height * 2 // 5 < y < height * 3 // 5 else row
                                      for y in range(height)])


def song_xml(title, author, verses, order):
    body = "".join(f'<verse name="{name}"><lines>{text}</lines></verse>' for name, text in verses)
    author_xml = f"<authors><author>{author}</author></authors>" if author else ""
    return (f'<?xml version="1.0" encoding="UTF-8"?><song xmlns="{OPENLYRICS}" version="0.8">'
            f"<properties><titles><title>{title}</title></titles>{author_xml}"
            f"<verseOrder>{order}</verseOrder></properties><lyrics>{body}</lyrics></song>")


def zefania_xml():
    books = {}
    for book, chapter, verse, text in VERSES:
        books.setdefault(book, {}).setdefault(chapter, []).append((verse, text))
    out = ['<?xml version="1.0" encoding="UTF-8"?><XMLBIBLE biblename="Demo Placeholder Bible">'
           "<INFORMATION><title>Demo Placeholder Bible</title><identifier>DEMO</identifier>"
           "<language>en</language><rights>Made-up placeholder text, free to use</rights></INFORMATION>"]
    for book, chapters in books.items():
        out.append(f'<BIBLEBOOK bnumber="{book}">')
        for chapter, verses in chapters.items():
            out.append(f'<CHAPTER cnumber="{chapter}">')
            out += [f'<VERS vnumber="{v}">{t}</VERS>' for v, t in verses]
            out.append("</CHAPTER>")
        out.append("</BIBLEBOOK>")
    out.append("</XMLBIBLE>")
    return "".join(out)


def make_files(folder):
    """Write the sample songs, Bible and slide images under `folder`; returns their paths."""
    folder = Path(folder)
    songs = folder / "songs"
    slides = folder / "slides"
    songs.mkdir(parents=True, exist_ok=True)
    slides.mkdir(parents=True, exist_ok=True)
    for n, (title, (author, verses, order)) in enumerate(SONGS.items(), start=1):
        (songs / f"song{n}.xml").write_text(song_xml(title, author, verses, order), encoding="utf-8")
    bible = folder / "bible.xml"
    bible.write_text(zefania_xml(), encoding="utf-8")
    colors = [((30, 60, 110), (90, 130, 200)), ((30, 100, 70), (100, 190, 140)),
              ((110, 40, 50), (200, 110, 120))]
    for n, (base, stripe) in enumerate(colors, start=1):
        (slides / f"slide{n}.png").write_bytes(png(1280, 720, base, stripe))
    return {"songs": songs, "bible": bible, "slides": slides}


def import_all(db_path, media, paths):
    from churchlight_presenter.core.database import DatabaseManager
    from churchlight_presenter.importers.bibles import import_bible
    from churchlight_presenter.importers.decks import import_image_folder
    from churchlight_presenter.importers.songs import import_openlyrics
    with DatabaseManager(db_path) as db:
        songs = import_openlyrics(db, paths["songs"])
        if db.get_translation("DEMO") is None:
            bible = import_bible(db, paths["bible"])
            bible_text = f"{bible.verse_count} verses"
        else:
            bible_text = "already there"
        deck = import_image_folder(db, paths["slides"], media, name="Placeholder Slideshow")
    return (f"songs: {len(songs.imported)} imported, {songs.duplicates} already there; "
            f"Bible DEMO: {bible_text}; slideshow: {deck.page_count} pages"
            + (" (already there)" if deck.duplicate else ""))


def main(argv=None):
    parser = argparse.ArgumentParser(description="Make placeholder sample data")
    parser.add_argument("--folder", default="sample-data", help="where to write the sample files")
    parser.add_argument("--db", help="also import everything into this database file")
    parser.add_argument("--media", default="media", help="media folder for the deck images")
    args = parser.parse_args(argv)
    paths = make_files(args.folder)
    print(f"Sample files written to {args.folder}")
    if args.db:
        print("Imported -> " + import_all(args.db, args.media, paths))
        print(f"\nNow start the program:\n  python -m churchlight_presenter --db {args.db} --media {args.media}")
    else:
        print("To import them yourself, use the importers in PROJECT.md, or rerun with --db test.db")
    return 0


if __name__ == "__main__":
    sys.exit(main())
