# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Unpack a wheel (a .whl file, for example pypdfium2's) into the program's vendor folder.

    python tools/add_vendor_wheel.py pypdfium2-5.14.0-py3-none-win_amd64.whl

The program then finds the package without any pip install, because it adds the vendor folder next to the
churchlight_presenter folder to its search path. Use this when preparing a download for churches. A wheel is
just a zip file; nothing is run. Files that would land outside the vendor folder are refused.
"""
import argparse
import sys
import zipfile
from pathlib import Path

VENDOR = Path(__file__).resolve().parent.parent / "vendor"


def add_wheel(wheel, vendor=VENDOR):
    """Unpack the wheel into `vendor`; returns the number of files written."""
    wheel, vendor = Path(wheel), Path(vendor)
    if wheel.suffix.lower() != ".whl" or not zipfile.is_zipfile(wheel):
        raise SystemExit(f"{wheel.name} is not a .whl file")
    vendor.mkdir(parents=True, exist_ok=True)
    root = vendor.resolve()
    written = 0
    with zipfile.ZipFile(wheel) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            target = (root / info.filename).resolve()
            if root not in target.parents:
                raise SystemExit(f"Refusing {info.filename}: it would be written outside the vendor folder")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(zf.read(info))
            written += 1
    return written


def main(argv=None):
    parser = argparse.ArgumentParser(description="Unpack a .whl into the vendor folder.")
    parser.add_argument("wheel", nargs="+")
    parser.add_argument("--vendor", default=str(VENDOR))
    args = parser.parse_args(argv)
    for wheel in args.wheel:
        print(f"{Path(wheel).name}: {add_wheel(wheel, args.vendor)} files -> {args.vendor}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
