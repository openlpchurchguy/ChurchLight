#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Rebuild the bundled King James text from eBible.org's verse-per-line XML.

    python tools/make_kjv.py path/to/eng-kjv2006_vpl.xml

Source: https://ebible.org/find/show.php?id=eng-kjv2006 (file "eng-kjv2006_vpl.zip", the BibleWorks
VPL download; inside it, eng-kjv2006_vpl.xml). The text is the standard 1769 King James Version,
66 books, public domain in the United States (see the notice written beside the output).

What this tool changes, and nothing else:
  * book codes (GEN, EXO ...) become book numbers 1-66, in the usual order;
  * the paragraph sign "¶" is removed (it would show on a slide);
  * runs of spaces are squeezed and the ends of each verse trimmed.
It then checks the result (31,102 verses, 66 books, known verses) and refuses to write if anything is off.
"""
import csv
import hashlib
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

OUT_DIR = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "content" / "bibles"
CODES = ("GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM "
         "EZK DAN HOS JOL AMO OBA JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP "
         "COL 1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV").split()
EXPECT = {"GEN": 1533, "EXO": 1213, "PSA": 2461, "MAT": 1071, "JHN": 879, "REV": 404}   # verses per book (KJV)
KNOWN = {
    (1, 1, 1): "In the beginning God created the heaven and the earth.",
    (19, 23, 1): "A Psalm of David. The LORD is my shepherd; I shall not want.",
    (43, 3, 16): "For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.",
    (66, 22, 21): "The grace of our Lord Jesus Christ be with you all. Amen.",
}
TOTAL = 31102


def build(source):
    root = ET.parse(source).getroot()
    rows, per_book = [], {}
    for v in root.iter("v"):
        code = v.get("b")
        if code not in CODES:
            raise SystemExit(f"Unknown book code {code!r}")
        text = re.sub(r"\s+", " ", (v.text or "").replace("¶", " ")).strip()
        if not text:
            raise SystemExit(f"Empty verse {code} {v.get('c')}:{v.get('v')}")
        rows.append((CODES.index(code) + 1, int(v.get("c")), int(v.get("v")), text))
        per_book[code] = per_book.get(code, 0) + 1
    problems = []
    if len(rows) != TOTAL:
        problems.append(f"{len(rows)} verses, expected {TOTAL}")
    if len(per_book) != 66:
        problems.append(f"{len(per_book)} books, expected 66")
    for code, count in EXPECT.items():
        if per_book.get(code) != count:
            problems.append(f"{code} has {per_book.get(code)} verses, expected {count}")
    if len({r[:3] for r in rows}) != len(rows):
        problems.append("a verse appears twice")
    index = {r[:3]: r[3] for r in rows}
    for key, text in KNOWN.items():
        if index.get(key) != text:
            problems.append(f"{key} reads {index.get(key)!r}")
    if any(re.search(r"[\[\]<>{}0-9¶]", r[3]) for r in rows):
        problems.append("a verse still holds a bracket, tag, digit or paragraph sign")
    if problems:
        raise SystemExit("Not written:\n  " + "\n  ".join(problems))
    return rows


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        raise SystemExit(__doc__)
    rows = build(argv[0])
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = OUT_DIR / "kjv.csv"
    with open(out, "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerows(rows)
    digest = hashlib.sha256(out.read_bytes()).hexdigest()
    (OUT_DIR / "kjv.sha256").write_text(f"{digest}  kjv.csv\n", encoding="utf-8")
    print(f"Wrote {out} ({len(rows)} verses, sha256 {digest[:12]}...)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
