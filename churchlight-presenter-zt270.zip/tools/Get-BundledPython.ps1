# Puts a private copy of Python inside the ChurchLight folder, so a church needs to install nothing.
# Run this ONCE when preparing a download (right-click, "Run with PowerShell"), then zip the whole folder.
#   .\tools\Get-BundledPython.ps1                      (downloads the embeddable Python and prints its fingerprint)
#   .\tools\Get-BundledPython.ps1 -Sha256 <hash>       (also refuses the file unless its fingerprint matches)
# The fingerprint (SHA-256) of each release is listed on its python.org download page; compare it with what this prints.
param([string]$Version = "3.12.8", [string]$Sha256 = "")
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$target = Join-Path $root "python"
$zip = Join-Path $env:TEMP "python-$Version-embed-amd64.zip"
$url = "https://www.python.org/ftp/python/$Version/python-$Version-embed-amd64.zip"
Write-Host "Downloading $url"
Invoke-WebRequest -Uri $url -OutFile $zip
$hash = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
Write-Host "SHA-256 of the download: $hash"
if ($Sha256 -and $hash -ne $Sha256.ToLower()) { Remove-Item $zip; throw "The fingerprint does not match. The file was deleted." }
if (Test-Path $target) { Remove-Item $target -Recurse -Force }
Expand-Archive -Path $zip -DestinationPath $target
Remove-Item $zip
# The embeddable Python ignores the current folder; tell it to also look one folder up, where churchlight_presenter and vendor are.
$pth = Get-ChildItem $target -Filter "python*._pth" | Select-Object -First 1
Add-Content -Path $pth.FullName -Value ".."
# Prove it works: the modules ChurchLight needs, and ChurchLight itself.
& (Join-Path $target "python.exe") -c "import sqlite3, ctypes, ssl, http.server, zlib; print('Python', __import__('sys').version.split()[0], 'is ready')"
& (Join-Path $target "python.exe") -c "import sys; sys.path.insert(0, r'$root'); import churchlight_presenter; print('ChurchLight found')"
Write-Host "Done. The folder 'python' is next to start_churchlight.bat. Zip the whole ChurchLight folder to share it."
