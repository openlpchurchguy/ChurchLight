#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Check that ChurchLight Presenter works on this computer, and write a report to send back.

    python tools/selftest.py
    python tools/selftest.py --songs "C:\\path\\to\\song-folder" --bible bible.xml --deck sermon.pdf

With no options it checks the computer, runs every test, plays the demo scenario and
starts the web server for a moment. The optional --songs/--bible/--deck options also try
YOUR files (in a throwaway database, never your real one). The report contains counts,
timings, file names and error messages. It never contains song lyrics or Bible text, so it
is safe to paste into a chat or an issue.

The report is printed and saved as selftest-report.txt (change it with --out).
"""
import argparse
import http.client
import io
import json
import platform
import shutil
import sqlite3
import statistics
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PASS, FAIL, SKIP, INFO = "PASS", "FAIL", "SKIP", "INFO"


class Section:
    def __init__(self, name):
        self.name, self.status, self.lines = name, PASS, []

    def note(self, text):
        self.lines.append(text)

    def skip(self, text):
        self.status = SKIP
        self.lines.append("skipped: " + text)

    def fail(self, text):
        self.status = FAIL
        self.lines.append("PROBLEM: " + text)

    def check(self, condition, text):
        self.lines.append(("ok:      " if condition else "PROBLEM: ") + text)
        if not condition:
            self.status = FAIL
        return condition


def _tool_version(names):
    for name in names:
        exe = shutil.which(name)
        if exe:
            try:
                flag = "-v" if Path(exe).stem.lower() == "pdftoppm" else "--version"   # poppler's spelling
                out = subprocess.run([exe, flag], capture_output=True, text=True, timeout=30)
                first = ((out.stdout or "") + (out.stderr or "")).strip().splitlines()
                return f"{exe} ({first[0] if first else 'version unknown'})"
            except (OSError, subprocess.SubprocessError):
                return f"{exe} (could not run it)"
    return None


# ---------------------------------------------------------------------------
def check_environment():
    s = Section("This computer")
    s.note(f"system:  {platform.platform()}")
    s.note(f"python:  {sys.version.split()[0]} ({platform.python_implementation()}) at {sys.executable}")
    s.note(f"sqlite:  {sqlite3.sqlite_version}")
    s.check(sys.version_info >= (3, 10), "Python is 3.10 or newer")
    conn = sqlite3.connect(":memory:")
    try:
        conn.execute("CREATE VIRTUAL TABLE t USING fts5(x)")
        s.check(True, "SQLite has full-text search (FTS5), needed for song search")
    except sqlite3.OperationalError:
        s.check(False, "SQLite has full-text search (FTS5), needed for song search")
    try:
        conn.execute("SELECT json_valid('{}')")
        s.check(True, "SQLite has JSON support")
    except sqlite3.OperationalError:
        s.check(False, "SQLite has JSON support")
    conn.close()
    from churchlight_presenter.importers import pdfrender
    status = pdfrender.pdf_status()
    if status["engine"] == "pypdfium2":
        s.note(f"pypdfium2: {status['version'] or 'installed'}{' (from the vendor folder)' if status['bundled'] else ''}  (renders PDFs)")
    else:
        s.note("pypdfium2: NOT INSTALLED (fix: python -m pip install pypdfium2, or put it in the vendor folder)")
    found = _tool_version(["pdftoppm"])
    s.note(f"poppler pdftoppm: {found or 'not found (only needed if pypdfium2 is missing)'}")
    s.note(f"PDF renderer that will be used: {pdfrender.renderer_name() or 'NONE (PDF import will not work)'}")
    s.note(f"node: {_tool_version(['node']) or 'NOT FOUND (needed for a few web-page tests, optional)'}")
    return s


def run_operator_page():
    s = Section("Operator page (the control page you will use)")
    from churchlight_presenter.core.database import DatabaseManager
    from churchlight_presenter.ui.controller import OperatorController
    from churchlight_presenter import launcher
    db = DatabaseManager(":memory:", shared=True)
    db.create_song_with_sections("Selftest Song", [("Verse 1", "verse", "line one\nline two")],
                                 order=["Verse 1"])
    controller = OperatorController(db)
    try:
        server = controller.serve()
        host, port = server.address

        def get(path):
            conn = http.client.HTTPConnection(host, port, timeout=10)
            conn.request("GET", path)
            res = conn.getresponse()
            body = res.read()
            conn.close()
            return res.status, body

        def do(action, args=None):
            conn = http.client.HTTPConnection(host, port, timeout=10)
            conn.request("POST", "/api/do", body=json.dumps({"action": action, "args": args or {}}),
                         headers={"Content-Type": "application/json", "X-ChurchLight": "selftest"})
            res = conn.getresponse()
            data = json.loads(res.read())
            conn.close()
            return res.status, data
        status, body = get("/operator")
        s.check(status == 200 and b"ChurchLight operator" in body, "the operator page loads")
        status, body = get("/static/operator.js")
        s.check(status == 200 and len(body) > 1000, "the operator script loads")
        status, lib = do("new_service", {"title": "Selftest"})
        s.check(status == 200 and lib.get("ok"), "a service can be started from the page's side")
        entries = json.loads(get("/api/library?q=Selftest")[1])["entries"]
        s.check(len(entries) == 1, "the library search finds a song")
        status, _ = do("add", {"kind": entries[0]["kind"], "id": entries[0]["id"]})
        s.check(status == 200, "the song can be added to the service")
        state = json.loads(get("/api/state")[1])
        s.check(len(state["items"]) == 1, "the service list shows it")
        status, _ = do("go_item", {"item_id": state["items"][0]["item_id"]})
        state = json.loads(get("/api/state")[1])
        s.check(status == 200 and state["live"]["base"]["text"] == "line one\nline two",
                "going live shows the song's first slide")
        conn = http.client.HTTPConnection(host, port, timeout=10)
        conn.request("GET", "/api/state", headers={"Host": "not-this-computer.example"})
        res = conn.getresponse()
        res.read()
        conn.close()
        s.check(res.status == 403, "requests addressed to other names are refused")
    finally:
        controller.close()
        db.close()
    found = launcher.find_browser()
    s.note(f"browser for the app window: {found[0] + ' at ' + found[1] if found else 'none found (the default browser will be used)'}")
    return s


def run_library_management():
    s = Section("Library: importing and editing from the page")
    import importlib.util
    from churchlight_presenter.core.database import DatabaseManager
    from churchlight_presenter.ui.controller import OperatorController
    spec = importlib.util.spec_from_file_location("make_sample_data", ROOT / "tools" / "make_sample_data.py")
    sample = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sample)
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        files = sample.make_files(tmp / "sample")
        db = DatabaseManager(tmp / "lib.db", shared=True)
        controller = OperatorController(db, media_root=tmp / "media")
        try:
            server = controller.serve(media_root=tmp / "media")
            host, port = server.address

            def post(path, body, headers):
                conn = http.client.HTTPConnection(host, port, timeout=30)
                conn.request("POST", path, body=body, headers={"X-ChurchLight": "selftest", **headers})
                res = conn.getresponse()
                data = json.loads(res.read())
                conn.close()
                return res.status, data

            def do(action, args=None):
                return post("/api/do", json.dumps({"action": action, "args": args or {}}),
                            {"Content-Type": "application/json"})

            def state():
                conn = http.client.HTTPConnection(host, port, timeout=30)
                conn.request("GET", "/api/state")
                res = conn.getresponse()
                data = json.loads(res.read())
                conn.close()
                return data
            status, reply = do("import_batch")
            s.check(status == 200, "an import batch can be started")
            batch = reply.get("batch")
            songs = sorted(files["songs"].glob("*.xml"))
            uploaded = 0
            for song in songs:
                code, _ = post(f"/api/upload?batch={batch}&kind=songs&name={song.name}", song.read_bytes(),
                               {"Content-Type": "application/octet-stream"})
                uploaded += code == 200
            s.check(uploaded == len(songs), f"{len(songs)} song files can be uploaded")
            status, _ = do("import_start", {"kind": "songs", "batch": batch})
            deadline = time.monotonic() + 60
            job = None
            while time.monotonic() < deadline:
                jobs = state()["imports"]
                job = jobs[0] if jobs else None
                if job and job["status"] in ("done", "failed"):
                    break
                time.sleep(0.1)
            s.check(job is not None and job["status"] == "done", "the songs are imported in the background"
                    + (f" ({job['message']})" if job else ""))
            _, check = do("song_check", {"text": "[Verse 1]\nline\n\n[Chorus]\nla\nOrder: Verse 1, Chorus, Verse 1"})
            s.check(check.get("valid") is True, "typed song words are understood")
            status, saved = do("song_save", {"title": "Selftest typed song", "author": "", "text": "[Verse 1]\nline one\nline two"})
            s.check(status == 200 and "id" in saved, "a typed song can be saved")
            found = controller.search_library("Selftest typed")
            s.check(len(found) == 1, "the typed song can be found by search")
            status, _ = do("song_delete", {"id": saved["id"]})
            s.check(status == 200 and not controller.search_library("Selftest typed"), "a song can be deleted")
            leftovers = list((tmp / "media" / ".uploads").glob("*")) if (tmp / "media" / ".uploads").exists() else []
            s.check(not leftovers, "temporary upload files are cleaned up")
        finally:
            controller.close()
            db.close()
    return s


def run_log_check():
    s = Section("Log file")
    from churchlight_presenter import logsetup
    import logging
    with tempfile.TemporaryDirectory() as tmp:
        path = logsetup.setup_logging(Path(tmp) / "test.log", warn=s.note)
        try:
            s.check(path is not None, "a log file can be created")
            logging.getLogger("churchlight_presenter.selftest").info("selftest line")
            s.check(path is not None and "selftest line" in path.read_text(encoding="utf-8"),
                    "a line written to the log can be read back")
        finally:
            logsetup.close_logging()
    return s


def run_pdf_import():
    s = Section("PDF import (a tiny test PDF)")
    from churchlight_presenter.importers import pdfrender
    name = pdfrender.renderer_name()
    if name is None:
        s.skip("no PDF renderer installed. Fix: python -m pip install pypdfium2")
        return s
    from churchlight_presenter.core.database import DatabaseManager
    from churchlight_presenter.importers.decks import import_deck
    from tests.test_decks import make_pdf
    with tempfile.TemporaryDirectory() as tmp, DatabaseManager(":memory:") as db:
        pdf = Path(tmp) / "test.pdf"
        make_pdf(pdf, 3)
        started = time.monotonic()
        result = import_deck(db, pdf, Path(tmp) / "media")
        s.note(f"renderer: {name}; {result.page_count} pages in {time.monotonic() - started:.2f}s")
        s.check(result.page_count == 3, "the 3-page test PDF became 3 page images")
        files = sorted((Path(tmp) / "media").rglob("page-*.png"))
        s.check(len(files) == 3 and all(f.read_bytes().startswith(b"\x89PNG") for f in files),
                "the page images are valid PNG files")
    return s


def run_unit_tests():
    s = Section("Automated tests")
    stream = io.StringIO()
    started = time.monotonic()
    suite = unittest.TestLoader().discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    result = unittest.TextTestRunner(stream=stream, verbosity=0).run(suite)
    seconds = time.monotonic() - started
    s.note(f"ran {result.testsRun} tests in {seconds:.1f}s: {len(result.failures)} failed, "
           f"{len(result.errors)} errors, {len(result.skipped)} skipped")
    for test, reason in result.skipped:
        s.note(f"skipped {test.id().split('.', 1)[-1]}: {reason}")
    for test, trace in result.failures + result.errors:
        s.fail(f"{test.id()}\n           {trace.strip().splitlines()[-1]}")
    if not result.wasSuccessful():
        s.note("(full details: run  python -m unittest discover -s tests -t .  )")
    return s


def run_demo_scenario():
    s = Section("Demo scenario (verse shown over a deck)")
    try:
        from churchlight_presenter.demo import run_demo
        _, steps = run_demo()
        payloads = {n: p["payloads"] for n, p in enumerate(steps)}
        s.check(payloads[2]["projector"]["base"]["label"] == "Slide 2"
                and payloads[2]["projector"]["overlay"]["reference"] == "John 3:16",
                "a verse appears over deck slide 2")
        s.check(payloads[5]["projector"]["overlay"] is None
                and payloads[5]["projector"]["base"]["label"] == "Slide 2",
                "hiding the verse leaves the deck where it was")
        s.check(all("notes" not in json.dumps(p["projector"]) for p in payloads.values()),
                "speaker notes never reach the projector")
    except Exception as err:  # noqa: BLE001 - a report must say what broke, not crash
        s.fail(f"{type(err).__name__}: {err}")
    return s


def run_server_smoke():
    s = Section("Web server and output pages")
    try:
        from churchlight_presenter.core.live import LiveSession
        from churchlight_presenter.core.outputs import Output
        from churchlight_presenter.core.slides import Slide
        from churchlight_presenter.server.app import OutputServer
        slides = [Slide("image", "presentation", 1, label="Slide 1", image_path="d/1.png",
                        notes="SECRET-NOTE"),
                  Slide("image", "presentation", 1, label="Slide 2", image_path="d/2.png")]
        session = LiveSession(slides)
        session.go_to(0)
        outputs = [Output("projector", "projector"), Output("stage", "ppt_notes")]
        with OutputServer(session, outputs) as server:
            def get(path):
                conn = http.client.HTTPConnection(*server.address, timeout=10)
                try:
                    conn.request("GET", path)
                    r = conn.getresponse()
                    return r.status, r.read()
                finally:
                    conn.close()
            s.note(f"listening at {server.url}")
            s.check(get("/view/projector")[0] == 200, "the output page loads")
            s.check(get("/static/output.js")[0] == 200, "the page script loads")
            s.check(b"SECRET-NOTE" not in get("/out/projector")[1], "public output has no speaker notes")
            s.check(b"SECRET-NOTE" in get("/out/stage")[1], "stage output has the speaker notes")
            version = json.loads(get("/out/stage")[1])["version"]
            started = time.monotonic()
            status = get(f"/out/stage?since={version}&wait=0.3")[0]
            s.check(status == 304 and time.monotonic() - started >= 0.25, "waiting for changes works")
            s.check(get("/media/../x.png")[0] == 404, "the media route refuses to leave its folder")
    except Exception as err:  # noqa: BLE001
        s.fail(f"{type(err).__name__}: {err}")
    return s


# ---------------------------------------------------------------------------
# Optional: the team's own files
# ---------------------------------------------------------------------------
def try_songs(path):
    from churchlight_presenter.core.database import DatabaseManager
    from churchlight_presenter.core.items import ItemRef
    from churchlight_presenter.core.slides import SlideBuilder
    from churchlight_presenter.importers.songs import import_openlyrics
    s = Section(f"Your songs ({path})")
    with DatabaseManager(":memory:") as db:
        started = time.monotonic()
        report = import_openlyrics(db, path)
        s.note(f"imported {len(report.imported)}, already-present {report.duplicates}, "
               f"failed {len(report.failed)}, notes {len(report.warnings)} "
               f"in {time.monotonic() - started:.1f}s")
        for name, message in report.failed[:15]:
            s.note(f"  failed {name}: {message}")
        if len(report.failed) > 15:
            s.note(f"  ...and {len(report.failed) - 15} more failures")
        for name, message in report.warnings[:10]:
            s.note(f"  note {name}: {message}")
        builder, counts, errors = SlideBuilder(db), [], 0
        for song_id in report.imported:
            try:
                counts.append(len(builder.build_item(ItemRef.song(song_id))))
            except ValueError:
                errors += 1
        if counts:
            s.note(f"slides per song: smallest {min(counts)}, typical {int(statistics.median(counts))}, "
                   f"largest {max(counts)}; songs that would not build: {errors}")
        if not report.imported:
            s.fail("no songs were imported")
        elif errors:
            s.fail(f"{errors} imported songs would not build into slides")
    return s


def try_bible(path):
    from churchlight_presenter.core.database import DatabaseManager
    from churchlight_presenter.core.scripture_ref import parse_reference
    from churchlight_presenter.importers.bibles import import_bible
    s = Section(f"Your Bible file ({path})")
    with DatabaseManager(":memory:") as db:
        started = time.monotonic()
        report = import_bible(db, path, abbreviation="TEST")
        s.note(f"imported {report.verse_count} verses in {report.book_count} books "
               f"in {time.monotonic() - started:.1f}s; notes: {len(report.warnings)}")
        for warning in report.warnings[:10]:
            s.note(f"  note: {warning}")
        for typed in ("John 3:16", "Genesis 1:1", "Psalm 23", "Revelation 22:21"):
            ref = parse_reference(typed)
            trans = db.get_translation("TEST")
            if ref.verse_start is None:                      # a whole chapter
                start, end = 1, db.last_verse(trans["id"], ref.book_id, ref.chapter)
            else:
                start, end = ref.verse_start, ref.verse_end or ref.verse_start
            found = bool(end and db.get_verses(trans["id"], ref.book_id, ref.chapter, start, end))
            s.note(f"  {typed}: {'found' if found else 'not found (fine for a partial Bible)'}")
        if report.verse_count < 100:
            s.fail("very few verses were imported; is this the right file?")
    return s


def try_deck(path):
    from churchlight_presenter.core.database import DatabaseManager
    from churchlight_presenter.importers.decks import import_deck
    s = Section(f"Your deck ({path})")
    with DatabaseManager(":memory:") as db, tempfile.TemporaryDirectory() as media:
        started = time.monotonic()
        result = import_deck(db, path, media)
        s.note(f"imported {result.page_count} pages ({result.notes_count} with speaker notes) "
               f"in {time.monotonic() - started:.1f}s")
        for warning in result.warnings:
            s.note(f"  note: {warning}")
        files = [p for p in Path(media).rglob("page-*") if p.is_file()]
        if files:
            sizes = [p.stat().st_size for p in files]
            s.note(f"page images: {len(files)}, average {int(sum(sizes) / len(sizes)) // 1024} KB, "
                   f"largest {max(sizes) // 1024} KB")
        if result.page_count < 1:
            s.fail("no pages were produced")
    return s


def attempt(section_fn, *args):
    """Run a section; an unexpected crash is reported as a failure of that section."""
    try:
        return section_fn(*args)
    except Exception as err:  # noqa: BLE001
        label = getattr(section_fn, "__name__", "section")
        s = Section(f"{label} {args[0] if args else ''}".strip())
        s.fail(f"{type(err).__name__}: {err}")
        return s


def main(argv=None):
    parser = argparse.ArgumentParser(description="ChurchLight Presenter self-test")
    parser.add_argument("--songs", help="a folder of OpenLyrics .xml files (or one file) to try")
    parser.add_argument("--bible", help="a Zefania .xml or .csv Bible file to try")
    parser.add_argument("--deck", help="a .pdf to try")
    parser.add_argument("--skip-tests", action="store_true", help="skip the automated test run")
    parser.add_argument("--out", default="selftest-report.txt", help="where to save the report")
    args = parser.parse_args(argv)

    sections = [check_environment()]
    if not args.skip_tests:
        sections.append(attempt(run_unit_tests))
    sections.append(attempt(run_demo_scenario))
    sections.append(attempt(run_server_smoke))
    sections.append(attempt(run_pdf_import))
    sections.append(attempt(run_operator_page))
    sections.append(attempt(run_library_management))
    sections.append(attempt(run_log_check))
    for option, fn in ((args.songs, try_songs), (args.bible, try_bible), (args.deck, try_deck)):
        if option:
            sections.append(attempt(fn, option))

    lines = ["ChurchLight Presenter self-test report",
             f"date: {time.strftime('%Y-%m-%d %H:%M:%S')}", ""]
    for section in sections:
        lines.append(f"[{section.status}] {section.name}")
        lines.extend("    " + line for line in section.lines)
        lines.append("")
    overall = FAIL if any(sec.status == FAIL for sec in sections) else PASS
    lines.append(f"OVERALL: {overall}")
    report = "\n".join(lines)
    print(report)
    try:
        Path(args.out).write_text(report + "\n", encoding="utf-8")
        print(f"\n(report saved to {args.out})")
    except OSError as err:
        print(f"\n(could not save the report: {err})")
    return 0 if overall == PASS else 1


if __name__ == "__main__":
    sys.exit(main())
