#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Copy the theme fonts out of a folder of Google Fonts downloads and write themefonts.css.

    python tools/bundle_fonts.py path/to/folder-with-the-unzipped-families

The folder holds one sub-folder per family as Google Fonts' "Download family" zips unpack
(Open_Sans/, Lato/, ...). For each family below, the Regular and Bold files are copied, unchanged, into
churchlight_presenter/server/static/fonts/, the family's OFL license is copied beside them as
OFL-<Name>.txt (the license requires it to stay with the font), and static/themefonts.css is rewritten.
Nothing else in the download (italics, other weights, variable files) is used.
"""
import shutil
import sys
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"

# css family, download folder, license name, [(weight, path inside the folder)], fallback, kind
FAMILIES = [
    ("Open Sans", "Open_Sans", "OpenSans", [(400, "static/OpenSans-Regular.ttf"), (700, "static/OpenSans-Bold.ttf")], "sans-serif", "Clean sans-serif"),
    ("Lato", "Lato", "Lato", [(400, "Lato-Regular.ttf"), (700, "Lato-Bold.ttf")], "sans-serif", "Warm sans-serif"),
    ("Source Sans 3", "Source_Sans_3", "SourceSans3", [(400, "static/SourceSans3-Regular.ttf"), (700, "static/SourceSans3-Bold.ttf")], "sans-serif", "Clean sans-serif"),
    ("Roboto", "Roboto", "Roboto", [(400, "static/Roboto-Regular.ttf"), (700, "static/Roboto-Bold.ttf")], "sans-serif", "Sturdy sans-serif"),
    ("Nunito", "Nunito", "Nunito", [(400, "static/Nunito-Regular.ttf"), (700, "static/Nunito-Bold.ttf")], "sans-serif", "Rounded, friendly"),
    ("Montserrat", "Montserrat", "Montserrat", [(400, "static/Montserrat-Regular.ttf"), (700, "static/Montserrat-Bold.ttf")], "sans-serif", "Modern, bold titles"),
    ("Poppins", "Poppins", "Poppins", [(400, "Poppins-Regular.ttf"), (700, "Poppins-Bold.ttf")], "sans-serif", "Modern, geometric"),
    ("Oswald", "Oswald", "Oswald", [(400, "static/Oswald-Regular.ttf"), (700, "static/Oswald-Bold.ttf")], "sans-serif", "Condensed, for titles"),
    ("Anton", "Anton", "Anton", [(400, "Anton-Regular.ttf")], "sans-serif", "Heavy condensed, titles"),
    ("Merriweather", "Merriweather", "Merriweather", [(400, "static/Merriweather_36pt-Regular.ttf"), (700, "static/Merriweather_36pt-Bold.ttf")], "serif", "Sturdy serif"),
    ("Lora", "Lora", "Lora", [(400, "static/Lora-Regular.ttf"), (700, "static/Lora-Bold.ttf")], "serif", "Elegant serif"),
    ("Libre Baskerville", "Libre_Baskerville", "LibreBaskerville", [(400, "static/LibreBaskerville-Regular.ttf"), (700, "static/LibreBaskerville-Bold.ttf")], "serif", "Classic serif"),
    ("PT Serif", "PT_Serif", "PTSerif", [(400, "PTSerif-Regular.ttf"), (700, "PTSerif-Bold.ttf")], "serif", "Plain, readable serif"),
    ("Playfair Display", "Playfair_Display", "PlayfairDisplay", [(400, "static/PlayfairDisplay-Regular.ttf"), (700, "static/PlayfairDisplay-Bold.ttf")], "serif", "Dramatic serif, titles"),
    ("Cinzel", "Cinzel", "Cinzel", [(400, "static/Cinzel-Regular.ttf"), (700, "static/Cinzel-Bold.ttf")], "serif", "Roman capitals, titles"),
    ("Dancing Script", "Dancing_Script", "DancingScript", [(400, "static/DancingScript-Regular.ttf"), (700, "static/DancingScript-Bold.ttf")], "cursive", "Script, titles only"),
]
# Atkinson Hyperlegible is already bundled for the operator page; the same files serve the themes.
EXISTING = ("Atkinson Hyperlegible", [(400, "AtkinsonHyperlegible-Regular.ttf"), (700, "AtkinsonHyperlegible-Bold.ttf")])


def face(family, weight, filename):
    return (f'@font-face {{ font-family: "{family}"; font-weight: {weight}; font-style: normal; font-display: swap;\n'
            f'  src: url("/static/fonts/{filename}") format("truetype"); }}\n')


def write_css():
    lines = ["/* Fonts for the slide themes, bundled so no font has to be installed on the projector or XSplit PC.\n"
             "   Written by tools/bundle_fonts.py. Licenses: the OFL-*.txt files in fonts/. */\n"]
    for family, _, _, files, _, _ in FAMILIES:
        for weight, path in files:
            lines.append(face(family, weight, Path(path).name))
    for weight, filename in EXISTING[1]:
        lines.append(face(EXISTING[0], weight, filename))
    (STATIC / "themefonts.css").write_text("".join(lines), encoding="utf-8")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        raise SystemExit(__doc__)
    source = Path(argv[0])
    target = STATIC / "fonts"
    problems = []
    for family, folder, license_name, files, _, _ in FAMILIES:
        for _, path in files:
            if not (source / folder / path).is_file():
                problems.append(f"{folder}/{path}")
        if not (source / folder / "OFL.txt").is_file():
            problems.append(f"{folder}/OFL.txt")
    if problems:
        raise SystemExit("Missing from the download folder:\n  " + "\n  ".join(problems))
    for family, folder, license_name, files, _, _ in FAMILIES:
        for _, path in files:
            shutil.copyfile(source / folder / path, target / Path(path).name)
        shutil.copyfile(source / folder / "OFL.txt", target / f"OFL-{license_name}.txt")
    write_css()
    print(f"Copied {len(FAMILIES)} families into {target} and wrote themefonts.css")
    return 0


if __name__ == "__main__":
    sys.exit(main())
