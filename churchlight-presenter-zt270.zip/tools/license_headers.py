#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Add (or check for) the license notice at the top of every Python file.

    python tools/license_headers.py          add the notice where it is missing
    python tools/license_headers.py --check  only report; exit 1 if any file lacks it

The notice is two comment lines, placed after a #! line or encoding line if
there is one. Running it twice changes nothing. To change the license
identifier or the copyright holder, edit the two constants below and run it
with --replace.
"""
import argparse
import sys
from pathlib import Path

SPDX = "AGPL-3.0-or-later"
HOLDER = "ChurchLight Presenter contributors"
NOTICE = [f"# SPDX-License-Identifier: {SPDX}",
          f"# Copyright (C) {HOLDER}"]
ROOTS = ("churchlight_presenter", "tests", "tools")


def python_files(project):
    for root in ROOTS:
        base = Path(project) / root
        if base.is_dir():
            yield from sorted(p for p in base.rglob("*.py") if "__pycache__" not in p.parts)


def has_notice(text):
    return any(line.startswith("# SPDX-License-Identifier:") for line in text.splitlines()[:6])


def missing_headers(project):
    return [p for p in python_files(project) if not has_notice(p.read_text(encoding="utf-8"))]


def _insert_at(lines):
    index = 0
    while index < len(lines) and (lines[index].startswith("#!") or
                                  lines[index].startswith("# -*-") or
                                  "coding:" in lines[index][:30] and lines[index].startswith("#")):
        index += 1
    return index


def add_notice(path, replace=False):
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    if has_notice(text):
        if not replace:
            return False
        lines = [l for l in lines if not (l.startswith("# SPDX-License-Identifier:")
                                          or l.startswith("# Copyright (C) "))]
    at = _insert_at(lines)
    lines[at:at] = [line + "\n" for line in NOTICE]
    path.write_text("".join(lines), encoding="utf-8")
    return True


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--replace", action="store_true", help="rewrite existing notices")
    parser.add_argument("--project", default=".", help="the project folder (default: here)")
    args = parser.parse_args(argv)
    if args.check:
        missing = missing_headers(args.project)
        for path in missing:
            print(f"missing license notice: {path}")
        return 1 if missing else 0
    changed = [p for p in python_files(args.project) if add_notice(p, args.replace)]
    for path in changed:
        print(f"updated {path}")
    print(f"{len(changed)} file(s) changed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
