# ChurchLight Presenter: project guide

A lightweight, open-source (AGPL-3.0), cross-platform church presentation program. It aims to combine
OpenLP's light weight and quick verse search with ProPresenter's split between **templates** (themes) and
**stages** (what each screen shows). Developed on Ubuntu 24.04; must also run on Windows (projector and
test bench), including DDR4-era PCs.

## What it does today

| Area | Status | Where |
|---|---|---|
| Database (SQLite, migrations, song search, scripture, services) | done, tested | `core/database.py`, `core/migrations.py` |
| Typed Bible references ("jn 3:16-18") | done, tested | `core/scripture_ref.py` |
| Slide building (lyrics, verses, decks, announcements) | done, tested | `core/slides.py`, `core/items.py` |
| Live session (current slide, verse overlay, blank) | done, tested | `core/live.py` |
| Outputs and per-screen payloads, notes kept off public screens | done, tested | `core/outputs.py` |
| Themes (font, colors, band) | done, tested | `core/themes.py` |
| Local web server and output pages (XSplit/OBS browser sources) | done; projector, stage and lower third verified in XSplit | `server/` |
| Importers: decks (PDF and slide pictures), OpenLyrics songs, Bible (Zefania, CSV) | done, tested | `importers/` |
| Operator controller and terminal console (change version + subscribe + wait_for_change; one notification per action) | done, tested | `ui/controller.py`, `ui/console.py` |
| **Operator web page** (library, service order, live controls, verse over slide, keys) over a thread-safe `OperatorApi`; `--open` app window, `start_churchlight.bat` | done; tested in headless Chromium and by unit tests; not yet tried by a person | `ui/operator_api.py`, `server/static/operator.*`, `launcher.py` |
| **Library tab**: import songs/Bibles/decks by choosing files (background import), plain-text song editor with live check, rename/delete with "in use" protection | done; tested in headless Chromium and by unit tests; not yet tried by a person | `ui/imports.py`, `core/songtext.py`, `ui/controller.py` (library admin), `server/static/operator.*` |
| Log file (rotating, no lyrics/verse text), `--log-file`, `--verbose` | done, tested | `logsetup.py`, `__main__.py` |
| PySide6 operator window and native projector window | not written (a browser app window is used instead; see the bookmark note) | `ui/` |
| Video/audio playback, song credits lines, OSIS/OpenSong import | not started | |

Verified on a real Windows 11 PC: install, health check, console service, browser pages, themes, XSplit outputs, PDF import (test PDF). Not yet run against real church decks, songs or Bibles. See `docs/BOOKMARK-2026-10-21-before-operator-ui.md` for the exact state before the operator UI work began.

## How the pieces fit

```
importers -> database -> SlideBuilder -> LiveSession -> build_payload -> outputs
 (once)     (library,     (computed,      (what is up      (one per        native window  (planned)
             services)     never stored)   right now)       screen)        web page /view/<name>
                                  ^
                     OperatorController: the operator's actions, no window in it
                     (used by the terminal console now, and by the Qt window later)
```

Rules that keep it simple:

1. **The core never imports the server, the UI or any GUI library.** The core is standard-library Python,
   so it can be tested on any machine with no display. Qt is only for `ui/` windows.
2. **Slides are computed, not stored.** Saved service items and items sent live from the library are the
   same thing (`ItemRef`); the builder turns them into slides on demand.
3. **Every output payload is made in one place** (`build_payload`). Speaker notes reach only `stage`-type
   layouts. A test fails if someone adds a `Slide` field without deciding whether public screens may see it.
4. **A Bible verse is an overlay**, separate from the slide underneath, so a slideshow slide stays put
   while a verse is shown and hidden. Long verses split at word boundaries; every piece keeps its verse
   number and reference, and later pieces are marked `continued`.
5. **Threads:** SQLite connections belong to one thread. The web server's threads never read the database;
   they read in-memory state (`LiveSession`, `ThemeStyles`). Keep it that way.
6. **No real song lyrics or Bible text in the repository or tests.** Use placeholder text.

## Outputs and layouts

An output is a name, a layout, and (for a native window) a monitor. Outputs live in a per-computer settings
file, not the database. Layouts (edit `LAYOUTS` in `core/outputs.py`):

| Layout | Audience | Shows |
|---|---|---|
| `projector`, `lower_third` | public | everything; overlay on top |
| `song_lower`, `song_full` | public | songs only |
| `verse_lower`, `verse_full` | public | verses only |
| `ppt_verse` | public | the deck, with a verse over it |
| `ppt_notes`, `stage` | stage | slide, next slide, position, **speaker notes** |

The web pages: `/view/<name>` is the page, `/out/<name>` its JSON, `/out/<name>?since=N&wait=20` waits for a
change. Public pages have transparent backgrounds. The server listens on 127.0.0.1 unless told otherwise;
anyone who can reach a stage output can read speaker notes. Because it is a network service, AGPL section 13
applies: pass `source_url` so `/source` points to the source code.

## Running it

```
python -m unittest discover -s tests -t .            # all tests (about 15 s)
python -m churchlight_presenter.demo                  # the verse-over-a-deck scenario, printed
python -m churchlight_presenter.importers.songs <folder> --db church.db
python -m churchlight_presenter.importers.bibles <file.xml|csv> --abbr XYZ --db church.db
python -m churchlight_presenter.importers.decks <file.pdf> --db church.db --media media
python -m churchlight_presenter --db church.db --media media     # terminal operator + web server
```

Used only at import time (needed on the machine doing the import, not during a service): **pypdfium2**
(`pip install pypdfium2`, Apache-2.0/BSD-3-Clause, no other software) renders PDFs; poppler's `pdftoppm` is the
fallback if it is absent.
For packaging, declare pypdfium2 as an optional dependency, e.g. `[project.optional-dependencies] pdf = ["pypdfium2>=4.0"]`.

Python 3.10 or newer. Tested on 3.11, 3.12 and 3.13. Optional: `node` (some page-logic tests skip without it).

## Conventions

- Small steps, each testable in a terminal before any window exists. New behavior comes with tests.
- Errors an operator can cause (typo in a reference, missing verse) give a plain message and never change
  what is on screen. A bad item in a service becomes a labeled placeholder slide, not a failed load.
- Changing the output payload shape: bump `PAYLOAD_SCHEMA` (old pages then fail visibly). Adding an optional
  field is compatible and does not need a bump.
- License notice: every Python file starts with an SPDX line. `python tools/license_headers.py` adds it;
  a test fails if any file lacks it. The identifier (`AGPL-3.0-or-later`) is one constant in that tool.

## Slide transitions

A deck (presentation row) carries `transition` (`none`, `dissolve`, `circle_out`, `circle_in`) and `transition_ms`
(0 to 2000 in steps of 100; schema migration 4). `SlideBuilder` copies them onto each of the deck's slides, so
changing the setting reloads the live slides in place (`set_deck_transition`). Only layouts flagged
`Layout.transitions` (the projector, for now) get `transitions: true` and a `preload` list (the next and previous
slides' pictures) in their payload; the output page then keeps the old frame, draws the new one above it and animates
with the Web Animations API (opacity, or `clip-path: circle()`), after decoding the new pictures. A new change settles
a running transition at once. The stage and lower-third pages are unchanged. Not done: transitions for other
outputs, for songs or verses, per-slide transitions, and Morph (the program has
flat pictures, no objects to match).

**Direction (November 2026): slideshows come in as a PDF or as slide pictures, and nothing else.** Importing presentation files, and reading speaker notes out of them, was removed; presenters export a PDF or pictures from their own software and choose the transition here. The one thing a PDF loses is speaker notes; a way to type or paste notes into the Library is the natural next step if they matter.

**Upgrade caution:** migration 4 changes an existing `churchlight.db`. A database touched by this version cannot be
opened by an older zip (it refuses a newer schema), so keep a copy of `churchlight.db` before upgrading.

## The Run page (Service tab)
Laid out like the Theme Library: Service order (40%) and Live (60%) side by side (`.board`, columns `2fr 3fr`, filling the window under the header (see "The Service board fits the window") and scrolling inside only when needed), and a tools panel (`.run-bottom`, `data-panel="tray"`, fixed along the bottom, `--run-bottom: 24vh`) with a tab strip: **Bible** (the verse tray) and **Announcements and timer** (the announcement form, the countdown and the speaker alert). `initRunPanel()` shows one pane at a time (`showRunPane`, `runPaneName` is pure and tested) and remembers the choice per browser (`churchlight.runpane`); the T and G keys switch to the Bible pane. There is no Screens list on this tab (the two Live previews replaced it) and no Keys paragraph (the Settings tab lists the keys); the typed "Add a Bible reference" form stays in the Service panel's "Add" fold. Panels are fixed: the old Arrange panels / fold / drag code (`initBoard`, `normalizeLayout`, `movePanel`, `COLLAPSIBLE`, `panelSummary` and the `churchlight.layout.v4` / `churchlight.collapsed` keys) was removed; old saved values in `localStorage` are simply never read. At 60rem or narrower it is one column: Live, then the tools panel (no longer fixed), then Service. The Live box holds two preview slots side by side (`LIVE_SLOTS` in operator.js: dropdowns `live-output` and `live-output-2`, frames `live-frame` and `live-frame-2`; slot 1 defaults to the first output, slot 2 to the second, "None" hides a slot; choices kept per browser in `churchlight.liveoutput` and `churchlight.liveoutput2`).

## The verse tray

`OperatorController` can hold one passage (a chapter or a verse range) as a `Tray`: `load_tray`, `clear_tray`,
`show_tray_verses(numbers)` and `tray_step(+1/-1)`. Showing builds slides with `SlideBuilder.build_passage`, which
sets `Slide.title_first`: the title is always "Book Chapter" and the output page draws each verse as "16) text". That
is a new public slide field (a decision recorded in `PUBLIC_SLIDE_FIELDS`); other verses keep their old look. Which
tray verses are on screen is derived from the overlay, never stored. The tray is not saved to the database. Ideas
left open: several passages in one tray, console commands.

Tray verses can be added to the open service (`add_tray_to_service`): side-by-side verses become one scripture
item, others separate items, each stored with the override `{"title_first": true}` so it keeps the tray's look
(typed references added to a service keep the old look). Adding never touches what is live. In the page, "Go to
verse" (`parseVerseJump`, pure and tested) only ticks and scrolls inside the tray; Enter is what shows the verses.

## Screens and previews (groundwork)

The operator state lists every configured output with its audience (`public` or `stage`) and page path. The
page draws a status chip per output and lets the operator switch a small live preview (a scaled frame of the
output's own page) on or off per output: off by default, at most three at once (browsers allow few connections
to one address), remembered per browser, and dropped while the window is hidden. Nothing in the page names a
particular output, so a second projector or an OBS feed needs only a settings entry. The operator page's policy
adds `frame-src 'self'`; output pages are unchanged.

## Threads and the operator page

The terminal, the operator web page and the output pages run on different threads. The database is opened with
`shared=True` and **every use of the controller goes through `controller.lock`** (the console does this in
`onecmd`, `OperatorApi` in every call). The output pages never touch the database: they read the live session
(which has its own lock) and preloaded theme styles. Operator requests are guarded: they must be addressed to
this computer (Host check), carry no foreign `Origin`, and POSTs need a JSON body and an `X-ChurchLight` header,
so another website cannot drive the program. Packaging must include `server/static/*`.

Imports upload files into `<media>/.uploads/<batch>/` (never served: the media route refuses any path part that
starts with a dot) and run one at a time on a background thread with **its own database connection**, so a long PDF
render never holds `controller.lock` and the live controls stay responsive. A throwaway `:memory:` database has no
second connection, so there the import takes the lock. Editing a song replaces its arrangements with the one order
shown in the text; deleting anything a service uses is refused (the database also enforces it with RESTRICT).

## Open decisions

- **`AGPL-3.0-or-later` vs `AGPL-3.0-only`:** the tool defaults to "or later"; confirm or change.
- **Layout table:** is `ppt_verse` right as public, and are lower/full placements right for XSplit? (The
  placements are a table at the top of `server/static/output.js`.)
- **Deck page paths** are stored relative to the media folder; absolute paths are not served.
- **Windows setup:** PDF import is one pip command (already bundled in the full download).

- **Other platforms (future, not started):** macOS (a Mac mini is a possible future machine, with OBS instead of XSplit) and, further out, iOS. For global shortcuts on a Mac: a second backend using Carbon `RegisterEventHotKey` through ctypes (no permission prompt; needs the main-thread event loop; Mac key table and Command key), written blind and tested on a real Mac. The cheaper cross-platform route is a trigger URL (for example `/hook/next`) that Stream Deck, Keyboard Maestro, BetterTouchTool or Shortcuts can call. iOS cannot run the program or claim global keys; the realistic route is the operator page opened in Safari on an iPhone/iPad (the page and a trigger URL already work from another device on the network), which would need touch-friendly controls and a phone layout. Check first that the whole program runs on a Mac (Python version, start script, fonts).

## Good first tasks for the team

1. Run the suite on Windows; run each importer against real files and report what breaks.
2. Import an OpenLP song export (OpenLyrics) and a real Bible file; compare slides with OpenLP's.
3. Point XSplit at `/view/<name>` for each layout and note what needs adjusting (sizes, positions).
4. PySide6 operator window: library left, service right, preview and live panels, over `OperatorController`.
5. Native projector window drawing the same payload as `/view/projector`.
6. OSIS / OpenSong Bible import; an OpenLP database importer; video playback.

## Near-finalization notes

- Test lid-close/sleep and reconnect behavior on the real operator PC, including whether the program survives sleep and how the page tells the operator it lost the connection (the page keeps retrying silently as "Reconnecting").
- Default Run layout is Service, Library, Verse tray on the left. Book typing uses prefix matching with the first book in Bible order winning (`reference_hint` drives the autofill line).
- **Bundled content:** the KJV is bundled and installs itself on a first run with no Bible (`content/`, `ensure_bundled_bible`, rebuilt with `tools/make_kjv.py` from eBible's `eng-kjv2006_vpl.xml`). Still to bundle for the inner circle: 10-25 public-domain hymns, a sample welcome deck, refined starter themes; keep `content/NOTICES.txt` (source and license of everything bundled) up to date for each addition.
- The Library tab is two columns: left "Add to the library" (slide decks, songs, Bible, in that order); right fixed containers Slide decks, Songs, Bibles that fold to a one-line summary (not movable; Bibles starts folded; saved under `churchlight.libraryfolds`).

## Song file formats

`importers/songs.py` reads OpenLyrics; `importers/songfiles.py` reads plain text (SongSelect style), ChordPro and OpenSong and picks a reader per file by name and first bytes (`parse_song_file`). All produce the same `ParsedSong`, so saving, duplicate skipping and reports are shared. Not supported: EasyWorship/ProPresenter/Proclaim files (proprietary), CCLI `.usr`, SongBeamer `.sng`, and any direct SongSelect database access (SongSelect has no open lyrics API for small apps as far as known; confirm with CCLI before promising it).

## Song editor window and drafts

The editor is a non-modal window (`#editor`, positioned by `placeEditor()` over the last board column on wide windows, full width at 960 px or narrower) so the operator can keep running the service while writing. It minimizes to `#editor-bar`; the typed text is kept in `localStorage` (`churchlight.songbuffer`) until saved or discarded. Space and arrow shortcuts are already ignored while typing. Drafts are `songs.is_draft` (migration 5): hidden from `search_library`, refused by `add_entry` and `go_live_entry`, listed in the library overview with `draft: true`; `publish_song` clears the flag and a song used in a service cannot be made a draft. **Migration 5 makes `churchlight.db` unreadable by older zips; back it up before upgrading.**

## Appearance

`static/look.js` (loaded in the operator page head, not on output pages) keeps the choice in `localStorage` (`churchlight.look`) and sets `data-theme` (resolved light/dark), `data-size`, `data-contrast` and `data-accent` on `<html>`. All colors in `operator.css` are variables defined in `:root` blocks of a fixed form; `tests/test_appearance.py` parses those blocks and checks WCAG contrast (4.5:1) for every theme x contrast x accent combination, so a new color or accent must be added there too. Slide previews stay dark in both themes. Layout spacing options were deliberately deferred.

## Fonts

Operator page only: Atkinson Hyperlegible Regular/Bold (text) and Bricolage Grotesque Bold (h1-h3), declared with `@font-face` in `operator.css` from `/static/fonts/` (served by `_font` in `server/app.py`: plain `.ttf`/`.woff2` names only; `font-src 'self'` is added to the operator CSP only). Missing files fall back to system fonts, so the program never depends on them. All three are SIL OFL 1.1, which allows bundling with the AGPL program as long as the license text accompanies the font files. Slide themes: 17 more OFL families (Open Sans, Lato, Source Sans 3, Roboto, Nunito, Atkinson Hyperlegible, Montserrat, Poppins, Oswald, Anton, Merriweather, Lora, Libre Baskerville, PT Serif, Playfair Display, Cinzel, Dancing Script) are bundled in the same folder, Regular and Bold, unmodified, with `OFL-*.txt`. `static/themefonts.css` (written by `tools/bundle_fonts.py`; linked from `output.html`; `PAGE_CSP` now has `font-src 'self'`) declares them, so output pages show them on any PC with nothing installed. `THEME_FONTS` in `themes.js` lists them first, then the old system fonts marked "(system font)". The starter themes still use system fonts; switching them is part of the theme refinement. `tests/test_theme_fonts.py` checks files, licenses, stylesheet, editor list, serving and glyph coverage (needs fontTools for the glyph check; skipped without it).

## Themes tab

A third tab builds themes. A theme is the existing `settings` JSON: `style` (font, size, colors, band, reference size) plus slide-splitting settings (`lines_per_slide`, `scripture_max_chars`, `scripture_split`), validated by `core/themes.py` (`validate_style`, `validate_build`). Migration 6 adds `app_settings(key, value)`; keys `default_theme` and `bible_theme` hold theme ids (a deleted theme simply stops being found). Starter themes (`STARTER_THEMES`) are added by `ensure_starter_themes` from `__main__` only when there are no themes at all.

Which theme wins: output override > item theme > Bible theme (verses, on projector-style outputs only: `BIBLE_THEME_LAYOUTS` in `core/outputs.py`, currently `projector` and `ppt_verse`) > service theme > none. A verse slide carries both `theme_id` (item or service theme) and `bible_theme_id`, and `build_payload` picks per output; the Bible theme's slide-length settings still split the verses for every output. New services start with the default theme. The Run tab only switches themes (service, per item); building happens on the Themes tab, where the Assignments section also holds the Bible theme (easy to move). The preview is the real output page loaded as `/view/<output>?sandbox&preview`; the operator page posts sample payloads to it with `postMessage` (same origin, parent only). Not built yet: pictures/GIF/video backgrounds, per-output theme picker in the page (the controller supports it but it is not saved to the outputs file), gradients, tweaks on the Run tab, import/export of themes.

## Timed slide advance for decks

Migration 7 adds `presentations.auto_seconds` (0 = manual, up to 600) and `end_action` (`stop`, `loop`, `blank`, `next_item`). A service item can override both through its existing `overrides` JSON (`auto_seconds`, `end_action`), set with `set_item_autoplay`; `core/autoplay.py` holds the rules (`check_autoplay`, `timing_for`, `next_step`) and builds no timers. Deck slides carry `auto_seconds`/`end_action` (listed as stage-only fields, so public outputs never receive them).

The controller owns the timer (`_rearm_timer`, one daemon `threading.Timer`). Every change to the live session restarts it, so a manual Next gives the new slide a full delay. It does not count while the screens are blanked, an overlay (verse) is showing, nothing is live, or the operator paused it (`set_timer_paused`, one global flag). Lock order: the timer callback takes the controller lock, then the session's; `_rearm_timer` takes only its own small lock, so it is safe to call from session listeners. Tests shrink `_timer_scale`. Not built: per-slide delays, a visible countdown, remembering the pause across restarts.

## Song editor: order box, CCLI, parts per service

The editor has the order as its own box (`order` in `song_save`/`song_check`); `song_for_editing` returns the words without an `Order:` line plus `order` and `ccli`. An empty order box keeps any `Order:` line typed into the words (older habit and old browser buffers), otherwise the box replaces it (`replace_order_line`). Part chips are built in the browser from the `[headings]` (`partNames`). The CCLI song number goes in the existing `songs.ccli_number` column (digits only, saved from the editor; imports may hold other text). The church's license number is `app_settings` key `church_ccli`, stored only. Song copyright text is untouched by editing. Nothing is shown on screen (that was the decision; a theme option could add it later).

A service item can skip parts of its song: `overrides` holds `parts_skip` (positions in the song's order) and `parts_of` (how long the order was). `skipped_parts` ignores the choice if the order's length has since changed or if it would skip everything. API: `item_parts` (the controller's `song_parts` feeds it; there is no `song_parts` API action); rows carry `parts: {total, used}`. Not built: reordering parts per service, named arrangements, showing credits on screen.

## Theme kinds (projector / overlay / confidence)
- A theme's `settings.kind` is projector (default), overlay or confidence. The kind is fixed after the first save.
- Resolution: output override > confidence layout uses the global confidence theme > overlay layouts use the slide's overlay theme > Bible theme for scripture on projector layouts > the slide's projector theme.
- Slides are shared by all outputs, so only projector and Bible themes affect slide splitting (lines per slide, Bible slide length).
- Overlay band is always on and capped at about 90% solid. Confidence text shrinks to fit and keeps showing while the projector is blanked.
- Migration 8 adds `overlay_theme_id` to services and items.

- Projector theme pictures: style keys `background_image` (only `backgrounds/<16 hex>.<ext>` in the media folder), `background_fit` (fill|fit), `background_dim` (0-80). Uploaded through the `background` import kind, then `background_import` moves it into `<media>/backgrounds/`; `_prune_backgrounds` removes unused ones after an hour. The band (`band: true`) now also draws behind text on full-screen text slides (a `.textband` wrapper); full-layer background color uses `background-color` so the picture can sit on top of it.

## Tabs
Service (view-run), Theme Library (view-themes), Song Library, Deck Library, Bible Library (view-songs/-decks/-bibles, class lib-view; each holds its own import block, status line and job list filtered by kind) and **Alerts Settings** (view-broadcast, the element ids kept: the countdown, scrolling bar and alert style editor, and nothing else: there is no Screens list on it or on the Service tab (the two Live previews replaced both), so the old status chips, per-output preview toggles and `describe_output` were removed. The browser-source addresses are on the server's root page `/` and in the start-up console output.

Service tab (view-run): a toolbar across the top, then Service order and Live, then the tools panel (Bible verse tray; Announcements and timer). The library search lives in the Service order box (Plan mode). Panels are fixed (no layout storage). Open per-item options are remembered in `openOptions` so redraws do not close them.

## Deck editor

*Wording: the operator page, messages and tests say **slideshow** where this document and the code say "deck" (`decks` tables, `deck_*` actions, `deck-list` ids are unchanged). Keep new user-facing text on "slideshow".*
Deck Library rows have "Edit deck", which opens `view-deckedit` (no tab; `VIEWS` includes it, `LIBRARY_VIEWS` does not; the Deck Library tab stays highlighted). Schema migration 9 adds `presentation_pages.skipped`; `SlideBuilder._presentation` leaves skipped pages out (labels keep the page number, so "Slide 3" can follow "Slide 1"). DB methods: `reorder_presentation_pages`, `delete_presentation_pages`, `duplicate_presentation_pages`, `set_presentation_pages_skipped`, `set_presentation_page_notes`, `presentation_service_titles`; pages keep their ids across reorders (numbers are rewritten in two steps because of the unique number). Controller: `deck_is_live`, `deck_for_editing`, `reorder_deck_pages`, `delete_deck_pages`, `duplicate_deck_pages`, `skip_deck_pages`, `set_deck_page_notes`; every change refuses with a message while the deck is live and then reloads what is loaded. API actions `deck_get`, `deck_pages_reorder|delete|duplicate|skip`, `deck_page_notes`. Rules kept in both the DB and the page: a deck keeps at least one page and one un-skipped page. Duplicated pages share the picture file, so image cleanup checks other pages first. Pure page helpers (`selectPages`, `movePages`, `dropPages`, `deckEditorState`, `usedText`) are exported for node tests. Planned: Stage B (add/replace pictures, add slides from another deck, split) and Stage C (per-slide delay and transition, migration 10). Thumbnails currently use the full page picture with lazy loading; add stored thumbnails only if big decks are slow.

Deck editor, stage B: upload kind `slidepics` (images only, 25 MB each; `ImportManager.take_pictures(batch, "decks/added", exactly_one)` validates every picture's first bytes before moving any, and sorts names naturally). DB: `add_presentation_pages(deck, [(path, notes)], after_page_id)`, `replace_presentation_page_image`. Controller: `add_deck_pictures`, `replace_deck_picture`, `add_deck_pages_from` (the source deck is read only, so it may be live), `split_deck` (new deck, source unchanged, allowed while live). API: `deck_pages_add`, `deck_page_replace`, `deck_pages_from`, `deck_split`. Copies and splits share picture files; `_remove_unused_images` checks other pages, and `importers.decks._finish` no longer wipes a `decks/<hash>` folder that a page still references (it picks a fresh folder instead). Page helpers `afterPageFor`, `splitName` are exported for node tests.

Deck editor, stage C: migration 10 adds nullable `presentation_pages.auto_seconds`, `transition`, `transition_ms` (NULL = follow the deck). `SlideBuilder._presentation` applies a page's own values over the service-item override over the deck's; the timer needed no change because it already reads `slide.auto_seconds` (0 on a slide = wait for Next). A page's transition kind and length are stored together (DB method refuses one without the other). `set_presentation_pages_timing` leaves an argument alone when it is left out and clears it when None. Controller `set_deck_pages_timing(deck, pages, seconds, transition, ms)` (locked while live); API `deck_pages_timing` changes only the keys present. `deck_for_editing` returns the deck's own timing as `deck` and each page's settings. Duplicate copies the settings; copy-from-deck and split do not. Page helpers `commonTiming`, `pageFlags`, `deckTimingText`.


Search suggestions: `OperatorController.suggest_library(text)` (names only; GET `/api/suggest?q=`): digits match the number a title or deck name starts with (`title_number`, zeros ignored, numeric order), then names starting with the text, then names with a word starting with it, then the rest of `search_library`; at most 8, drafts excluded; an empty text returns `RECENT_LIMIT` items from `DatabaseManager.recent_library_items` (most recent service use). Page: `attachSuggest(input, onPick)` wraps an input in `.suggest-box`, draws a fixed-position `ul.suggest` (role listbox), drops stale answers with a counter, handles arrows (`stepSuggestion`), Enter on a highlighted row, Esc and blur; used on `#finder-text` and `#search`. Picking a row adds it to the service (`addSuggested`). If song numbers become their own field later, extend the digit branch of `suggest_library` only.
Arrow keys: Up/Down (and Space, PageUp/PageDown) step slides (`next`/`previous`); Right/Left step service items (`next_item`/`previous_item` -> `OperatorController.step_item`: first item when nothing live, stay put at the ends, skip items with nothing to show).

Bible quick add: `tray_load` with `add: true` loads the reference and adds every verse to the open service in one step (adjacent verses become one item); UI is Ctrl/Shift+Enter in the tray box or the "Load + add to service" button.

Keyboard shortcuts (on the **Shortcuts** tab, `view-shortcuts`, with the global-key controls; page keys are ignored on that tab): `KEY_ACTIONS` in operator.js is the table of actions and default keys; `keyAction(key, ctx, keys)` is pure; choices live in localStorage `churchlight.keys` (`parseKeyChoices`, `assignKey`). Keys work on the Service and Broadcast tabs (the ones that need the Service tab's boxes are marked `where: "service"`). (OS-wide keys: see Global shortcuts below.)

Global shortcuts: `ui/globalkeys.py`. `GlobalKeys` (mapping saved in the `global_keys` setting; "on" is never saved, so every start is Off) claims only the mapped keys through a backend while armed and releases all on disarm/close. `WindowsBackend` uses ctypes `RegisterHotKey` on its own thread with a 20 ms message poll (MOD_NOREPEAT); other platforms have no backend and the page says so. Combos need Ctrl/Alt/Shift unless they are F keys. API: `global_keys_set`, `global_keys_arm`; state: `global_keys`. UNTESTED on real Windows: see TESTING.md 3.26. Not built: a trigger URL for XSplit/Stream Deck.

Verse overlay rule: the controller's `show_verse`, `show_tray_verses`, `reshow_verse` (the typed `show_verse` and `reshow_verse` are for the console and tests only; the operator page uses the verse tray and has no typed verse box, no V key) require the live base slide to be a deck's (`item_type == "presentation"`; `verse_over_ok` in the state); a session subscriber hides a showing overlay when the base stops being a deck. The Bible choice is the `default_translation` app setting (Library > Bibles > "Use for verses"); there is no Bible box on the Service tab.

Deck names: picture uploads are named from `plan["label"]` (the picture's stem, or "Slide pictures <date>"), never the batch folder. The deck editor has Rename (`deck_rename`).

## Screen shape

Only the projector and the confidence monitor have a shape (`SHAPE_LAYOUTS` in the controller; `hasScreenShape` on the page). Output pages fill whatever size their browser source has (text in vh/vw), so 4:3 projectors already work. The operator window draws previews in each output's shape: setting `screen_shapes` (JSON name -> "16:9" | "4:3" | "16:10", `screen_shape` / `set_screen_shape` in the controller, action `screen_shape_set`, `shape` in each output of the state). Previews lay the page out 1920 wide by `frameHeight(shape)` and scale it. Not done yet: custom sizes, and a warning when a slideshow image does not match the shape.

## Security notes (REMIND THE OWNER BEFORE THE SOFT LAUNCH)

Review these when the build is close to final. Today: the server listens on 127.0.0.1 only, `/api` answers only requests whose Host is this computer and whose Origin matches (stops a web page in the browser from driving it), a log warning appears if `--host` is anything but local, there is no login, and the page runs under a strict content policy.

Before the soft launch:
1. Opening it to the network (`--host 0.0.0.0`) lets anyone on that network run the operator page and read stage notes. Decide: keep it local, or add an access code for the operator page first. Never on a guest or congregation Wi-Fi.
2. Operator page has no password (fine locally). Consider an access code, needed before any phone/tablet use or a trigger URL (`/hook/next`), which would also need protecting.
3. Global hotkeys take keys system-wide while on (off by default); make sure the Shortcuts tab explains this.
4. Imports (songs, images, Bible files): only from trusted sources; keep size/type limits.
5. Streaming PC hygiene (write into a short "safe setup" page for volunteers): updates, a separate user account for volunteers, no church social-media logins in a shared browser, careful with USB sticks.
6. Back up `churchlight.db`; keep the backup somewhere safe.
7. No automatic updates: tell users how to update Python, Windows and the program.
Possible work: an access code for the operator page, a "safe setup" doc.

## Picture size

`presentations.image_fit` (migration 11: `fit` | `fill` | `stretch`, default `fit`) per slideshow, set on the Slideshow Library tab (`deck_image_fit`, `set_deck_image_fit`, `db.set_presentation_image_fit`). `Slide.image_fit` is a public slide field (`PUBLIC_SLIDE_FIELDS`, `slide_to_dict`); `output.js` adds `fit-<mode>` to the picture layer and `output.css` sizes the `<img>` to 100% x 100% with `object-fit` contain / cover / fill, so a small picture always scales up to the screen. Single media assets (not in a deck) are always `fit`. Not built: a program-wide default, a per-page setting, a blurred backdrop for the bands.

## Trigger URLs

`/hook/<secret>/<button>` (GET or POST) presses one of `operator_api.TRIGGERS` (next/previous slide and item, blank on/off/toggle, words hide/show/toggle, hide verse, take the ready verse). Nothing that changes the library or settings is in the list, so the same list is the starting point for the LAN remote's limited role (objective #1). The secret (`controller._hook`, setting `hook` = `{on, token}`) is 24 random bytes, urlsafe, kept in memory for the server threads, checked with `hmac.compare_digest`; **a new secret** kills old addresses at once. Defences: the same Host/Origin checks as the operator API (no rebinding, no cross-site), wrong secret / switched off / unknown button all answer 404, ten misses in a minute answer 429 to everyone for that minute (a slow-down that can also be used to lock the buttons out for a minute by anyone who can reach the port), HEAD answers 405 so link previews never press a button, and `log_message` redacts `/hook/<secret>` from the log. Security notes: the secret appears in `state.hook` for the operator page, so a future remote role must never be sent that field; the address travels in clear text over `--host`, so on a shared network it is no better than the network.

## Hide the words

`LiveSession.set_text_hidden/toggle_text_hidden` (`LiveState.text_hidden`), controller `toggle_text_hidden`, API action `text_hide` (`state.live.text_hidden`), key W, global key action `hide_text`, console `words`. `build_payload` sets `payload["text_hidden"]` for public layouts only (never confidence/stage) and not while blanked (blank wins). `output.js` `viewModel` drops text from each layer: a lower layer disappears, a full layer stays empty so its theme background (colour/picture) remains, pictures are untouched; `hasTextBand` is false for an empty layer. The flag persists across slide changes like Blank. Same slide key, so no transition plays when the words return.

## Overlay height cap

Overlay themes have `style.max_height` (0-60, percent of screen height, 0 = no limit). `output.js` gives the box `max-height` + `overflow: hidden` and `fitLayers` shrinks its text (after the frame is attached, since detached boxes cannot be measured) down to 60% of the theme size (`MIN_SHRINK`). Because every output shares the same built slides, `SlideBuilder._fit_overlay` lowers `scripture_max_chars` to `themes.overlay_char_capacity(style)`, an estimate of the characters that fit at the smallest size (16:9 frame, 0.5 em letters, 20% word-wrap slack). So the capped overlay forces the verse break for all outputs. The service's overlay theme (or the item's own) supplies the cap; a different overlay theme per slide is honoured at build time. Estimate is deliberately cautious; tune the constants in `overlay_char_capacity` against real fonts.

## Verses per slide
Default is one verse per slide. "Fit as many whole verses as will fit" (`scripture_split = "chars"`) in production runs uses `projector_char_capacity(style, aspect)` (core/themes.py, mirrored by `projectorLayout` in themes.js; a parity test keeps them equal) instead of a typed character count; tests that pass explicit `BuildSettings` keep the fixed limit. Precedence: item override > service (`services.verse_split`, migration 12) > theme > default. Rows carry `slides`, `note` and `slide_list` for the service list.

## Home screen

A picture the projector shows while the screens are blanked (between parts of the service) and, by default, while nothing is live (no service open, or before the first slide). Setting `home_screen` (JSON `{image, fit: "fit"|"fill", on, idle}`; `on` = when blanked, `idle` = when nothing is live, both default true), kept in memory by the controller (`home_screen`, `set_home_screen`, action `home_set`, `state.home`) because the web server reads it from its own threads. The picture is stored by the same upload as theme backgrounds (`background_import`, `<media>/backgrounds/`); `_prune_backgrounds` treats it as in use. `build_payload(..., home=)` adds `payload["home"]` only for the projector layout while blanked (`when_blank`) or while neither base nor overlay is live (`when_idle`); the page just draws whatever `home` it is sent; `output.js` draws it as `.home-pic`. The Blank button reads "Home screen (B)" / "Back to the service (B)" when a picture is set (`blankText`). Not built: a different picture per service part, or a home screen for other outputs.

## Settings tab

The old Shortcuts tab is now **Settings**: the home place for set-once, whole-program options. Its sections today: Screens (home screen picture, screen shape for the projector and confidence monitor), Keys for running the service, Keys that work in any program. The element ids still say `shortcuts` (`tab-shortcuts`, `view-shortcuts`) to keep the change small. On the Service tab's Timer panel the words input follows the projector choice (`syncCountdownInputs`): with the big clock it is **Words above it** (`#cd-label`, sent with each countdown start); with the scrolling bar it is **What the bar says** (`#cd-bar-text`; empty is allowed and means the bar says nothing, like the zero wording) and **When it reaches zero** (`#cd-zero-text`, `bar_zero_text`) (`#cd-bar-text`, the saved `bar_text` style with `{minutes}`, saved on Enter or blur through `timer_style_set`, so it is the same words as the Alerts Settings editor and a running countdown picks it up at its next pop-up). In the Deck Library each slideshow's picture size, transition and autoplay controls sit in a `.deck-settings` box (`display: contents`, so the layout is unchanged when open) behind a per-row **Show settings / Hide settings** button; folded is the default and the open ones are kept per browser (`churchlight.deckopen`, `parseDeckOpen`, `toggleDeckOpen`). The summary line (pages, uses, transition, autoplay) stays visible. The **Go** button of a service item (song, Bible or slideshow) is the first thing on its row (`.item-go`, before the title); the move, ⋯ and remove buttons stay together on the right. A slideshow item's ⋯ panel lists its slides like a song's parts do (`ServiceRow.deck_slides`: each slide's number in the whole service and its label, the title from the editor or "Slide N"; `deckSlideList`, `deckSlideView` in operator.js): a scrolling list, live slide marked, earlier ones faded, next outlined, each with a Go button that sends `go_slide`. No pictures are loaded, no migration, and nothing is added to exports (titles were already part of the slideshow). Skipped pages are not in the list. `start_churchlight.bat` relaunches itself once with `start /min` (the copy that runs gets the argument `min`), so the console that runs the program sits minimized on the taskbar; a start-up problem still ends in `pause` inside that window. Closing it, or the Shut down button, stops the program. A **Fold all / Open all** button beside the title (`#settings-fold-all`, `foldAllPlan` in operator.js: if any section is open it folds all, only an all-folded page opens all) works on every `details[data-settings-fold]`; every section name is in `SETTINGS_FOLDS` so each one's folded state is remembered (`clicker` and `shutdown` were missing before). The first section is **Shut down ChurchLight** (`#shutdown-btn`, press then "Sure?" via `confirmClick`): the `shutdown` API action calls `controller.request_shutdown()`, which sets `shutdown_requested` (a `threading.Event`); `__main__` waits on it (`_wait_until_stopped`, or `_exit_when_asked` for the typed console), pauses `SHUTDOWN_GRACE_SECONDS` so the page gets its answer, then the existing `finally` runs `controller.close()` (clicker helper, global keys, imports, servers). The page then shows a goodbye screen and stops polling (`shutDown`). It is not a trigger URL action, so a Stream Deck cannot press it. A hard kill of the process still skips the cleanup (see the open job-object idea). New global options go here, not on Alerts Settings, which only holds the countdown/bar/alert style.

## Export
`core/export.py` writes songs (OpenLyrics `.xml` or plain `.txt`; several in a `.zip`) and slideshow bundles (`slideshows.json` + `pictures/<n>/page-<n>.<ext>`, format `churchlight-slideshows` version 1). `GET /api/export?kind=songs|slideshows&ids=..|all=1&format=xml|txt` answers with a download (the snapshot is read under the controller lock; the zip is written outside it to a temp file that is deleted afterwards). `importers/bundle.py` reads a bundle as untrusted input (strict picture names, size caps, picture signature check, the same transition/autoplay validators); the Slideshows import accepts it as a single `.zip`. The plain-text song reader also understands `Author: ...` lines in the closing info block.

## Operator window place
The launcher opens `/operator?app=1`. A page with `?app=1` reports `window.screenX/Y/outerWidth/outerHeight` (every 2 s when changed, and on hide/close) through the quiet `window_place` action; the controller stores them as the `operator_window` setting after `launcher.clean_window` rejects minimized or sliver sizes. At the next start `launcher.app_command` adds `--window-position` and `--window-size`. A window left on a monitor that is later removed is moved on-screen by the browser. Mixed-DPI monitors can be a few pixels off.

## Text area (theme margins and the guide box)
Projector themes have `margin_top/bottom` (percent of the screen height, default 4) and `margin_left/right` (percent of the width, default 6), applied as the full-frame layer's CSS padding (`textMargins` in output.js). The pair sums are validated to leave at least 20% (`_check_margins`; a damaged stored style loses only its margins). `projector_char_capacity` and `projectorLayout` (themes.js) use them. The theme builder draws a guide over the preview from `guideRect` and `dragGuide` (pure, tested in tests/test_text_area.py); for overlay themes the preview page reports the real box height (`sandbox: measure`) so the guide matches the box.

## Song themes
`songs.theme_id` (migration 13, set NULL when the theme is deleted) is a song's own projector theme. Precedence for a song's look: the service item's own theme > the song's theme > the service's theme (the program's starting theme when no service is open) > none. `SlideBuilder._song_theme` applies it; `OperatorController._build` now passes the service's themes, so a library item sent straight live looks like the service's items. `song_save` takes `theme_id` (omit it to keep, null to clear; only a projector theme is accepted).

## Reference position
Theme style `reference_pos` (`auto` | `above` | `below`, default auto; offered on overlay themes). `layerView` in output.js turns it into `titleFirst` (a passage's title above, title size) or `refAbove` (a single verse's reference above, reference size, class `.ref.above`); auto follows the slide's `title_first`.

## Balance long lines
Theme style `balance_lines` (flag, default off; projector and overlay themes, "Songs" group). `drawBody` adds class `balance` (`text-wrap: balance`) to lyric lines only (`view.kind === "lyrics"`); Bible text and announcements never use it. It changes where a long line breaks, not the line count, so slide splitting and capacity estimates are unchanged. The page does the balancing itself (`balanceLine` in output.js: it finds the narrowest width that keeps the same number of wrapped lines, then writes real line breaks and `white-space: pre-line`), because the browser inside XSplit/OBS can lack `text-wrap: balance`; the CSS rule stays only as a fallback. Lines are measured again once fonts finish loading. `tests/test_balance_browser.py` runs it in headless Chromium when playwright is installed (skipped otherwise).

## Theme export and import
`core/export.py` (`theme_snapshot`, `write_themes_bundle`, `themes_file_name`) writes `themes.json` (format `churchlight-themes`, version 1: name, kind, style, build per theme, plus `picture` naming a file under `pictures/`) and the background pictures. "Export all" skips starters that still match their `STARTER_THEMES` entry (`is_unchanged_starter`); a theme chosen by number is always exported. Usage (defaults, services, songs) and ids are never written. `importers/themes.py` (`import_themes`) treats the file as untrusted: picture names must match `pictures/<n>.<ext>`, bytes must really be that image type, unknown or bad settings are dropped with a warning instead of failing the theme, an unknown kind skips the theme, same name and same look (picture bytes included) is skipped, same name with another look becomes "Name (2)". Imported themes are never made a default. The buttons are on the Settings page (a theme picker, "Export this theme", "Export all my themes", "Import themes…"). Route `GET /api/export?kind=themes&ids=..|all=1`; import is upload kind `themes` plus action `theme_import` (synchronous, under the controller lock; `OperatorController.import_themes`). `style_for_kind` and `theme_entry` live in `core/themes.py`.

## Settings sections
Each section of the Settings page is a `<details class="settings-fold" data-settings-fold="...">`; the closed ones are remembered in this browser (`churchlight.settingsfolds`, see `initSettingsFolds`, `SETTINGS_FOLDS`). A new section needs its key in `SETTINGS_FOLDS` (a test compares it with the page).

## PDF renderer for the final version
The renderer (pypdfium2: Apache-2.0 / BSD-3-Clause, no dependencies, one `py3-none-<platform>` wheel per platform holding PDFium) is not part of the source tree. `importers/pdfrender.py` appends `<program folder>/vendor` to `sys.path` (`use_vendor_folder`, after anything installed) before importing it, so a distribution only has to carry the unpacked wheel: `python tools/add_vendor_wheel.py pypdfium2-<ver>-py3-none-win_amd64.whl` (it refuses paths that escape the folder and keeps the wheel's license files). `pdf_status()` feeds the Settings "PDF import" section (`state.pdf`, looked up once per run) and `tools/selftest.py`. Keep the wheel's `*.dist-info` licence files in the download (AGPL-3.0 program, permissive component).
Bundled now: `vendor/` holds pypdfium2 5.14.0 for Windows x86-64 (`py3-none-win_amd64`, about 8 MB unpacked, `pypdfium2_raw/pdfium.dll` plus the licence files under `pypdfium2-5.14.0.dist-info/licenses`). It is not loadable on Linux (the program then reports the renderer as not set up and uses an installed copy or poppler). Other platforms (win32, win_arm64) would need their own wheels and a small selector; not done. Not yet run on a Windows PC from this folder.

## A song's parts and position
`Slide.part` (songs only) is the slide's position in the song's order, so a left-out part keeps its number. `OperatorController._song_outline` builds, per song item, every part (left-out ones too) with the slides it made and each slide's number in the whole service; `ServiceRow.outline` / `items[].outline` in the state. Only while a service is loaded (`mode == "service"`); a library song sent straight to live has none to follow. The page's `songOutlineControls` / `outlineView` (pure) draw the list in the item's ⋯ options: part tick boxes (`item_parts`), live / done / next marks from `state.live.index`, and a Go button per slide (`go_slide`). The live item's options open by themselves unless the operator chose otherwise (`optionsChoice`). The `song_parts` API stays for scripts but the page no longer calls it.

## A theme for a verse over a slideshow
Setting `verse_over_theme` (an Overlay-kind theme id, `OperatorController.set_verse_over_theme`, action `verse_over_theme`, `state.verse_over_theme`), cached in `ThemeStyles.verse_over_theme_id` because the web server reads it from its own threads. `build_payload(..., verse_over_theme_id=)` uses it for the *overlay layer* of the projector-style layouts (`BIBLE_THEME_LAYOUTS`) in place of the slide's Bible/projector theme; the base layer and every other layout are untouched. Verses built to go over a slide (`show_verse`, the tray) are fitted to that theme's box (`_build(..., over=True)`, tray's `build_passage`). The pickers are on the Bible Library tab ("How verses look") and the Themes tab ("Where themes are used"). Unset = the old behaviour. Verses already on screen are not re-split when the choice changes.

`planTransition` (output.js) animates only between slides of the same slideshow item: a change from another item (a song, a verse item, another slideshow) is a plain change, whatever the incoming deck's transition. Coming up from nothing (no previous slide) still animates.

## Hide the lower thirds
`LiveState.lower_hidden` (`LiveSession.set_lower_hidden` / `toggle_lower_hidden`, controller `toggle_lower_hidden`, action `lower_hide`, key `L` = `KEY_ACTIONS` `hide_lower`) is a third switch beside blank and hide-words. `build_payload` draws nothing for `OVERLAY_LAYOUTS` (lower_third, song_lower, verse_lower) while it is set and marks the payload `lower_hidden: true`; the projector, stage and confidence layouts and the blank/home logic never look at it. Operator previews (`peek`) still show the content. Not remembered across restarts. Not yet a trigger-URL or global key.

Key hints on the operator page are never typed into the HTML: `drawKeyHints()` (operator.js) writes the button texts, titles, placeholders, the banners from `keyChoices` (`keyHint`, `withHint`, `keysLine`, `blankText(blank, home, keyName)`), on every redraw and whenever a key changes. A test fails if a static button in operator.html names a single-letter key.

## OpenLyrics part names
Export (`core/export.py`, `_verse_names`) always writes a letter and a number (v1, c1, b1, p1, i1, e1, o1; the number is the label's own when it ends in one, else the next free for that type), because OpenLP does; each `<verse>` also carries `cl:label` (namespace `CHURCHLIGHT_NS`), the real part name, which other programs ignore. Import (`importers/songs.py`, `_label_for`) reads one-letter names with or without a number ("c", "v1", "v1a"), whole words ("verse1", "Chorus 2", "pre-chorus") and, when present, prefers `cl:label`. OpenLP's own type letters are the same as ours (v Verse, c Chorus, b Bridge, p Pre-Chorus, i Intro, e Ending, o Other). The text export is unchanged. Not verified against a real OpenLP install; the OpenLP sample in tests/test_export.py is written from OpenLP's documented format.

OpenLP splits a long verse into parts named `v1a`, `v1b` and then writes `<verseOrder>` with the whole name (`v1`). `parse_openlyrics` joins the parts of one verse into one section, a blank line between them (a blank line forces a slide break, so each part stays a slide), and maps both the whole name and the part names to it. If the order itself names single parts (`v1a`), they stay separate sections and a whole-name token expands to its parts. Two plain verses with the same name stay two sections ("Verse 1", "Verse 1 (2)").

A Bible item's slide list in the ⋯ options (`item.slide_list` with `item.slide_numbers`) has a Go button per slide that calls `go_slide` with the slide's number in the whole service, the same action a song's parts list uses.

Hide words (`LiveState.text_hidden`) now reaches the confidence monitor as well as the public screens (`build_payload` marks `text_hidden` for every layout except the stage pages); the monitor keeps its black screen, and Blank still leaves it showing as before. Settings, Screens has a switch for the confidence monitor: setting `confidence_hides_words` (default on; `"0"` turns it off), cached in the controller, passed to `build_payload(confidence_hides_words=...)` and to `OutputServer(confidence_words=...)`, API action `confidence_words_set`, state `confidence_hides_words`.

## Countdown and speaker alert
`LiveState.countdown` is `(end epoch seconds, label)` and `LiveState.message` is a text; both live in `LiveSession` (`start_countdown`, `stop_countdown`, `set_message`) and are independent of the slides, so loading, blanking and clearing never touch them. They are not saved. `build_payload` sends `countdown` ({end, now, label, linger}) to the layouts in `COUNTDOWN_LAYOUTS` (projector, confidence, stage, ppt_notes; never the lower-third layouts, which sit over the camera) and `message` only to `MESSAGE_LAYOUTS` (the speaker screens). `now` is the server's clock, so the page's own clock does not matter. `output.js` draws both outside `#root` (`syncOverlays`, called first in `render`), so slide transitions never redraw or blink the clock; a 250 ms timer updates it and removes it `linger` (5) seconds after zero. The controller's `start_countdown(at="HH:MM" | minutes=, label)` refuses a time that has passed and out-of-range minutes; `set_alert` collapses spaces and caps at 140. Operator actions: `countdown_start`, `countdown_stop`, `alert_set`; state carries `countdown` ({end, label, now, message}). Later ideas (auto-start at a set time before service, a speaker timer that counts the sermon, an alert on a timer) are in the private brainstorm notes.

## Slide titles (deck pages)
Migration 14 adds nullable `presentation_pages.title` (1 to 60 characters). `SlideBuilder._presentation` labels a slide with its title, else `Slide N` (N is the page number, so a skipped slide never renames the others). `set_presentation_page_title` collapses spaces; empty text clears it. Page entries (`add_presentation`, `add_presentation_pages`, `_entries_from`) are now `(path, notes, title)`; `_page_entry` still accepts a bare path or a `(path, notes)` pair. Duplicate, copy-from-deck and split carry the title; the export bundle writes `title` per page and `import_bundle` reads it (absent in older bundles = no title). Controller `set_deck_page_title` (locked while live), API `deck_page_title`, `deck_for_editing` pages carry `title`. Editor: `#de-slide-title` (saved on Enter or blur, like the notes) and a `.de-title` line on thumbnails.

## More slide transitions
`core/transitions.TRANSITIONS` now has 18 kinds (none, dissolve, circle_out, circle_in, slide_left/right/up/down, split_horizontal/vertical/diagonal_left/diagonal_right, wipe_left/right/up/down, fade_black, fade_white). Directions name where the movement goes: slide_left comes in from the right edge, wipe_left sweeps from the right edge; diagonal_left opens from a `\` line, diagonal_right from `/`. Migrations 4 and 10 hold a CHECK list of four names on `presentations.transition` and `presentation_pages.transition`; SQLite cannot alter a CHECK, so migration 15 is a function (`migrate()` now accepts a callable instead of SQL) that widens the stored table definitions with `PRAGMA writable_schema` and a `schema_version` bump (SQLite's documented way to loosen a constraint), checks that the old text is gone, and touches no rows. `output.js`: slide is a transform of the new frame; wipe and the split_horizontal/vertical kinds are `clip-path: inset()` growth of the new frame; the diagonal splits animate a four-corner `polygon()` that starts as a line; fade_black/white add a cover element above the frames (opacity 0, 1, 0) while the new frame is switched on at the midpoint under the solid cover (`transitionSteps` returns `{moves: "cover", color}`), and `render` removes the cover and the old frames when done (or after `ms + 600` if the window is not painting). The list in `operator.js` (`TRANSITION_CHOICES`) must match `TRANSITIONS`; a test checks it.

## The song report
Migration 16 adds `song_report` (section, service_id, service_title, service_date, position, song_id, title, author, copyright, ccli_number, reported_at): one running list, a section per service. The song details are copied in, so editing or deleting a song later does not change what was reported. `report_service_songs` (database) takes the service's `song` items in order (a song used twice once), and replaces the service's existing section (found by `service_id`) or starts the next section number, in one transaction; no songs raises ValueError and changes nothing. `service_id` has no foreign key (the list outlives the service) and `delete_service` clears it to NULL, so an SQLite-reused id can never overwrite an old section. Controller: `report_service`, `song_report` (sections and a plain-text version), `remove_report_section`; API: `report_service`, `report_list`, `report_remove`. Operator page: Report and Report list buttons in the service strip, with Copy section, Copy whole list and Remove (two clicks). Nothing is sent anywhere: CCLI accepts reports only by hand on its website, so the list is for copying from.

## Countdown and alert style
`core/timerstyle.py` holds the defaults, the rules and the sums that turn the settings into the `style` carried in the countdown payload (`projector_style`: mode, font, big-clock `box` rectangle and text, and the scrolling `bar`; `speaker_style`: the small corner timer) and `message_style` (`alert_style`). Boxes are `x, y, w, h` in percent of the screen (`check(changes, current)` refuses one that would leave the screen; `clean()` drops the first version's `position` look and puts a bad box back to its standard place); text sizes are percent of the box (clock, bar) or of the screen height (speaker timer, alert). The controller keeps the style in memory (server threads must not touch the DB) and saves it in the `countdown_style` setting; actions `timer_style_set` and `timer_style_reset`; `projector_mode` ("clock" or "bar") is chosen from the Service tab or the editor.
`output.js` draws it through the CSSOM outside `#root`: the clock as a rectangle (`fitCountdown` sizes the text from the box and shrinks it to fit), or the bar (`#cl-bar`): `barDue` decides when it pops up (at the start, then each whole minute left that is a multiple of `bar_every`, and once at zero; `barMessage` words the minutes), `playBar` fades it in and scrolls the words with the Web Animations API (the CSP forbids inline style sheets; speed is seconds to cross the screen width). It keeps working while the screens are blanked, like the clock. Stopping the countdown removes the bar at once; a countdown that ran out lets a bar still scrolling finish.
Alerts Settings (`operator.js`: `TIMER_GROUPS`, `dragRect`, `wireRectEditor`, `timerPreviewStyles`) has a collapsible projector editor (switch between the clock and the bar, a draggable/resizable box over a live preview iframe that loops a demo popup) and a collapsible stage/confidence section. A node test keeps `timerPreviewStyles` in step with the Python sums. No migration. The Service tab's bottom panel has two tabs, Bible and Announcements and timer (the old `timer` pane name maps to the combined one). The theme editor's text-area guide is always on.

## Song usage log
`core/usagelog.py` writes `song_usage.csv` beside the database, one row each time a song goes live, led by the CCLI number (a variation of OpenLP's usage export): CCLI number, date, time with microseconds, title, authors, copyright, "songs", "display", all quoted. The controller subscribes to the session (`_log_song_usage`): a row when the live slide is a song that differs from the last one logged; leaving it (another item, Clear) resets, so showing it again logs again. `set_usage_log(path)` is called by `__main__` only, so tests and the demo write nothing. `/api/export?kind=usage` downloads the file. A failed write is logged and never stops the service.

## Clicker helper
Settings tab, "Clicker helper (Windows)" (`operator.js`: `ahkKeyName`, `cleanClickerRows`, `buildClickerScript`, `wireClicker`). It makes an AutoHotkey v2 script in the browser (no server code): each chosen clicker key (captured from `event.code`) calls its Trigger URL (`/hook/<secret>/<action>`) with a synchronous WinHttp request and swallows the key (`$Key::`); if ChurchLight does not answer (or the secret is stale) the key is sent on as a normal key, so a closed ChurchLight never leaves the clicker dead. Ctrl+Alt+F12 suspends the script. Buttons are kept per browser in `churchlight.clicker`. The script holds the trigger secret: part of the pre-soft-launch security notes. It cannot tell the clicker from the keyboard (no driver-level tools by design). UNTESTED on real Windows: TESTING.md 3.85.

Trigger URL buttons `verse` (toggle), `verse_on` and `verse_off` work like the blank trio (`controller.toggle_verse/verse_on/verse_off`): on does nothing when a verse is already showing, otherwise brings back the verse just hidden (`reshow_verse`), otherwise shows the first verse of the tray; off does nothing when nothing is showing. The old `hide_verse` name is kept as a quiet alias of `verse_off` (`TRIGGER_ALIASES`; saved addresses and clicker buttons keep working, and it is not listed). Trigger URL buttons for a verse over a slideshow: `verse_forward` / `verse_back` (`controller.verse_forward/verse_back`). Forward shows the next part of the verse showing (`session.overlay_next`) and only when every part has shown moves to the next tray verse (`tray_step(1)`, first part); a verse not from the tray stops at its last part. Back mirrors it and lands on the last part of the previous verse. They answer 409 with the reason when nothing can move. Theme rule (tested in `VerseTriggerTests`): overlay layouts (`lower_third`, `song_lower`, `verse_lower`) always use the slide's overlay theme; only the projector-style layouts use `verse_over_theme` for a verse over a slideshow. The slide keeps the service's lower-third theme in `overlay_theme_id` (the verse-over theme is applied in `build_payload` only), and the verse is fitted to both boxes (`build_item`/`build_passage` take `verse_over_theme_id`, `_fit_verses` measures both). An overlay theme with the style flag `projector_hide` chosen as the verse-over theme makes `build_payload` drop the overlay layer on projector-style outputs (lower thirds still show the verse).

## Enter on an empty tray box
`operator.js` (`trayEnterEmpty`, `trayEnterRun`, `trayEnterStep`): with a chapter in the verse tray, Enter in the empty "Go to verse" box (`#tray-jump`; the book and chapter box only loads what is typed) adds the whole passage to the service (`tray_add` with every verse: one item), the next Enter shows its first verse (`tray_show`), a third says it is already showing. A chapter loaded with Ctrl+Enter counts as added. The state is per loaded chapter (`trayEnter`, client only) and the steps run through a promise queue so quick presses cannot repeat a step. Tested in `tests/test_tray_enter.py`.

**Service tab layout (Plan/Run, control strip, tools panel).** The Service tab's `#run-toolbar` spans both columns at the top of the board (Previous/Next, Blank, Hide words, Hide lower third, Clear verse, Clear live, and on the right `#live-title` with `#position`/`#mode`); the page header has `#chip-countdown` and `#chip-alert` (hidden unless a countdown runs / an alert shows; drawn from `tickCountdownStatus`/`drawCountdown`; clicking opens the Announcements and timer pane). The Service order box has a Plan/Run toggle (`#mode-plan`/`#mode-run`, localStorage `churchlight.runmode`): Run adds `run-mode` to the service column, which hides the library box, service settings and report panel; the "/" key returns to Plan. The tools panel (`#run-bottom`) has a drag/keyboard resize handle (`#rb-resize`) and a Fold button (`#rb-collapse`); its height is `--run-bottom` set on `.board` through CSSOM, kept in localStorage `churchlight.dock` as `{vh, folded}` (`clampDock` 12-60, default 24, `parseDock`, `parseRunMode`; all pure and node-tested). Choosing a tab or the T/G keys opens a folded panel. Nothing needed to jump (song outline Go buttons, Bible slide Go buttons, verse tray) is hidden by Run; `tests/test_service_layout.py` covers this in a real browser.

**Exports never replace the page.** Every export button calls `downloadFile(url)` (operator.js), which loads `/api/export?...` in a hidden frame; a refusal (JSON `{"error": ...}`) is read back and shown with `showMessage`, so the operator page stays. "Export all songs" and "Export all slideshows" are disabled while the library has none (`drawSongList`/`drawDeckList`). `tests/test_export_empty.py`.

**Report button and list placement.** The Service tab has only **Report** (`#report-btn`, a `confirmClick`: press, then "Sure?" in the same place), hidden in Run mode. **Report list** (`#report-list-btn`) and its panel (`#report-panel`, with the usage-log download) live on the Song Library tab, in the Songs section next to Export all songs.

**Bundled clicker helper.** `vendor/autohotkey/` holds the unchanged `AutoHotkey64.exe` from the official AutoHotkey 2.0.31 zip (GPLv2; `license.txt` and `NOTICE.txt` with the source link travel with it; it runs as a separate program, ChurchLight never links to it). `core/clickerhelper.py`: `clean_rows` (only `KEY_NAMES` keys and the Trigger URL action names from `TRIGGER_NAMES`, each key once, at most 24), `build_script(port, token, rows)` (refuses an unusable port, secret, key or action, so nothing a page sends can become script text) and `ClickerHelper` (Windows and the exe present = `available()`; `start` writes `ChurchLight-clicker.ahk` next to the database and runs it with no window, `stop` ends it and deletes the script, because it holds the secret). The controller owns it (`set_clicker_dir`, `clicker_view`, `start_clicker`, `stop_clicker`, `set_clicker_auto`, `auto_start_clicker` called from `__main__`, `_sync_clicker` from `set_hook`, so a new secret restarts it and turning Trigger URLs off stops it, `close()` stops it); the church's buttons and the "start with ChurchLight" choice are the setting `clicker`. API actions `clicker_start` (rows), `clicker_stop`, `clicker_auto_set`; `state.clicker` = {available, running, auto, rows}. The page's Clicker section (`drawClicker`) is redrawn when `state.clicker` changes (it is part of `drawHook`'s change key). The browser-built download script (`buildClickerScript`) stays as a fallback for a computer with its own AutoHotkey. The script also closes itself (`CheckAlive`, every 5 seconds; exits after 3 misses in a row of `GET /` on the program's port), so a helper started from the downloaded script or left over after a crash never outlives ChurchLight; `close()` stops the helper first. Never accept script text from a page. Run on a real Windows PC (zt211: closes with the program); not run on a real Windows PC yet (TESTING 3.93); tests use a fake process (`tests/test_clicker_bundled.py`).

**On/off buttons, no banners.** Blank (and Home screen), Hide words and Hide lower third show that they are on by `setToggle(button, on)` (class `toggle-on`, amber from `--warn`/`--warn-text`, plus `aria-pressed`); the Alerts Settings tab has no Blank button. The three full-width banners were removed; only the global-shortcuts banner remains.

**Clicker toolbar button.** `#btn-clicker` in the Service toolbar (hidden unless `state.clicker.available`) starts the helper (`clicker_start` with this browser's rows) or stops it, and shows `state.clicker.running` with `setToggle`. It is drawn by `drawClicker` with the rest of the clicker section.

**The Service board fits the window.** `.board` is `height: calc(100vh - var(--board-top))` with grid rows `auto 1fr`, so the page never scrolls; `fitBoard()` (operator.js) measures where the board starts (the header grows with a wrapped tab row, a message or a banner) and sets `--board-top`, called from `render`, `showMessage`, `showView` and on resize. The Service order and Live columns scroll inside themselves (`overflow: auto`). The one-column layout (under 60rem) keeps a normal scrolling page. `tests/test_service_layout.py` checks the page height at several sizes.

**Screen windows, the Test page and closing the program's browsers.** `ui/screenwindows.py` (`ScreenWindows`) opens a page full screen on a chosen monitor in an Edge/Chrome window with its own profile folder (`browser-profile/screen-<name>`), refuses the monitor the operator window is on, and closes any leftover browser using that screen's profile first (`launcher.close_browsers_using(profile, wait=0)`). The only user is the setup guide's Test (API `screen_show`/`screen_hide`, `controller.show_screen`): it opens `/view/<name>?kiosk=1&test=1`, and `output.js` draws the white TEST page for `?test` (nothing is fetched) and closes on Escape for `?kiosk`. There is no timed test and no real-screen kiosk any more (OBS puts the room screens on the monitors). On shut-down (`__main__`, the Shut down button, Ctrl+C or closing the window) `launcher.close_browsers_using(<browser-profile>)` lists processes with PowerShell (`list_processes`), keeps those whose command line has `--user-data-dir=<that folder>` (or a folder inside it; `processes_using_profile`, never another profile, never this program), asks them to close, then forces what is left after 3 seconds. Windows only; tests use fake process lists (`tests/test_close_browsers.py`).

## Video and sound (zt220)
- Library: `media_assets` rows with type `video` or `audio` (MP4 H.264, MP3, WAV), a `duration_ms` (migration 19; the operator page reads it from the file before uploading, because the server has no media library). Files live in `<media>/media/<random>.<ext>`; `ui/imports.py take_media` checks the first bytes; API actions `media_add/rename/delete`, listed under `manage.media`.
- Streaming: `/media/...` serves video/audio with HTTP Range (206/416) in 64 KB chunks (`server/app.py _stream_file`), so a big file never sits in memory. Page CSP has `media-src 'self'`; the operator page also allows `blob:` (reading a file's length).
- Playback state is kept as an anchor, not progress: `core/live.py` holds for the live clip (`LiveState.media`) and the music under the slides (`LiveState.sound`) `pos`, `at` (when it last changed), `playing`, `loop`, duration, plus shared volume/mute. Anyone can work out the position with `clip_position(view, now)`; `build_payload` adds the server clock `now`, and `output.js` does the same sum, so nothing polls. Pause/seek/restart/loop/volume/mute all re-anchor and send one payload.
- Only `PLAYER_LAYOUTS = {"projector"}` get `media`/`sound` in their payload. `plays_sound` is true only for the one output named by `controller.sound_output()` (the first projector-layout output); other projector pages play silently, and `?peek`/`?sandbox` pages show a label only. Blank hides a clip but not the music.
- A clip slide (`kind` video/audio, `Slide.duration_ms`) draws no layer; `output.js syncMedia` keeps a `<video>` (in `#cl-media`, behind the slides) and `<audio>` elements in three slots: the slide's video, a sound slide, the music. Elements are created once, steered by the payload (drift over 0.5 s while playing is corrected), and released when gone. If the browser blocks sound it plays muted and shows a click-to-enable hint (Test/kiosk windows start with `--autoplay-policy=no-user-gesture-required`).
- Moving on at the end: controller `_rearm_clip_timers` sets one timer per clip for its remaining time (+0.25 s grace, `CLIP_GRACE`); `_clip_fired` checks the anchor (`media_finished(at)`), and if `media_advance` (default ON, not saved) moves to the next slide. Looping clips and paused clips have no timer. Music has a timer too (marks it finished; nothing advances).
- Operator: Service tab "Playing now" / "Music under the slides" panel (only visible with a service open), the `clips` key of the state, `media_*`/`music_*` API actions, and trigger buttons `media_toggle`, `media_restart`, `music_toggle`.
- Not built: looping video backgrounds behind songs; setup-guide OBS sound setup ("Control audio via OBS"); saving the advance choice; a media-source mode for OBS/XSplit if the browser-source route proves poor.

## Media Library and slideshow media (zt221)
- The Media Library tab lists `media_assets` of every type (picture, video, sound); `ui/imports.py take_media` accepts pictures (checked by their first bytes, 25 MB each), MP4 and MP3/WAV. `manage.media` rows also say how many services and slideshows use each; delete is refused while used or on screen. `manage.media_sources` (read-only) lists pictures that came from elsewhere: each slideshow's own pictures, theme backgrounds, the home picture.
- Slideshow pages can point at a library file (`presentation_pages.media_id`, with `image_path` kept equal to the file so older code keeps working), carry `muted` (a video page without its own sound) and a `sound_id`/`sound_loop` (migration 20). `_remove_unused_images` never deletes a file the library owns. Replacing a page's picture clears `media_id`/`muted`. Export refuses a slideshow with a video page; a page's sound and mute are not exported.
- A video page is `Slide(kind="video", item_type="presentation")` with `duration_ms`, `muted`, and `sound_*` fields; it plays like a clip (`state.media`, with `silent` for muted), and the deck delay timer ignores it: the clip timer moves on when it ends (if `media_advance`).
- A page's sound is its own anchored clip in `core/live.py` (`_page`, started by `_sync_play` when the slide becomes live, dropped when it leaves; `LiveState.page_sound`, payload `page_sound` for the projector, `plays_sound` for the one sound screen). It shares the clip volume and mute. Controller `page_sound_control`, API `page_sound_*`, and a third clip timer slot (`page`).
- Operator: `view-media` (Media Library), deck editor "Add from Media Library…" panel (`de-library`), "Sound" section in the side panel, and the "Sound with this slide" block on the Service page.

## Setup guide steps 5 and 6 (zt222)
- `wizard.js`: the content step has `wizardAddRow` (file picker, status line, job line fed by `wizardJobsChanged`, called from `drawJobs`) using `importFiles(kind, files, extra, statusNode)` and `importMedia(files, statusNode)`; the extras step has small versions of the Settings controls (look, default themes, home picture via `chooseHome`, clicker with the usual buttons, trigger URLs with Copy). Nothing in the guide calls `showView`, so the guide stays open.

## Sound plays from ChurchLight's own window (zt223)
- The operator page keeps a hidden iframe of the sound screen (`/view/<sound_output>?hear=1`, `syncHearFrame` in operator.js, class `hear-frame`, setting `hear-on` in Settings → Sound, localStorage `churchlight-hear`, default on). `output.js` `pageMaySound`: a page makes sound if it has `?hear`, or if it is not a `?kiosk` window and not inside OBS (`window.obsstudio`), unless the address has `?sound=obs`. So an OBS browser source and the full-screen test window are silent, and nothing plays twice; OBS gets the sound as "Desktop Audio". `obssetup` does NOT tick "Control audio via OBS".
- `launcher.app_command` passes `--autoplay-policy=no-user-gesture-required`.

## Setup guide step 6 redraws on state changes (zt224)
- The page learns the result of an action a moment after the call returns (long-poll), so redrawing the guide right after `act()` used stale state. `wizardStateChanged()` (wizard.js, called from the main draw in operator.js) redraws step 6 when `wizardExtrasKey()` (home image, trigger on/secret, clicker running/auto) differs from what was drawn.

## Several PDFs in one go (zt225)
- `importFiles` (operator.js): when every chosen file is a PDF and there are several, each is imported in its own batch (`importBatch`) named after its file; the server's import plan still takes one PDF or a set of pictures per batch.

## Search bar finds Media Library files (zt226)
- `OperatorController.search_library(text, kinds, media_type)` also returns `LibraryEntry("media", id, name, detail, media_type)` when "media" is in `kinds`; `suggest_library(kind=...)` accepts `image|video|audio` as well as `song|presentation`. API `library()` default is songs, slideshows and media; `/api/library?kind=` and `/api/suggest?kind=` take the same filter words. The page's `search-kind` menu (operator.html) has Pictures, Videos, Sound; `entryBadge` names each result. Recent names (empty box) still list songs and slideshows only.

## One player only; no re-seeking while stalled (zt227)
- From a recording of a long video heard "on top of itself": the audio held a steady ~94 ms repeat, i.e. two copies (the hidden `?hear` frame plus XSplit's own web-page source, which is not OBS so `window.obsstudio` was not there to silence it). Now `output.js` `pageMaySound` is true only for `?hear` or `?sound=on|obs|1|yes`; every other page is muted. `inObs` is gone.
- The operator page takes a Web Lock (`churchlight-hear`) before it makes the hidden frame, so a second operator window or tab in the same browser stays quiet (`takeHearLock`/`dropHearLock`).
- `driveClip` jumps to the clip's clock at most once every 2 s and not while `seeking` or buffering (`readyState < 3`), with a retry timer, so a long file that is still loading is not re-seeked repeatedly.

## Uploads one at a time (zt228)
- Reported: the program froze after uploading a couple of videos in quick succession. Not reproduced; the likely cause is the browser's limit of six connections per host: the operator page already holds the state long-poll, a preview per screen and the hidden sound frame, so two uploads at once (plus a media stream) leave no connection for the page's own calls until a long-poll times out (20 s). `importMedia`/`importFiles` now go through `inImportQueue` (one import at a time).

## Rejected play() handling (zt229)
- `driveClip`'s catch was inverted: a silent clip whose play() was turned away (still loading, interrupted) set `soundBlocked` and put up "Click this page once…" on a page that never makes sound, and the clip stayed paused (first play with sound but no picture). Now: an unmuted clip rejected with `NotAllowedError` → play silently and show the notice once; a silent clip rejected for any reason → `retryClip` (up to 10 tries, 0.4 s·n apart); `loadeddata` also re-drives; `waiting`/`stalled` set a status line (visible on the stage page or with `?debug`).

## Playback changes after the zt229 test (zt230)
- Reported: video lags then freezes (sound fine) after quick start/clear/start; scrubbing quickly unsyncs the sound. Changes: the sound frame (`?hear`) plays a video's sound with an `<audio>` element (no second picture to decode); a page keeps one reusable `<video>` (`spareVideo`, released after 10 s idle) instead of making and breaking one per clip; an operator's play/seek/restart (a new anchor `pos|at|playing|loop`) is applied at once, while automatic drift correction keeps its 2 s guard (4 s and a 1 s tolerance for a silent picture, `DRIFT_PICTURE`); `?debug` shows a per-clip line (`showClipDebug`) with frame counts from `getVideoPlaybackQuality`. Not reproduced on the real PC: the headless test cycles 25 quick start/clears and quick seeks cleanly with a VP9 video.
- Messages from `showMessage` are drawn inside the setup guide (`#wizard-message`) while it is open.

## H.265 videos refused (zt231)
- The video that broke playback (`green-rays.mp4`) was 1080p H.265 (HEVC, `hvc1`): Edge needs the Windows HEVC extension or hardware support, and the web engines in XSplit and OBS generally cannot decode it, so the picture lagged, froze or stayed black while the sound played. `ui/imports.py mp4_uses_h265` finds `hvc1/hev1/dvh1/dvhe` in the MP4's `moov` box (anywhere in the file); `take_media` refuses such a file with a plain message pointing to HandBrake. Files added by earlier builds are not re-checked.

## Bad-file protection and the operator's way out (zt232)
- `core/mediacheck.py` reads only the MP4 movie header (`moov`, wherever it sits): per track the handler (`vide`/`soun`), the `stsd` sample entry, `avcC` profile, size and frame rate. `check_video(path)` returns `(problem, warnings)`. Refused: H.265, AV1, ProRes, MJPEG, MPEG-4 part 2, H.263 (unknown video codecs), H.264 with profile 110/122/244 (10-bit/4:2:2/4:4:4), sound that is not AAC/Opus/FLAC/MP3 (AC-3, DTS...), and a file with sound but no picture. VP8/VP9 are accepted. A file whose header cannot be understood is let through (never turn away a good file). Warned (accepted): larger than 1080p, over 30 fps. Every refusal carries the same fix text (HandBrake, "Fast 1080p30", Format MP4).
- `ImportManager.take_media` calls it; `media_warnings` holds the last result; `media_add` returns `{"id", "warning"}` and the page shows the warning with `showMessage` (inside the guide when it is open). `ui/imports.mp4_uses_h265` stays for its tests.
- Runtime guard for files already in the library: an output page reports a live video that raised a media `error` or stayed below `readyState` 2 for 10 s while it should be playing, once per file, with `POST /api/do {"action": "clip_problem", "args": {"src", "output"}}` (no new route; the output CSP already allows `connect-src 'self'`). `controller.report_clip_problem` records it only if `src` is the live media; `media_view()["problem"]` carries the sentence while that file stays live; the Run page shows it in `#clip-problem` in the Playing now box. Clearing or changing the live media removes it.
- Help in the program: `<details id="media-help">` "How to prepare a video…" at the top of the Media Library tab; wizard media row help points to it.
- Tests: `tests/test_mediacheck.py` (synthetic MP4 headers), `tests/test_media_problem_browser.py` (screen error → operator banner → cleared; help present), `tests/test_h265.py` fixture got an `hdlr` box.

## Long videos (zt233)
- `MAX_FILE_BYTES["media"]` and `MAX_BATCH_BYTES` are 8 GB; the page's `IMPORT_LIMITS.media.max` matches (`8192 * MB`, checked by test_operator_page); the page shows limits as GB/MB (`sizeText`). Uploads were already streamed to disk in 1 MB pieces and playback uses HTTP Range, so size does not change memory use.
- `ImportManager._check_room` refuses a file when `length + KEEP_FREE_BYTES (512 MB)` exceeds the disk's free space, before writing, with a plain message (sizes in GB).
- `uploadOne` now uses XMLHttpRequest so a Media Library upload shows "Uploading X… NN%". Other uploads behave as before. A cancelled upload is still deleted by the "stopped early" path in `save_upload`.
- Not done: backups with large video libraries (check whether backups copy media), a very-high-bitrate warning.

## Library flags (zt234)
- `controller.media_list()` adds `flag` ({"level": "warning"|"problem", "text"}) to a video row when `check_video` finds something; the answer is cached by (path, size, mtime), so the list stays quick and a file replaced later is checked again. The Media Library row shows a tag ("⚠ May stutter" / "⚠ Will not play well") and the text under the name (`.media-flag`, `.media-flag-text`). This also covers old files already in a library from before the intake checks.
- Tests: `LibraryFlagTests` in tests/test_mediacheck.py, a browser test in tests/test_media_problem_browser.py.

## Seeking in a long video froze playback (zt235)
- Cause found by reproduction (a 5-minute VP9 file with a keyframe only every 60 s, operator page + both preview frames + hidden sound frame + a projector page in one Chromium): a browser allows six connections to one address. The operator page holds the state long-poll, two preview long-polls, the sound frame's own long-poll and the sound frame's file stream; the projector page holds its own two. A seek needs a new file request (and the Seek button a POST), so with seven or more wanted it waited for a free one and the projector never even heard about the jump (it stayed at its old position for 12-20 s). With the sound frame switched off, all seeks recovered in under about 2 s.
- Fix: `hearAddress()` in operator.js puts the hidden sound frame on the other loopback name (`localhost` <-> `127.0.0.1`), which the browser counts as a separate address with six connections of its own. Any other host (LAN address) is left as before. `OPERATOR_CSP` frame-src now also allows `http://localhost:*` and `http://127.0.0.1:*`.
- Known edge: Web Locks are per origin, so two operator windows opened on different loopback names would both hold the sound lock. The launcher always opens one name.
- Tests: tests/test_hear.py (frame is on the other name; sound still plays under default autoplay rules after a click). Repro scripts (not shipped): scratchpad/scrub_repro.py, scrub_repro2.py with scratchpad/scrub/longgop.mp4.

## Video details and heavy-video warning (zt236)
- `mediacheck.describe_video(path, seconds)` gives "1920×1080 · 30 fps · H.264 · 8 Mbit/s"; `media_list()` returns it as `spec`, shown in the library row's detail line. `check_video(path, seconds)` now also warns above `HIGH_MBPS` (20 Mbit/s, average from file size / length); `take_media(batch, seconds)` passes the length read by the page.
- Memory check: streaming about 1 GB (12 full reads of an 80 MB file, 3 at once) grew the program by 7 MB, so ChurchLight's own server is not the memory problem on a long video; the load is in the browser/XSplit decoding.

## Service edits keep the playing video; gentler song import (zt237)
- Bug: `_reload_preserving_live` did `session.load` then `go_to`, so the live clip's anchor (`_play`) was reset and a video restarted whenever an item was added, moved or removed. Now `LiveSession.reload(slides, pick)` replaces the list and picks the slide in one step and `_carry_playback` keeps `_play`/`_page` when the live slide is still the same item and file (the key is (index, item id, file), only the index may change). Tests: tests/test_reload_keeps_video.py (fail without the fix).
- Song-import lag: could not be reproduced here (4,000 songs in about 13 s, no playback stall, server answers in under 0.7 s, in Chromium on 2 cores), but the import used a whole core for those seconds, which matches the 5-15 s seen on the church PC beside XSplit with a heavy video. `import_openlyrics(..., pause=)` rests after each song; the program's import passes `SONG_PAUSE = 0.004`. Batches are at most 500 files, so a bigger import runs as several jobs one after another.
- Not done: decks (PDF rendering) and Bible imports are also CPU-heavy and are not throttled; a lower priority for the import thread was not tried (the GIL makes that risky).

## False "could not play" box after a jump (zt238)
- The 10 s "stuck" watchdog in output.js treated a good video waiting to catch up after a seek as a bad file. Now a video that has ever reached readyState 2 (`held.hasPlayed`) is never reported by the watchdog, the watchdog waits 20 s, and the media `error` event reports only codes 3 (decode) and 4 (not supported).
- `report_clip_problem` re-checks the live file with `check_video`: a real format problem keeps the "wrong format" text; a file that looks fine gets "had trouble playing ... computer may be too busy or the video too heavy".
- Still open: after a jump the XSplit projector took over 10 s to show a picture on a 20-minute video. That is slow decoding or a slow seek in that browser (likely a heavy file); needs the file's details line and XSplit's CPU from the church PC.

## ChurchLight's own projector windows (zt239)
- Reason: the video freeze happens only in XSplit's embedded browser. Edge decodes it fine, so ChurchLight now opens the screens itself in Edge/Chrome kiosk windows (the `ScreenWindows` code the setup guide's Test already used).
- Saved in the `screens` setting: `{"assign": {output name: monitor index}, "auto": bool}`. `controller.screens_view/set_screens/open_screens/close_screens/auto_open_screens`; `show_screen(..., test=False)` opens `/view/<name>?kiosk=1` (no `test=1`). API: `screens_get`, `screens_set`, `screens_open`, `screens_close`. UI: Settings fold "Projector windows" (`initProjectorWindows` in operator.js).
- Opening at start waits 3 s and skips the monitor where the operator window was last seen. A screen on the operator's current monitor is refused with a plain message; the others still open.
- Kiosk windows stay silent (only the operator's hear frame makes sound). Esc closes a kiosk window; `close_all` runs at shutdown.
- Streaming: capture the window or display in OBS/XSplit (not a browser source) when video must go to the stream. Not verified on real Windows hardware yet.

## Screens are ChurchLight's own windows; OBS captures them (zt241)
- Pivot: the broadcaster no longer shows the room screens. Step 3 of the guide calls `screen_assign {name, monitor|null, operator_at}`: it saves `screens.assign` and opens the real kiosk window at once (refused on the operator's monitor; nothing saved then). `auto` is on unless turned off, so `auto_open_screens` opens them at every start (`__main__`). No Test/Stop button, Esc no longer closes a kiosk window; `close_all` still runs at shutdown.
- `controller.screen_positions()` gives each assigned screen's monitor corner; `obsctl.setup` passes it to `obssetup.build_scenes(..., positions)`. Only the livestream scene keeps a browser source (the lower third). Projector/stage/confidence scenes get a display capture ("ChurchLight <output> screen", kind `monitor_capture`/`display_capture`), the monitor chosen by matching "@ x,y" in OBS's `monitor_id` list, bounds-fitted to the canvas. A screen with no monitor is skipped with a report line.
- The wizard's OBS projector section and the OBS auto-project at start are no longer used (the `obs_project`/`obs_auto_set` actions remain, unused by the UI).
- Not verified on real Windows/OBS: window kiosk placement, the `monitor_id` text OBS gives ("Display 2: 1920x1080 @ 1920,0" is what OBS 30 prints), the capture of an Edge window by OBS.

## Screen windows reopen and hide from the taskbar (zt243)
- `ScreenWindows` remembers `_wanted` (url, monitor, operator_at) for each window shown; `hide`/`close_all` forget it. `reopen_missing()` reopens any wanted window whose process ended (at most 5 times a minute per screen); `start_watching()` runs it every 2 s from `__main__` (not in tests).
- `ui/winhide.py` (Windows only, ctypes, quiet on failure): after a window starts, finds the browser's `Chrome_WidgetWin_1` window among the process and its children, sets WS_EX_TOOLWINDOW (clears WS_EX_APPWINDOW), hide/show so Windows re-reads it. Unverified on real Windows.

## Self-restart when frozen; lock-free shutdown (zt247)
- `ui/watchdog.py`: a thread probes `GET /api/state` (needs the controller lock, so a deadlocked program does not answer) every 3 s; 5 silent checks in a row after the first answer → `_restart_now` (tries `controller.close()` for 5 s, then `spawn_restart`: a new `python -c` runs the module after a 3 s pause, without `--open`, `CHURCHLIGHT_RESTARTS` counts restarts, max 5 in a row, then `os._exit(3)`).
- `OperatorApi.call("shutdown")` no longer takes `c.lock`; `_close_within(controller)` waits at most 5 s for `controller.close()` so shutdown cannot hang.
- No Restart button (the owner did not want one).

## Deadlock between listeners and long-poll waiters (zt250)
- Found from the zt248 thread dump: `LiveSession.go_to_item` (and toggle_blank / toggle_text_hidden / toggle_lower_hidden) called `_apply` while holding the session lock, so listeners ran with it held. The web server's listener (`_on_change`) waits for `app._changed`; a long-poll thread inside `wait_for_change` held `app._changed` while reading `session.version` (needs the session lock). ABBA: the whole server stopped; controller.close() hung behind it.
- Fix: no public changing method calls another one under the lock (toggles pass None to `set_*`; `go_to_item` finds the index under the lock, calls `go_to` after). `OutputServer.wait_for_change` never asks for the session lock while holding `_changed` (uses a `_ticks` counter).
- Tests: tests/test_no_deadlock.py (another thread must be able to take the session lock inside a listener; a long-poll + clicks stress run). Scratch repro: scratchpad/deadlock_repro.py hung before the fix.

## Setup guide revisions (zt255)
Window fixed at `min(44rem, 92vh)` high; `#wizard-back[hidden]`/`#wizard-skip[hidden]` keep their place (`visibility: hidden`), `#wizard-next` has a minimum width. The "why" line is its own `#wizard-why` element under the title. Step 3 scene labels carry Recommended/Optional; step 3's OBS wording is gone. Step 4 (`obs`) explains what the broadcast software needs, shows only the lower-third address (`LOWER_THIRD_LAYOUTS`), notes the tested XSplit video issue and the XSplit monitor-number mismatch, then the automatic OBS setup; other addresses are in `details.wizard-manual`. `wizardObs.skip` ("I don't livestream") skips step 4 going forward only. `wizardObs.remember` defaults to false. The Home picture box is at the top of `content`; the practice-service button is in `done`.

## One monitor per screen, earlier-install imports (zt256)
`OperatorController._refuse_shared_monitor` runs in `set_screens` and, before any window opens, in `assign_screen`; `open_screens` skips a second screen on an already-used monitor and reports it (an older saved setup). Messages name both screens in plain words ("The projector is already on Monitor 2, ..."). Wizard step 5 (`content`) ends with `details.wizard-earlier`: a slideshow-bundle row (kind "bundle", imports with `importFiles("deck", ...)`; `wizardDeckFrom` decides which slideshow row shows the job line) and a themes row (`wizardImportThemes`, the Theme Library's upload + `theme_import`). The intro says the KJV is bundled.

## Settings groups, fold help, own accent (zt257)
Settings: an "Everyday" heading, four folds, then one `details[data-settings-fold=advanced]` fold holding pdf, triggers, clicker, keys, anykeys (`SETTINGS_FOLDS` now lists "advanced"). `initSettingsHelp` (operator.js) wraps each fold's `<h3>` in `.fold-head` with a caption and a `.fold-why` sentence behind a `.fold-help` "?" button (texts in `SETTINGS_HELP`); the "?" never toggles the fold, Esc hides open sentences. The summary is a full-width bar (`.settings-fold > summary`) with a chevron on the right (`::after`). look.js: `accent` may be "#rrggbb"; `fitAccent(hex, theme)` nudges lightness until the accent is readable as text on the panels and as a button background (dark: luminance 0.30 to 0.60, light: 0.04 to 0.15; text #06121f or #ffffff; hover a little lighter or darker) and `apply()` sets `--accent`, `--accent-text`, `--accent-hover` inline, removing them when a preset is chosen; `data-accent` is "custom".

## Plain words, sticky messages, Saved ✓ (zt258)

- `showMessage` (problems and warnings) now stays until cleared with its ✕ button or replaced by a newer message; `showNotice` (ordinary "Added…" notices) still fades (8 s, 12 s in the setup guide). `showMessage("")` clears only a notice. `act()` success no longer wipes a standing error.
- Message markup: `#message` / `#wizard-message` each hold a `.message-text` span and a `.message-clear` button wired by `wireMessageClear()`.
- `SAVED_ACTIONS` (operator.js) is the allow-list of edit actions that flash "Saved ✓" in `#connection` for 2 s; `setConnection()` / `connectionDown` make red connection states override it.
- ~21 plain-word replacements (log kept outside the tree); "Overlay" deliberately unchanged.
- Destructive-action confirmations are NOT in this revision (planned zt259 after owner reviews the list).

## Ready check, empty lists, confirmations, Undo (zt259)

- Service tab empty state (`#landing`): `#ready` panel. `setup.ready_checks()` returns the server-side rows (screens, windows, Bible, backup; remote links and clicker only when turned on); the page adds the connection row and checks OBS itself with `obs_connect` (it takes a moment). Fix buttons: `goSettings(fold)`, Bible tab, `backup_now`, `wizardShow(obs step)`. Runs once when the empty state appears and on "Check again"; read-only.
- "I don't livestream" is saved as setting `no_livestream` (`setup_no_livestream` action, `state.setup.no_livestream`); `wizardShow` ticks the box from it; the OBS row is left out when set.
- `confirmClick(button, action, message, yes)`: with a message (string or function) the first press shows it as a notice and the button reads "Yes, delete"/`yes`; without one it is the old "Sure?". Used for songs, drafts, slideshows, Bibles, media, themes, slide deletion, editor discard, shut down.
- Undo: `showNotice(text, undoFn)` adds an Undo button (10 s). `remove_item` keeps one snapshot (`_undo_item`; `undo_remove` restores it at its position via `db.restore_service_item`); report sections likewise (`_undo_report`, `undo_report_remove`). Report Remove no longer asks "Sure?".
- Friendly empty-list sentences for the song, slideshow, Bible, media and earlier-service lists; PDF tip on the slideshow page.

## Monitor layout memory (zt260)

- Setting `screen_layout` (JSON list of {index, x, y, width, height}) is saved by `Controller.save_layout()` whenever `open_screens` opens everything without a problem, and by the `layout_accept` action ("This layout is correct").
- `Controller.layout_changes()` compares it with the monitors now (count, size, position) and returns plain sentences; `setup.ready_checks` shows them as a "layout" row on the empty Service tab, or a tick when the same. Alert only: nothing is moved automatically.

## Import lists, stage timer look, folded ready check (zt261)

- Setup guide import rows: `wizardJobsChanged()` sorts `state.imports` by id (the server lists newest first) and draws one `<li>` per job in `#wizard-job-<kind>`, numbered when there is more than one; slideshow jobs are given to the row ("deck" or "bundle") in use when the job first appeared (`wizardJobRow`). Rows with no job (themes, media) append finished lines to `#wizard-log-<kind>` through `status.logLine`.
- `core/timerstyle.py`: new fields `speaker_font`, `speaker_color`, `speaker_ended_color`. `clean()` copies the projector's font/colors into them when a saved style lacks them (old data keeps looking the same); after that they are independent. `speaker_style()` uses them. Settings: three new rows in the stage group plus "Copy the projector's font and colors here" (`#ts-copy-stage`). The alert bar still shares the projector font.
- The empty Service tab's `#ready` is a `<details class="settings-fold ready-fold">`, always folded when the tab shows; `readyHeadline()` writes the bar line and sets `ready-good` / `ready-todo` / `ready-checking`.

## Fixes after reviewing zt261 (zt262)

- `open_screens()` now saves the monitor layout only when none is saved or it is unchanged; before, the screens opening by themselves at start would have overwritten a changed layout before the operator saw the warning.
- `showNotice(text, undo, force)`: an ordinary notice is dropped while a problem is showing; Undo notices and confirmation questions (`force`) still show.
- The OBS row of the ready check includes OBS's own error text.


## Folded settings, slideshow filter, slides guide (zt263)

- Settings and Alerts Settings fold on entry: `showView` calls `foldOnEntry(name)` when the view changes; `initSettingsFolds` no longer reads or writes localStorage (`churchlight.settingsfolds` is gone). `goSettings` and `cd-look` open their target after `showView`, so they open only that fold. `#ts-proj`/`#ts-speak` no longer have `open` in the HTML.
- `filterDecks(decks, text)` and `#deck-filter` mirror the song filter; "No slideshows match".
- `#slides-guide` dialog (tabs per slide program, "what does not come across" list) opened by `openSlidesGuide()` from `#sg-open`, the empty slideshow list and the setup guide's slideshow row (`row.guide`). Tests: `tests/test_slides_guide_and_filter.py`, `tests/test_fold_all.py`.

## Editor toolbar, slides to Media Library, video check (zt264)

- Toolbar rebuilt: row 1 bring-in (`#de-add` primary, `<details class="de-menu">` menus `#de-menu-from` / `#de-menu-replace` holding the old ids `de-library-open`, `de-from-open`, `de-replace`, `de-pdf`; `#de-all` far right); row 2 `#de-selbar` with label `#de-sel-label` and buttons `de-left`/`de-right` (arrows), `de-duplicate`, `de-skip`, `de-tomedia`, `de-split-open`, `de-delete`. Menu closing wired in `wireDeckEditor` area (choice, outside click, Esc).
- `Controller.copy_slides_to_media(deck_id, page_ids)` / action `deck_pages_to_media`: copies each non-video slide's picture to `media/<random>.<ext>` and registers an image asset ("<deck> - slide N" or title, duplicates numbered); video slides (media_id set) skipped; disk-space check (512 MB kept free); rolls back copies on failure; works while live.
- Video pages: already supported (see test_media_slideshows); added regression tests in `tests/test_slide_to_media.py`. Known gap: bundle export refuses slideshows with video pages (`export.slideshow_snapshot`).

## Owner feedback round (zt265)

- Ready check: the Screens and Screen-windows rows now carry `fix: "windows"`; `readyFix` has a `windows` entry; wording says "Projector windows".
- Editor toolbar row 1 reordered (Add pictures, Select all, Add from, Replace), all `primary`/accent, menu option buttons use the panel colour. `#de-grid` click on itself (empty space, min-height 14rem) deselects.
- `confirmClick`: arms a capture-phase `pointerdown` listener that resets the button when anything else is pressed; a message function may return `null` ("nothing to confirm": run the action), and `yes` may be a function.
- `#de-library-filter` filters the media panel with `filterDecks` (name substring); chosen files stay chosen.
- Export: `presentation_summaries` has `has_video`; library decks carry `has_video`; `export_slideshows(ids, everything, skip_video)`; `/api/export` accepts `skip_video=1`; Export all asks only when some slideshow has video. Refusal text explains the Media Library workaround. Tests: `tests/test_zt265.py`.

## Toolbar alignment (zt266)

- `.de-menu` had inherited a 16 px top margin from the page's `details` style, so the two menu buttons sat 8 px low; the margin is now 0 and the summary uses the same font, padding, min-height and radius as a button. Test in `tests/test_zt265.py`.

## Deselect area and filter spacing (zt267)

- The deselect click handler is on `.de-main` (the whole Slides box) and ignores clicks on buttons, summaries, details, inputs, selects, labels, links, `.de-card` and `.de-panel`.
- `#de-library-filter` has block display and margins; `#de-library-grid` has 2 px padding so the cards' outlines are not clipped or touching.

## Video starts after the slide is up (zt268)

- `LiveSession._sync_play` anchors a newly live clip (and a page's own sound) at `clock() + _start_lead()`: `START_LEAD` 0.5 s, plus the slide's `transition_ms` (max 2 s) when the move is inside the same slideshow (previous slide had the same `(item_type, source_item_id)` and the slide has a transition). Pause, play, restart, seek keep their immediate anchors.
- `clip_position` (Python and `output.js`) holds the clip at `pos` until `at`. `driveClip` keeps a clip paused until `at` and re-drives it from a timer (`held.startTimer`, cleared in `dropClip`). `Controller._clip_target` counts the end of a clip from `at`.
- Tests: `tests/test_clip_start_lead.py` (payload lead, transition lead and cap, arrival from another item, immediate controls, end timer, page sound, the same sum in `output.js`). The behaviour on a real projector is for the owner to check.

## OBS wording, no transitions for video pages (zt269)

- The OBS-skip tick box, its note and the Ready-bar hint now say "I don't need the OBS connection" (the setting key stays `no_livestream`).
- `planTransition` (output.js) returns null onto or off a `video` page; `LiveSession._start_lead` no longer adds a transition to the wait for a video page (a page's own sound on a picture page still waits for the transition). Tests in `tests/test_clip_start_lead.py`.

## Ready bar follows the setup guide (zt270)

- The OBS tick box calls `setup_no_livestream` and then `refreshReady()` (when the Service-tab landing is showing); `wizardHide()` also refreshes the bar, so the bar always reflects what the guide left behind. Test: `tests/test_ready_and_undo.py`.
