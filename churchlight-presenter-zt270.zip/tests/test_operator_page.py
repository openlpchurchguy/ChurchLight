# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import json
import re
import shutil
import subprocess
import unittest

from churchlight_presenter.server.app import STATIC_DIR

HTML = (STATIC_DIR / "operator.html").read_text(encoding="utf-8")
JS_PATH = STATIC_DIR / "operator.js"
JS = JS_PATH.read_text(encoding="utf-8") + (STATIC_DIR / "wizard.js").read_text(encoding="utf-8")   # the setup guide is its own script
CSS = (STATIC_DIR / "operator.css").read_text(encoding="utf-8")


class PageStructureTests(unittest.TestCase):
    """Checks that need no browser and no node."""

    def test_every_element_the_script_asks_for_exists(self):
        wanted = set(re.findall(r'\$\("([\w-]+)"\)', JS))
        present = set(re.findall(r'\sid="([\w-]+)"', HTML))
        self.assertTrue(wanted)
        self.assertEqual(sorted(wanted - present), [])

    def test_ids_are_unique(self):
        ids = re.findall(r'\sid="([\w-]+)"', HTML)
        self.assertEqual(len(ids), len(set(ids)))

    def test_the_page_has_no_inline_script_style_or_handlers(self):
        # the server's policy would block them; keeping them out is the rule
        self.assertNotRegex(HTML, r"<script(?![^>]*\ssrc=)")
        self.assertNotRegex(HTML, r"\sstyle=")
        self.assertNotRegex(HTML, r"\son[a-z]+=")
        self.assertIn('src="/static/operator.js"', HTML)
        self.assertIn('href="/static/operator.css"', HTML)

    def test_the_script_never_builds_html_from_text_or_evaluates_anything(self):
        for forbidden in ("innerHTML", "outerHTML", "insertAdjacentHTML", "document.write", "eval(",
                          "new Function", "setTimeout(\""):
            self.assertNotIn(forbidden, JS, forbidden)

    def test_every_button_in_the_page_is_wired_or_a_submit(self):
        for button_id in re.findall(r'<button[^>]*\sid="(btn-[\w-]+|preview-close)"', HTML):
            self.assertIn(f'$("{button_id}")', JS)

    def test_the_stylesheet_is_not_empty_and_has_a_narrow_layout(self):
        self.assertIn("@media (max-width", CSS)

    def test_hidden_things_stay_hidden_whatever_display_rule_a_class_has(self):
        self.assertRegex(CSS, r"\[hidden\]\s*\{\s*display:\s*none\s*!important")

    def test_the_file_pickers_ask_for_the_right_kinds_of_file(self):
        self.assertIn('id="file-songs" multiple', HTML)
        self.assertIn('id="file-bible" accept=".xml,.csv,.tsv,.txt"', HTML)
        self.assertRegex(HTML, r'id="file-deck" accept="\.pdf" multiple')

    def test_the_limits_in_the_page_match_the_server(self):
        from churchlight_presenter.ui import imports
        for kind, limit in imports.MAX_FILE_BYTES.items():
            self.assertIn(f"{kind}: {{", JS)
            self.assertIn(f"max: {limit // (1024 * 1024)} * MB", JS)
        for kind, suffixes in imports.ALLOWED.items():
            for suffix in suffixes:
                self.assertIn(f'"{suffix}"', JS, f"{kind} {suffix}")

    def test_every_action_the_script_sends_exists_in_the_api(self):
        from churchlight_presenter.ui.operator_api import OperatorApi
        sent = (set(re.findall(r'(?:act|call)\("([a-z_]+)"', JS)) | set(re.findall(r'action: "([a-z_]+)"', JS)))
        known = set(OperatorApi(None)._actions)
        self.assertTrue(sent)
        self.assertEqual(sorted(sent - known), [])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageLogicTests(unittest.TestCase):
    def run_js(self, expression):
        script = ("const m=require(process.argv[1]);"
                  f"console.log(JSON.stringify({expression}))")
        out = subprocess.run(["node", "-e", script, str(JS_PATH)], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    def test_the_script_parses(self):
        subprocess.run(["node", "--check", str(JS_PATH)], check=True, timeout=30)

    def state(self, **live):
        base = dict(blank=False, index=None, count=0, base=None, next=None, overlay=None,
                    overlay_loaded=False, overlay_index=None, overlay_count=0)
        base.update(live)
        return {"mode": "service", "live": base}

    def summary(self, **live):
        return self.run_js("m.liveSummary(%s)" % json.dumps(self.state(**live)))

    def test_a_screen_shape_sets_the_height_of_the_preview_page(self):
        self.assertEqual(self.run_js("m.frameHeight('16:9')"), 1080)
        self.assertEqual(self.run_js("m.frameHeight('4:3')"), 1440)
        self.assertEqual(self.run_js("m.frameHeight('16:10')"), 1200)
        for odd in ("''", "'7:5'", "undefined", "'wide'"):
            self.assertEqual(self.run_js("m.frameHeight(%s)" % odd), 1080, odd)
        self.assertEqual(self.run_js("m.shapeParts('4:3')"), [4, 3])

    def test_preview_scale_fits_the_box_and_never_divides_by_zero(self):
        self.assertEqual(self.run_js("m.previewScale(480)"), 0.25)
        for bad in ("0", "-5", "NaN", "undefined", "Infinity"):
            self.assertEqual(self.run_js("m.previewScale(%s)" % bad), 0, bad)

    def test_nothing_live(self):
        s = self.summary()
        self.assertEqual(s["position"], "Nothing live")
        self.assertFalse(s["canNext"])
        self.assertFalse(s["canPrevious"])
        self.assertEqual(s["nextTitle"], "First slide")

    def test_before_anything_is_live_next_starts_the_service(self):
        self.assertTrue(self.summary(count=3)["canNext"])

    def test_position_and_buttons_in_the_middle_and_at_the_ends(self):
        self.assertEqual(self.summary(index=1, count=3)["position"], "Slide 2 of 3")
        mid = self.summary(index=1, count=3)
        self.assertTrue(mid["canNext"] and mid["canPrevious"])
        first = self.summary(index=0, count=3)
        self.assertTrue(first["canNext"] and not first["canPrevious"])
        last = self.summary(index=2, count=3)
        self.assertTrue(not last["canNext"] and last["canPrevious"])

    def test_a_verse_in_two_parts_is_described_and_can_be_hidden_and_shown_again(self):
        overlay = {"text": "a", "label": "KJV", "reference": "John 3:16", "segments": [], "continued": False}
        shown = self.summary(index=0, count=1, overlay=overlay, overlay_loaded=True,
                             overlay_index=0, overlay_count=2)
        self.assertEqual(shown["overlayPosition"], "Verse part 1 of 2")
        self.assertTrue(shown["verseShown"] and shown["verseLoaded"])
        hidden = self.summary(index=0, count=1, overlay=None, overlay_loaded=True,
                              overlay_index=0, overlay_count=2)
        self.assertTrue(hidden["verseLoaded"] and not hidden["verseShown"])
        none = self.summary(index=0, count=1)
        self.assertFalse(none["verseLoaded"])

    def test_notes_blank_and_the_single_item_mode(self):
        base = {"text": "x", "notes": "say hello", "label": "Slide 1"}
        s = self.summary(index=0, count=1, base=base, blank=True)
        self.assertEqual(s["notes"], "say hello")
        self.assertTrue(s["blank"])
        state = self.state()
        state["mode"] = "item"
        self.assertIn("single item", self.run_js("m.liveSummary(%s)" % json.dumps(state))["mode"])

    def test_slide_text_lines_numbers_and_images(self):
        lines = self.run_js('m.slideSummary({text:"one\\ntwo",label:"Verse 1"})')
        self.assertEqual([l["text"] for l in lines["lines"]], ["one", "two"])
        self.assertTrue(all(l["number"] is None for l in lines["lines"]))
        verse = self.run_js('m.slideSummary({text:"a b",segments:[[16,"a"],[17,"b"]],reference:"John 3:16-17"})')
        self.assertEqual([(l["number"], l["text"]) for l in verse["lines"]], [(16, "a"), (17, "b")])
        single = self.run_js('m.slideSummary({text:"a",segments:[[16,"a"]]})')
        self.assertIsNone(single["lines"][0]["number"])         # one verse: no number shown
        image = self.run_js('m.slideSummary({text:"",image_path:"decks/ab/page 1.png"})')
        self.assertEqual(image["image"], "/media/decks/ab/page%201.png")
        self.assertEqual(image["lines"], [])
        self.assertIsNone(self.run_js("m.slideSummary(null)"))

    def test_media_urls_cannot_smuggle_extra_parts(self):
        self.assertEqual(self.run_js('m.mediaUrl("a/b?c#d.png")'), "/media/a/b%3Fc%23d.png")

    def test_keys(self):
        def key(k, **ctx):
            return self.run_js("m.keyAction(%s, %s)" % (json.dumps(k), json.dumps(ctx)))
        for k in (" ", "ArrowDown", "PageDown"):
            self.assertEqual(key(k), {"action": "next"})
        for k in ("ArrowUp", "PageUp"):
            self.assertEqual(key(k), {"action": "previous"})
        self.assertEqual(key("ArrowRight"), {"action": "next_item"})
        self.assertEqual(key("ArrowLeft"), {"action": "previous_item"})
        self.assertEqual(key("b"), {"action": "blank"})
        self.assertEqual(key("H"), {"action": "hide_verse"})
        self.assertEqual(key("]"), {"action": "verse_next"})
        self.assertEqual(key("["), {"action": "verse_previous"})
        self.assertEqual(key("/"), {"focus": "search"})
        self.assertIsNone(key("v"))                                           # there is no verse box any more
        self.assertIsNone(key("x"))
        self.assertIsNone(key("Escape"))
        self.assertEqual(key("Escape", verseShown=True), {"action": "hide_verse"})

    def test_keys_are_ignored_while_typing_and_space_does_not_double_up_on_buttons(self):
        def key(k, **ctx):
            return self.run_js("m.keyAction(%s, %s)" % (json.dumps(k), json.dumps(ctx)))
        for k in (" ", "b", "h", "v", "/", "ArrowRight", "ArrowDown", "["):
            self.assertIsNone(key(k, typing=True))
        self.assertEqual(key("Escape", typing=True), {"blur": True})
        self.assertIsNone(key(" ", onButton=True))
        self.assertEqual(key("ArrowDown", onButton=True), {"action": "next"})
        self.assertEqual(key("ArrowRight", onButton=True), {"action": "next_item"})

    def test_move_targets_use_the_neighbors_position(self):
        items = [{"position": 0}, {"position": 1}, {"position": 2}]
        self.assertEqual(self.run_js("m.moveTarget(%s, 1, -1)" % json.dumps(items)), 0)
        self.assertEqual(self.run_js("m.moveTarget(%s, 1, 1)" % json.dumps(items)), 2)
        self.assertIsNone(self.run_js("m.moveTarget(%s, 0, -1)" % json.dumps(items)))
        self.assertIsNone(self.run_js("m.moveTarget(%s, 2, 1)" % json.dumps(items)))

    def test_file_checks_explain_each_problem(self):
        files = [{"name": "a.xml", "size": 10}, {"name": "b.EXE", "size": 10}, {"name": "c.xml", "size": 0},
                 {"name": "d.xml", "size": 6 * 1024 * 1024}, {"name": "noext", "size": 5}]
        out = self.run_js("m.checkFiles('songs', %s)" % json.dumps(files))
        self.assertEqual([f["name"] for f in out["good"]], ["a.xml", "noext"])   # OpenSong files have no extension
        self.assertEqual(len(out["problems"]), 3)
        self.assertIn("is not one of", out["problems"][0])
        self.assertIn("is empty", out["problems"][1])
        self.assertIn("too large", out["problems"][2])
        decks = self.run_js("m.checkFiles('deck', %s)" % json.dumps(
            [{"name": "x.PDF", "size": 1}, {"name": "y.pptx", "size": 1}, {"name": "z.JPG", "size": 1}]))
        self.assertEqual([f["name"] for f in decks["good"]], ["x.PDF", "z.JPG"])      # presentation files are not accepted
        self.assertEqual(len(decks["problems"]), 1)
        self.assertEqual(self.run_js("m.extensionOf('a.b.TXT')"), ".txt")
        self.assertEqual(self.run_js("m.extensionOf('plain')"), "")

    def test_song_filter_and_labels(self):
        songs = [{"title": "Amazing Grace", "author": "Newton"}, {"title": "Other", "author": ""}]
        self.assertEqual(len(self.run_js("m.filterSongs(%s, '')" % json.dumps(songs))), 2)
        self.assertEqual(self.run_js("m.filterSongs(%s, ' GRACE ')" % json.dumps(songs))[0]["title"], "Amazing Grace")
        self.assertEqual(self.run_js("m.filterSongs(%s, 'newton')" % json.dumps(songs))[0]["title"], "Amazing Grace")
        self.assertEqual(self.run_js("m.filterSongs(%s, 'zzz')" % json.dumps(songs)), [])
        self.assertEqual(self.run_js("m.usesText(0)"), "")
        self.assertEqual(self.run_js("m.usesText(1)"), "used in 1 service")
        self.assertEqual(self.run_js("m.usesText(3)"), "used in 3 services")
        self.assertEqual(self.run_js("m.jobStatusText('failed')"), "Problem")
        self.assertEqual(self.run_js("m.jobStatusText('running')"), "Importing…")

    def test_service_chooser(self):
        state = {"service": None, "services": [{"id": 3, "title": "Sun", "date": "2026-10-25"}]}
        out = self.run_js("m.describeServiceSelect(%s)" % json.dumps(state))
        self.assertEqual(out["selected"], "")
        self.assertEqual(out["options"][0]["text"], "Choose a service…")
        self.assertEqual(out["options"][1], {"value": "3", "text": "Sun (2026-10-25)"})
        state["service"] = {"id": 3}
        self.assertEqual(self.run_js("m.describeServiceSelect(%s)" % json.dumps(state))["selected"], "3")
        empty = self.run_js("m.describeServiceSelect(%s)" % json.dumps({"service": None, "services": []}))
        self.assertEqual(empty["options"][0]["text"], "No services yet")


if __name__ == "__main__":
    unittest.main()
