# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Deleting several songs or slideshows at once: the ones in use are skipped, the rest go, one backup first."""
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core import backup
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.test_library_admin import AdminBase, TEXT


class BatchDeleteTests(AdminBase):
    def setUp(self):
        super().setUp()
        self.api = OperatorApi(self.c)
        self.songs = [self.c.create_song(f"Song {n}", "", TEXT) for n in range(4)]

    def titles(self):
        return sorted(s["title"] for s in self.db.song_summaries())

    def test_several_songs_are_deleted_at_once_with_one_notification(self):
        self.calls.clear()
        result = self.c.delete_songs(self.songs[:3])
        self.assertEqual((result["deleted"], result["skipped"]), (3, []))
        self.assertEqual(self.titles(), ["Song 3"])
        self.assertEqual(len(self.calls), 1)

    def test_a_song_used_in_a_service_is_skipped_with_its_reason_and_the_rest_go(self):
        self.c.new_service("Sunday")
        self.c.add_entry(self.entry("song", "Song 1"))
        result = self.c.delete_songs(self.songs)
        self.assertEqual(result["deleted"], 3)
        self.assertEqual([s["id"] for s in result["skipped"]], [self.songs[1]])
        self.assertIn("used in 1 service", result["skipped"][0]["reason"])
        self.assertEqual(self.titles(), ["Song 1"])

    def test_ids_that_do_not_exist_are_reported_not_fatal(self):
        result = self.c.delete_songs([self.songs[0], 9999])
        self.assertEqual(result["deleted"], 1)
        self.assertEqual([s["id"] for s in result["skipped"]], [9999])

    def test_nothing_chosen_and_too_many_are_refused(self):
        with self.assertRaises(ControllerError):
            self.c.delete_songs([])
        with self.assertRaises(ControllerError):
            self.c.delete_songs(list(range(1, 502)))

    def test_slideshows_are_deleted_in_a_batch_and_their_pictures_go_too(self):
        a, paths_a = self.make_deck("A", 2, "decks/a")
        b, paths_b = self.make_deck("B", 2, "decks/b")
        c, paths_c = self.make_deck("C", 2, "decks/c")
        self.c.new_service("Sunday")
        self.c.add_entry(self.entry("presentation", "C"))
        result = self.c.delete_decks([a, b, c])
        self.assertEqual(result["deleted"], 2)
        self.assertEqual([s["id"] for s in result["skipped"]], [c])
        self.assertEqual([r["name"] for r in self.db.presentation_summaries()], ["C"])
        self.assertFalse((self.tmp / "media" / paths_a[0]).exists())
        self.assertTrue((self.tmp / "media" / paths_c[0]).exists())

    def test_the_api_checks_the_list(self):
        for bad in ({}, {"ids": "1"}, {"ids": [1, "2"]}, {"ids": [True]}, {"ids": list(range(501))}):
            with self.assertRaises(ApiError):
                self.api.call("songs_delete", bad)
        result = self.api.call("songs_delete", {"ids": self.songs[:2]})
        self.assertEqual(result["deleted"], 2)
        result = self.api.call("decks_delete", {"ids": [12345]})
        self.assertEqual(result["deleted"], 0)


class BackupBeforeBatchTests(unittest.TestCase):
    def test_a_backup_is_made_first_even_if_one_was_made_a_minute_ago(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        path = tmp / "church.db"
        db = DatabaseManager(path, shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db, media_root=tmp / "media")
        ids = [c.create_song(f"S{n}", "", TEXT) for n in range(2)]
        self.assertIsNotNone(backup.make_backup(path))                        # the start-up copy
        self.assertIsNone(backup.make_backup(path, now=None))                 # a normal one is held back for ten minutes
        before = len(backup.list_backups(path))
        result = c.delete_songs(ids)
        self.assertTrue(result["backed_up"])
        self.assertGreaterEqual(len(backup.list_backups(path)), before)       # (same-second names replace each other)


if __name__ == "__main__":
    unittest.main()
