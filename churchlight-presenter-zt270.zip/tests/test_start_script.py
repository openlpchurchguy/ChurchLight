# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The Windows start file prefers the bundled Python, falls back to an installed one, and explains a missing one."""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class StartScriptTests(unittest.TestCase):
    def setUp(self):
        self.bat = (ROOT / "start_churchlight.bat").read_text(encoding="utf-8")

    def test_an_installed_python_is_used_first_and_the_bundled_one_only_as_a_fallback(self):
        order = [self.bat.index(t) for t in ('set "PY=python"', 'set "PY=py"', 'set "PY=python\\python.exe"')]
        self.assertEqual(order, sorted(order))
        self.assertIn("(3, 10)", self.bat)                                    # an installed Python that is too old is skipped

    def test_a_missing_python_is_explained_and_the_download_page_opens(self):
        self.assertIn("goto nopython", self.bat)
        tail = self.bat.split(":nopython", 1)[1]
        self.assertIn("python.org/downloads", tail)
        self.assertIn("Add python.exe to PATH", tail)
        self.assertIn("pause", tail)

    def test_the_bundling_script_adds_the_program_folder_to_the_search_path(self):
        ps = (ROOT / "tools" / "Get-BundledPython.ps1").read_text(encoding="utf-8")
        self.assertIn('Value ".."', ps)
        self.assertIn("embed-amd64", ps)


if __name__ == "__main__":
    unittest.main()
