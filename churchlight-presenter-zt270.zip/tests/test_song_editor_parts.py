# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Song editor refinements: separate order, CCLI numbers, and choosing parts per service."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.songtext import replace_order_line, skipped_parts
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

WORDS = "[Verse 1]\none\n\n[Verse 2]\ntwo\n\n[Verse 3]\nthree\n\n[Verse 4]\nfour\n\n[Chorus]\nsing"
ORDER = "Verse 1, Chorus, Verse 2, Chorus, Verse 3, Chorus, Verse 4, Chorus"


class PureTests(unittest.TestCase):
    def test_order_line_is_replaced_or_removed(self):
        self.assertEqual(replace_order_line("[A]\nx\n\nOrder: A, A", "A"), "[A]\nx\n\nOrder: A")
        self.assertEqual(replace_order_line("[A]\nx", ""), "[A]\nx")
        self.assertEqual(replace_order_line("[A]\nx\nOrder: A", "  "), "[A]\nx")

    def test_skipped_parts_rules(self):
        self.assertEqual(skipped_parts({"parts_skip": [1, 2], "parts_of": 4}, 4), {1, 2})
        self.assertEqual(skipped_parts({"parts_skip": [1], "parts_of": 4}, 5), set())      # song changed length
        self.assertEqual(skipped_parts({"parts_skip": [0, 1], "parts_of": 2}, 2), set())   # cannot skip everything
        self.assertEqual(skipped_parts({"parts_skip": [9, "x", True], "parts_of": 4}, 4), set())
        self.assertEqual(skipped_parts(None, 4), set())


class Base(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db)
        self.api = OperatorApi(self.c)
        self.song = self.c.create_song("Long Song", "Ann", WORDS, order=ORDER, ccli="7068424")


class EditorFieldTests(Base):
    def test_order_and_ccli_round_trip(self):
        info = self.c.song_for_editing(self.song)
        self.assertEqual((info["order"], info["ccli"]), (ORDER, "7068424"))
        self.assertNotIn("Order:", info["text"])
        self.c.update_song(self.song, "Long Song", "Ann", info["text"], order="Verse 1, Chorus", ccli="")
        info = self.c.song_for_editing(self.song)
        self.assertEqual((info["order"], info["ccli"]), ("Verse 1, Chorus", ""))

    def test_leaving_ccli_out_keeps_it_and_the_copyright(self):
        self.db.update_song(self.song, copyright="(c) Someone")
        self.c.update_song(self.song, "Long Song", "Ann", WORDS, order=ORDER)
        row = self.db.get_song(self.song)
        self.assertEqual((row["ccli_number"], row["copyright"]), ("7068424", "(c) Someone"))

    def test_bad_input(self):
        for bad in ("abc", "12 34", "12345678901"):
            with self.assertRaises(ControllerError):
                self.c.create_song("X", "", WORDS, ccli=bad)
        with self.assertRaises(ControllerError):
            self.c.create_song("X", "", WORDS, order="Verse 1, Nope")
        self.assertEqual(self.c.check_song_text(WORDS, "Verse 1, Chorus")["order"], ["Verse 1", "Chorus"])

    def test_an_order_line_typed_in_the_words_still_works_when_no_order_box_is_sent(self):
        song = self.c.create_song("Old way", "", "[A]\nx\n\n[B]\ny\n\nOrder: B, A")
        self.assertEqual(self.c.song_for_editing(song)["order"], "B, A")

    def test_church_license_number(self):
        self.assertEqual(self.c.library_overview()["church_ccli"], "")
        self.api.call("church_ccli", {"number": " 123456 "})
        self.assertEqual(self.c.library_overview()["church_ccli"], "123456")
        self.api.call("church_ccli", {"number": ""})
        self.assertEqual(self.c.library_overview()["church_ccli"], "")
        with self.assertRaises(ApiError):
            self.api.call("church_ccli", {"number": "abc"})
        self.assertEqual(self.c.library_overview()["songs"][0]["ccli"], "7068424")


class ServicePartsTests(Base):
    def setUp(self):
        super().setUp()
        self.c.new_service("S")
        self.c.add_entry(LibraryEntry("song", self.song, ""))
        self.item = self.c.service_rows()[0].item_id

    def labels(self):
        self.c.go_live_service_item(self.item)
        return [s.label for s in self.c.session.slides]

    def test_whole_song_by_default(self):
        self.assertEqual(self.c.service_rows()[0].parts, {"total": 8, "used": 8})
        self.assertEqual(len(self.labels()), 8)

    def test_first_and_last_verse_only(self):
        info = self.c.song_parts(self.item)
        self.assertEqual([p["label"] for p in info["parts"]][:3], ["Verse 1", "Chorus", "Verse 2"])
        self.assertEqual(info["parts"][0]["first_line"], "one")
        self.c.set_item_parts(self.item, [2, 3, 4, 5])             # skip verses 2 and 3 and their choruses
        self.assertEqual(self.labels(), ["Verse 1", "Chorus", "Verse 4", "Chorus"])
        self.assertEqual(self.c.service_rows()[0].parts, {"total": 8, "used": 4})
        self.assertEqual([p["skipped"] for p in self.c.song_parts(self.item)["parts"]],
                         [False, False, True, True, True, True, False, False])

    def test_reset_and_refusals(self):
        self.c.set_item_parts(self.item, [1])
        self.c.set_item_parts(self.item, [])
        self.assertEqual(len(self.labels()), 8)
        for bad in ([0, 1, 2, 3, 4, 5, 6, 7], [8], [-1], ["a"], "no"):
            with self.assertRaises(ControllerError):
                self.c.set_item_parts(self.item, bad)

    def test_the_choice_is_per_service_item_not_per_song(self):
        self.c.add_entry(LibraryEntry("song", self.song, ""))
        other = self.c.service_rows()[1].item_id
        self.c.set_item_parts(self.item, [2, 3])
        self.assertEqual(self.c.service_rows()[1].parts["used"], 8)
        self.assertNotEqual(other, self.item)

    def test_a_song_that_changed_length_goes_back_to_the_whole_song(self):
        self.c.set_item_parts(self.item, [2, 3])
        self.c.update_song(self.song, "Long Song", "Ann", WORDS, order="Verse 1, Chorus")
        self.assertEqual(self.c.service_rows()[0].parts, {"total": 2, "used": 2})

    def test_only_song_items_in_this_service(self):
        with self.assertRaises(ControllerError):
            self.c.set_item_parts(999, [0])

    def test_api(self):
        self.api.call("item_parts", {"item_id": self.item, "skip": [1, 3]})
        self.assertEqual(self.api.state()["items"][0]["parts"], {"total": 8, "used": 6})
        with self.assertRaises(ApiError):
            self.api.call("item_parts", {"item_id": self.item, "skip": "x"})



class OutlineTests(Base):
    """The options list of a song: its parts (left-out ones too), each with the slides it made and where they are."""
    def setUp(self):
        super().setUp()
        self.c.new_service("S")
        self.other = self.c.create_song("Other", "", "[A]\nalpha\n\n[B]\nbeta")
        self.c.add_entry(LibraryEntry("song", self.other, ""))
        self.c.add_entry(LibraryEntry("song", self.song, ""))
        self.rows = self.c.service_rows()
        self.item = self.rows[1].item_id

    def outline(self, row=1):
        return self.c.service_rows()[row].outline

    def test_every_part_is_listed_with_its_slides_and_their_numbers_in_the_whole_service(self):
        parts = self.outline()
        self.assertEqual([p["label"] for p in parts][:3], ["Verse 1", "Chorus", "Verse 2"])
        self.assertEqual(len(parts), 8)
        slides = [slide for part in parts for slide in part["slides"]]
        self.assertEqual([s["index"] for s in slides], list(range(2, 2 + len(slides))))     # after the other song's 2 slides
        self.assertEqual(parts[0]["slides"][0]["line"], "one")
        self.assertEqual([self.c.session.slides[s["index"]].text for s in slides][:2], ["one", "sing"])
        self.assertEqual([p["index"] for p in parts], list(range(8)))

    def test_a_left_out_part_is_still_listed_with_no_slides(self):
        self.c.set_item_parts(self.item, [1, 2])
        parts = self.outline()
        self.assertEqual([p["skipped"] for p in parts][:4], [False, True, True, False])
        self.assertEqual([len(p["slides"]) for p in parts][:4], [1, 0, 0, 1])
        self.assertEqual(len([s for p in parts for s in p["slides"]]), 6)

    def test_slide_numbers_let_the_page_jump_and_follow(self):
        parts = self.outline()
        target = parts[2]["slides"][0]["index"]
        self.c.go_to_slide(target)
        self.assertEqual(self.c.session.state().base_index, target)
        self.assertTrue(self.c.service_rows()[1].is_live)
        self.assertEqual(self.c.service_rows()[0].is_live, False)

    def test_a_long_part_has_several_slides_marked_as_continued(self):
        lines = "\n".join(f"line {i}" for i in range(1, 10))
        song = self.c.create_song("Wordy", "", "[Verse 1]\n" + lines)
        self.c.add_entry(LibraryEntry("song", song, ""))
        parts = self.outline(2)
        self.assertGreater(len(parts[0]["slides"]), 1)
        self.assertEqual([s["continued"] for s in parts[0]["slides"]][:2], [False, True])

    def test_the_state_carries_the_outline_for_songs_only(self):
        items = self.api.state()["items"]
        self.assertEqual(len(items[1]["outline"]), 8)
        self.assertEqual(items[1]["outline"][0]["slides"][0]["line"], "one")

    def test_a_song_sent_straight_to_live_has_no_service_numbers_to_follow(self):
        self.c.go_live_entry(LibraryEntry("song", self.song, ""))
        self.assertTrue(all(not part["slides"] for part in self.c.service_rows()[1].outline))


if __name__ == "__main__":
    unittest.main()


import json
import shutil
import subprocess
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_part_names_come_from_the_headings_once_each(self):
        self.assertEqual(self.js("m.partNames('[Verse 1]\\na\\n\\n[Chorus]\\nb\\n[Verse 1]\\nc')"), ["Verse 1", "Chorus"])
        self.assertEqual(self.js("m.partNames('no headings here')"), [])
        self.assertEqual(self.js("m.partNames(null)"), [])

    def test_clicking_a_part_builds_the_order(self):
        self.assertEqual(self.js("m.appendToOrder('', 'Chorus')"), "Chorus")
        self.assertEqual(self.js("m.appendToOrder('Verse 1, ', 'Chorus')"), "Verse 1, Chorus")
        self.assertEqual(self.js("m.appendToOrder('Verse 1', 'Verse 2')"), "Verse 1, Verse 2")

    def test_parts_summary(self):
        self.assertEqual(self.js("m.partsSummary({total:8,used:4})"), "4 of 8 parts")
        self.assertEqual(self.js("m.partsSummary({total:8,used:8})"), "")
        self.assertEqual(self.js("m.partsSummary(null)"), "")

    def test_the_kept_song_buffer_carries_order_and_ccli(self):
        buffered = self.js("""m.parseSongBuffer('{"title":"T","author":"","text":"x","order":"A, B","ccli":"123"}')""")
        self.assertEqual((buffered["order"], buffered["ccli"]), ("A, B", "123"))
        old = self.js("""m.parseSongBuffer('{"title":"T","author":"","text":"x"}')""")
        self.assertEqual((old["order"], old["ccli"]), ("", ""))

    def test_the_page_has_the_new_fields(self):
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        for ident in ("song-order", "song-ccli", "song-parts", "church-ccli", "church-ccli-form"):
            self.assertIn(f'id="{ident}"', html)
