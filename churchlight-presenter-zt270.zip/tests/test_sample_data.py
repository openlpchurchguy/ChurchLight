# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import contextlib
import importlib.util
import io
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import OperatorController

ROOT = Path(__file__).resolve().parent.parent
_spec = importlib.util.spec_from_file_location("make_sample_data", ROOT / "tools" / "make_sample_data.py")
sample = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sample)


class SampleDataTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def run_tool(self, *extra):
        with contextlib.redirect_stdout(io.StringIO()) as out:
            code = sample.main(["--folder", str(self.tmp / "s"), "--media", str(self.tmp / "m"), *extra])
        return code, out.getvalue()

    def test_everything_imports_and_a_service_can_run_with_no_extra_software(self):
        db_path = self.tmp / "t.db"
        code, text = self.run_tool("--db", str(db_path))
        self.assertEqual(code, 0)
        self.assertIn("songs: 3 imported", text)
        self.assertIn("slideshow: 3 pages", text)
        with DatabaseManager(db_path) as db:
            c = OperatorController(db)
            self.assertEqual(c.translations(), ["DEMO"])
            titles = [e.title for e in c.search_library()]
            self.assertEqual(titles, ["Placeholder Slideshow", "Placeholder Song One",
                                      "Placeholder Song Three", "Placeholder Song Two"])
            deck = next(e for e in c.search_library() if e.kind == "presentation")
            c.go_live_entry(deck)
            slides = c.show_verse("jn 3:16")
            self.assertGreaterEqual(len(slides), 1)
            self.assertEqual(c.payloads()["projector"]["base"]["label"], "Slide 1")
            self.assertEqual(slides[0].reference, "John 3:16")
            for page in db.get_presentation_pages(deck.id):
                self.assertTrue((self.tmp / "m" / page["image_path"]).read_bytes().startswith(b"\x89PNG"))

    def test_running_it_twice_does_not_double_anything(self):
        db_path = self.tmp / "t.db"
        self.run_tool("--db", str(db_path))
        code, text = self.run_tool("--db", str(db_path))
        self.assertEqual(code, 0)
        self.assertIn("songs: 0 imported, 3 already there", text)
        self.assertIn("Bible DEMO: already there", text)
        self.assertIn("(already there)", text)

    def test_without_a_database_it_only_writes_files(self):
        code, text = self.run_tool()
        self.assertEqual(code, 0)
        self.assertTrue((self.tmp / "s" / "bible.xml").is_file())
        self.assertEqual(len(list((self.tmp / "s" / "songs").glob("*.xml"))), 3)

    def test_the_sample_text_is_obviously_placeholder(self):
        files = sample.make_files(self.tmp / "s")
        text = (files["bible"].read_text() + " ".join(p.read_text() for p in files["songs"].glob("*.xml")))
        self.assertIn("placeholder", text.lower())
        self.assertNotIn("For God so loved", text)

    def test_the_picture_is_a_valid_png_of_the_right_size(self):
        import struct
        import zlib
        data = sample.png(40, 20, (1, 2, 3), (9, 9, 9))
        self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
        width, height = struct.unpack(">II", data[16:24])
        self.assertEqual((width, height), (40, 20))
        idat = data[data.index(b"IDAT") + 4:data.index(b"IEND") - 8]
        self.assertEqual(len(zlib.decompress(idat)), 20 * (1 + 40 * 3))


if __name__ == "__main__":
    unittest.main()
