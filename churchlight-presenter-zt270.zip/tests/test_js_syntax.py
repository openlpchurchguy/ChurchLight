# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Every page script must at least parse (one stray quote can break a whole page)."""
import subprocess
import unittest
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


class JsSyntaxTests(unittest.TestCase):
    def test_every_script_parses(self):
        for path in sorted(STATIC.glob("*.js")):
            with self.subTest(script=path.name):
                out = subprocess.run(["node", "--check", str(path)], capture_output=True, text=True, timeout=30)
                self.assertEqual(out.returncode, 0, out.stderr)
