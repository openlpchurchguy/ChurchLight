# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The fonts bundled for slide themes: files, licenses, the stylesheet, the editor's list and serving."""
import csv
import http.client
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.server.app import OutputServer

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
FONTS = STATIC / "fonts"
KJV = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "content" / "bibles" / "kjv.csv"
FACE = re.compile(r'font-family: "([^"]+)"; font-weight: (\d+);.*?url\("/static/fonts/([^"]+)"\)', re.S)


def faces():
    return FACE.findall((STATIC / "themefonts.css").read_text(encoding="utf-8"))


def editor_fonts():
    script = "const m=require(process.argv[1]);console.log(JSON.stringify(m.THEME_FONTS))"
    out = subprocess.run(["node", "-e", script, str(STATIC / "themes.js")], capture_output=True, text=True, check=True)
    return json.loads(out.stdout)


class BundledFontFilesTests(unittest.TestCase):
    def test_every_face_points_at_a_real_font_file_with_its_license(self):
        self.assertGreaterEqual(len({f[0] for f in faces()}), 17)
        for family, weight, filename in faces():
            self.assertTrue((FONTS / filename).is_file(), filename)
            self.assertIn(int(weight), (400, 700), family)
        licenses = {p.name for p in FONTS.glob("OFL-*.txt")}
        self.assertGreaterEqual(len(licenses), 17)
        for path in FONTS.glob("OFL-*.txt"):
            text = path.read_text(encoding="utf-8")
            self.assertIn("SIL OPEN FONT LICENSE Version 1.1", text, path.name)
            self.assertIn("Copyright", text, path.name)

    def test_every_family_has_a_regular_face_and_names_are_servable(self):
        by_family = {}
        for family, weight, filename in faces():
            by_family.setdefault(family, set()).add(int(weight))
            self.assertRegex(filename, r"^[A-Za-z0-9_\-]+\.ttf$")           # what server/app.py will serve
        for family, weights in by_family.items():
            self.assertIn(400, weights, family)

    def test_the_bundle_stays_a_sensible_size(self):
        total = sum(p.stat().st_size for p in FONTS.iterdir())
        self.assertLess(total, 12 * 1024 * 1024)

    def test_the_fonts_readme_lists_every_bundled_family(self):
        readme = (FONTS / "README.md").read_text(encoding="utf-8")
        for family in {f[0] for f in faces()}:
            self.assertIn(family, readme)

    @unittest.skipUnless(shutil.which("node"), "node is not installed")
    def test_the_editor_list_uses_only_bundled_or_system_fonts_and_every_bundled_family_is_offered(self):
        bundled = {f[0] for f in faces()}
        offered = set()
        for value, text in editor_fonts():
            first = value.split(",")[0].strip().strip("'\"")
            if "(system font" in text:
                self.assertNotIn(first, bundled)
            else:
                self.assertIn(first, bundled, value)
                self.assertIn(f"'{first}'", value)                          # quoted, so "Source Sans 3" parses
                offered.add(first)
        self.assertEqual(offered, bundled)

    def test_the_bundled_fonts_draw_the_text_the_program_shows(self):
        try:
            from fontTools.ttLib import TTFont
        except ImportError:
            self.skipTest("fontTools is not installed")
        with open(KJV, encoding="utf-8", newline="") as handle:
            needed = {ch for row in csv.reader(handle) for ch in row[3]}
        needed |= set("æÆ’‘“”—–…") | {chr(c) for c in range(32, 127)}
        for family, weight, filename in faces():
            cmap = TTFont(FONTS / filename).getBestCmap()
            missing = [ch for ch in sorted(needed) if ord(ch) not in cmap]
            self.assertEqual(missing, [], f"{family} {weight} cannot draw {missing}")


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class VerseNumberFontTests(unittest.TestCase):
    def test_the_verse_number_font_offers_every_theme_font_and_same_as_the_text(self):
        from churchlight_presenter.core.themes import validate_style
        source = (STATIC / "themes.js").read_text(encoding="utf-8")
        line = next(l for l in source.splitlines() if l.strip().startswith("number_font: () =>"))
        self.assertIn('[["same", "Same as the verse text"]].concat(THEME_FONTS)', line)
        for value, _ in editor_fonts():
            validate_style({"number_font": value})                         # the server accepts every offered value
        validate_style({"number_font": "same"})


class ServingTests(unittest.TestCase):
    def get(self, server, path):
        conn = http.client.HTTPConnection(*server.address, timeout=5)
        try:
            conn.request("GET", path)
            response = conn.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            conn.close()

    def test_output_pages_load_the_font_stylesheet_and_may_load_fonts_from_the_server(self):
        with OutputServer(LiveSession(), [Output("projector", "projector")]) as server:
            status, headers, body = self.get(server, "/static/themefonts.css")
            self.assertEqual(status, 200)
            self.assertIn(b"Open Sans", body)
            status, headers, body = self.get(server, "/static/output.html")
            self.assertIn(b"/static/themefonts.css", body)
            self.assertIn("font-src 'self'", headers["Content-Security-Policy"])
            self.assertIn("default-src 'none'", headers["Content-Security-Policy"])
            family, weight, filename = faces()[0]
            status, headers, body = self.get(server, "/static/fonts/" + filename)
            self.assertEqual((status, headers["Content-Type"]), (200, "font/ttf"))
            self.assertEqual(body, (FONTS / filename).read_bytes())


if __name__ == "__main__":
    unittest.main()
