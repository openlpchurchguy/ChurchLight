# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import logging
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path

from churchlight_presenter import logsetup
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.console import Console
from churchlight_presenter.ui.controller import OperatorController

LYRIC = "zebra-lantern-lyric"


def make_controller():
    db = DatabaseManager(":memory:")
    db.create_song_with_sections("Alpha", [("Verse 1", "verse", LYRIC + "\nsecond line")],
                                 order=["Verse 1"], author="A")
    return db, OperatorController(db)


class ChangeNotificationTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make_controller()
        self.addCleanup(self.db.close)
        self.calls = []
        self.c.subscribe(lambda: self.calls.append(self.c.version))

    def entry(self):
        return self.c.search_library("Alpha")[0]

    def test_version_grows_with_each_change_and_not_without_one(self):
        start = self.c.version
        self.c.new_service("S", "2026-10-25")
        self.assertGreater(self.c.version, start)
        before = self.c.version
        self.c.search_library("Alpha")
        self.c.services()
        self.assertEqual(self.c.version, before)

    def test_one_action_tells_listeners_once(self):
        self.c.new_service("S", "2026-10-25")
        self.calls.clear()
        self.c.add_entry(self.entry())
        self.assertEqual(len(self.calls), 1)
        self.calls.clear()
        self.c.go_live_entry(self.entry())
        self.assertEqual(len(self.calls), 1)
        self.calls.clear()
        self.c.open_service(self.c.service_id)
        self.assertEqual(len(self.calls), 1)

    def test_versions_seen_by_listeners_are_increasing(self):
        self.c.new_service("S", "2026-10-25")
        self.c.add_entry(self.entry())
        self.c.go_live_service_item(self.c.service_rows()[0].item_id)
        self.c.next()
        self.assertEqual(self.calls, sorted(set(self.calls)))

    def test_theme_edits_and_library_imports_notify(self):
        before = self.c.version
        self.c.save_theme("T", {"color": "#ffffff"})
        self.assertGreater(self.c.version, before)
        before = self.c.version
        self.c.library_changed()
        self.assertEqual(self.c.version, before + 1)

    def test_a_listener_that_raises_does_not_break_anything(self):
        def bad():
            raise RuntimeError("boom")
        self.c.subscribe(bad)
        with self.assertLogs("churchlight_presenter.ui.controller", "ERROR"):
            self.c.new_service("S", "2026-10-25")
        self.assertTrue(self.calls)               # the well-behaved listener still heard it
        self.assertEqual(self.c.service_id, 1)

    def test_an_edit_that_fails_still_tells_listeners_about_what_changed(self):
        self.c.new_service("S", "2026-10-25")
        self.calls.clear()
        with self.assertRaises(Exception):
            self.c.add_entry(self.entry(), position="not a number")
        # either nothing changed (no call) or it was announced; the batch must be closed again
        self.assertEqual(self.c._batch_depth, 0)
        self.c.next()                              # and later changes still notify
        self.c.go_live_entry(self.entry())
        self.assertTrue(self.calls)

    def test_wait_for_change_returns_at_once_when_already_different(self):
        self.c.new_service("S", "2026-10-25")
        started = time.monotonic()
        self.assertGreater(self.c.wait_for_change(0, 5), 0)
        self.assertLess(time.monotonic() - started, 1)

    def test_wait_for_change_times_out_quietly(self):
        version = self.c.version
        started = time.monotonic()
        self.assertEqual(self.c.wait_for_change(version, 0.2), version)
        self.assertGreaterEqual(time.monotonic() - started, 0.15)

    def test_wait_for_change_wakes_when_another_thread_changes_something(self):
        version = self.c.version
        threading.Timer(0.1, self.c.toggle_blank).start()      # (no database use off the main thread)
        started = time.monotonic()
        self.assertGreater(self.c.wait_for_change(version, 5), version)
        self.assertLess(time.monotonic() - started, 2)


class LoggingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.addCleanup(logsetup.close_logging)
        self.path = self.tmp / "logs" / "church.log"

    def text(self):
        for handler in logging.getLogger(logsetup.PACKAGE).handlers:
            handler.flush()
        return self.path.read_text(encoding="utf-8")

    def test_a_service_is_logged_without_any_lyrics_or_verse_text(self):
        self.assertEqual(logsetup.setup_logging(self.path), self.path)
        db, c = make_controller()
        self.addCleanup(db.close)
        c.new_service("Sunday", "2026-10-25")
        entry = c.search_library("Alpha")[0]
        c.add_entry(entry)
        c.add_announcement("Picnic", "Bring " + LYRIC)
        c.go_live_entry(entry)
        c.toggle_blank()
        c.clear()
        text = self.text()
        self.assertIn("Created service 1", text)
        self.assertIn("Added song", text)
        self.assertIn("Live (single item): song", text)
        self.assertNotIn(LYRIC, text)
        self.assertNotIn("Picnic", text)

    def test_errors_are_logged_with_a_traceback_and_console_survives(self):
        logsetup.setup_logging(self.path)
        db, c = make_controller()
        self.addCleanup(db.close)

        def explode(*a, **k):
            raise RuntimeError("kaboom")
        c.services = explode
        import io
        out = io.StringIO()
        console = Console(c, stdout=out)
        console.onecmd("services")
        self.assertIn("Something unexpected", out.getvalue())
        self.assertIn(str(self.path), out.getvalue())
        text = self.text()
        self.assertIn("Unexpected error in command 'services'", text)
        self.assertIn("RuntimeError: kaboom", text)

    def test_verbose_adds_detail_and_default_hides_it(self):
        logging.getLogger("churchlight_presenter.test").debug("quiet detail")
        logsetup.setup_logging(self.path)
        logging.getLogger("churchlight_presenter.test").debug("quiet detail")
        self.assertNotIn("quiet detail", self.text())
        logsetup.setup_logging(self.path, verbose=True)
        logging.getLogger("churchlight_presenter.test").debug("loud detail")
        self.assertIn("loud detail", self.text())

    def test_setting_up_twice_does_not_double_the_lines(self):
        logsetup.setup_logging(self.path)
        logsetup.setup_logging(self.path)
        logging.getLogger("churchlight_presenter.test").info("only once")
        self.assertEqual(self.text().count("only once"), 1)

    def test_an_unwritable_log_is_reported_and_the_program_carries_on(self):
        blocker = self.tmp / "file"
        blocker.write_text("x")
        warnings = []
        result = logsetup.setup_logging(blocker / "sub" / "x.log", warn=warnings.append)
        self.assertIsNone(result)
        self.assertEqual(len(warnings), 1)
        self.assertIn("Carrying on without a log", warnings[0])
        logging.getLogger("churchlight_presenter.test").error("still fine")   # must not raise
        self.assertIsNone(logsetup.current_log_path())

    def test_the_log_rotates_instead_of_growing_forever(self):
        logsetup.setup_logging(self.path)
        logger = logging.getLogger("churchlight_presenter.test")
        for _ in range(3000):
            logger.info("x" * 1000)
        logsetup.close_logging()
        files = sorted(p.name for p in self.path.parent.iterdir())
        self.assertIn("church.log.1", files)
        self.assertLessEqual(len(files), 1 + logsetup.BACKUPS)

    def test_starting_the_program_writes_a_start_and_stop_line_beside_the_database(self):
        import contextlib
        import io
        from unittest import mock
        from churchlight_presenter.__main__ import main
        with mock.patch("sys.stdin", io.StringIO("new Sunday\nquit\n")), \
                contextlib.redirect_stdout(io.StringIO()) as out:
            code = main(["--db", str(self.tmp / "t.db"), "--media", str(self.tmp / "m"), "--port", "0"])
        self.assertEqual(code, 0)
        self.assertIn("Log file:", out.getvalue())
        text = (self.tmp / "churchlight.log").read_text(encoding="utf-8")
        self.assertIn("Starting ChurchLight build", text)
        self.assertIn("Python", text)
        self.assertIn("Created service 1", text)
        self.assertIn("Stopped", text)

    def test_default_path_is_beside_the_database(self):
        self.assertEqual(logsetup.default_log_path(self.tmp / "x.db"), (self.tmp / "churchlight.log").resolve())

    def test_closing_releases_the_file_so_it_can_be_deleted(self):
        logsetup.setup_logging(self.path)
        logsetup.close_logging()
        self.path.unlink()


if __name__ == "__main__":
    unittest.main()
