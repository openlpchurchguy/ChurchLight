# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The program remembers how the monitors were arranged and says so when they differ."""
import unittest

from churchlight_presenter.ui import setup
from tests.test_verse_tray import make


def monitors(*specs):
    return [{"index": i, "x": x, "y": y, "width": w, "height": h, "primary": i == 0, "name": f"M{i}"}
            for i, (x, y, w, h) in enumerate(specs)]


class LayoutTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.now = monitors((0, 0, 1920, 1080), (1920, 0, 1920, 1080))
        self.c.screen_windows._list = lambda: self.now

    def test_nothing_saved_means_no_warning(self):
        self.assertEqual(self.c.layout_changes(), [])

    def test_same_layout_is_quiet_and_shows_a_tick(self):
        self.c.set_screens({"stage": 1}, True)
        self.c.save_layout()
        self.assertEqual(self.c.layout_changes(), [])
        rows = {r["id"]: r for r in setup.ready_checks(self.c)}
        self.assertTrue(rows["layout"]["ok"])

    def test_a_different_size_or_count_is_reported(self):
        self.c.save_layout()
        self.now = monitors((0, 0, 1920, 1080), (1920, 0, 1280, 720))
        self.assertIn("Monitor 2 was 1920×1080 and is now 1280×720.", self.c.layout_changes())
        self.now = monitors((0, 0, 1920, 1080))
        self.assertIn("There were 2 monitors last time and there are 1 now.", self.c.layout_changes()[0])

    def test_a_moved_monitor_is_reported_and_accepting_clears_it(self):
        self.c.set_screens({"stage": 1}, True)
        self.c.save_layout()
        self.now = monitors((0, 0, 1920, 1080), (-1920, 0, 1920, 1080))
        rows = {r["id"]: r for r in setup.ready_checks(self.c)}
        self.assertFalse(rows["layout"]["ok"])
        self.assertEqual(rows["layout"]["fix"], "layout")
        self.api.do("layout_accept", {}) if hasattr(self.api, "do") else self.c.save_layout()
        self.assertEqual(self.c.layout_changes(), [])


if __name__ == "__main__":
    unittest.main()


class AutoOpenKeepsTheWarningTests(unittest.TestCase):
    def test_opening_the_screens_does_not_overwrite_a_changed_layout(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.screen_windows._list = lambda: monitors((0, 0, 1920, 1080), (1920, 0, 1920, 1080))
        c.show_screen = lambda *a, **k: None              # no real window in a test
        c.set_screens({"stage": 1}, True)
        self.assertEqual(c.open_screens(), [])               # first time: the layout is remembered
        self.assertEqual(c.layout_changes(), [])
        c.screen_windows._list = lambda: monitors((0, 0, 1920, 1080), (1920, 0, 1280, 720))
        self.assertEqual(c.open_screens(), [])               # the screens open by themselves at start...
        self.assertTrue(c.layout_changes())                  # ...but the change is still reported
        c.save_layout()                                      # "This layout is correct"
        self.assertEqual(c.layout_changes(), [])
