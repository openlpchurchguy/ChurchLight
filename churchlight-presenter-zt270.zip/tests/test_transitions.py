# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Per-deck slide transitions: the setting, the database upgrade, the payload and the page logic."""
import json
import shutil
import sqlite3
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.migrations import MIGRATIONS, migrate
from churchlight_presenter.core.outputs import LAYOUTS, Output, build_payload
from churchlight_presenter.core.slides import Slide
from churchlight_presenter.core.transitions import (
    DEFAULT_MS, MAX_MS, STEP_MS, TRANSITIONS, check_transition)
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


class RuleTests(unittest.TestCase):
    def test_good_choices_are_accepted_in_tenths_of_a_second_up_to_two_seconds(self):
        for kind in TRANSITIONS:
            for ms in (0, 100, 500, 1900, 2000):
                self.assertEqual(check_transition(kind, ms), (kind, ms))
        self.assertEqual((STEP_MS, MAX_MS, DEFAULT_MS), (100, 2000, 500))

    def test_bad_choices_are_refused_in_plain_words(self):
        bad = [("wipe", 500), ("", 500), (None, 500), ("dissolve", -100), ("dissolve", 2100),
               ("dissolve", 150), ("dissolve", 0.5), ("dissolve", "500"), ("dissolve", None),
               ("dissolve", True)]
        for kind, ms in bad:
            with self.assertRaises(ValueError, msg=f"{kind!r} {ms!r}"):
                check_transition(kind, ms)

    def test_the_choices_are_the_ones_the_pages_know(self):
        self.assertEqual(len(TRANSITIONS), 18)
        for kind in ("none", "dissolve", "circle_in", "circle_out", "slide_left", "split_vertical", "wipe_down",
                     "fade_black", "fade_white"):
            self.assertIn(kind, TRANSITIONS)


class UpgradeTests(unittest.TestCase):
    def test_a_version_3_database_gains_the_columns_and_keeps_its_decks(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        migrate(conn, MIGRATIONS[:3])
        conn.execute("INSERT INTO presentations (name) VALUES ('Old deck')")
        conn.commit()
        self.assertEqual(migrate(conn), len(MIGRATIONS))
        row = conn.execute("SELECT name, transition, transition_ms FROM presentations").fetchone()
        self.assertEqual(tuple(row), ("Old deck", "none", 500))
        self.assertEqual(conn.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_the_database_itself_refuses_nonsense(self):
        db = DatabaseManager(":memory:")
        self.addCleanup(db.close)
        deck = db.add_presentation("D", [("d/1.png", None)])
        for kind, ms in (("spin", 500), ("dissolve", 5000), ("dissolve", -1)):
            with self.assertRaises(sqlite3.IntegrityError, msg=f"{kind} {ms}"):
                db.set_presentation_transition(deck, kind, ms)
        db.set_presentation_transition(deck, "circle_in", 800)
        row = db.get_presentation(deck)
        self.assertEqual((row["transition"], row["transition_ms"]), ("circle_in", 800))


def make():
    db = DatabaseManager(":memory:", shared=True)
    deck = db.add_presentation("Deck", [("d/1.png", None), ("d/2.png", None), ("d/3.png", None)])
    db.create_song_with_sections("Song", [("Verse 1", "verse", "a\nb")], order=["Verse 1"])
    c = OperatorController(db, [Output("projector", "projector"), Output("stage", "stage"),
                                Output("lower", "lower_third")])
    return db, c, deck


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.deck = make()
        self.addCleanup(self.db.close)
        self.entry = LibraryEntry("presentation", self.deck, "Deck")

    def test_slides_carry_the_decks_transition_and_a_none_or_zero_means_none(self):
        self.c.go_live_entry(self.entry)
        self.assertEqual({(s.transition, s.transition_ms) for s in self.c.session.slides}, {("none", 0)})
        self.c.set_deck_transition(self.deck, "dissolve", 700)
        self.assertEqual({(s.transition, s.transition_ms) for s in self.c.session.slides}, {("dissolve", 700)})
        self.c.set_deck_transition(self.deck, "dissolve", 0)
        self.assertEqual({(s.transition, s.transition_ms) for s in self.c.session.slides}, {("none", 0)})

    def test_changing_it_keeps_the_live_slide_and_the_verse(self):
        self.c.new_service("S")
        self.c.add_entry(self.entry)
        self.c.go_to_slide(2)
        self.c.set_deck_transition(self.deck, "circle_out", 400)
        state = self.c.session.state()
        self.assertEqual((state.base_index, state.base.transition), (2, "circle_out"))

    def test_a_deck_sent_live_on_its_own_is_updated_in_place(self):
        self.c.go_live_entry(self.entry)
        self.c.go_to_slide(1)
        self.c.set_deck_transition(self.deck, "circle_in", 1500)
        state = self.c.session.state()
        self.assertEqual((self.c.mode, state.base_index, state.base.transition_ms), ("item", 1, 1500))

    def test_another_decks_change_does_not_disturb_what_is_live(self):
        other = self.db.add_presentation("Other", [("o/1.png", None)])
        self.c.go_live_entry(self.entry)
        before = self.c.session.slides
        self.c.set_deck_transition(other, "dissolve", 500)
        self.assertEqual(self.c.session.slides, before)

    def test_bad_requests_are_reported_and_change_nothing(self):
        for args in ((999, "dissolve", 500), (self.deck, "spin", 500), (self.deck, "dissolve", 2500),
                     (self.deck, "dissolve", 130)):
            with self.assertRaises(ControllerError, msg=str(args)):
                self.c.set_deck_transition(*args)
        row = self.db.get_presentation(self.deck)
        self.assertEqual((row["transition"], row["transition_ms"]), ("none", 500))

    def test_one_change_is_one_notification(self):
        seen = []
        self.c.subscribe(lambda: seen.append(1))
        self.c.set_deck_transition(self.deck, "dissolve", 500)
        self.assertEqual(len(seen), 1)

    def test_the_overview_lists_each_decks_setting(self):
        self.c.set_deck_transition(self.deck, "dissolve", 900)
        deck = self.c.library_overview()["decks"][0]
        self.assertEqual((deck["transition"], deck["transition_ms"]), ("dissolve", 900))

    def test_a_song_never_has_a_transition(self):
        self.c.set_deck_transition(self.deck, "dissolve", 500)
        self.c.go_live_entry(next(e for e in self.c.search_library("Song") if e.kind == "song"))
        self.assertEqual({s.transition for s in self.c.session.slides}, {"none"})


class PayloadTests(unittest.TestCase):
    def slides(self):
        def image(n, kind="dissolve"):
            return Slide(kind="image", item_type="presentation", source_item_id=1, label=f"Slide {n}",
                         image_path=f"d/{n}.png", transition=kind, transition_ms=600)
        return [image(1), image(2), Slide(kind="lyrics", item_type="song", source_item_id=2, text="la"), image(3)]

    def live(self):
        session = LiveSession(self.slides())
        return session

    def payload(self, layout, session):
        return build_payload(session.state(), Output("x", layout))

    def test_only_the_projector_is_marked_as_drawing_transitions(self):
        self.assertEqual([n for n, l in LAYOUTS.items() if l.transitions], ["projector"])
        session = self.live()
        session.go_to(1)
        projector = self.payload("projector", session)
        self.assertTrue(projector["transitions"])
        for name in LAYOUTS:
            if name != "projector":
                data = self.payload(name, session)
                self.assertNotIn("transitions", data, name)
                self.assertNotIn("preload", data, name)

    def test_the_slide_says_how_it_should_arrive(self):
        session = self.live()
        session.go_to(1)
        base = self.payload("projector", session)["base"]
        self.assertEqual((base["transition"], base["transition_ms"]), ("dissolve", 600))

    def test_the_pictures_either_side_are_listed_for_preloading_but_not_text_slides(self):
        session = self.live()
        session.go_to(1)                                  # next is a song (no picture); previous is slide 1
        self.assertEqual(self.payload("projector", session)["preload"], ["d/1.png"])
        session.go_to(0)
        self.assertEqual(self.payload("projector", session)["preload"], ["d/2.png"])
        session.go_to(2)
        self.assertEqual(self.payload("projector", session)["preload"], ["d/3.png", "d/2.png"])
        session.clear()
        self.assertEqual(self.payload("projector", session)["preload"], ["d/1.png"])   # the first slide is next

    def test_nothing_is_preloaded_while_blanked_and_the_list_has_no_repeats(self):
        session = LiveSession([Slide(kind="image", item_type="presentation", source_item_id=1,
                                     image_path="same.png") for _ in range(3)])
        session.go_to(1)
        self.assertEqual(self.payload("projector", session)["preload"], ["same.png"])
        session.set_blank(True)
        self.assertEqual(self.payload("projector", session)["preload"], [])

    def test_public_payloads_still_carry_no_notes(self):
        session = LiveSession([Slide(kind="image", item_type="presentation", source_item_id=1,
                                     image_path="a.png", notes="secret", transition="dissolve", transition_ms=500)])
        session.go_to(0)
        self.assertNotIn("secret", json.dumps(self.payload("projector", session)))


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.deck = make()
        self.addCleanup(self.db.close)
        self.api = OperatorApi(self.c)

    def test_set_it_through_the_api_and_read_it_back(self):
        self.api.call("deck_transition", {"id": self.deck, "transition": "circle_out", "milliseconds": 1200})
        deck = self.api.manage()["decks"][0]
        self.assertEqual((deck["transition"], deck["transition_ms"]), ("circle_out", 1200))

    def test_bad_requests_are_refused(self):
        bad = ({}, {"id": self.deck}, {"id": self.deck, "transition": "dissolve"},
               {"id": self.deck, "transition": "dissolve", "milliseconds": "500"},
               {"id": self.deck, "transition": "dissolve", "milliseconds": 99},
               {"id": self.deck, "transition": "nope", "milliseconds": 500},
               {"id": 999, "transition": "dissolve", "milliseconds": 500})
        for args in bad:
            with self.assertRaises(ApiError, msg=str(args)):
                self.api.call("deck_transition", args)


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageLogicTests(unittest.TestCase):
    def js(self, file, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / file)], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    @staticmethod
    def payload(path="a.png", kind="dissolve", ms=500, transitions=True, base=True):
        slide = dict(kind="image", item_type="presentation", source_item_id=1, text="", label="Slide",
                     reference="Deck", image_path=path, continued=False, verse_numbers=[],
                     transition=kind, transition_ms=ms)
        return dict(transitions=transitions, base=slide if base else None, overlay=None)

    def plan(self, prev, nxt):
        return self.js("output.js", f"m.planTransition({json.dumps(prev)}, {json.dumps(nxt)})")

    def test_a_new_slide_with_a_transition_is_animated(self):
        self.assertEqual(self.plan(self.payload("a.png"), self.payload("b.png", "circle_in", 800)),
                         {"type": "circle_in", "ms": 800})

    def test_nothing_is_animated_when_it_should_just_change(self):
        a, b = self.payload("a.png"), self.payload("b.png")
        self.assertIsNone(self.plan(None, b))                                    # first draw of the page
        self.assertIsNone(self.plan(a, self.payload("b.png", "none")))
        self.assertIsNone(self.plan(a, self.payload("b.png", "dissolve", 0)))
        self.assertIsNone(self.plan(a, self.payload("b.png", "spin")))
        self.assertIsNone(self.plan(a, self.payload("b.png", transitions=False)))  # not the projector
        self.assertIsNone(self.plan(a, self.payload(base=False)))                 # cleared or blanked
        self.assertIsNone(self.plan(a, self.payload("a.png")))                    # same slide (a verse came or went)

    def test_a_transition_is_only_for_slides_of_the_same_slideshow(self):
        deck_b = self.payload("b.png")
        deck_b["base"]["source_item_id"] = 2                                      # another slideshow in the service
        self.assertIsNone(self.plan(self.payload("a.png"), deck_b))
        song = self.payload("a.png")
        song["base"].update(item_type="song", kind="lyrics", image_path=None, source_item_id=3, transition=None)
        self.assertIsNone(self.plan(song, self.payload("b.png")))                 # arriving from a song
        self.assertEqual(self.plan(self.payload("a.png"), self.payload("b.png"))["type"], "dissolve")  # slide to slide

    def test_coming_up_from_nothing_is_animated(self):
        self.assertEqual(self.plan(self.payload(base=False), self.payload("b.png"))["type"], "dissolve")

    def test_the_length_is_capped_at_two_seconds(self):
        self.assertEqual(self.plan(self.payload("a.png"), self.payload("b.png", "dissolve", 99999))["ms"], 2000)

    def test_what_moves_for_each_transition(self):
        dissolve = self.js("output.js", "m.transitionSteps('dissolve')")
        self.assertEqual(dissolve["moves"], "new")
        self.assertEqual(dissolve["keyframes"], [{"opacity": 0}, {"opacity": 1}])
        out = self.js("output.js", "m.transitionSteps('circle_out')")
        self.assertEqual(out["moves"], "new")
        self.assertTrue(out["keyframes"][0]["clipPath"].startswith("circle(0%"))
        inward = self.js("output.js", "m.transitionSteps('circle_in')")
        self.assertEqual(inward["moves"], "old")
        self.assertTrue(inward["keyframes"][1]["clipPath"].startswith("circle(0%"))
        self.assertIsNone(self.js("output.js", "m.transitionSteps('none')"))

    def test_the_pages_know_the_same_types_as_the_server(self):
        self.assertEqual(sorted(self.js("output.js", "m.TRANSITION_TYPES")), sorted(k for k in TRANSITIONS if k != "none"))
        self.assertEqual([c["value"] for c in self.js("operator.js", "m.TRANSITION_CHOICES")], list(TRANSITIONS))

    def test_typed_seconds_become_tenths_of_a_second_or_are_refused(self):
        good = {"0": 0, "0.5": 500, "1,2": 1200, " 2 ": 2000, "0.04": 0, "0.06": 100, "1.25": 1300}
        for text, ms in good.items():
            self.assertEqual(self.js("operator.js", f"m.secondsToMs({json.dumps(text)})"), ms, text)
        for text in ("", "abc", "-1", "2.1", "3", "1e2", None):
            self.assertIsNone(self.js("operator.js", f"m.secondsToMs({json.dumps(text)})"), str(text))

    def test_the_deck_line_describes_its_transition(self):
        self.assertEqual(self.js("operator.js", "m.transitionText('dissolve', 500)"), "Dissolve, 0.5 s")
        self.assertEqual(self.js("operator.js", "m.transitionText('circle_out', 1200)"), "Circle wipe, out, 1.2 s")
        self.assertEqual(self.js("operator.js", "m.transitionText('none', 500)"), "No transition")
        self.assertEqual(self.js("operator.js", "m.transitionText('dissolve', 0)"), "No transition")
        self.assertEqual(self.js("operator.js", "m.msToSeconds(2000)"), "2.0")


if __name__ == "__main__":
    unittest.main()
