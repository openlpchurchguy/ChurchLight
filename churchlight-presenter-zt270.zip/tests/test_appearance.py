# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The operator page's light/dark theme, text size, high contrast and accent color."""
import json
import re
import shutil
import subprocess
import unittest
from itertools import product
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
CSS = (STATIC / "operator.css").read_text(encoding="utf-8")
HTML = (STATIC / "operator.html").read_text(encoding="utf-8")


def _blocks():
    """The `:root[...] { --x: y; }` blocks of the style sheet, in file order, as (attributes, variables)."""
    for match in re.finditer(r"(:root(?:\[[^\]]+\])*)\s*\{([^}]*)\}", CSS):
        attrs = dict(re.findall(r'\[data-([a-z]+)="([^"]+)"\]', match.group(1)))
        variables = dict(re.findall(r"(--[a-z0-9-]+)\s*:\s*([^;]+);", match.group(2)))
        yield attrs, variables


def palette(**chosen):
    """The variables in force for a combination such as theme=light, contrast=high, accent=green."""
    result = {}
    for attrs, variables in _blocks():
        if all(chosen.get(key) == value for key, value in attrs.items()):
            result.update({k: v.strip() for k, v in variables.items()})
    return result


def _channel(value):
    value /= 255
    return value / 12.92 if value <= 0.03928 else ((value + 0.055) / 1.055) ** 2.4


def luminance(color):
    color = color.lstrip("#")
    r, g, b = (int(color[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * _channel(r) + 0.7152 * _channel(g) + 0.0722 * _channel(b)


def contrast(a, b):
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


# (text color, background color, least contrast) for the pairs the page really draws
PAIRS = [
    ("--text", "--bg", 4.5), ("--text", "--panel", 4.5), ("--text", "--panel2", 4.5), ("--text", "--hover", 4.5),
    ("--muted", "--bg", 4.5), ("--muted", "--panel", 4.5), ("--muted", "--panel2", 4.5),
    ("--accent", "--panel", 4.5), ("--accent", "--bg", 4.5), ("--accent-text", "--accent", 4.5),
    ("--accent-text", "--accent-hover", 4.5),
    ("--live-text", "--live", 4.5), ("--warn-text", "--warn", 4.5), ("--ok-text", "--ok", 4.5),
    ("--warn-ink", "--panel", 4.5), ("--ok-ink", "--panel", 4.5), ("--bad", "--panel", 4.5),
    ("--text", "--msg-bg", 4.5), ("--text", "--danger-hover", 4.5),
    ("--slide-text", "--slide-bg", 4.5), ("--slide-muted", "--slide-bg", 4.5), ("--notes", "--slide-bg", 4.5),
    ("--ok-ink", "--bg", 4.5),
]


class ContrastTests(unittest.TestCase):
    def test_every_combination_keeps_text_readable(self):
        for theme, contrast_mode, accent in product(("dark", "light"), ("normal", "high"),
                                                    ("blue", "green", "purple", "orange")):
            colors = palette(theme=theme, contrast=contrast_mode, accent=accent)
            for foreground, background, least in PAIRS:
                with self.subTest(theme=theme, contrast=contrast_mode, accent=accent, pair=(foreground, background)):
                    self.assertIn(foreground, colors)
                    self.assertIn(background, colors)
                    self.assertGreaterEqual(contrast(colors[foreground], colors[background]), least,
                                            f"{foreground} on {background}: {colors[foreground]} / {colors[background]}")

    def test_high_contrast_is_stronger_than_normal(self):
        for theme in ("dark", "light"):
            normal = palette(theme=theme, contrast="normal", accent="blue")
            high = palette(theme=theme, contrast="high", accent="blue")
            self.assertGreaterEqual(contrast(high["--text"], high["--panel"]), 15)
            self.assertGreaterEqual(contrast(high["--muted"], high["--panel"]), contrast(normal["--muted"], normal["--panel"]))
            self.assertGreaterEqual(contrast(high["--border"], high["--panel"]), 3)

    def test_the_slide_previews_stay_dark_in_both_themes(self):
        for theme in ("dark", "light"):
            self.assertLess(luminance(palette(theme=theme)["--slide-bg"]), 0.02)

    def test_no_stray_colors_are_left_in_the_rules(self):
        body = CSS[CSS.index("* { box-sizing"):]
        # only transparent shadows and the black behind the preview frames are allowed outside the variables
        found = set(re.findall(r"#[0-9a-fA-F]{3,6}\b", body)) - {"#000"}
        swatches = {"#3b82f6", "#22a06b", "#8b6cf0", "#f08a24"}
        self.assertEqual(found - swatches, set())


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class LookScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "look.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_defaults_for_nothing_or_junk(self):
        default = {"theme": "auto", "size": "medium", "contrast": False, "accent": "blue"}
        for raw in ("null", "'{bad'", "''", "'[]'", "42", "'{\"theme\":\"neon\",\"size\":9}'"):
            self.assertEqual(self.js(f"m.parseLook({raw})"), default, raw)

    def test_a_saved_choice_is_kept_and_bad_parts_dropped(self):
        saved = '{"theme":"light","size":"large","contrast":true,"accent":"orange"}'
        self.assertEqual(self.js(f"m.parseLook('{saved}')"),
                         {"theme": "light", "size": "large", "contrast": True, "accent": "orange"})
        self.assertEqual(self.js("m.parseLook('{\"theme\":\"dark\",\"accent\":\"pink\"}')")["accent"], "blue")

    def test_auto_follows_the_computer(self):
        self.assertEqual(self.js("m.resolveTheme('auto', true)"), "light")
        self.assertEqual(self.js("m.resolveTheme('auto', false)"), "dark")
        self.assertEqual(self.js("m.resolveTheme('dark', true)"), "dark")

    def test_attributes_set_on_the_page(self):
        attrs = self.js("m.attributesFor(m.parseLook('{\"contrast\":true,\"theme\":\"auto\"}'), true)")
        self.assertEqual(attrs, {"data-theme": "light", "data-size": "medium", "data-contrast": "high", "data-accent": "blue"})


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class CustomAccentTests(LookScriptTests):
    SAMPLES = ["#ff0000", "#ffff00", "#00ff00", "#0000ff", "#000000", "#ffffff", "#808080", "#ff00ff", "#00ffff",
               "#123456", "#fedcba", "#8b6cf0", "#f08a24", "#220000", "#fffff0"]

    def test_any_colour_is_fitted_so_every_pair_stays_readable(self):
        for theme in ("dark", "light"):
            for contrast_mode in ("normal", "high"):
                base = palette(theme=theme, contrast=contrast_mode, accent="blue")
                for hex_ in self.SAMPLES:
                    fit = self.js(f"m.fitAccent('{hex_}', '{theme}')")
                    with self.subTest(theme=theme, contrast=contrast_mode, colour=hex_):
                        self.assertGreaterEqual(contrast(fit["accent"], base["--panel"]), 4.5)       # as text on a panel
                        self.assertGreaterEqual(contrast(fit["accent"], base["--bg"]), 4.5)
                        self.assertGreaterEqual(contrast(fit["text"], fit["accent"]), 4.5)           # words on a button
                        self.assertGreaterEqual(contrast(fit["text"], fit["hover"]), 4.5)

    def test_a_colour_that_already_works_is_left_alone(self):
        fit = self.js("m.fitAccent('#d90000', 'light')")
        self.assertEqual(fit["accent"], "#d90000")
        self.assertFalse(fit["adjusted"])
        self.assertTrue(self.js("m.fitAccent('#ffff00', 'light')")["adjusted"])

    def test_the_hue_is_kept_when_a_colour_is_adjusted(self):
        fit = self.js("m.fitAccent('#0000ff', 'dark')")["accent"]
        r, g, b = (int(fit[i:i + 2], 16) for i in (1, 3, 5))
        self.assertGreater(b, r)
        self.assertEqual(r, g)                                                                  # still a blue

    def test_a_chosen_colour_is_stored_and_marked_custom_and_junk_is_dropped(self):
        self.assertEqual(self.js("m.parseLook('{\"accent\":\"#AA33CC\"}')")["accent"], "#aa33cc")
        self.assertEqual(self.js("m.parseLook('{\"accent\":\"#abc\"}')")["accent"], "blue")
        self.assertEqual(self.js("m.parseLook('{\"accent\":\"red\"}')")["accent"], "blue")
        attrs = self.js("m.attributesFor(m.parseLook('{\"accent\":\"#aa33cc\"}'), false)")
        self.assertEqual(attrs["data-accent"], "custom")


class WiringTests(unittest.TestCase):
    def test_the_page_loads_the_look_script_first_and_has_a_picker(self):
        self.assertLess(HTML.index("/static/look.js"), HTML.index("/static/operator.js"))
        self.assertIn('id="btn-look"', HTML)
        self.assertIn('id="look-panel"', HTML)

    def test_the_output_pages_do_not_load_the_look_script(self):
        self.assertNotIn("look.js", (STATIC / "output.html").read_text(encoding="utf-8"))


class FontTests(unittest.TestCase):
    def test_the_style_sheet_names_the_fonts_with_system_fallbacks(self):
        self.assertIn('--font-body: "Atkinson Hyperlegible", "Segoe UI"', CSS)
        self.assertIn('--font-head: "Bricolage Grotesque", "Segoe UI"', CSS)
        for name in ("AtkinsonHyperlegible-Regular.ttf", "AtkinsonHyperlegible-Bold.ttf", "BricolageGrotesque.ttf"):
            self.assertIn(f"/static/fonts/{name}", CSS)
        self.assertIn("h1, h2, h3 { font-family: var(--font-head); font-weight: 700; }", CSS)

    def test_pages_may_load_fonts_from_this_server_only(self):
        # Output pages load the bundled theme fonts (themefonts.css); nothing may come from elsewhere.
        from churchlight_presenter.server.app import OPERATOR_CSP, PAGE_CSP
        for policy in (OPERATOR_CSP, PAGE_CSP):
            self.assertIn("font-src 'self';", policy + ";")
            self.assertNotIn("http", policy.replace("http://localhost:*", "").replace("http://127.0.0.1:*", ""))   # only this computer's own sound frame
            self.assertIn("default-src 'none'", policy)

    def test_the_bundled_font_files_and_licenses_are_present(self):
        folder = STATIC / "fonts"
        for name in ("AtkinsonHyperlegible-Regular.ttf", "AtkinsonHyperlegible-Bold.ttf", "BricolageGrotesque.ttf"):
            data = (folder / name).read_bytes()
            self.assertEqual(data[:4], b"\x00\x01\x00\x00", name)          # a TrueType font file
            self.assertGreater(len(data), 30000, name)
        for name in ("OFL-AtkinsonHyperlegible.txt", "OFL-BricolageGrotesque.txt"):
            text = (folder / name).read_text(encoding="utf-8")
            self.assertIn("SIL OPEN FONT LICENSE Version 1.1", text, name)
            self.assertIn("Copyright", text, name)

    def test_the_font_folder_explains_what_to_put_in_it(self):
        readme = (STATIC / "fonts" / "README.md").read_text(encoding="utf-8")
        for name in ("AtkinsonHyperlegible-Regular.ttf", "AtkinsonHyperlegible-Bold.ttf", "BricolageGrotesque.ttf", "OFL"):
            self.assertIn(name, readme)


class FontRouteTests(unittest.TestCase):
    def setUp(self):
        import http.client
        from churchlight_presenter.core.live import LiveSession
        from churchlight_presenter.core.outputs import Output
        from churchlight_presenter.server.app import OutputServer
        self.dummy = STATIC / "fonts" / "ZzTestFont.ttf"
        self.dummy.write_bytes(b"\x00\x01\x00\x00fake")
        self.addCleanup(lambda: self.dummy.unlink(missing_ok=True))
        self.server = OutputServer(LiveSession(), [Output("projector", "projector")]).start()
        self.addCleanup(self.server.close)
        host, port = self.server.address[:2]
        self.conn = http.client.HTTPConnection(host, port)
        self.addCleanup(self.conn.close)

    def get(self, path):
        self.conn.request("GET", path)
        response = self.conn.getresponse()
        return response.status, response.getheader("Content-Type"), response.read()

    def test_a_font_file_is_served_with_its_type(self):
        status, kind, body = self.get("/static/fonts/ZzTestFont.ttf")
        self.assertEqual((status, kind), (200, "font/ttf"))
        self.assertTrue(body.endswith(b"fake"))

    def test_missing_odd_and_traversing_names_are_not_found(self):
        for path in ("/static/fonts/Nope.ttf", "/static/fonts/README.md", "/static/fonts/..%2Foperator.js",
                     "/static/fonts/a.TXT", "/static/fonts/.hidden.ttf", "/static/fonts/sub/x.ttf"):
            self.assertEqual(self.get(path)[0], 404, path)


if __name__ == "__main__":
    unittest.main()
