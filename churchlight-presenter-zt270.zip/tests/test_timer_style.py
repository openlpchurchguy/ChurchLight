# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The countdown and alert style: validation, saving, the payloads, the output pages, and the Broadcast Integration area."""
import json
import shutil
import subprocess
import time
import unittest
from pathlib import Path

from churchlight_presenter.core import timerstyle
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import ControllerError, OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
OUTPUTS = [Output("projector", "projector"), Output("stage", "stage"), Output("confidence", "confidence")]


def until(check, seconds=5):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


class StyleRulesTests(unittest.TestCase):
    def test_defaults_pass_their_own_rules(self):
        timerstyle.check(dict(timerstyle.DEFAULTS), {})
        self.assertEqual(timerstyle.clean({}), timerstyle.DEFAULTS)

    def test_bad_values_are_refused_by_name(self):
        for change, word in (({"size": 3}, "size"), ({"size": 99}, "size"), ({"color": "red"}, "color"),
                             ({"projector_mode": "both"}, "projector mode"), ({"alert_position": "center"}, "alert position"),
                             ({"bar_every": 3}, "bar every"), ({"bar_text": "x" * 121}, "bar text"),
                             ({"clock_w": 1}, "clock w"), ({"position": "top"}, "position"), ({"nonsense": 1}, "nonsense")):
            with self.assertRaises(ValueError) as caught:
                timerstyle.check(change, {})
            self.assertIn(word, str(caught.exception))

    def test_a_box_must_stay_on_the_screen(self):
        with self.assertRaises(ValueError) as caught:
            timerstyle.check({"bar_x": 60, "bar_w": 60}, {})
        self.assertIn("bar box", str(caught.exception))
        self.assertEqual(timerstyle.check({"bar_x": 50, "bar_w": 50}, {}), {"bar_x": 50, "bar_w": 50})
        saved = {"clock_x": 90, "clock_w": 30}                      # damaged: goes back to the standard place
        cleaned = timerstyle.clean(saved)
        self.assertEqual((cleaned["clock_x"], cleaned["clock_w"]), (timerstyle.DEFAULTS["clock_x"], timerstyle.DEFAULTS["clock_w"]))

    def test_both_bar_wordings_may_be_empty_which_means_the_bar_says_nothing(self):
        self.assertEqual(timerstyle.check({"bar_zero_text": "  "}, {}), {"bar_zero_text": ""})
        self.assertEqual(timerstyle.check({"bar_text": "  "}, {}), {"bar_text": ""})

    def test_the_first_versions_saved_look_is_dropped_not_misread(self):
        old = {"size": 30, "label_size": 8, "position": "top", "color": "#123456"}
        cleaned = timerstyle.clean(old)
        self.assertEqual((cleaned["size"], cleaned["label_size"]), (timerstyle.DEFAULTS["size"], timerstyle.DEFAULTS["label_size"]))
        self.assertEqual(cleaned["color"], "#123456")
        self.assertNotIn("position", cleaned)

    def test_unknown_or_broken_saved_values_fall_back_to_the_standard(self):
        self.assertEqual(timerstyle.clean({"size": 500, "color": "#123456", "zzz": 1})["size"], timerstyle.DEFAULTS["size"])
        self.assertEqual(timerstyle.clean({"color": "#123456"})["color"], "#123456")


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, OUTPUTS)

    def test_changes_are_kept_and_reset(self):
        self.c.set_timer_style({"color": "#00ff00", "size": 30})
        self.assertEqual(self.c.timer_style()["color"], "#00ff00")
        again = OperatorController(self.db, OUTPUTS)
        self.assertEqual(again.timer_style()["size"], 30)
        self.c.reset_timer_style()
        self.assertEqual(self.c.timer_style(), timerstyle.DEFAULTS)

    def test_a_bad_change_changes_nothing(self):
        before = dict(self.c.timer_style())
        with self.assertRaises(ControllerError):
            self.c.set_timer_style({"size": 2, "color": "#00ff00"})
        with self.assertRaises(ControllerError):
            self.c.set_timer_style({"bar_x": 70, "bar_w": 50})
        self.assertEqual(self.c.timer_style(), before)

    def test_a_box_moved_in_two_steps_is_checked_against_what_is_saved(self):
        self.c.set_timer_style({"bar_x": 40, "bar_w": 60})            # fits
        with self.assertRaises(ControllerError):
            self.c.set_timer_style({"bar_x": 50})                    # would now run off the right edge

    def test_payloads_carry_the_style(self):
        self.c.new_service("Sunday")
        self.c.set_timer_style({"size": 30, "speaker_size": 10, "alert_bg": "#ff0000", "projector_mode": "bar",
                                "bar_text": "{minutes} to go", "clock_x": 10})
        self.c.start_countdown(minutes=2)
        self.c.set_alert("Hi")
        pays = self.c.payloads()
        style = pays["projector"]["countdown"]["style"]
        self.assertEqual((style["mode"], style["size"], style["box"]["x"], style["bar"]["text"]), ("bar", 30, 10, "{minutes} to go"))
        self.assertEqual(pays["stage"]["countdown"]["style"]["size"], 10)
        self.assertEqual(pays["stage"]["message_style"]["bg"], "#ff0000")


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class NodeTests(unittest.TestCase):
    def js(self, expression, page="operator.js"):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / page)], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_the_preview_style_matches_the_servers(self):
        for values in (dict(timerstyle.DEFAULTS),
                       dict(timerstyle.DEFAULTS, size=31, speaker_size=9, label_size=13, alert_size=5, projector_mode="bar",
                            speaker_position="bottom-left", alert_position="top", backdrop="#11223380", color="#abcdef",
                            clock_x=5.5, clock_w=20.5, bar_every=5, bar_text="{minutes} left", bar_zero_text="", bar_speed=9,
                            bar_radius=20, bar_bg="#11223344")):
            got = self.js(f"m.timerPreviewStyles({json.dumps(values)})")
            self.assertEqual(got["projector"], timerstyle.projector_style(values))
            self.assertEqual(got["speaker"], timerstyle.speaker_style(values))
            self.assertEqual(got["alert"], timerstyle.alert_style(values))

    def test_color_and_opacity_round_trip(self):
        self.assertEqual(self.js("m.colorWithOpacity('#112233',100)"), "#112233")
        self.assertEqual(self.js("m.colorWithOpacity('#112233',0)"), "#11223300")
        self.assertEqual(self.js("m.splitOpacity('#11223300')"), {"hex": "#112233", "percent": 0})
        self.assertEqual(self.js("m.splitOpacity('#fff')"), {"hex": "#ffffff", "percent": 100})

    def test_dragging_a_box_moves_and_resizes_it_on_the_screen(self):
        rect = "{x:30,y:40,w:40,h:20}"
        self.assertEqual(self.js(f"m.dragRect({rect}, 'move', 10, -5)"), {"x": 40, "y": 35, "w": 40, "h": 20})
        self.assertEqual(self.js(f"m.dragRect({rect}, 'move', 500, 500)"), {"x": 60, "y": 80, "w": 40, "h": 20})       # stops at the edge
        self.assertEqual(self.js(f"m.dragRect({rect}, 'e', 10, 99)"), {"x": 30, "y": 40, "w": 50, "h": 20})
        self.assertEqual(self.js(f"m.dragRect({rect}, 'w', 10, 0)"), {"x": 40, "y": 40, "w": 30, "h": 20})
        self.assertEqual(self.js(f"m.dragRect({rect}, 'nw', -10, -10)"), {"x": 20, "y": 30, "w": 50, "h": 30})
        self.assertEqual(self.js(f"m.dragRect({rect}, 'se', 500, 500)"), {"x": 30, "y": 40, "w": 70, "h": 60})
        self.assertEqual(self.js(f"m.dragRect({rect}, 'e', -500, 0)")["w"], 5)                                      # never smaller than 5 x 3
        self.assertEqual(self.js(f"m.dragRect({rect}, 's', 0, -500)")["h"], 3)

    def test_the_bar_says_minutes_with_the_right_word(self):
        self.assertEqual(self.js("m.barMessage('{minutes} until service begins', 10)", "output.js"), "10 minutes until service begins")
        self.assertEqual(self.js("m.barMessage('{minutes} until service begins', 1)", "output.js"), "1 minute until service begins")
        self.assertEqual(self.js("m.barMessage('Soon: {minutes}!', 2)", "output.js"), "Soon: 2 minutes!")

    def test_the_bar_pops_up_at_the_start_each_whole_minute_and_at_zero(self):
        script = """(() => {
          const st = {lastM: null, zeroDone: false}; const seen = [];
          for (let left = 190000; left >= -2000; left -= 500) {
            const due = m.barDue(st, left, 1);
            if (due) seen.push([left, due.zero ? 'zero' : due.minutes]);
          }
          return seen; })()"""
        got = self.js(script, "output.js")
        self.assertEqual(got, [[190000, 4], [180000, 3], [120000, 2], [60000, 1], [0, "zero"]])

    def test_every_five_minutes_and_a_late_start(self):
        script = """(() => {
          const st = {lastM: null, zeroDone: false}; const seen = [];
          for (let left = 12.5 * 60000; left >= 0; left -= 1000) {
            const due = m.barDue(st, left, 5);
            if (due) seen.push(due.zero ? 'zero' : due.minutes);
          }
          return seen; })()"""
        self.assertEqual(self.js(script, "output.js"), [13, 10, 5, "zero"])


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, OUTPUTS)
        self.c.new_service("Sunday")
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            self.browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(self.browser.close)
        self.base = self.server.url.rstrip("/")

    def output(self):
        page = self.browser.new_page(viewport={"width": 960, "height": 540})
        page.goto(self.base + "/view/projector")
        return page

    def test_the_big_clock_fills_its_box_on_the_real_output_page(self):
        self.c.set_timer_style({"color": "#00ff00", "backdrop": "#336699", "clock_x": 10, "clock_y": 20, "clock_w": 50, "clock_h": 40})
        page = self.output()
        self.c.start_countdown(minutes=5)
        page.wait_for_selector("#cl-countdown .cd-time", state="visible")
        self.assertIn("rect", page.get_attribute("#cl-countdown", "class"))
        box = page.evaluate("(() => { const r = document.querySelector('#cl-countdown .cd-box').getBoundingClientRect(); return [r.left, r.top, r.width, r.height]; })()")
        self.assertEqual([round(n) for n in box], [96, 108, 480, 216])           # 10%, 20%, 50% and 40% of 960 x 540
        self.assertEqual(page.evaluate("getComputedStyle(document.querySelector('#cl-countdown .cd-time')).color"), "rgb(0, 255, 0)")
        inside = page.evaluate("(() => { const b = document.querySelector('#cl-countdown .cd-box').getBoundingClientRect(); const t = document.querySelector('#cl-countdown .cd-time').getBoundingClientRect(); return t.left >= b.left - 1 && t.right <= b.right + 1 && t.top >= b.top - 1 && t.bottom <= b.bottom + 1; })()")
        self.assertTrue(inside)

    def test_a_long_time_shrinks_to_fit_the_box(self):
        self.c.set_timer_style({"clock_w": 12, "clock_h": 20, "size": 90})
        page = self.output()
        self.c.start_countdown(minutes=90)                                       # 1:30:00 is wider than 0:00
        page.wait_for_selector("#cl-countdown .cd-time", state="visible")
        self.assertTrue(until(lambda: page.evaluate("(() => { const b = document.querySelector('#cl-countdown .cd-box').getBoundingClientRect(); const t = document.querySelector('#cl-countdown .cd-time').getBoundingClientRect(); return t.right <= b.right + 1 && t.left >= b.left - 1; })()")))

    def test_the_bar_mode_hides_the_clock_and_scrolls_the_words(self):
        self.c.set_timer_style({"projector_mode": "bar", "bar_text": "{minutes} to go", "bar_speed": 5})
        page = self.output()
        self.c.start_countdown(minutes=5)
        self.assertTrue(until(lambda: page.query_selector("#cl-bar:not([hidden])") is not None, 6))
        self.assertTrue(page.is_hidden("#cl-countdown"))
        self.assertEqual(page.inner_text("#cl-bar .bar-text"), "5 minutes to go")
        first = page.evaluate("document.querySelector('#cl-bar .bar-text').getBoundingClientRect().left")
        time.sleep(0.6)
        second = page.evaluate("document.querySelector('#cl-bar .bar-text').getBoundingClientRect().left")
        self.assertLess(second, first)                                           # it is moving left
        box = page.evaluate("(() => { const r = document.getElementById('cl-bar').getBoundingClientRect(); return [r.left, r.top, r.width, r.height]; })()")
        self.assertEqual([round(n) for n in box], [0, round(540 * 0.88), 960, round(540 * 0.09)])

    def test_stopping_the_countdown_takes_the_bar_away_at_once_and_changing_mode_swaps_them(self):
        self.c.set_timer_style({"projector_mode": "bar"})
        page = self.output()
        self.c.start_countdown(minutes=5)
        self.assertTrue(until(lambda: page.query_selector("#cl-bar:not([hidden])") is not None, 6))
        self.c.set_timer_style({"projector_mode": "clock"})
        self.assertTrue(until(lambda: page.query_selector("#cl-bar") is None))
        self.assertTrue(page.is_visible("#cl-countdown .cd-time"))
        self.c.set_timer_style({"projector_mode": "bar"})
        self.assertTrue(until(lambda: page.query_selector("#cl-bar:not([hidden])") is not None, 6))
        self.c.stop_countdown()
        self.assertTrue(until(lambda: page.query_selector("#cl-bar") is None))

    def operator(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1100})
        page.goto(self.base + "/operator")
        page.click("#tab-broadcast")
        page.click("#ts-proj > summary")                          # the folds start folded every visit
        page.click("#ts-speak > summary")
        page.wait_for_selector("#ts-controls-clock select", state="visible")
        return page

    def test_the_editor_saves_a_change_and_resets(self):
        page = self.operator()
        self.assertGreater(page.locator("#ts-controls-clock input, #ts-controls-clock select").count(), 5)
        slider = page.locator("#ts-controls-clock input[type=range]").first            # clock text size
        slider.evaluate("(n) => { n.value = 40; n.dispatchEvent(new Event('input', {bubbles: true})); n.dispatchEvent(new Event('change', {bubbles: true})); }")
        self.assertTrue(until(lambda: self.c.timer_style()["size"] == 40))
        page.locator("#ts-controls-speaker select").nth(1).select_option("bottom-left")      # the first is the font
        self.assertTrue(until(lambda: self.c.timer_style()["speaker_position"] == "bottom-left"))
        page.click("#ts-reset")
        self.assertTrue(until(lambda: self.c.timer_style() == timerstyle.DEFAULTS))
        self.assertTrue(until(lambda: page.locator("#ts-controls-clock input[type=range]").first.input_value() == str(timerstyle.DEFAULTS["size"])))

    def test_dragging_the_box_on_the_preview_saves_its_place_and_resizing_changes_its_size(self):
        page = self.operator()
        page.wait_for_selector("#ts-rect", state="visible")
        view = page.locator("#ts-proj-view").bounding_box()
        rect = page.locator("#ts-rect").bounding_box()
        cx, cy = rect["x"] + rect["width"] / 2, rect["y"] + rect["height"] / 2
        page.mouse.move(cx, cy)
        page.mouse.down()
        page.mouse.move(cx + view["width"] * 0.10, cy + view["height"] * 0.20, steps=5)
        page.mouse.up()
        self.assertTrue(until(lambda: abs(self.c.timer_style()["clock_x"] - 40) < 1.5 and abs(self.c.timer_style()["clock_y"] - 54) < 1.5))
        handle = page.locator("#ts-rect .h-e").bounding_box()
        hx, hy = handle["x"] + handle["width"] / 2, handle["y"] + handle["height"] / 2
        page.mouse.move(hx, hy)
        page.mouse.down()
        page.mouse.move(hx + view["width"] * 0.10, hy, steps=5)
        page.mouse.up()
        self.assertTrue(until(lambda: abs(self.c.timer_style()["clock_w"] - 50) < 1.5))

    def test_the_bar_editor_has_its_own_box_and_use_this_switches_the_projector(self):
        page = self.operator()
        page.check("input[name=ts-edit][value=bar]")
        self.assertTrue(page.is_visible("#ts-controls-bar"))
        self.assertTrue(page.is_hidden("#ts-controls-clock"))
        view = page.locator("#ts-proj-view").bounding_box()
        rect = page.locator("#ts-rect").bounding_box()
        self.assertAlmostEqual(rect["width"] / view["width"], 1.0, delta=0.02)               # the bar's standard box spans the screen
        self.assertAlmostEqual((rect["y"] - view["y"]) / view["height"], 0.88, delta=0.02)
        text = page.locator("#ts-controls-bar input[type=text]").first
        text.fill("{minutes} to go")
        text.dispatch_event("change")
        self.assertTrue(until(lambda: self.c.timer_style()["bar_text"] == "{minutes} to go"))
        page.click("#ts-use")
        self.assertTrue(until(lambda: self.c.timer_style()["projector_mode"] == "bar"))
        self.assertTrue(until(lambda: page.is_disabled("#ts-use")))

    def test_the_preview_frames_draw_the_clock_the_bar_and_the_speaker_screen(self):
        page = self.operator()
        frames = lambda: [f for f in page.frames if "sandbox" in f.url]
        self.assertTrue(until(lambda: any(f.query_selector("#cl-countdown .cd-box") for f in frames()), 15))
        self.assertTrue(until(lambda: any(f.query_selector("#cl-message") for f in frames()), 15))
        page.check("input[name=ts-edit][value=bar]")
        self.assertTrue(until(lambda: any(f.query_selector("#cl-bar:not([hidden])") for f in frames()), 15))

    def test_the_service_tab_chooses_the_projector_look_and_links_to_the_editor(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1100})
        page.goto(self.base + "/operator")
        page.click("#rb-tab-announce")
        page.select_option("#cd-mode", "bar")
        self.assertTrue(until(lambda: self.c.timer_style()["projector_mode"] == "bar"))
        page.click("#cd-look")
        page.wait_for_selector("#ts-proj", state="visible")
        self.assertTrue(until(lambda: page.is_checked("input[name=ts-edit][value=bar]"), 10))


class StageLookTests(unittest.TestCase):
    def test_an_older_saved_style_starts_the_stage_timer_like_the_projector(self):
        style = timerstyle.clean({"font": "Georgia, serif", "color": "#112233", "ended_color": "#aabbcc"})
        self.assertEqual((style["speaker_font"], style["speaker_color"], style["speaker_ended_color"]),
                         ("Georgia, serif", "#112233", "#aabbcc"))

    def test_after_that_the_two_looks_are_separate(self):
        raw = {"font": "Georgia, serif", "color": "#112233", "speaker_color": "#ff0000"}
        style = timerstyle.clean(raw)
        self.assertEqual(style["speaker_color"], "#ff0000")
        self.assertEqual(timerstyle.speaker_style(raw)["color"], "#ff0000")
        self.assertEqual(timerstyle.projector_style(raw)["color"], "#112233")

    def test_the_stage_fields_are_checked_like_the_others(self):
        with self.assertRaises(ValueError):
            timerstyle.check({"speaker_color": "red"})
        self.assertEqual(timerstyle.check({"speaker_font": "Arial"}), {"speaker_font": "Arial"})
