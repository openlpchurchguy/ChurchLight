# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The verse tray: a chapter held ready, with chosen verses shown as "John 3" over "16) text"."""
import json
import shutil
import re
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output, build_payload
from churchlight_presenter.core.slides import BuildSettings
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

LONG = "A very long verse " * 8          # longer than the 80 character slide limit used below
VERSES = [("John", 3, 1, "One."), ("John", 3, 2, "Two."), ("John", 3, 3, "Three."),
          ("John", 3, 4, "Four."), ("John", 3, 5, LONG.strip()), ("John", 3, 6, "Six."),
          ("John", 4, 1, "Other chapter."), ("Jude", 1, 5, "Only chapter.")]
OUTPUTS = [Output("lower", "lower_third"), Output("stage", "stage")]
STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


def make():
    db = DatabaseManager(":memory:", shared=True)
    t = db.add_translation("DEMO", "Demo")
    db.add_verses(t, VERSES)
    t2 = db.add_translation("ALT", "Alt")
    db.add_verses(t2, [("John", 3, 1, "Alt one."), ("John", 3, 2, "Alt two.")])
    db.add_presentation("Deck", [("d/1.png", "one"), ("d/2.png", "two"), ("d/3.png", None)])
    c = OperatorController(db, OUTPUTS, BuildSettings(scripture_max_chars=80), translation="DEMO")
    return db, c, OperatorApi(c)


def deck_live(controller):
    """Verses only go over a deck, so most tests start with one live."""
    controller.go_live_entry(next(e for e in controller.search_library("Deck") if e.kind == "presentation"))


class TrayControllerTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        deck_live(self.c)

    def test_there_is_no_tray_until_one_is_loaded(self):
        self.assertIsNone(self.c.tray)
        self.assertIsNone(self.api.state()["tray"])
        for call in (lambda: self.c.show_tray_verses([1]), lambda: self.c.tray_step(1)):
            with self.assertRaises(ControllerError):
                call()

    def test_a_whole_chapter_loads_and_is_titled_by_book_and_chapter(self):
        tray = self.c.load_tray("john 3")
        self.assertEqual((tray.reference, tray.title, tray.translation), ("John 3", "John 3", "DEMO"))
        self.assertEqual([n for n, _ in tray.verses], [1, 2, 3, 4, 5, 6])
        self.assertIsNone(self.c.session.state().overlay)          # holding is not showing

    def test_a_range_keeps_its_range_in_the_label_but_the_title_stays_the_chapter(self):
        tray = self.c.load_tray("John 3:2-4")
        self.assertEqual((tray.reference, tray.title), ("John 3:2-4", "John 3"))
        self.assertEqual([n for n, _ in tray.verses], [2, 3, 4])

    def test_the_translation_can_be_chosen_and_bad_references_are_reported(self):
        self.assertEqual(self.c.load_tray("John 3", "ALT").translation, "ALT")
        self.assertEqual(len(self.c.tray.verses), 2)
        before = self.c.tray
        for bad in ("Nonsense 3", "John 99", "John", "John 3:1-2 foo"):
            with self.assertRaises(ControllerError, msg=bad):
                self.c.load_tray(bad)
        self.assertIs(self.c.tray, before)                         # a failed load changes nothing

    def test_a_single_chapter_book_loads(self):
        self.assertEqual(self.c.load_tray("Jude 5").title, "Jude 1")

    def test_one_verse_is_shown_with_its_full_reference_above_it(self):
        self.c.load_tray("John 3")
        slides = self.c.show_tray_verses([2])
        self.assertEqual(len(slides), 1)
        slide = self.c.session.state().overlay
        self.assertEqual((slide.reference, slide.label, slide.title_first), ("John 3:2", "DEMO", True))
        self.assertEqual(slide.segments, ((2, "Two."),))
        self.assertEqual(slide.verse_numbers, (2,))
        self.assertEqual(self.c.tray_live_numbers(), (2,))

    def test_several_verses_share_a_slide_when_they_fit_and_need_not_be_consecutive(self):
        self.c.load_tray("John 3")
        self.c.show_tray_verses([4, 1, 3, 1])                       # order and repeats do not matter
        slide = self.c.session.state().overlay
        self.assertEqual(slide.verse_numbers, (1, 3, 4))
        self.assertEqual(slide.reference, "John 3:1-4")             # the whole reference of what is on the slide
        self.assertEqual(self.c.tray_live_numbers(), (1, 3, 4))

    def test_a_long_verse_splits_into_parts_with_the_same_number_and_title(self):
        self.c.load_tray("John 3")
        slides = self.c.show_tray_verses([5])
        self.assertGreater(len(slides), 1)
        self.assertEqual({s.reference for s in slides}, {"John 3:5"})
        self.assertEqual({s.verse_numbers for s in slides}, {(5,)})
        self.assertEqual([s.continued for s in slides][:2], [False, True])
        self.c.verse_next()
        self.assertTrue(self.c.session.state().overlay.continued)

    def test_a_verse_the_tray_does_not_have_is_refused(self):
        self.c.load_tray("John 3:1-3")
        for numbers in ([9], [1, 9], []):
            with self.assertRaises(ControllerError, msg=str(numbers)):
                self.c.show_tray_verses(numbers)

    def test_showing_a_tray_verse_never_moves_the_slide_underneath(self):
        self.c.new_service("S")
        self.c.add_entry(next(e for e in self.c.search_library("Deck") if e.kind == "presentation"))
        self.c.go_live_service_item(self.c.service_rows()[0].item_id)
        self.c.go_to_slide(1)
        self.c.load_tray("John 3")
        self.c.show_tray_verses([1])
        self.assertEqual(self.c.session.state().base_index, 1)
        self.c.tray_step(1)
        self.assertEqual(self.c.session.state().base_index, 1)

    def test_stepping_goes_to_the_next_and_previous_verse_and_stops_at_the_ends(self):
        self.c.load_tray("John 3:2-4")
        self.c.tray_step(1)                                         # nothing shown yet: the first verse
        self.assertEqual(self.c.tray_live_numbers(), (2,))
        self.c.tray_step(1)
        self.c.tray_step(1)
        self.assertEqual(self.c.tray_live_numbers(), (4,))
        with self.assertRaisesRegex(ControllerError, "last verse"):
            self.c.tray_step(1)
        self.c.tray_step(-1)
        self.c.tray_step(-1)
        self.assertEqual(self.c.tray_live_numbers(), (2,))
        with self.assertRaisesRegex(ControllerError, "first verse"):
            self.c.tray_step(-1)
        with self.assertRaises(ControllerError):
            self.c.tray_step(2)

    def test_stepping_back_with_nothing_shown_is_refused_and_after_a_group_it_uses_the_group_edges(self):
        self.c.load_tray("John 3")
        with self.assertRaises(ControllerError):
            self.c.tray_step(-1)
        self.c.show_tray_verses([2, 3])
        self.c.tray_step(1)
        self.assertEqual(self.c.tray_live_numbers(), (4,))
        self.c.show_tray_verses([2, 3])
        self.c.tray_step(-1)
        self.assertEqual(self.c.tray_live_numbers(), (1,))

    def test_stepping_brings_a_hidden_verse_back_with_the_next_one(self):
        self.c.load_tray("John 3")
        self.c.show_tray_verses([1])
        self.c.hide_verse()
        self.assertEqual(self.c.tray_live_numbers(), ())            # hidden means not live
        self.c.tray_step(1)
        self.assertEqual(self.c.tray_live_numbers(), (2,))

    def test_a_typed_verse_is_not_mistaken_for_a_tray_verse(self):
        self.c.load_tray("John 3")
        self.c.show_verse("John 3:2")
        self.assertEqual(self.c.tray_live_numbers(), ())
        self.c.show_tray_verses([2])
        self.assertEqual(self.c.tray_live_numbers(), (2,))
        self.c.load_tray("John 3", "ALT")                           # same chapter, other Bible
        self.assertEqual(self.c.tray_live_numbers(), ())

    def test_the_tray_survives_clearing_the_screen_and_is_replaced_by_a_new_load(self):
        self.c.load_tray("John 3")
        self.c.show_tray_verses([1])
        self.c.clear()
        self.assertIsNotNone(self.c.tray)
        self.assertEqual(self.c.tray_live_numbers(), ())
        self.c.load_tray("John 4")
        self.assertEqual(self.c.tray.title, "John 4")
        self.c.clear_tray()
        self.assertIsNone(self.c.tray)
        self.c.clear_tray()                                          # clearing twice is harmless

    def test_each_action_is_one_notification(self):
        seen = []
        self.c.subscribe(lambda: seen.append(1))
        self.c.load_tray("John 3")
        self.assertEqual(len(seen), 1)
        self.c.show_tray_verses([1, 2])
        self.assertEqual(len(seen), 2)
        self.c.tray_step(1)
        self.assertEqual(len(seen), 3)
        self.c.clear_tray()
        self.assertEqual(len(seen), 4)

    def test_the_overlay_stays_after_the_service_is_edited(self):
        self.c.new_service("S")
        deck_live(self.c)
        self.c.load_tray("John 3")
        self.c.show_tray_verses([3])
        self.c.add_announcement("Hello", "body")
        self.assertEqual(self.c.tray_live_numbers(), (3,))


class TrayPublicOutputTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        deck_live(self.c)

    def payload(self, output):
        return build_payload(self.c.session.state(), output)

    def test_public_outputs_get_the_title_flag_and_numbered_segments_but_no_notes(self):
        self.c.load_tray("John 3")
        self.c.show_tray_verses([2])
        lower = self.payload(OUTPUTS[0])["overlay"]
        self.assertTrue(lower["title_first"])
        self.assertEqual((lower["reference"], lower["segments"]), ("John 3:2", [[2, "Two."]]))
        self.assertNotIn("notes", lower)
        self.assertTrue(self.payload(OUTPUTS[1])["overlay"]["title_first"])

    def test_typed_verses_get_the_same_look(self):
        self.c.show_verse("John 3:2")
        overlay = self.payload(OUTPUTS[0])["overlay"]
        self.assertTrue(overlay["title_first"])
        self.assertEqual((overlay["reference"], overlay["segments"][0][0]), ("John 3:2", 2))


class TrayApiTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        deck_live(self.c)

    def test_load_show_step_and_clear_through_the_api(self):
        self.assertEqual(self.api.call("tray_load", {"text": "John 3"})["verses"], 6)
        tray = self.api.state()["tray"]
        self.assertEqual((tray["reference"], tray["title"], tray["translation"], tray["live"]),
                         ("John 3", "John 3", "DEMO", []))
        self.assertEqual(tray["verses"][0], [1, "One."])
        json.dumps(self.api.state())
        self.assertEqual(self.api.call("tray_show", {"verses": [1, 2]})["slides"], 1)
        self.assertEqual(self.api.state()["tray"]["live"], [1, 2])
        self.api.call("tray_step", {"delta": 1})
        self.assertEqual(self.api.state()["tray"]["live"], [3])
        self.api.call("tray_clear")
        self.assertIsNone(self.api.state()["tray"])

    def test_load_with_a_translation(self):
        self.api.call("tray_load", {"text": "John 3", "translation": "ALT"})
        self.assertEqual(self.api.state()["tray"]["translation"], "ALT")

    def test_bad_requests_are_refused_in_plain_words(self):
        with self.assertRaises(ApiError):
            self.api.call("tray_show", {"verses": [1]})            # no tray yet
        self.api.call("tray_load", {"text": "John 3"})
        bad = ({}, {"verses": "1"}, {"verses": []}, {"verses": [True]}, {"verses": ["1"]},
               {"verses": [1.5]}, {"verses": list(range(1, 400))}, {"verses": [99]})
        for args in bad:
            with self.assertRaises(ApiError, msg=str(args)):
                self.api.call("tray_show", args)
        for args in ({}, {"delta": "1"}, {"delta": 0}, {"delta": 5}):
            with self.assertRaises(ApiError, msg=str(args)):
                self.api.call("tray_step", args)
        with self.assertRaises(ApiError):
            self.api.call("tray_load", {"text": "Not a book 3"})
        with self.assertRaises(ApiError):
            self.api.call("tray_load", {"text": 5})


class TrayToServiceTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        deck_live(self.c)

    def items(self):
        return [(r["verse_start"], r["verse_end"]) for r in self.db.get_service_items(self.c.service_id)]

    def test_adding_needs_a_service_and_a_tray_and_a_real_verse(self):
        self.c.load_tray("John 3")
        with self.assertRaisesRegex(ControllerError, "service"):
            self.c.add_tray_to_service([1])
        self.c.new_service("S")
        self.c.clear_tray()
        with self.assertRaisesRegex(ControllerError, "tray"):
            self.c.add_tray_to_service([1])
        self.c.load_tray("John 3:1-3")
        for numbers in ([], [9], [1, 9]):
            with self.assertRaises(ControllerError, msg=str(numbers)):
                self.c.add_tray_to_service(numbers)
        self.assertEqual(self.items(), [])

    def test_verses_side_by_side_become_one_item_and_separate_ones_become_several(self):
        self.c.new_service("S")
        self.c.load_tray("John 3")
        ids = self.c.add_tray_to_service([2, 3, 4, 6, 1])
        self.assertEqual(len(ids), 2)
        self.assertEqual(self.items(), [(1, 4), (6, None)])
        self.assertEqual(len(self.c.add_tray_to_service([5])), 1)
        self.assertEqual(self.items()[-1], (5, None))

    def test_the_whole_passage_is_one_item(self):
        self.c.new_service("S")
        self.c.load_tray("John 3")
        self.c.add_tray_to_service([n for n, _ in self.c.tray.verses])
        self.assertEqual(self.items(), [(1, 6)])

    def test_service_items_keep_the_tray_look(self):
        self.c.new_service("S")
        self.c.load_tray("John 3")
        self.c.add_tray_to_service([2, 3])
        slide = self.c.session.slides[0]
        self.assertEqual((slide.reference, slide.title_first, slide.verse_numbers), ("John 3:2-3", True, (2, 3)))
        self.assertEqual(self.c.service_rows()[0].title, "John 3:2-3 (DEMO)")

    def test_typed_verses_added_to_a_service_get_the_same_look(self):
        self.c.new_service("S")
        self.c.add_verse("John 3:2-3")
        slide = self.c.session.slides[0]
        self.assertEqual((slide.reference, slide.title_first), ("John 3:2-3", True))
        self.assertEqual(self.c.service_rows()[0].title, "John 3:2-3 (DEMO)")     # the list still names the range

    def test_adding_never_changes_what_is_live_or_blanks_the_verse(self):
        self.c.new_service("S")
        self.c.add_entry(next(e for e in self.c.search_library("Deck") if e.kind == "presentation"))
        self.c.go_live_service_item(self.c.service_rows()[0].item_id)
        self.c.load_tray("John 3")
        self.c.add_tray_to_service([1])
        self.c.go_to_slide(0)
        self.c.show_tray_verses([2])
        before = (self.c.session.state().base_index, self.c.tray_live_numbers())
        self.c.add_tray_to_service([3])
        self.c.add_tray_to_service([4, 5])
        after = (self.c.session.state().base_index, self.c.tray_live_numbers())
        self.assertEqual(before, after)
        self.assertEqual(self.c.session.state().base.label, "Slide 1")

    def test_one_add_is_one_notification(self):
        self.c.new_service("S")
        self.c.load_tray("John 3")
        seen = []
        self.c.subscribe(lambda: seen.append(1))
        self.c.add_tray_to_service([1, 3, 5])                       # three items, one notification
        self.assertEqual(len(seen), 1)

    def test_the_item_survives_a_reopen(self):
        sid = self.c.new_service("S")
        self.c.load_tray("John 3")
        self.c.add_tray_to_service([2])
        self.c.open_service(sid)
        slide = self.c.session.slides[0]
        self.assertTrue(slide.title_first)
        self.assertEqual(slide.segments, ((2, "Two."),))

    def test_an_item_can_be_added_at_a_position(self):
        self.c.new_service("S")
        self.c.add_announcement("First", "x")
        self.c.add_announcement("Last", "y")
        self.c.load_tray("John 3")
        self.c.add_tray_to_service([2], position=1)
        self.assertEqual([r.item_type for r in self.c.service_rows()], ["announcement", "scripture", "announcement"])

    def test_load_and_add_the_whole_passage_in_one_step(self):
        with self.assertRaises(ApiError):                           # no service: refused, tray untouched
            self.api.call("tray_load", {"text": "John 3", "add": True})
        self.assertIsNone(self.api.state()["tray"])
        self.api.call("new_service", {"title": "S"})
        reply = self.api.call("tray_load", {"text": "John 3", "add": True})
        self.assertEqual((reply["verses"], len(reply["item_ids"])), (6, 1))   # a whole chapter is one item
        self.assertEqual([r.item_type for r in self.c.service_rows()], ["scripture"])
        self.assertIsNotNone(self.api.state()["tray"])
        with self.assertRaises(ApiError):
            self.api.call("tray_load", {"text": "John 3", "add": "yes"})
        self.api.call("tray_load", {"text": "John 3"})              # plain Load adds nothing
        self.assertEqual(len(self.c.service_rows()), 1)

    def test_through_the_api(self):
        self.api.call("tray_load", {"text": "John 3"})
        with self.assertRaises(ApiError):
            self.api.call("tray_add", {"verses": [1]})              # no service yet
        self.api.call("new_service", {"title": "S"})
        reply = self.api.call("tray_add", {"verses": [1, 2, 4]})
        self.assertEqual(len(reply["item_ids"]), 2)
        for args in ({}, {"verses": []}, {"verses": ["1"]}, {"verses": [True]}, {"verses": [99]},
                     {"verses": list(range(1, 400))}):
            with self.assertRaises(ApiError, msg=str(args)):
                self.api.call("tray_add", args)


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class TrayJumpLogicTests(unittest.TestCase):
    def jump(self, text, numbers=(1, 2, 3, 4, 5, 6, 16, 17, 18)):
        script = ("const m=require(process.argv[1]);console.log(JSON.stringify("
                  "m.parseVerseJump(JSON.parse(process.argv[2]), JSON.parse(process.argv[3]))))")
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js"), json.dumps(text),
                              json.dumps(list(numbers))], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_a_single_number_or_a_range_or_a_list_picks_those_verses(self):
        self.assertEqual(self.jump("16"), {"picked": [16], "missing": []})
        self.assertEqual(self.jump("16-18"), {"picked": [16, 17, 18], "missing": []})
        self.assertEqual(self.jump("16, 18"), {"picked": [16, 18], "missing": []})
        self.assertEqual(self.jump("2 4; 6"), {"picked": [2, 4, 6], "missing": []})
        self.assertEqual(self.jump("17\u201318"), {"picked": [17, 18], "missing": []})     # a typographic dash
        self.assertEqual(self.jump("5-3")["picked"], [3, 4, 5])                              # either way round

    def test_numbers_the_passage_lacks_are_reported_not_picked(self):
        self.assertEqual(self.jump("9"), {"picked": [], "missing": ["9"]})
        self.assertEqual(self.jump("16, 40"), {"picked": [16], "missing": ["40"]})
        self.assertEqual(self.jump("40-45"), {"picked": [], "missing": ["40-45"]})
        self.assertEqual(self.jump("5-12")["picked"], [5, 6])                              # the part that exists

    def test_half_typed_and_junk_input_is_quietly_ignored(self):
        for text in ("", "   ", "16-", "-", ",", "abc", "1x", "1-2-3", "9999", None):
            self.assertEqual(self.jump(text)["picked"], [], str(text))
        self.assertEqual(self.jump("16-")["missing"], [])
        self.assertEqual(self.jump("16- 17")["picked"], [17])

    def test_repeats_are_collapsed_and_the_result_is_sorted(self):
        self.assertEqual(self.jump("18 16 16 17-18")["picked"], [16, 17, 18])

    def test_g_goes_to_the_jump_box(self):
        script = "const m=require(process.argv[1]);console.log(JSON.stringify(m.keyAction('g',{typing:false})))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True,
                             timeout=30, check=True)
        self.assertEqual(json.loads(out.stdout), {"focus": "jump"})


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class TrayPageLogicTests(unittest.TestCase):
    def run_js(self, path, expression, *args):
        script = (f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))")
        out = subprocess.run(["node", "-e", script, str(STATIC / path), *args],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    TRAY = {"reference": "John 3", "title": "John 3", "translation": "DEMO",
            "verses": [[1, "One."], [2, "Two."], [3, "Three."], [4, "Four."]], "live": [2]}

    def test_the_output_page_puts_the_reference_first_and_numbers_only_shared_slides(self):
        slide = dict(kind="scripture", item_type="scripture", source_item_id=None, text="Two.",
                     segments=[[2, "Two."]], label="DEMO", reference="John 3:2", verse_numbers=[2],
                     continued=False, image_path=None, theme_id=None, title_first=True)
        payload = dict(schema=1, version=1, output="x", layout="lower_third", audience="public",
                       theme_id=None, blank=False, base=None, overlay=slide)
        vm = self.run_js("output.js", "m.viewModel(JSON.parse(process.argv[2]))", json.dumps(payload))
        view = vm["layers"][0]["view"]
        self.assertTrue(view["titleFirst"])
        self.assertEqual(view["reference"], "John 3:2")
        self.assertEqual(view["parts"], [{"number": None, "text": "Two."}])   # no leading number on a single verse
        slide["verse_numbers"] = [2, 3]
        slide["segments"] = [[2, "Two."], [3, "Three."]]
        payload["overlay"] = slide
        shared = self.run_js("output.js", "m.viewModel(JSON.parse(process.argv[2]))", json.dumps(payload))["layers"][0]["view"]
        self.assertEqual([(p["number"], p["text"]) for p in shared["parts"]], [(None, "Two."), (None, "Three.")])   # only the text
        slide["verse_numbers"] = [2]
        slide["segments"] = [[2, "Two."]]
        slide["title_first"] = False
        payload["overlay"] = slide
        view = self.run_js("output.js", "m.viewModel(JSON.parse(process.argv[2]))",
                           json.dumps(payload))["layers"][0]["view"]
        self.assertFalse(view["titleFirst"])
        self.assertEqual(view["parts"], [{"number": None, "text": "Two."}])   # the old look is unchanged

    def test_a_theme_can_put_the_reference_above_or_below_the_verse(self):
        slide = dict(kind="scripture", item_type="scripture", source_item_id=None, text="For God so loved.",
                     segments=[[16, "For God so loved."]], label="KJV", reference="John 3:16", verse_numbers=[16],
                     continued=False, image_path=None, theme_id=None, title_first=False, style={})
        payload = dict(schema=1, version=1, output="x", layout="lower_third", audience="public",
                       theme_id=None, blank=False, base=None, overlay=slide)

        def view(pos, title_first):
            slide["title_first"] = title_first
            slide["style"] = {} if pos is None else {"reference_pos": pos}
            return self.run_js("output.js", "m.viewModel(JSON.parse(process.argv[2]))",
                               json.dumps(payload))["layers"][0]["view"]

        for pos in (None, "auto"):             # automatic: below one verse, above a passage
            v = view(pos, False)
            self.assertEqual((v["titleFirst"], v["refAbove"]), (False, False))
            v = view(pos, True)
            self.assertEqual((v["titleFirst"], v["refAbove"]), (True, False))
        v = view("above", False)               # forced above a single verse: normal reference size
        self.assertEqual((v["titleFirst"], v["refAbove"]), (False, True))
        v = view("above", True)                # a passage keeps its title look
        self.assertEqual((v["titleFirst"], v["refAbove"]), (True, False))
        v = view("below", True)                # forced below, even for a passage
        self.assertEqual((v["titleFirst"], v["refAbove"]), (False, False))

    def test_balanced_lines_are_asked_for_by_songs_only(self):
        def draws_balance(kind, style):
            slide = dict(kind=kind, item_type="song", source_item_id=None, text="A long line", segments=[],
                         label="", reference="", verse_numbers=[], continued=False, image_path=None,
                         theme_id=None, title_first=False, style=style)
            payload = dict(schema=1, version=1, output="x", layout="projector", audience="public",
                           theme_id=None, blank=False, base=slide, overlay=None)
            view = self.run_js("output.js", "m.viewModel(JSON.parse(process.argv[2]))",
                               json.dumps(payload))["layers"][0]["view"]
            return view["kind"] == "lyrics" and bool(view["style"].get("balance_lines"))
        self.assertTrue(draws_balance("lyrics", {"balance_lines": True}))
        self.assertFalse(draws_balance("lyrics", {"balance_lines": False}))
        self.assertFalse(draws_balance("lyrics", {}))
        self.assertFalse(draws_balance("scripture", {"balance_lines": True}))     # Bible text never balances

    def test_the_confidence_monitor_balances_every_plain_line_unless_its_theme_says_no(self):
        def wants(kind, style, confidence):
            view = json.dumps({"kind": kind, "style": style})
            return self.run_js("output.js", f"m.wantsBalance(JSON.parse(process.argv[2]), {str(confidence).lower()})", view)
        self.assertTrue(wants("lyrics", {}, True))                       # no theme at all: on
        self.assertTrue(wants("scripture", {}, True))                    # Bible text too
        self.assertTrue(wants("lyrics", {"balance_lines": True}, True))
        self.assertFalse(wants("lyrics", {"balance_lines": False}, True))
        self.assertFalse(wants("lyrics", {}, False))                     # the projector still needs the theme to ask
        self.assertFalse(wants("scripture", {"balance_lines": True}, False))

    def test_the_tray_view_marks_live_and_ticked_verses(self):
        view = self.run_js("operator.js", "m.trayView(JSON.parse(process.argv[2]), [3])", json.dumps(self.TRAY))
        self.assertEqual(view["title"], "John 3 (DEMO)")
        self.assertEqual(view["count"], 4)
        self.assertEqual([(r["number"], r["live"], r["checked"]) for r in view["rows"]],
                         [(1, False, False), (2, True, False), (3, False, True), (4, False, False)])
        self.assertIsNone(self.run_js("operator.js", "m.trayView(null, [])"))

    def test_the_tray_key_changes_only_when_the_passage_does(self):
        a = self.run_js("operator.js", "m.trayView(JSON.parse(process.argv[2]), []).key", json.dumps(self.TRAY))
        other = dict(self.TRAY, live=[4])
        b = self.run_js("operator.js", "m.trayView(JSON.parse(process.argv[2]), []).key", json.dumps(other))
        c = self.run_js("operator.js", "m.trayView(JSON.parse(process.argv[2]), []).key",
                        json.dumps(dict(self.TRAY, translation="ALT")))
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)

    def test_ticking_and_shift_runs(self):
        js = self.run_js
        self.assertEqual(js("operator.js", "m.toggleChecked([3], 1)"), [1, 3])
        self.assertEqual(js("operator.js", "m.toggleChecked([1, 3], 3)"), [1])
        self.assertEqual(js("operator.js", "m.checkRun([], [1,2,3,4,5], 2, 4)"), [2, 3, 4])
        self.assertEqual(js("operator.js", "m.checkRun([1], [1,2,3,4,5], 4, 2)"), [1, 2, 3, 4])
        self.assertEqual(js("operator.js", "m.checkRun([5], [1,2,3], 9, 2)"), [2, 5])   # unknown anchor: plain tick

    def test_keys_step_verses_and_focus_the_tray_box(self):
        key = lambda k: self.run_js("operator.js", "m.keyAction(process.argv[2], {typing:false,onButton:false,verseShown:false})", k)
        self.assertEqual(key("."), {"action": "tray_step", "args": {"delta": 1}})
        self.assertEqual(key(","), {"action": "tray_step", "args": {"delta": -1}})
        self.assertEqual(key("t"), {"focus": "tray"})
        typing = self.run_js("operator.js", "m.keyAction('.', {typing:true})")
        self.assertIsNone(typing)

    def test_a_tray_slide_shows_its_number_even_alone_in_the_operator_summary(self):
        view = dict(segments=[[16, "For God"]], text="For God", title_first=True, reference="John 3",
                    label="KJV", continued=False)
        summary = self.run_js("operator.js", "m.slideSummary(JSON.parse(process.argv[2]))", json.dumps(view))
        self.assertEqual(summary["lines"], [{"number": 16, "text": "For God"}])
        view["title_first"] = False
        summary = self.run_js("operator.js", "m.slideSummary(JSON.parse(process.argv[2]))", json.dumps(view))
        self.assertEqual(summary["lines"], [{"number": None, "text": "For God"}])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class RunPanelTests(unittest.TestCase):
    """The Service tab's bottom panel (Bible, Announcements, Timer) remembers which pane was open."""
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_a_saved_pane_is_kept_and_anything_else_gives_the_bible(self):
        for name in ("bible", "announce"):
            self.assertEqual(self.js(f"m.runPaneName('{name}')"), name)
        self.assertEqual(self.js("m.runPaneName('timer')"), "announce")      # the Timer tab was folded into Announcements
        for raw in ("null", "undefined", "''", "'service'", "42", "'{bad'"):
            self.assertEqual(self.js(f"m.runPaneName({raw})"), "bible", raw)

class VerseTriggerTests(unittest.TestCase):
    """Trigger URLs that step a verse over a slideshow, and which theme each output gives that verse."""
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        deck_live(self.c)

    def verse_numbers(self):
        slide = self.c.session.state().overlay
        return None if slide is None else list(slide.verse_numbers)

    def test_forward_and_back_walk_the_tray_one_verse_at_a_time(self):
        self.c.load_tray("John 3")
        self.api.trigger("verse_forward")                     # nothing showing yet: the first verse
        self.assertEqual(self.verse_numbers(), [1])
        self.api.trigger("verse_forward")
        self.assertEqual(self.verse_numbers(), [2])
        self.api.trigger("verse_back")
        self.assertEqual(self.verse_numbers(), [1])
        with self.assertRaises(ApiError) as caught:
            self.api.trigger("verse_back")                    # already the first verse
        self.assertEqual(caught.exception.status, 409)

    def test_forward_never_leaves_a_verse_before_all_its_parts_have_shown(self):
        self.c.load_tray("John 3")
        self.c.show_tray_verses([5])                          # the long one, in parts
        parts = len(self.c._overlay_slides)
        self.assertGreater(parts, 1)
        for expected in range(1, parts):
            self.api.trigger("verse_forward")
            self.assertEqual((self.verse_numbers(), self.c.session.state().overlay_index), ([5], expected))
        self.api.trigger("verse_forward")                     # every part has shown: now verse 6
        self.assertEqual(self.verse_numbers(), [6])
        self.assertEqual(self.c.session.state().overlay_index, 0)

    def test_back_walks_the_parts_and_lands_on_the_last_part_of_the_previous_verse(self):
        self.c.load_tray("John 3")
        self.c.show_tray_verses([6])
        self.api.trigger("verse_back")                        # verse 5, on its last part
        self.assertEqual(self.verse_numbers(), [5])
        last = len(self.c._overlay_slides) - 1
        self.assertEqual(self.c.session.state().overlay_index, last)
        self.api.trigger("verse_back")
        self.assertEqual(self.c.session.state().overlay_index, last - 1)

    def test_a_single_verse_shown_without_the_tray_stops_at_its_last_part(self):
        self.c.show_verse("John 3:5")
        self.c.load_tray("John 4")                            # a tray exists, but this verse is not from it
        for _ in range(len(self.c._overlay_slides) - 1):
            self.api.trigger("verse_forward")
        with self.assertRaises(ApiError) as caught:
            self.api.trigger("verse_forward")
        self.assertEqual(caught.exception.status, 409)
        self.assertEqual(self.verse_numbers(), [5])

    def test_they_say_so_when_there_is_no_deck_or_no_tray(self):
        db, controller, api = make()                          # no slideshow is live here
        self.addCleanup(db.close)
        controller.load_tray("John 3")
        for name in ("verse_forward", "verse_back"):
            with self.assertRaises(ApiError) as caught:
                api.trigger(name)
            self.assertEqual(caught.exception.status, 409)

    def test_the_lower_third_output_keeps_its_theme_and_the_projector_uses_the_verse_over_theme(self):
        from dataclasses import replace
        self.c.load_tray("John 3")
        self.c.show_tray_verses([1])
        state = self.c.session.state()
        state = replace(state, overlay=replace(state.overlay, overlay_theme_id=5, bible_theme_id=6, theme_id=7))
        pick = lambda output: build_payload(state, output, style_for=lambda theme_id: theme_id, verse_over_theme_id=9)["overlay"]["style"]
        self.assertEqual(pick(Output("lower", "lower_third")), 5)        # the normal lower third theme
        self.assertEqual(pick(Output("verse", "verse_lower")), 5)
        self.assertEqual(pick(Output("projector", "projector")), 9)      # the verse over slide theme
        self.assertEqual(build_payload(state, Output("projector", "projector"), style_for=lambda t: t)["overlay"]["style"], 6)


if __name__ == "__main__":
    unittest.main()
