# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The program once stopped answering for good: a thread that told listeners of a change still held the session's
lock while it waited for the web server's lock, and a long-polling page held the web server's lock while it waited for the
session's. These tests keep both halves from coming back."""
import json
import threading
import unittest
import urllib.request

from churchlight_presenter.core.live import LiveSession
from tests.test_live import slides
from tests.test_media_playback import MP4, Base
from churchlight_presenter.ui.controller import LibraryEntry


class ListenersAreToldOutsideTheLockTests(unittest.TestCase):
    def lock_is_free_for_others(self, session, call):
        """Run `call`; inside a listener, can another thread take the session's lock?"""
        seen = []

        def listener(state):
            result = []

            def try_lock():
                got = session._lock.acquire(timeout=1)
                result.append(got)
                if got:
                    session._lock.release()               # the thread that took it gives it back

            other = threading.Thread(target=try_lock)
            other.start()
            other.join(3)
            seen.append(bool(result and result[0]))

        session.subscribe(listener)
        call()
        return seen

    def test_no_change_tells_listeners_while_still_holding_the_lock(self):
        for name, call in (("go_to_item", lambda s: s.go_to_item(7)),
                           ("toggle_blank", lambda s: s.toggle_blank()),
                           ("toggle_text_hidden", lambda s: s.toggle_text_hidden()),
                           ("toggle_lower_hidden", lambda s: s.toggle_lower_hidden()),
                           ("go_to", lambda s: s.go_to(1)),
                           ("set_blank", lambda s: s.set_blank(True))):
            with self.subTest(name):
                session = LiveSession()
                session.load(slides(3, [5, 6, 7]))
                seen = self.lock_is_free_for_others(session, lambda: call(session))
                self.assertEqual(seen, [True])

    def test_the_toggles_still_toggle_and_report_changes(self):
        session = LiveSession()
        session.load(slides(2))
        self.assertTrue(session.toggle_blank())
        self.assertTrue(session.state().blank)
        self.assertTrue(session.toggle_blank())
        self.assertFalse(session.state().blank)
        self.assertTrue(session.toggle_text_hidden())
        self.assertTrue(session.toggle_lower_hidden())
        self.assertFalse(session.set_blank(False))              # no change: no report
        with self.assertRaises(ValueError):
            session.go_to_item(99)


class PollingPagesAndOperatorTogetherTests(Base):
    def test_long_polling_pages_and_fast_operator_clicks_never_stop_the_program(self):
        video = self.add("a.mp4", MP4, 1200)
        self.c.new_service("Sunday")
        items = [self.c.add_entry(LibraryEntry("media", video, "")) for _ in range(3)]
        for n in range(3):
            self.c.add_announcement(f"A{n}", "text", 0)
        base = f"http://127.0.0.1:{self.c._server.address[1]}"
        stop = threading.Event()

        def poller(path):
            since = None
            while not stop.is_set():
                url = base + path + "?wait=5" + (f"&since={since}" if since is not None else "")
                try:
                    with urllib.request.urlopen(url, timeout=20) as reply:
                        since = json.loads(reply.read()).get("version", since)
                except Exception:  # noqa: BLE001
                    pass

        for path in ("/out/projector", "/out/lower-third", "/out/stage"):
            for _ in range(3):
                threading.Thread(target=poller, args=(path,), daemon=True).start()
        self.addCleanup(stop.set)

        def post(action, args):
            request = urllib.request.Request(base + "/api/do", data=json.dumps({"action": action, "args": args}).encode(),
                                             headers={"Content-Type": "application/json", "X-ChurchLight": "operator"})
            urllib.request.urlopen(request, timeout=10).read()

        def clicker(count):
            for i in range(count):
                post("go_item", {"item_id": items[i % 3]})
                post("media_seek", {"seconds": float(i % 1100)})
                post("blank", {})

        workers = [threading.Thread(target=clicker, args=(120,), daemon=True) for _ in range(3)]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join(60)
        self.assertFalse(any(worker.is_alive() for worker in workers), "the program stopped answering")


if __name__ == "__main__":
    unittest.main()
