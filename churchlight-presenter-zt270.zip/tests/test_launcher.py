# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import contextlib
import io
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from churchlight_presenter import launcher, logsetup

ROOT = Path(__file__).resolve().parent.parent


class FindBrowserTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def make(self, *parts):
        path = self.tmp.joinpath(*parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"")
        return path

    def test_windows_prefers_edge_then_chrome_in_the_usual_folders(self):
        env = {"ProgramFiles": str(self.tmp / "pf"), "ProgramFiles(x86)": str(self.tmp / "pf86"),
               "LOCALAPPDATA": str(self.tmp / "local")}
        names = [n for n, _ in launcher.browser_candidates("win32", env)]
        self.assertEqual(names[0], "Edge")
        self.assertIn("Chrome", names)
        chrome = self.make("local", "Google", "Chrome", "Application", "chrome.exe")
        self.assertEqual(launcher.find_browser("win32", env), ("Chrome", str(chrome)))
        edge = self.make("pf86", "Microsoft", "Edge", "Application", "msedge.exe")
        self.assertEqual(launcher.find_browser("win32", env), ("Edge", str(edge)))

    def test_nothing_found_gives_none(self):
        self.assertIsNone(launcher.find_browser("win32", {"ProgramFiles": str(self.tmp)}))
        self.assertIsNone(launcher.find_browser("linux", {}, which=lambda name: None))

    def test_linux_uses_the_path(self):
        found = launcher.find_browser("linux", {}, which=lambda n: "/usr/bin/chromium" if n == "chromium" else None)
        self.assertEqual(found, ("chromium", "/usr/bin/chromium"))

    def test_the_command_is_an_app_window_for_the_address(self):
        self.assertEqual(launcher.app_command("/x/edge", "http://127.0.0.1:8765/operator"),
                         ["/x/edge", "--app=http://127.0.0.1:8765/operator", "--autoplay-policy=no-user-gesture-required"])


class WindowPlaceTests(unittest.TestCase):
    def test_the_command_places_the_window_where_it_was(self):
        self.assertEqual(
            launcher.app_command("/x/edge", "http://h/operator?app=1", (1920, 40, 1200, 800)),
            ["/x/edge", "--app=http://h/operator?app=1", "--autoplay-policy=no-user-gesture-required", "--window-position=1920,40", "--window-size=1200,800"])

    def test_a_minimized_or_silly_place_is_ignored(self):
        for place in ((-32000, -32000, 160, 28), (0, 0, 50, 50), (0, 0, 99999, 800), ("a", 0, 800, 600), (0, 0, True, 600)):
            self.assertIsNone(launcher.clean_window(*place), place)
            self.assertEqual(launcher.app_command("/x/edge", "http://h/o", place), ["/x/edge", "--app=http://h/o", "--autoplay-policy=no-user-gesture-required"])

    def test_a_window_on_a_monitor_to_the_left_keeps_its_negative_position(self):
        self.assertEqual(launcher.clean_window(-1920, 10, 1300.4, 900), (-1920, 10, 1300, 900))


class OwnProfileTests(unittest.TestCase):
    def test_the_window_gets_a_browser_process_of_its_own(self):
        command = launcher.app_command("/x/edge", "http://h/o", (-1500, 20, 1000, 700), profile="/p/browser-profile")
        self.assertIn("--user-data-dir=/p/browser-profile", command)
        self.assertIn("--window-position=-1500,20", command)
        self.assertIn("--no-first-run", command)
        self.assertIn("--disable-background-mode", command)
        self.assertIn("--disable-sync", command)

    def test_without_a_profile_the_command_is_unchanged(self):
        self.assertEqual(launcher.app_command("/x/edge", "http://h/o"), ["/x/edge", "--app=http://h/o", "--autoplay-policy=no-user-gesture-required"])

    def test_the_profile_lives_next_to_the_database(self):
        from churchlight_presenter.__main__ import _browser_profile
        self.assertEqual(Path(_browser_profile("some/dir/church.db")).parts[-2:], ("dir", "browser-profile"))
        self.assertIsNone(_browser_profile(":memory:"))


class PlaceInTheAddressTests(unittest.TestCase):
    def test_the_saved_place_rides_in_the_address_as_well_as_the_flags(self):
        start = mock.Mock()
        launcher.open_operator("http://h:1/operator?app=1", start=start, fallback=mock.Mock(), window=(1920, 30, 1100, 700),
                               platform="linux", env={}, which=lambda n: "/usr/bin/chromium" if n == "chromium" else None)
        command = start.call_args.args[0]
        self.assertEqual(command[1], "--app=http://h:1/operator?app=1&place=1920,30,1100,700")
        self.assertIn("--window-position=1920,30", command)

    def test_no_saved_place_leaves_the_address_alone(self):
        start = mock.Mock()
        launcher.open_operator("http://h:1/operator?app=1", start=start, fallback=mock.Mock(), window=None,
                               platform="linux", env={}, which=lambda n: "/usr/bin/chromium" if n == "chromium" else None)
        self.assertEqual(start.call_args.args[0], ["/usr/bin/chromium", "--app=http://h:1/operator?app=1", "--autoplay-policy=no-user-gesture-required"])


class OpenOperatorTests(unittest.TestCase):
    URL = "http://127.0.0.1:8765/operator"

    def found(self, **kw):
        return dict(platform="linux", env={}, which=lambda n: "/usr/bin/chromium" if n == "chromium" else None, **kw)

    def test_opens_an_app_window(self):
        start = mock.Mock()
        how = launcher.open_operator(self.URL, start=start, fallback=mock.Mock(), **self.found())
        self.assertEqual(how, "app window (chromium)")
        self.assertEqual(start.call_args.args[0], ["/usr/bin/chromium", f"--app={self.URL}", "--autoplay-policy=no-user-gesture-required"])

    def test_falls_back_to_the_default_browser_when_starting_fails(self):
        fallback = mock.Mock(return_value=True)
        with self.assertLogs("churchlight_presenter.launcher", "WARNING"):
            how = launcher.open_operator(self.URL, start=mock.Mock(side_effect=OSError("no")),
                                         fallback=fallback, **self.found())
        self.assertEqual(how, "browser tab")
        fallback.assert_called_once_with(self.URL)

    def test_falls_back_when_no_chrome_family_browser_exists(self):
        fallback = mock.Mock(return_value=True)
        how = launcher.open_operator(self.URL, platform="linux", env={}, which=lambda n: None,
                                     start=mock.Mock(), fallback=fallback)
        self.assertEqual(how, "browser tab")

    def test_reports_none_when_nothing_works_and_never_raises(self):
        self.assertIsNone(launcher.open_operator(self.URL, platform="linux", env={}, which=lambda n: None,
                                                 start=mock.Mock(), fallback=mock.Mock(return_value=False)))
        with self.assertLogs("churchlight_presenter.launcher", "WARNING"):
            self.assertIsNone(launcher.open_operator(self.URL, platform="linux", env={}, which=lambda n: None,
                                                     start=mock.Mock(), fallback=mock.Mock(side_effect=RuntimeError)))


class MainFlagTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.addCleanup(logsetup.close_logging)

    def run_main(self, *extra):
        from churchlight_presenter.__main__ import main
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = main(["--db", str(self.tmp / "t.db"), "--media", str(self.tmp / "m"), "--port", "0", *extra])
        return code, out.getvalue()

    def test_open_and_no_console_start_the_page_and_stop_on_ctrl_c(self):
        with mock.patch.object(launcher, "open_operator", return_value="app window (Edge)") as opener, \
                mock.patch("churchlight_presenter.__main__._wait_until_stopped", side_effect=KeyboardInterrupt):
            code, text = self.run_main("--open", "--no-console")
        self.assertEqual(code, 0)
        self.assertRegex(opener.call_args.args[0], r"^http://127\.0\.0\.1:\d+/operator\?app=1$")
        self.assertIn("Operator page: http://127.0.0.1:", text)
        self.assertIn("Press Ctrl+C", text)
        self.assertIn("Stopping", text)
        self.assertIn("Stopped", (self.tmp / "churchlight.log").read_text(encoding="utf-8"))

    def test_if_no_browser_can_be_opened_the_address_is_printed(self):
        with mock.patch.object(launcher, "open_operator", return_value=None), \
                mock.patch("churchlight_presenter.__main__._wait_until_stopped", side_effect=KeyboardInterrupt):
            _, text = self.run_main("--open", "--no-console")
        self.assertIn("Could not open a browser by itself", text)

    def test_those_flags_need_the_server(self):
        from churchlight_presenter.__main__ import main
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as caught:
            main(["--db", str(self.tmp / "t.db"), "--no-server", "--open"])
        self.assertEqual(caught.exception.code, 2)

    def test_the_operator_page_works_through_the_started_program(self):
        # the database main() opens must be shareable, or the page's requests would fail
        import http.client
        import json
        from churchlight_presenter.__main__ import main
        seen = {}

        def wait(requested=None):
            conn = http.client.HTTPConnection(*seen["address"], timeout=10)
            conn.request("GET", "/api/state")
            res = conn.getresponse()
            seen["status"], seen["body"] = res.status, json.loads(res.read())
            conn.close()
            raise KeyboardInterrupt

        def remember(url, **kwargs):
            host, port = url.split("//")[1].split("/")[0].split(":")
            seen["address"] = (host, int(port))
            return "browser tab"
        with mock.patch.object(launcher, "open_operator", side_effect=remember), \
                mock.patch("churchlight_presenter.__main__._wait_until_stopped", wait), \
                contextlib.redirect_stdout(io.StringIO()):
            main(["--db", str(self.tmp / "t.db"), "--media", str(self.tmp / "m"), "--port", "0",
                  "--open", "--no-console"])
        self.assertEqual(seen["status"], 200)
        self.assertEqual(seen["body"]["schema"], 1)


class StartFilesTests(unittest.TestCase):
    def test_windows_start_file_uses_windows_line_endings_and_the_right_command(self):
        raw = (ROOT / "start_churchlight.bat").read_bytes()
        self.assertNotIn(b"\n", raw.replace(b"\r\n", b""))
        text = raw.decode()
        self.assertIn("-m churchlight_presenter", text)
        self.assertIn("--open --no-console", text)
        self.assertIn('cd /d "%~dp0"', text)

    def test_windows_start_file_relaunches_itself_minimized_once(self):
        text = (ROOT / "start_churchlight.bat").read_bytes().decode()
        lines = text.splitlines()
        guard = next(i for i, line in enumerate(lines) if 'if /i not "%~1"=="min"' in line)
        self.assertIn('start "ChurchLight Presenter" /min "%~f0" min', lines[guard + 1])     # the copy that does the work gets "min"
        self.assertIn("exit /b", lines[guard + 2])                                           # the first window closes at once
        self.assertLess(guard, next(i for i, line in enumerate(lines) if "-m churchlight_presenter" in line))
        self.assertIn("pause", text)                                                         # a start-up problem still waits to be read
        for n, line in enumerate(text.splitlines()):                                         # a ")" inside a parenthesised block ends it early and cmd then stops before "exit"
            if line.startswith("echo ") or line.startswith("if "):
                self.assertNotIn(")", line.replace("%CODE%", ""), line)
        self.assertEqual(lines[-1], "exit")                                                 # a normal stop closes the window itself
        self.assertIn('if "%CODE%"=="0" exit', text)                                          # only a problem waits, and it says the code

    def test_unix_start_file_runs_the_same_thing(self):
        text = (ROOT / "start_churchlight.sh").read_text()
        self.assertTrue(text.startswith("#!/bin/sh"))
        self.assertIn("--open --no-console", text)


if __name__ == "__main__":
    unittest.main()


class ControllerWindowPlaceTests(unittest.TestCase):
    def setUp(self):
        from churchlight_presenter.core.database import DatabaseManager
        from churchlight_presenter.ui.controller import OperatorController
        from churchlight_presenter.ui.operator_api import OperatorApi
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db)
        self.api = OperatorApi(self.c)

    def test_the_place_is_remembered_and_nothing_refreshes(self):
        self.assertIsNone(self.c.operator_window())
        before = self.c.version
        reply = self.api.call("window_place", {"x": 1920, "y": 0, "width": 1280, "height": 720})
        self.assertTrue(reply["saved"])
        self.assertEqual(self.c.operator_window(), (1920, 0, 1280, 720))
        self.assertEqual(self.c.version, before)

    def test_a_minimized_window_does_not_overwrite_the_saved_place(self):
        self.c.set_operator_window(100, 50, 1000, 700)
        reply = self.api.call("window_place", {"x": -32000, "y": -32000, "width": 160, "height": 28})
        self.assertFalse(reply["saved"])
        self.assertEqual(self.c.operator_window(), (100, 50, 1000, 700))

    def test_damaged_storage_means_no_place(self):
        self.db.set_setting("operator_window", "{oops")
        self.assertIsNone(self.c.operator_window())
        self.db.set_setting("operator_window", "[1, 2]")
        self.assertIsNone(self.c.operator_window())
