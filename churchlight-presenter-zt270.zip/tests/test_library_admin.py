# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError, OperatorController

TEXT = "[Verse 1]\nalpha one\nalpha two\n\n[Chorus]\nchorus words\n\nOrder: Verse 1, Chorus, Verse 1"


class AdminBase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        self.calls = []
        self.c.subscribe(lambda: self.calls.append(1))

    def entry(self, kind, text):
        return next(e for e in self.c.search_library(text) if e.kind == kind)

    def make_deck(self, name="Deck", pages=2, folder="decks/abc"):
        paths = []
        for n in range(1, pages + 1):
            rel = f"{folder}/page-{n:03d}.png"
            (self.tmp / "media" / rel).parent.mkdir(parents=True, exist_ok=True)
            (self.tmp / "media" / rel).write_bytes(b"\x89PNG")
            paths.append(rel)
        return self.db.add_presentation(name, [(p, None) for p in paths]), paths


class SongTests(AdminBase):
    def test_create_edit_and_read_back_as_text(self):
        song_id = self.c.create_song("  My Song ", " Ann ", TEXT)
        info = self.c.song_for_editing(song_id)
        self.assertEqual((info["title"], info["author"]), ("My Song", "Ann"))
        self.assertEqual(info["text"], TEXT.split("\n\nOrder:")[0])      # the order is its own box now
        self.assertEqual(info["order"], "Verse 1, Chorus, Verse 1")
        self.c.update_song(song_id, "Better", "", TEXT.replace("alpha one", "zebra one"))
        info = self.c.song_for_editing(song_id)
        self.assertEqual((info["title"], info["author"]), ("Better", ""))
        self.assertIn("zebra one", info["text"])
        self.assertEqual([e.title for e in self.c.search_library("zebra")], ["Better"])

    def test_the_new_song_builds_slides_in_the_typed_order(self):
        song_id = self.c.create_song("S", "", TEXT)
        slides = self.c.preview(self.entry("song", "S"))
        self.assertEqual([s.label for s in slides], ["Verse 1", "Chorus", "Verse 1"])
        self.assertEqual(song_id, self.entry("song", "S").id)

    def test_bad_input_is_explained_and_nothing_is_saved(self):
        with self.assertRaisesRegex(ControllerError, "title cannot be empty"):
            self.c.create_song("  ", "", TEXT)
        with self.assertRaisesRegex(ControllerError, "too long"):
            self.c.create_song("x" * 300, "", TEXT)
        with self.assertRaisesRegex(ControllerError, "no words"):
            self.c.create_song("T", "", "")
        with self.assertRaisesRegex(ControllerError, "heading"):
            self.c.create_song("T", "", "words\n[A]\nx")
        with self.assertRaisesRegex(ControllerError, "no song number 99"):
            self.c.update_song(99, "T", "", TEXT)
        self.assertEqual(self.c.library_overview()["songs"], [])

    def test_check_reports_parts_without_saving(self):
        result = self.c.check_song_text(TEXT)
        self.assertEqual([(s["label"], s["type"], s["lines"]) for s in result["sections"]],
                         [("Verse 1", "verse", 2), ("Chorus", "chorus", 1)])
        self.assertEqual(result["order"], ["Verse 1", "Chorus", "Verse 1"])
        with self.assertRaises(ControllerError):
            self.c.check_song_text("[A]\nx\nOrder: B")
        self.assertEqual(self.c.library_overview()["songs"], [])

    def test_editing_a_song_in_the_open_service_updates_the_live_slide_in_place(self):
        song_id = self.c.create_song("S", "", "[Verse 1]\nold line\n\n[Chorus]\nchorus")
        self.c.new_service("Sun")
        item = self.c.add_entry(self.entry("song", "S"))
        self.c.go_live_service_item(item)
        self.c.next()                                       # on the Chorus
        self.calls.clear()
        self.c.update_song(song_id, "S", "", "[Verse 1]\nnew line\n\n[Chorus]\nnew chorus")
        self.assertEqual(self.c.session.state().base.text, "new chorus")
        self.assertEqual(self.c.session.state().base_index, 1)
        self.assertEqual(len(self.calls), 1)

    def test_a_song_in_a_service_cannot_be_deleted_until_removed(self):
        song_id = self.c.create_song("S", "", TEXT)
        self.c.new_service("Sun")
        item = self.c.add_entry(self.entry("song", "S"))
        with self.assertRaisesRegex(ControllerError, "used in 1 service"):
            self.c.delete_song(song_id)
        self.assertEqual(len(self.c.library_overview()["songs"]), 1)
        self.c.remove_item(item)
        self.c.delete_song(song_id)
        self.assertEqual(self.c.library_overview()["songs"], [])
        with self.assertRaisesRegex(ControllerError, "no song"):
            self.c.delete_song(song_id)

    def test_changes_notify_listeners(self):
        song_id = self.c.create_song("S", "", TEXT)
        self.assertTrue(self.calls)
        self.calls.clear()
        self.c.delete_song(song_id)
        self.assertEqual(len(self.calls), 1)


class DraftTests(AdminBase):
    def test_a_draft_is_hidden_from_search_and_cannot_be_used_until_published(self):
        from churchlight_presenter.ui.controller import LibraryEntry
        draft = self.c.create_song("Unfinished", "", TEXT, draft=True)
        self.c.create_song("Finished", "", TEXT)
        self.c.new_service("S")
        self.assertEqual([e.title for e in self.c.search_library("")], ["Finished"])
        self.assertEqual(self.c.search_library("chorus words")[0].title, "Finished")
        self.assertEqual(len(self.c.search_library("chorus words")), 1)
        with self.assertRaisesRegex(ControllerError, "draft"):
            self.c.add_entry(LibraryEntry("song", draft, ""))
        with self.assertRaisesRegex(ControllerError, "draft"):
            self.c.go_live_entry(LibraryEntry("song", draft, ""))
        self.assertTrue(self.c.song_for_editing(draft)["draft"])
        overview = {s["title"]: s["draft"] for s in self.c.library_overview()["songs"]}
        self.assertEqual(overview, {"Unfinished": True, "Finished": False})
        self.c.publish_song(draft)
        self.assertEqual(sorted(e.title for e in self.c.search_library("")), ["Finished", "Unfinished"])
        self.c.add_entry(LibraryEntry("song", draft, ""))

    def test_saving_a_draft_again_and_publishing_by_a_normal_save(self):
        song = self.c.create_song("D", "", TEXT, draft=True)
        self.c.update_song(song, "D2", "", TEXT)                     # leaves it a draft
        self.assertTrue(self.c.song_for_editing(song)["draft"])
        self.c.update_song(song, "D2", "", TEXT, draft=False)        # Save publishes
        self.assertFalse(self.c.song_for_editing(song)["draft"])

    def test_a_song_in_a_service_cannot_become_a_draft(self):
        from churchlight_presenter.ui.controller import LibraryEntry
        song = self.c.create_song("Used", "", TEXT)
        self.c.new_service("S")
        self.c.add_entry(LibraryEntry("song", song, ""))
        with self.assertRaisesRegex(ControllerError, "cannot become a draft"):
            self.c.update_song(song, "Used", "", TEXT, draft=True)

    def test_the_web_api_saves_drafts_and_publishes(self):
        from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
        api = OperatorApi(self.c)
        saved = api.call("song_save", {"title": "Api", "text": TEXT, "draft": True})
        self.assertTrue(self.c.song_for_editing(saved["id"])["draft"])
        with self.assertRaises(ApiError):
            api.call("song_save", {"title": "x", "text": TEXT, "draft": "yes"})
        api.call("song_publish", {"id": saved["id"]})
        self.assertFalse(self.c.song_for_editing(saved["id"])["draft"])


class DeckTests(AdminBase):
    def test_rename_and_overview(self):
        deck_id, _ = self.make_deck("Old")
        self.c.rename_deck(deck_id, " New name ")
        self.assertEqual(self.c.library_overview()["decks"],
                         [{"id": deck_id, "name": "New name", "pages": 2, "uses": 0,
                           "transition": "none", "transition_ms": 500, "has_video": False,
                       "auto_seconds": 0, "end_action": "stop", "image_fit": "fit", "live": False}])
        with self.assertRaises(ControllerError):
            self.c.rename_deck(deck_id, " ")
        with self.assertRaises(ControllerError):
            self.c.rename_deck(999, "x")

    def test_deleting_a_deck_removes_its_files_but_only_its_own(self):
        deck_id, paths = self.make_deck("A", folder="decks/aaa")
        other_id, other_paths = self.make_deck("B", folder="decks/bbb")
        stray = self.tmp / "media" / "keep.txt"
        stray.write_text("x")
        self.c.delete_deck(deck_id)
        for rel in paths:
            self.assertFalse((self.tmp / "media" / rel).exists())
        self.assertFalse((self.tmp / "media" / "decks" / "aaa").exists())      # empty folder tidied
        for rel in other_paths:
            self.assertTrue((self.tmp / "media" / rel).exists())
        self.assertTrue(stray.exists())
        self.assertEqual([d["name"] for d in self.c.library_overview()["decks"]], ["B"])

    def test_a_deck_in_a_service_cannot_be_deleted(self):
        deck_id, paths = self.make_deck("A")
        self.c.new_service("Sun")
        self.c.add_entry(self.entry("presentation", "A"))
        with self.assertRaisesRegex(ControllerError, "used in 1 service"):
            self.c.delete_deck(deck_id)
        self.assertTrue((self.tmp / "media" / paths[0]).exists())

    def test_a_deck_that_is_live_on_its_own_is_taken_off_screen(self):
        deck_id, _ = self.make_deck("A")
        self.c.go_live_entry(self.entry("presentation", "A"))
        self.assertIsNotNone(self.c.session.state().base)
        self.c.delete_deck(deck_id)
        self.assertIsNone(self.c.session.state().base)

    def test_images_shared_with_another_deck_are_kept(self):
        a, paths = self.make_deck("A", pages=1, folder="decks/shared")
        b = self.db.add_presentation("B", [(paths[0], None)])
        self.c.delete_deck(a)
        self.assertTrue((self.tmp / "media" / paths[0]).exists())
        self.assertTrue(self.db.get_presentation(b))

    def test_a_path_that_escapes_the_media_folder_is_never_deleted(self):
        victim = self.tmp / "outside.png"
        victim.write_bytes(b"x")
        deck_id = self.db.add_presentation("Evil", [("../outside.png", None)])
        self.c.delete_deck(deck_id)
        self.assertTrue(victim.exists())


class BibleTests(AdminBase):
    def test_remove_a_bible_unless_a_service_uses_it(self):
        t = self.db.add_translation("DEMO", "Demo")
        self.db.add_verses(t, [("John", 3, 16, "x")])
        self.assertEqual(self.c.library_overview()["translations"],
                         [{"id": t, "abbreviation": "DEMO", "name": "Demo", "verses": 1, "uses": 0}])
        self.c.new_service("Sun")
        item = self.c.add_verse("jn 3:16")
        with self.assertRaisesRegex(ControllerError, "used in 1 service"):
            self.c.delete_translation("DEMO")
        self.c.remove_item(item)
        self.c.delete_translation("DEMO")
        self.assertEqual(self.c.translations(), [])
        self.assertIsNone(self.c.translation)
        with self.assertRaisesRegex(ControllerError, "No Bible named"):
            self.c.delete_translation("DEMO")


if __name__ == "__main__":
    unittest.main()
