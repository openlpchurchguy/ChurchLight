# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A Bible item's slide list (the ⋯ options) has a Go button per slide, like a song's parts list."""
import unittest

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class ScriptureGoTests(unittest.TestCase):
    def test_go_jumps_to_a_verse_in_the_middle_of_the_passage(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.new_service("S")
        c.set_service_verse_split("verse")
        c.add_verse("jn 3:1-4")
        row = [r for r in c.service_rows() if r.item_type == "scripture"][0]
        self.assertGreater(len(row.slide_numbers), 2)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector(".item-slide-list li", state="attached")
        # the options of an item that is not live start closed: open them
        if not page.is_visible(".item-slide-list"):
            page.click("button.more")
        buttons = page.query_selector_all(".item-slide-list .slide-bar")
        self.assertEqual(len(buttons), len(row.slide_numbers))
        buttons[1].click()                                         # the second slide, in the middle of the passage
        page.wait_for_selector(".item-slide-list li.slide-live", state="attached")
        self.assertEqual(c.session.state().base_index, row.slide_numbers[1])
        marked = page.query_selector_all(".item-slide-list li.slide-live")
        self.assertEqual(len(marked), 1)
        self.assertIn("v2", marked[0].inner_text())


if __name__ == "__main__":
    unittest.main()
