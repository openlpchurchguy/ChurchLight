# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Export buttons are grayed out with nothing to export, and a refused export never replaces the page."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

OUTPUTS = [Output("projector", "projector")]


def until(check, seconds=5):
    import time
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class EmptyExportTests(unittest.TestCase):
    def open(self, with_song=False):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        db.set_setting("setup_done", "1")                  # the first-time guide would cover the page
        c = OperatorController(db, OUTPUTS)
        if with_song:
            c.create_song("Grace", "", "[V1]\nline one")
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(accept_downloads=True)
        self.page.goto(server.url.rstrip("/") + "/operator")
        self.page.click("#tab-songs")
        self.page.wait_for_selector("#song-list li", state="attached")

    def test_export_all_songs_is_grayed_out_with_no_songs(self):
        self.open()
        self.assertTrue(until(lambda: self.page.is_disabled("#song-export-all")))

    def test_export_all_slideshows_is_grayed_out_with_no_slideshows(self):
        self.open()
        self.page.click("#tab-decks")
        self.assertTrue(until(lambda: self.page.is_disabled("#deck-export-all")))

    def test_a_refused_export_shows_a_message_and_keeps_the_page(self):
        self.open()
        self.page.evaluate("document.getElementById('song-export-all').disabled = false")
        self.page.click("#song-export-all")
        self.assertTrue(until(lambda: self.page.is_visible("#message") and "export" in self.page.inner_text("#message").lower()))
        self.assertTrue(self.page.is_visible("#tab-songs"))
        self.assertTrue(self.page.url.endswith("/operator"))

    def test_with_a_song_the_button_is_on_and_the_file_downloads(self):
        self.open(with_song=True)
        self.assertTrue(until(lambda: not self.page.is_disabled("#song-export-all")))
        with self.page.expect_download() as info:
            self.page.click("#song-export-all")
        self.assertTrue(info.value.suggested_filename.endswith(".xml"))
        self.assertTrue(self.page.url.endswith("/operator"))


if __name__ == "__main__":
    unittest.main()
