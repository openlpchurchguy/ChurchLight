# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Timed slide advance for decks: the rules, the settings, and the timer."""
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.autoplay import check_autoplay, next_step, timing_for
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi


class RuleTests(unittest.TestCase):
    def test_check(self):
        self.assertEqual(check_autoplay(8, "loop"), (8, "loop"))
        for bad in ((-1, "stop"), (601, "stop"), (1.5, "stop"), (True, "stop"), (5, "explode")):
            with self.assertRaises(ValueError):
                check_autoplay(*bad)

    def test_item_override_wins_and_damage_is_ignored(self):
        self.assertEqual(timing_for(5, "stop", {}), (5, "stop"))
        self.assertEqual(timing_for(5, "stop", {"auto_seconds": 0}), (0, "stop"))
        self.assertEqual(timing_for(5, "stop", {"end_action": "loop"}), (5, "loop"))
        self.assertEqual(timing_for(5, "stop", {"auto_seconds": "x"}), (5, "stop"))

    def test_next_step(self):
        self.assertEqual(next_step(0, 3, True, "stop"), "next")
        self.assertEqual(next_step(2, 3, False, "stop"), "stop")
        self.assertEqual(next_step(2, 3, False, "loop"), "first")
        self.assertEqual(next_step(2, 3, False, "blank"), "blank")
        self.assertEqual(next_step(1, 3, False, "next_item"), "next")
        self.assertEqual(next_step(2, 3, False, "next_item"), "stop")      # nothing follows


class TimerBase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        self.c._timer_scale = 0.02            # "1 second" lasts 20 ms
        self.addCleanup(self.c.set_timer_paused, True)
        self.deck = self.make_deck("Welcome", 3)

    def make_deck(self, name, pages):
        paths = []
        for n in range(1, pages + 1):
            rel = f"{name}/page-{n:03d}.png"
            (self.tmp / "media" / rel).parent.mkdir(parents=True, exist_ok=True)
            (self.tmp / "media" / rel).write_bytes(b"\x89PNG")
            paths.append(rel)
        return self.db.add_presentation(name, [(p, None) for p in paths])

    def index(self):
        return self.c.session.state().base_index

    def wait_for(self, condition, seconds=2.0):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if condition():
                return True
            time.sleep(0.005)
        return condition()

    def live_alone(self):
        self.c.go_live_entry(LibraryEntry("presentation", self.deck, ""))


class DeckTimerTests(TimerBase):
    def test_manual_decks_never_move(self):
        self.live_alone()
        time.sleep(0.15)
        self.assertEqual(self.index(), 0)
        self.assertFalse(self.c.timer_view()["available"])

    def test_advances_then_stops_on_the_last_slide(self):
        self.c.set_deck_autoplay(self.deck, 1, "stop")
        self.live_alone()
        self.assertTrue(self.wait_for(lambda: self.index() == 2))
        time.sleep(0.15)
        self.assertEqual(self.index(), 2)
        self.assertFalse(self.c.timer_view()["running"])

    def test_loop_keeps_going(self):
        self.c.set_deck_autoplay(self.deck, 1, "loop")
        self.live_alone()
        seen = set()
        self.wait_for(lambda: seen.add(self.index()) or len(seen) == 3)
        self.assertEqual(seen, {0, 1, 2})
        self.assertTrue(self.wait_for(lambda: self.index() == 0 and self.c.timer_view()["running"]))

    def test_blank_ending(self):
        self.c.set_deck_autoplay(self.deck, 1, "blank")
        self.live_alone()
        self.assertTrue(self.wait_for(lambda: self.c.session.state().blank))
        self.assertEqual(self.index(), 2)

    def test_pause_and_resume(self):
        self.c.set_deck_autoplay(self.deck, 1, "stop")
        self.c.set_timer_paused(True)
        self.live_alone()
        time.sleep(0.15)
        self.assertEqual(self.index(), 0)
        self.assertTrue(self.c.timer_view()["paused"])
        self.c.set_timer_paused(False)
        self.assertTrue(self.wait_for(lambda: self.index() == 2))

    def test_blank_screens_and_a_verse_hold_the_countdown(self):
        self.c.set_deck_autoplay(self.deck, 1, "stop")
        self.c.session.set_blank(True)
        self.live_alone()
        time.sleep(0.15)
        self.assertEqual(self.index(), 0)
        self.c.session.set_blank(False)
        self.assertTrue(self.wait_for(lambda: self.index() == 2))

    def test_going_elsewhere_stops_the_timer(self):
        self.c.set_deck_autoplay(self.deck, 600, "stop")
        self.live_alone()
        self.assertTrue(self.c.timer_view()["running"])
        self.c.clear()
        self.assertFalse(self.c.timer_view()["running"])

    def test_pressing_next_restarts_the_countdown_on_the_new_slide(self):
        self.c.set_deck_autoplay(self.deck, 600, "stop")
        self.live_alone()
        self.c.next()
        self.assertEqual(self.index(), 1)
        self.assertTrue(self.c.timer_view()["running"])

    def test_settings_are_checked(self):
        with self.assertRaises(ControllerError):
            self.c.set_deck_autoplay(self.deck, -5, "stop")
        with self.assertRaises(ControllerError):
            self.c.set_deck_autoplay(999, 5, "stop")


class ServiceTimerTests(TimerBase):
    def setUp(self):
        super().setUp()
        self.c.new_service("S")
        self.c.add_entry(LibraryEntry("presentation", self.deck, ""))
        self.other = self.make_deck("Other", 2)
        self.c.add_entry(LibraryEntry("presentation", self.other, ""))
        self.first, self.second = [r.item_id for r in self.c.service_rows()]

    def test_loop_stays_inside_its_own_deck(self):
        self.c.set_deck_autoplay(self.deck, 1, "loop")
        self.c.go_live_service_item(self.first)
        time.sleep(0.3)
        self.assertIn(self.index(), (0, 1, 2))      # never wanders into the second deck

    def test_next_item_carries_on_into_the_next_deck(self):
        self.c.set_deck_autoplay(self.deck, 1, "next_item")
        self.c.go_live_service_item(self.first)
        self.assertTrue(self.wait_for(lambda: self.index() == 3))   # first slide of the second deck
        time.sleep(0.1)
        self.assertEqual(self.index(), 3)                          # that deck is manual: stays

    def test_item_override_and_back(self):
        self.c.set_item_autoplay(self.first, 7, "loop")
        row = self.c.service_rows()[0]
        self.assertEqual(row.timing, {"custom": True, "seconds": 7, "end_action": "loop"})
        self.c.set_item_autoplay(self.first)
        self.assertEqual(self.c.service_rows()[0].timing, {"custom": False, "seconds": 0, "end_action": "stop"})
        with self.assertRaises(ControllerError):
            self.c.set_item_autoplay(self.first, 9999, "stop")

    def test_the_item_override_beats_the_deck(self):
        self.c.set_deck_autoplay(self.deck, 600, "stop")
        self.c.set_item_autoplay(self.first, 0, "stop")           # manual for this use
        self.c.go_live_service_item(self.first)
        self.assertFalse(self.c.timer_view()["available"])

    def test_api(self):
        api = OperatorApi(self.c)
        api.call("deck_autoplay", {"id": self.deck, "seconds": 600, "end_action": "loop"})
        api.call("item_autoplay", {"item_id": self.first, "seconds": 3})
        state = api.state()
        self.assertEqual(state["items"][0]["timing"], {"custom": True, "seconds": 3, "end_action": "loop"})
        api.call("item_autoplay", {"item_id": self.first})
        api.call("timer_pause", {"paused": True})
        self.assertTrue(api.state()["timer"]["paused"])
        with self.assertRaises(ApiError):
            api.call("timer_pause", {"paused": "yes"})
        with self.assertRaises(ApiError):
            api.call("deck_autoplay", {"id": self.deck, "seconds": 5, "end_action": "boom"})


if __name__ == "__main__":
    unittest.main()


import json
import re
import shutil as _shutil
import subprocess

from churchlight_presenter.core.autoplay import END_ACTIONS

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


@unittest.skipUnless(_shutil.which("node"), "node is not installed")
class PageScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_the_page_offers_exactly_the_endings_the_server_accepts(self):
        self.assertEqual([c["value"] for c in self.js("m.END_CHOICES")], list(END_ACTIONS))

    def test_seconds_are_parsed_strictly(self):
        self.assertEqual(self.js("m.parseAutoSeconds('8')"), 8)
        self.assertEqual(self.js("m.parseAutoSeconds('0')"), 0)
        for bad in ("''", "'-1'", "'1.5'", "'601'", "'abc'"):
            self.assertIsNone(self.js(f"m.parseAutoSeconds({bad})"), bad)

    def test_descriptions(self):
        self.assertEqual(self.js("m.autoplayText(0,'stop')"), "Manual advance")
        self.assertEqual(self.js("m.autoplayText(8,'loop')"), "Every 8 s, loop back to the first slide")
        self.assertEqual(self.js("m.timerText(null)")["enabled"], False)
        self.assertEqual(self.js("m.timerText({available:true,paused:true})")["button"], "Resume timer")
        running = self.js("m.timerText({available:true,paused:false,running:true,seconds:5,end_action:'stop'})")
        self.assertTrue(running["text"].startswith("Timer running"))
        done = self.js("m.timerText({available:true,paused:false,running:false,seconds:5,end_action:'stop'})")
        self.assertTrue(done["text"].startswith("Timer finished"))
