# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Global shortcuts: claimed only while switched on, mapped by the operator, released at once on Off."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.globalkeys import ACTIONS, ComboError, GlobalKeys, parse_combo
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


class FakeBackend:
    """Stands in for Windows: remembers which keys are claimed and lets a test press them."""
    def __init__(self, refuse=()):
        self.held = {}                      # hotkey id -> (flags, code)
        self.refuse = set(refuse)
        self.on_press = lambda hotkey_id: None
        self.calls = []
        self.closed = False

    def register(self, hotkey_id, flags, code):
        self.calls.append(("register", hotkey_id))
        if code in self.refuse:
            return False, "in use by another program"
        self.held[hotkey_id] = (flags, code)
        return True, ""

    def unregister_all(self):
        self.calls.append(("clear",))
        self.held.clear()

    def close(self):
        self.closed = True

    def press(self, hotkey_id):
        if hotkey_id in self.held:          # Windows only reports keys that are claimed
            self.on_press(hotkey_id)


def make(backend=None, db=None):
    db = db or DatabaseManager(":memory:", shared=True)
    if db.search_song() == []:
        db.create_song_with_sections("Song", [("Verse 1", "verse", "a\nb"), ("Chorus", "chorus", "c")],
                                     order=["Verse 1", "Chorus"])
    c = OperatorController(db, [Output("p", "projector")])
    c.global_keys = GlobalKeys(c, backend)
    return db, c, OperatorApi(c)


def ids():
    return {a[0]: i for i, a in enumerate(ACTIONS, start=1)}


class ComboTests(unittest.TestCase):
    def test_combos_are_read_and_written_in_one_standard_form(self):
        self.assertEqual(parse_combo("ctrl+alt+right")[2], "Ctrl+Alt+Right")
        self.assertEqual(parse_combo("Shift+Ctrl+a")[2], "Ctrl+Shift+A")
        self.assertEqual(parse_combo("F8"), (0, 0x77, "F8"))
        self.assertEqual(parse_combo("Ctrl+Alt+Right")[:2], (3, 0x27))

    def test_a_bare_letter_or_arrow_is_refused_but_an_f_key_may_stand_alone(self):
        for bad in ("A", "Right", "Space", "7", ""):
            with self.assertRaises(ComboError, msg=bad):
                parse_combo(bad)
        parse_combo("F12")

    def test_nonsense_is_refused(self):
        for bad in ("Ctrl+", "Ctrl+Ctrl+A", "Ctrl+Foo", "Win+A", None, 5, "Ctrl+Alt"):
            with self.assertRaises(ComboError, msg=str(bad)):
                parse_combo(bad)


class ManagerTests(unittest.TestCase):
    def setUp(self):
        self.backend = FakeBackend()
        self.db, self.c, self.api = make(self.backend)
        self.addCleanup(self.db.close)
        self.gk = self.c.global_keys

    def test_nothing_is_claimed_until_it_is_switched_on(self):
        self.gk.set_combo("next", "Ctrl+Alt+Right")
        self.assertEqual(self.backend.held, {})
        self.assertFalse(self.gk.armed)
        self.assertEqual(self.gk.view()["actions"][0]["status"], "ready")

    def test_only_the_mapped_keys_are_claimed(self):
        self.gk.set_combo("next", "Ctrl+Alt+Right")
        self.gk.set_combo("blank", "F9")
        self.gk.arm()
        self.assertEqual(set(self.backend.held), {ids()["next"], ids()["blank"]})
        status = {a["id"]: a["status"] for a in self.gk.view()["actions"]}
        self.assertEqual((status["next"], status["blank"], status["previous"]), ("active", "active", "none"))

    def test_turning_off_hands_every_key_back(self):
        self.gk.set_combo("next", "Ctrl+Alt+Right")
        self.gk.arm()
        self.gk.disarm()
        self.assertEqual(self.backend.held, {})
        self.assertFalse(self.gk.view()["armed"])
        self.backend.held[ids()["next"]] = (3, 0x27)
        self.backend.press(ids()["next"])                       # even a stray press does nothing once off
        self.assertEqual(self.c.session.state().base, None)

    def test_it_cannot_be_turned_on_with_nothing_mapped_or_without_a_backend(self):
        with self.assertRaisesRegex(ControllerError, "at least one key"):
            self.gk.arm()
        _, c2, _ = make(None, self.db)
        c2.global_keys.set_combo("next", "F8")
        with self.assertRaisesRegex(ControllerError, "Windows"):
            c2.global_keys.arm()
        self.assertFalse(c2.global_keys.view()["available"])

    def test_a_key_another_program_owns_is_reported_and_the_rest_still_work(self):
        self.backend.refuse = {0x77}                            # F8
        self.gk.set_combo("next", "F8")
        self.gk.set_combo("previous", "F9")
        self.gk.arm()
        status = {a["id"]: a["status"] for a in self.gk.view()["actions"]}
        self.assertEqual(status["next"], "in use by another program")
        self.assertEqual(status["previous"], "active")
        self.assertTrue(self.gk.armed)

    def test_changing_a_key_while_on_takes_effect_at_once(self):
        self.gk.set_combo("next", "F8")
        self.gk.arm()
        self.gk.set_combo("next", "F9")
        self.assertEqual(self.backend.held[ids()["next"]][1], 0x78)
        self.gk.set_combo("next", None)                         # clearing releases it
        self.assertEqual(self.backend.held, {})

    def test_two_actions_cannot_share_a_combo_and_bad_combos_are_refused(self):
        self.gk.set_combo("next", "F8")
        with self.assertRaisesRegex(ControllerError, "already used"):
            self.gk.set_combo("previous", "f8")
        with self.assertRaises(ControllerError):
            self.gk.set_combo("previous", "Right")
        with self.assertRaises(ControllerError):
            self.gk.set_combo("nope", "F8")

    def test_pressing_a_claimed_key_does_the_job(self):
        self.gk.set_combo("next_item", "F7")
        self.gk.set_combo("next", "F8")
        self.gk.set_combo("blank", "F9")
        self.c.new_service("S")
        item = self.c.add_entry(self.c.search_library("Song")[0])
        self.gk.arm()
        self.backend.press(ids()["next_item"])
        self.assertEqual(self.c.session.state().base.source_item_id, item)
        self.backend.press(ids()["next"])
        self.assertEqual(self.c.session.state().base_index, 1)
        self.backend.press(ids()["blank"])
        self.assertTrue(self.c.session.state().blank)

    def test_a_press_with_nothing_to_do_is_not_an_error(self):
        self.gk.set_combo("next", "F8")
        self.gk.arm()
        self.backend.press(ids()["next"])                      # nothing loaded: must not raise

    def test_the_mapping_is_remembered_but_on_is_not(self):
        self.gk.set_combo("next", "Ctrl+Alt+Right")
        self.gk.arm()
        again = GlobalKeys(self.c, FakeBackend())
        self.assertEqual(again.combos, {"next": "Ctrl+Alt+Right"})
        self.assertFalse(again.armed)
        self.assertEqual(again.backend.held, {})

    def test_a_damaged_saved_mapping_is_ignored_piece_by_piece(self):
        self.db.set_setting("global_keys", json.dumps({"next": "F8", "previous": "F8", "blank": "Right", "x": "F1"}))
        self.assertEqual(GlobalKeys(self.c, FakeBackend()).combos, {"next": "F8"})
        self.db.set_setting("global_keys", "not json")
        self.assertEqual(GlobalKeys(self.c, FakeBackend()).combos, {})

    def test_closing_the_controller_releases_the_keys(self):
        self.gk.set_combo("next", "F8")
        self.gk.arm()
        self.c.close()
        self.assertEqual(self.backend.held, {})
        self.assertTrue(self.backend.closed)
        self.assertFalse(self.gk.armed)


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.backend = FakeBackend()
        self.db, self.c, self.api = make(self.backend)
        self.addCleanup(self.db.close)

    def test_the_state_carries_the_global_keys_and_starts_off(self):
        view = self.api.state()["global_keys"]
        self.assertEqual((view["available"], view["armed"]), (True, False))
        self.assertEqual([a["id"] for a in view["actions"]], [a[0] for a in ACTIONS])

    def test_set_and_arm_through_the_api(self):
        self.api.call("global_keys_set", {"action": "next", "combo": "Ctrl+Alt+Right"})
        self.api.call("global_keys_arm", {"on": True})
        self.assertTrue(self.api.state()["global_keys"]["armed"])
        self.assertEqual(len(self.backend.held), 1)
        self.api.call("global_keys_arm", {"on": False})
        self.assertEqual(self.backend.held, {})

    def test_bad_requests_are_refused(self):
        for action, args in (("global_keys_arm", {}), ("global_keys_arm", {"on": "yes"}),
                             ("global_keys_set", {"action": "next", "combo": 5}),
                             ("global_keys_set", {"action": "next", "combo": "Right"}),
                             ("global_keys_arm", {"on": True})):          # nothing mapped yet
            with self.assertRaises(ApiError, msg=str(args)):
                self.api.call(action, args)

    def test_the_default_controller_has_no_backend_off_windows(self):
        db = DatabaseManager(":memory:")
        self.addCleanup(db.close)
        c = OperatorController(db, [Output("p", "projector")])
        import sys
        self.assertEqual(c.global_keys.view()["available"], sys.platform == "win32")


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class ComboFromEventTests(unittest.TestCase):
    def combo(self, event):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify(m.comboFromEvent({json.dumps(event)})))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True, check=True)
        return json.loads(out.stdout)

    def test_the_page_turns_key_presses_into_combo_names(self):
        self.assertEqual(self.combo({"code": "ArrowRight", "ctrlKey": True, "altKey": True}), "Ctrl+Alt+Right")
        self.assertEqual(self.combo({"code": "KeyA", "shiftKey": True, "ctrlKey": True}), "Ctrl+Shift+A")
        self.assertEqual(self.combo({"code": "F8"}), "F8")
        self.assertEqual(self.combo({"code": "Digit5", "altKey": True}), "Alt+5")
        self.assertEqual(self.combo({"code": "PageDown", "ctrlKey": True}), "Ctrl+PageDown")
        self.assertEqual(self.combo({"code": "Period", "altKey": True}), "Alt+.")

    def test_modifier_only_and_unusable_keys_give_nothing(self):
        for code in ("ShiftLeft", "ControlLeft", "Escape", "Enter", "Tab", ""):
            self.assertIsNone(self.combo({"code": code, "ctrlKey": True}), code)


class PageTests(unittest.TestCase):
    def test_the_page_has_the_banner_switch_and_table(self):
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        for ident in ("globalkeys-banner", "gk-toggle", "gk-body", "gk-note"):
            self.assertIn(f'id="{ident}"', html)


if __name__ == "__main__":
    unittest.main()
