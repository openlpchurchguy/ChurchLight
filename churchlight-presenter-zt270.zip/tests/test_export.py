# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Exporting songs (OpenLyrics / text) and slideshows (a bundle), and reading them back."""
import http.client
import io
import json
import tempfile
import time
import unittest
import zipfile
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.export import (
    ExportError, export_songs, slideshow_snapshot, song_to_openlyrics, song_to_text, write_bundle)
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.importers.bundle import import_bundle
from churchlight_presenter.importers.common import ImporterError
from churchlight_presenter.importers.songfiles import parse_plain_text
from churchlight_presenter.importers.songs import import_openlyrics, parse_openlyrics
from churchlight_presenter.server.app import OutputServer
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi

PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 40


def make_song(db, title="Amazing Grace"):
    return db.create_song_with_sections(
        title, [("Verse 1", "verse", "Amazing grace\nhow sweet the sound"),
                ("Chorus", "chorus", "My chains are gone"),
                ("Verse 2", "verse", "Twas grace that taught")],
        order=["Verse 1", "Chorus", "Verse 2", "Chorus"], author="John Newton, Ann Example",
        copyright="Public domain", ccli_number="22025", default_key="G", notes="slow")


class SongExportTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.song = make_song(self.db)

    def test_openlyrics_reads_back_the_same_song(self):
        parsed = parse_openlyrics(song_to_openlyrics(self.db, self.song))
        self.assertEqual(parsed.title, "Amazing Grace")
        self.assertEqual(parsed.sections, [("Verse 1", "verse", "Amazing grace\nhow sweet the sound"),
                                           ("Chorus", "chorus", "My chains are gone"),
                                           ("Verse 2", "verse", "Twas grace that taught")])
        self.assertEqual(parsed.order, ["Verse 1", "Chorus", "Verse 2", "Chorus"])
        self.assertEqual((parsed.author, parsed.copyright, parsed.ccli_number, parsed.default_key, parsed.notes),
                         ("John Newton, Ann Example", "Public domain", "22025", "G", "slow"))

    def test_every_part_is_named_with_a_letter_and_a_number_like_openlp_does(self):
        xml = song_to_openlyrics(self.db, self.song).decode()
        self.assertIn('name="v1"', xml)
        self.assertIn('name="c1"', xml)                     # not a bare "c"
        self.assertIn('name="v2"', xml)
        self.assertIn("<verseOrder>v1 c1 v2 c1</verseOrder>", xml)

    def test_a_songs_own_part_names_and_order_survive_the_round_trip(self):
        song = self.db.create_song_with_sections(
            "Parts", [("Intro", "intro", "i"), ("Verse 1", "verse", "a"), ("Pre-Chorus", "pre_chorus", "p"),
                      ("Chorus", "chorus", "c"), ("Bridge", "bridge", "b"), ("Tag", "other", "t"),
                      ("Interlude", "other", "x"), ("Outro", "outro", "o")],
            order=["Intro", "Verse 1", "Pre-Chorus", "Chorus", "Verse 1", "Chorus", "Bridge", "Chorus", "Tag", "Interlude", "Outro"])
        parsed = parse_openlyrics(song_to_openlyrics(self.db, song))
        self.assertEqual([s[0] for s in parsed.sections],
                         ["Intro", "Verse 1", "Pre-Chorus", "Chorus", "Bridge", "Tag", "Interlude", "Outro"])
        self.assertEqual(parsed.order, ["Intro", "Verse 1", "Pre-Chorus", "Chorus", "Verse 1", "Chorus", "Bridge", "Chorus",
                                        "Tag", "Interlude", "Outro"])

    def test_another_program_ignores_our_extra_attribute_and_reads_the_standard_names(self):
        xml = song_to_openlyrics(self.db, self.song)
        stripped = xml.decode().replace(' xmlns:cl="urn:churchlight-presenter:openlyrics-extension"', "")
        import re as _re
        stripped = _re.sub(r' cl:label="[^"]*"', "", stripped)
        parsed = parse_openlyrics(stripped.encode())
        self.assertEqual([s[0] for s in parsed.sections], ["Verse 1", "Chorus 1", "Verse 2"])     # plain OpenLyrics names
        self.assertEqual(parsed.order, ["Verse 1", "Chorus 1", "Verse 2", "Chorus 1"])

    OPENLP = b"""<?xml version='1.0' encoding='UTF-8'?>
<song xmlns="http://openlyrics.info/namespace/2009/song" version="0.8" createdIn="OpenLP 3.0" modifiedIn="OpenLP 3.0">
  <properties><titles><title>How Great</title></titles>
    <verseOrder>i1 v1 p1 c1 v2 p1 c1 b1 c1 o1 e1 x9</verseOrder>
    <authors><author>Someone</author></authors></properties>
  <format><tags application="OpenLP"><tag name="su"><open>&lt;sup&gt;</open><close>&lt;/sup&gt;</close></tag></tags></format>
  <lyrics>
    <verse name="i1"><lines>intro words</lines></verse>
    <verse name="v1"><lines>first <tag name="su">1</tag> line<br/>second line</lines></verse>
    <verse name="p1"><lines>pre words</lines></verse>
    <verse name="c1"><lines>chorus words</lines></verse>
    <verse name="v2"><lines>verse two</lines></verse>
    <verse name="b1"><lines>bridge words<br/><br/>after a gap</lines></verse>
    <verse name="o1"><lines>other words</lines></verse>
    <verse name="e1"><lines>ending words</lines></verse>
    <verse name="v3"><lines/></verse>
  </lyrics>
</song>"""

    def test_an_openlp_file_reads_with_openlps_own_part_names(self):
        parsed = parse_openlyrics(self.OPENLP)
        self.assertEqual([(s[0], s[1]) for s in parsed.sections],
                         [("Intro 1", "intro"), ("Verse 1", "verse"), ("Pre-Chorus 1", "pre_chorus"), ("Chorus 1", "chorus"),
                          ("Verse 2", "verse"), ("Bridge 1", "bridge"), ("Other 1", "other"), ("Ending 1", "outro")])
        self.assertEqual(parsed.order, ["Intro 1", "Verse 1", "Pre-Chorus 1", "Chorus 1", "Verse 2", "Pre-Chorus 1",
                                        "Chorus 1", "Bridge 1", "Chorus 1", "Other 1", "Ending 1"])
        self.assertEqual(parsed.sections[1][2], "first 1 line\nsecond line")           # formatting tags keep their words
        self.assertTrue(any("x9" in w for w in parsed.warnings))                       # a name with no words is skipped

    OPENLP_SPLIT = b"""<?xml version='1.0' encoding='UTF-8'?>
<song xmlns="http://openlyrics.info/namespace/2009/song" version="0.8" createdIn="OpenLP 2.4.6" modifiedIn="OpenLP 2.4.6">
  <properties><titles><title>Split Song</title></titles>
    <verseOrder>v1 c1 v2 c1 c1 b1 b1 c1 c1</verseOrder></properties>
  <lyrics>
    <verse name="v1a"><lines>one a1<br/>one a2</lines></verse>
    <verse name="v1b"><lines>one b1<br/>one b2</lines></verse>
    <verse name="c1"><lines>chorus 1<br/>chorus 2</lines></verse>
    <verse name="v2a"><lines>two a1</lines></verse>
    <verse name="v2b"><lines>two b1</lines></verse>
    <verse name="b1a"><lines>bridge a</lines></verse>
    <verse name="b1b"><lines>bridge b</lines></verse>
  </lyrics>
</song>"""

    def test_openlp_verses_split_into_parts_keep_their_order(self):
        parsed = parse_openlyrics(self.OPENLP_SPLIT)
        self.assertEqual([(s[0], s[1]) for s in parsed.sections],
                         [("Verse 1", "verse"), ("Chorus 1", "chorus"), ("Verse 2", "verse"), ("Bridge 1", "bridge")])
        self.assertEqual(parsed.sections[0][2], "one a1\none a2\n\none b1\none b2")       # each part stays its own slide
        self.assertEqual(parsed.order, ["Verse 1", "Chorus 1", "Verse 2", "Chorus 1", "Chorus 1", "Bridge 1", "Bridge 1",
                                        "Chorus 1", "Chorus 1"])
        self.assertEqual(parsed.warnings, [])

    def test_an_order_that_names_single_parts_keeps_them_separate(self):
        xml = self.OPENLP_SPLIT.replace(b"v1 c1 v2 c1 c1 b1 b1 c1 c1", b"v1a c1 v1b v2 b1")
        parsed = parse_openlyrics(xml)
        self.assertEqual([s[0] for s in parsed.sections], ["Verse 1a", "Verse 1b", "Chorus 1", "Verse 2a", "Verse 2b",
                                                           "Bridge 1a", "Bridge 1b"])
        self.assertEqual(parsed.order, ["Verse 1a", "Chorus 1", "Verse 1b", "Verse 2a", "Verse 2b", "Bridge 1a", "Bridge 1b"])

    def test_split_openlp_verses_become_one_song_with_the_right_slides(self):
        import tempfile as _tf
        from churchlight_presenter.importers.songs import import_openlyrics as _import
        folder = Path(_tf.mkdtemp())
        (folder / "s.xml").write_bytes(self.OPENLP_SPLIT)
        report = _import(self.db, folder / "s.xml")
        self.assertEqual(len(report.imported), 1)
        default = self.db.get_default_arrangement(report.imported[0])
        self.assertEqual([r["label"] for r in self.db.get_arrangement_sections(default["id"])],
                         ["Verse 1", "Chorus 1", "Verse 2", "Chorus 1", "Chorus 1", "Bridge 1", "Bridge 1", "Chorus 1", "Chorus 1"])

    def test_whole_word_part_names_are_understood_too(self):
        from churchlight_presenter.importers.songs import _label_for
        for name, want in {"v1": ("Verse 1", "verse"), "V2": ("Verse 2", "verse"), "c": ("Chorus", "chorus"),
                           "verse1": ("Verse 1", "verse"), "Chorus 2": ("Chorus 2", "chorus"),
                           "pre-chorus": ("Pre-Chorus", "pre_chorus"), "Ending": ("Ending", "outro"),
                           "b1": ("Bridge 1", "bridge"), "v1a": ("Verse 1a", "verse"), "xyz": ("xyz", "other")}.items():
            self.assertEqual(_label_for(name, set()), want, name)

    def test_text_is_written_in_singing_order_and_reads_back(self):
        text = song_to_text(self.db, self.song).decode()
        self.assertTrue(text.startswith("Amazing Grace\n\nVerse 1\n"))
        self.assertEqual(text.count("My chains are gone"), 2)        # the repeated chorus is written out
        parsed = parse_plain_text(text)
        self.assertEqual([s[0] for s in parsed.sections], ["Verse 1", "Chorus", "Verse 2"])
        self.assertEqual(parsed.order, ["Verse 1", "Chorus", "Verse 2", "Chorus"])
        self.assertEqual((parsed.author, parsed.ccli_number), ("John Newton, Ann Example", "22025"))
        self.assertIn("Public domain", parsed.copyright)

    def test_a_text_song_with_only_an_author_keeps_it_without_inventing_a_verse(self):
        song = self.db.create_song_with_sections("Solo", [("Verse 1", "verse", "la la")], author="Someone")
        parsed = parse_plain_text(song_to_text(self.db, song).decode())
        self.assertEqual((parsed.author, [s[0] for s in parsed.sections]), ("Someone", ["Verse 1"]))

    def test_special_characters_and_blank_lines_survive_xml(self):
        song = self.db.create_song_with_sections("Tom & <Jerry>", [("Verse 1", "verse", "a & b\n\nc < d")])
        parsed = parse_openlyrics(song_to_openlyrics(self.db, song))
        self.assertEqual(parsed.title, "Tom & <Jerry>")
        self.assertEqual(parsed.sections[0][2].replace("\n\n", "\n"), "a & b\nc < d")

    def test_one_song_is_a_plain_file_and_several_are_a_zip_with_unique_names(self):
        other = make_song(self.db)                                    # same title again
        name, kind, data = export_songs(self.db, [self.song], "xml")
        self.assertEqual((name, kind.split(";")[0]), ("Amazing Grace.xml", "application/xml"))
        name, kind, data = export_songs(self.db, [self.song, other], "txt")
        self.assertTrue(name.endswith(".zip"))
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            self.assertEqual(sorted(zf.namelist()), ["Amazing Grace (2).txt", "Amazing Grace.txt"])

    def test_nothing_chosen_or_a_bad_format_is_refused(self):
        with self.assertRaises(ExportError):
            export_songs(self.db, [], "xml")
        with self.assertRaises(ExportError):
            export_songs(self.db, [self.song], "pdf")
        with self.assertRaises(ExportError):
            export_songs(self.db, [9999], "xml")

    def test_the_exported_file_imports_through_the_normal_importer(self):
        other = DatabaseManager(":memory:")
        self.addCleanup(other.close)
        for fmt in ("xml", "txt"):
            name, _kind, data = export_songs(self.db, [self.song], fmt)
            with tempfile.TemporaryDirectory() as folder:
                (Path(folder) / name).write_bytes(data)
                report = import_openlyrics(other, folder)
            self.assertEqual((len(report.imported), report.failed), (1, []), fmt)
            self.db_check(other)
            other.conn.execute("DELETE FROM songs")

    def db_check(self, other):
        row = other.search_song(title="Amazing Grace")[0]
        self.assertEqual(len(other.get_sections(row["id"])), 3)


class BundleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.media_a = Path(self.tmp.name) / "a"
        self.media_b = Path(self.tmp.name) / "b"
        (self.media_a / "decks").mkdir(parents=True)
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        pages = []
        for n in range(1, 4):
            (self.media_a / "decks" / f"p{n}.png").write_bytes(PNG + bytes([n]))
            pages.append((f"decks/p{n}.png", f"note {n}" if n != 2 else None))
        self.show = self.db.add_presentation("Welcome", pages)
        self.db.set_presentation_transition(self.show, "dissolve", 700)
        self.db.set_presentation_autoplay(self.show, 8, "loop")
        self.db.set_presentation_image_fit(self.show, "fill")
        ids = [p["id"] for p in self.db.get_presentation_pages(self.show)]
        self.db.set_presentation_pages_skipped(self.show, [ids[1]], True)
        self.db.set_presentation_pages_timing(self.show, [ids[2]], auto_seconds=3, transition="circle_in", transition_ms=300)
        self.db.reorder_presentation_pages(self.show, [ids[2], ids[0], ids[1]])

    def bundle(self):
        path = Path(self.tmp.name) / "out.zip"
        with open(path, "wb") as f:
            write_bundle(slideshow_snapshot(self.db, [self.show]), self.media_a, f)
        return path

    def test_a_slideshow_arrives_with_order_notes_and_settings(self):
        other = DatabaseManager(":memory:")
        self.addCleanup(other.close)
        report = import_bundle(other, self.bundle(), self.media_b)
        self.assertEqual([(n, p) for _i, n, p in report.imported], [("Welcome", 3)])
        pres = other.get_presentation(report.imported[0][0])
        self.assertEqual((pres["transition"], pres["transition_ms"], pres["auto_seconds"], pres["end_action"], pres["image_fit"]),
                         ("dissolve", 700, 8, "loop", "fill"))
        pages = other.get_presentation_pages(pres["id"])
        self.assertEqual([p["notes"] for p in pages], ["note 3", "note 1", None])
        self.assertEqual([bool(p["skipped"]) for p in pages], [False, False, True])
        self.assertEqual((pages[0]["auto_seconds"], pages[0]["transition"], pages[0]["transition_ms"]), (3, "circle_in", 300))
        self.assertIsNone(pages[1]["auto_seconds"])
        self.assertEqual((self.media_b / pages[0]["image_path"]).read_bytes(), PNG + bytes([3]))

    def test_importing_the_same_bundle_twice_adds_nothing(self):
        other = DatabaseManager(":memory:")
        self.addCleanup(other.close)
        bundle = self.bundle()
        import_bundle(other, bundle, self.media_b)
        again = import_bundle(other, bundle, self.media_b)
        self.assertEqual((again.imported, again.duplicates), ([], 1))
        self.assertEqual(len(other.presentation_summaries()), 1)

    def rewrite(self, change, extra=None):
        source = self.bundle()
        path = Path(self.tmp.name) / "edited.zip"
        with zipfile.ZipFile(source) as zin, zipfile.ZipFile(path, "w") as zout:
            for info in zin.infolist():
                data = zin.read(info)
                if info.filename == "slideshows.json":
                    manifest = json.loads(data)
                    change(manifest)
                    data = json.dumps(manifest).encode()
                zout.writestr(info.filename, data)
            for name, data in (extra or {}).items():
                zout.writestr(name, data)
        return path

    def refuses(self, path, words):
        other = DatabaseManager(":memory:")
        self.addCleanup(other.close)
        with self.assertRaises(ImporterError) as ctx:
            import_bundle(other, path, self.media_b)
        self.assertIn(words, str(ctx.exception))
        self.assertEqual(other.presentation_summaries(), [])

    def test_an_unsafe_or_damaged_bundle_is_refused_and_leaves_nothing(self):
        self.refuses(self.rewrite(lambda m: m["slideshows"][0]["pages"][0].update(image="../../evil.png")), "should not contain")
        self.refuses(self.rewrite(lambda m: m["slideshows"][0]["pages"][0].update(image="pictures/001/page-001.exe")), "should not contain")
        self.refuses(self.rewrite(lambda m: m["slideshows"][0].update(transition="spin")), "transition")
        self.refuses(self.rewrite(lambda m: m["slideshows"][0].update(image_fit="zoom")), "picture size")
        self.refuses(self.rewrite(lambda m: m.update(format="other")), "not a ChurchLight")
        self.refuses(self.rewrite(lambda m: m.update(version=99)), "newer version")
        self.refuses(self.rewrite(lambda m: [p.update(skipped=True) for p in m["slideshows"][0]["pages"]]), "skipped")

    def test_a_picture_that_is_not_really_a_picture_is_refused(self):
        path = self.rewrite(lambda m: None)
        bad = Path(self.tmp.name) / "bad.zip"
        with zipfile.ZipFile(path) as zin, zipfile.ZipFile(bad, "w") as zout:
            for info in zin.infolist():
                data = zin.read(info)
                zout.writestr(info.filename, b"MZ this is a program" if info.filename.endswith("page-001.png") else data)
        self.refuses(bad, "not a picture")
        self.assertEqual([p for p in self.media_b.rglob("*") if p.is_file()], [])

    def test_something_that_is_not_a_zip_is_refused(self):
        junk = Path(self.tmp.name) / "junk.zip"
        junk.write_bytes(b"hello")
        self.refuses(junk, "not a zip")

    def test_a_missing_picture_stops_the_export(self):
        (self.media_a / "decks" / "p2.png").unlink()
        with self.assertRaises(ExportError):
            self.bundle()


class ImportPlanTests(unittest.TestCase):
    def test_a_bundle_must_be_chosen_on_its_own(self):
        from churchlight_presenter.ui.controller import ControllerError
        from churchlight_presenter.ui.imports import ImportManager
        plan = ImportManager._plan("deck", [Path("Welcome.zip")])
        self.assertEqual((plan["mode"], plan["label"]), ("bundle", "Welcome"))
        with self.assertRaises(ControllerError):
            ImportManager._plan("deck", [Path("a.zip"), Path("b.pdf")])


class DownloadRouteTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        media = Path(self.tmp.name)
        (media / "decks").mkdir()
        (media / "decks" / "a.png").write_bytes(PNG)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.song = make_song(self.db)
        self.show = self.db.add_presentation("Deck", [("decks/a.png", None)])
        outputs = [Output("projector", "projector")]
        self.c = OperatorController(self.db, outputs, media_root=str(media))
        self.server = OutputServer(self.c.session, outputs, operator=OperatorApi(self.c)).start()
        self.addCleanup(self.server.close)
        self.port = self.server.address[1]

    def get(self, path, host=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        try:
            conn.request("GET", path, headers={"Host": host} if host else {})
            r = conn.getresponse()
            return r.status, dict(r.getheaders()), r.read()
        finally:
            conn.close()

    def test_a_song_downloads_as_a_file(self):
        status, headers, body = self.get(f"/api/export?kind=songs&format=txt&ids={self.song}")
        self.assertEqual(status, 200)
        self.assertIn('filename="Amazing Grace.txt"', headers["Content-Disposition"])
        self.assertTrue(body.startswith(b"Amazing Grace"))

    def test_every_song_comes_as_a_zip(self):
        make_song(self.db, "Second")
        status, headers, body = self.get("/api/export?kind=songs&format=xml&all=1")
        self.assertEqual(status, 200)
        with zipfile.ZipFile(io.BytesIO(body)) as zf:
            self.assertEqual(sorted(zf.namelist()), ["Amazing Grace.xml", "Second.xml"])

    def test_a_slideshow_downloads_as_a_bundle(self):
        status, headers, body = self.get(f"/api/export?kind=slideshows&ids={self.show}")
        self.assertEqual(status, 200)
        self.assertIn("Deck.zip", headers["Content-Disposition"])
        with zipfile.ZipFile(io.BytesIO(body)) as zf:
            self.assertIn("slideshows.json", zf.namelist())
        for _ in range(50):                      # the server removes it just after the last byte is sent
            left = list(Path(tempfile.gettempdir()).glob("churchlight-export-*.zip"))
            if not left:
                break
            time.sleep(0.1)
        self.assertEqual(left, [])

    def test_bad_requests_get_plain_answers(self):
        self.assertEqual(self.get("/api/export?kind=songs&ids=")[0], 400)
        self.assertEqual(self.get("/api/export?kind=cats")[0], 400)
        self.assertEqual(self.get("/api/export?kind=songs&ids=abc")[0], 400)
        self.assertEqual(self.get(f"/api/export?kind=songs&ids={self.song}", host="evil.example.com")[0], 403)


if __name__ == "__main__":
    unittest.main()


class LongNameAndSongSelectTests(unittest.TestCase):
    NAME = ("MP3_10_000_Reasons__Bless_The_Lord___For_use_solely_with_the_SongSelect__Terms_of_Use."
            "__All_rights_reserved._www.ccli.com_.xml")

    def test_a_long_upload_name_keeps_its_ending(self):
        from churchlight_presenter.ui.imports import safe_filename
        name = safe_filename(self.NAME)
        self.assertTrue(name.endswith(".xml"))
        self.assertLessEqual(len(name), 120)
        self.assertEqual(safe_filename("a" * 300 + ".txt")[-4:], ".txt")
        self.assertEqual(safe_filename("plain.xml"), "plain.xml")
        self.assertLessEqual(len(safe_filename("b" * 300)), 120)

    def test_the_songselect_licence_sentence_is_not_an_author_and_a_hash_is_dropped_from_the_number(self):
        xml = ('<song xmlns="http://openlyrics.info/namespace/2009/song" version="0.8"><properties>'
               "<titles><title>Ten Thousand</title></titles><ccliNo>#6016351</ccliNo><authors>"
               "<author>For use solely with the SongSelect Terms of Use.  All rights reserved. www.ccli.com</author>"
               "<author>Matt Redman</author></authors></properties>"
               '<lyrics><verse name="v1"><lines>Bless the Lord<br/>O my soul</lines></verse></lyrics></song>')
        parsed = parse_openlyrics(xml)
        self.assertEqual((parsed.author, parsed.ccli_number), ("Matt Redman", "6016351"))
