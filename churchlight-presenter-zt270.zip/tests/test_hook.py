# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Trigger URLs: a secret address that presses a few safe buttons."""
import http.client
import logging
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import LibraryEntry, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi, TRIGGER_NAMES


def make():
    db = DatabaseManager(":memory:", shared=True)
    c = OperatorController(db)
    c.new_service("S")
    for title in ("One", "Two"):
        sid = db.insert_song(title)
        db.add_section(sid, "V1", "la " + title)
        c.add_entry(LibraryEntry("song", sid, ""))
    c.go_live_service_item(c.service_rows()[0].item_id)
    return db, c


class SecretTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make()
        self.addCleanup(self.db.close)

    def test_a_long_random_secret_is_made_once_and_kept(self):
        token = self.c.hook_settings()["token"]
        self.assertGreaterEqual(len(token), 20)
        self.assertEqual(self.db.get_setting("hook") and __import__("json").loads(self.db.get_setting("hook"))["token"], token)
        again = OperatorController(self.db)
        self.assertEqual(again.hook_settings()["token"], token)

    def test_check_needs_the_exact_secret_and_the_switch_on(self):
        token = self.c.hook_settings()["token"]
        self.assertTrue(self.c.hook_check(token))
        for wrong in ("", "x", token[:-1], token + "x", None):
            self.assertFalse(self.c.hook_check(wrong))
        self.c.set_hook(on=False)
        self.assertFalse(self.c.hook_check(token))
        self.c.set_hook(on=True)
        self.assertTrue(self.c.hook_check(token))

    def test_a_new_secret_replaces_the_old_one_at_once(self):
        old = self.c.hook_settings()["token"]
        self.c.set_hook(new_token=True)
        self.assertNotEqual(self.c.hook_settings()["token"], old)
        self.assertFalse(self.c.hook_check(old))

    def test_a_damaged_stored_secret_is_replaced(self):
        self.db.set_setting("hook", '{"on": true, "token": "short"}')
        self.assertGreaterEqual(len(OperatorController(self.db).hook_settings()["token"]), 20)


class ButtonTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make()
        self.api = OperatorApi(self.c)
        self.addCleanup(self.db.close)

    def test_only_the_listed_buttons_exist(self):
        self.assertEqual(set(TRIGGER_NAMES), {"next", "previous", "next_item", "previous_item", "blank", "blank_on",
                                              "blank_off", "words", "words_hide", "words_show", "verse", "verse_on", "verse_off", "take_verse",
                                              "verse_forward", "verse_back", "media_toggle", "media_restart", "music_toggle"})
        for name in ("clear", "go_item", "remove", "theme_save", "hook_new_token", "", "../x"):
            with self.assertRaises(ApiError) as caught:
                self.api.trigger(name)
            self.assertEqual(caught.exception.status, 404)

    def test_buttons_do_their_job(self):
        self.api.trigger("blank_on")
        self.assertTrue(self.c.session.state().blank)
        self.api.trigger("blank_on")                       # pressing "on" twice stays on
        self.assertTrue(self.c.session.state().blank)
        self.api.trigger("blank_off")
        self.assertFalse(self.c.session.state().blank)
        self.api.trigger("words_hide")
        self.assertTrue(self.c.session.state().text_hidden)
        self.api.trigger("words")
        self.assertFalse(self.c.session.state().text_hidden)
        before = self.c.session.state().base_index
        self.api.trigger("next_item")
        self.assertNotEqual(self.c.session.state().base_index, before)

    def test_a_button_that_cannot_happen_says_so(self):
        with self.assertRaises(ApiError) as caught:
            self.api.trigger("take_verse")                 # nothing is ready
        self.assertEqual(caught.exception.status, 409)

    def test_state_lists_the_secret_and_buttons_for_the_settings_tab(self):
        hook = self.api.state()["hook"]
        self.assertEqual(hook["token"], self.c.hook_settings()["token"])
        self.assertEqual([a["name"] for a in hook["actions"]], list(TRIGGER_NAMES))

    def test_settings_actions(self):
        self.api.call("hook_set", {"on": False})
        self.assertFalse(self.c.hook_settings()["on"])
        with self.assertRaises(ApiError):
            self.api.call("hook_set", {"on": "yes"})
        old = self.c.hook_settings()["token"]
        self.api.call("hook_new_token", {})
        self.assertNotEqual(self.c.hook_settings()["token"], old)


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make()
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        self.addCleanup(self.db.close)
        self.host, self.port = self.server.address[:2]

    def request(self, method, path, headers=None):
        conn = http.client.HTTPConnection(self.host, self.port, timeout=10)
        conn.request(method, path, headers=headers or {})
        response = conn.getresponse()
        body = response.read().decode()
        conn.close()
        return response.status, body

    def url(self, name):
        return f"/hook/{self.c.hook_settings()['token']}/{name}"

    def test_get_and_post_press_the_button(self):
        self.assertEqual(self.request("GET", self.url("blank_on")), (200, "ok: blank_on\n"))
        self.assertTrue(self.c.session.state().blank)
        self.assertEqual(self.request("POST", self.url("blank_off"))[0], 200)
        self.assertFalse(self.c.session.state().blank)

    def test_head_never_presses_anything(self):
        status, _ = self.request("HEAD", self.url("blank_on"))
        self.assertEqual(status, 405)
        self.assertFalse(self.c.session.state().blank)

    def test_wrong_secret_wrong_button_and_switched_off_all_look_the_same(self):
        for path in ("/hook/wrong/blank_on", self.url("nothing")):
            self.assertEqual(self.request("GET", path), (404, '{"error": "Not found"}'))
        self.c.set_hook(on=False)
        self.assertEqual(self.request("GET", self.url("blank_on"))[0], 404)
        self.assertFalse(self.c.session.state().blank)

    def test_a_button_that_cannot_happen_is_a_conflict(self):
        status, body = self.request("GET", self.url("take_verse"))
        self.assertEqual(status, 409)
        self.assertIn("Nothing is ready", body)

    def test_a_request_for_another_host_name_is_refused(self):
        self.assertEqual(self.request("GET", self.url("blank_on"), {"Host": "evil.example"})[0], 403)
        self.assertFalse(self.c.session.state().blank)

    def test_a_request_from_another_site_is_refused(self):
        status, _ = self.request("GET", self.url("blank_on"), {"Origin": "http://evil.example"})
        self.assertEqual(status, 403)
        self.assertFalse(self.c.session.state().blank)

    def test_many_wrong_tries_are_slowed_down(self):
        for _ in range(10):
            self.assertEqual(self.request("GET", "/hook/guess/blank_on")[0], 404)
        self.assertEqual(self.request("GET", "/hook/guess/blank_on")[0], 429)
        self.assertEqual(self.request("GET", self.url("blank_on"))[0], 429)      # even the right one waits out the minute

    def test_the_secret_is_kept_out_of_the_log(self):
        token = self.c.hook_settings()["token"]
        with self.assertLogs("churchlight_presenter.server.app", level="DEBUG") as logs:
            self.request("GET", self.url("blank_on"))
            logging.getLogger("churchlight_presenter.server.app").debug("keep the test alive")
        self.assertNotIn(token, "\n".join(logs.output))
        self.assertIn("/hook/***", "\n".join(logs.output))


if __name__ == "__main__":
    unittest.main()
