# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Exporting themes to a file and importing them on another computer."""
import http.client
import io
import json
import tempfile
import time
import unittest
import zipfile
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.export import (
    ExportError, THEMES_MANIFEST, theme_snapshot, themes_file_name, write_themes_bundle)
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.core.themes import STARTER_THEMES, ensure_starter_themes
from churchlight_presenter.importers.common import ImporterError
from churchlight_presenter.importers.themes import import_themes
from churchlight_presenter.server.app import OutputServer
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.imports import ImportManager
from churchlight_presenter.ui.operator_api import OperatorApi

PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 40
STYLE = {"font_family": "Georgia, serif", "font_size": 8.0, "color": "#ffffff", "align": "left",
         "band": True, "band_color": "#000000b0", "reference_pos": "above", "balance_lines": True}


def make_zip(path, manifest, extra=None):
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr(THEMES_MANIFEST, json.dumps(manifest))
        for name, data in (extra or {}).items():
            zf.writestr(name, data)


def manifest(*themes, version=1):
    return {"format": "churchlight-themes", "version": version, "themes": list(themes)}


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.media = self.dir / "media"
        (self.media / "backgrounds").mkdir(parents=True)
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)

    def make_picture(self, name="0123456789abcdef.png"):
        (self.media / "backgrounds" / name).write_bytes(PNG)
        return "backgrounds/" + name

    def bundle(self, themes):
        path = self.dir / "out.zip"
        with open(path, "wb") as f:
            write_themes_bundle(themes, self.media, f)
        return path


class ExportTests(Base):
    def test_starters_that_were_never_changed_are_left_out_of_export_all(self):
        ensure_starter_themes(self.db)
        mine = self.db.add_theme("Easter", {"kind": "projector", "style": dict(STYLE), "lines_per_slide": 3})
        names = [t["name"] for t in theme_snapshot(self.db)]
        self.assertEqual(names, ["Easter"])
        edited = self.db.list_themes()[0]
        settings = self.db.get_theme_settings(edited["id"])
        settings["style"]["font_size"] = 9.0
        self.db.update_theme(edited["id"], settings=settings)
        self.assertIn(edited["name"], [t["name"] for t in theme_snapshot(self.db)])
        self.assertEqual(mine, mine)

    def test_a_chosen_starter_is_exported_when_asked_for_by_number(self):
        ensure_starter_themes(self.db)
        first = self.db.list_themes()[0]
        self.assertEqual([t["name"] for t in theme_snapshot(self.db, [first["id"]])], [first["name"]])

    def test_nothing_to_export_is_a_plain_message(self):
        ensure_starter_themes(self.db)
        with self.assertRaises(ExportError):
            theme_snapshot(self.db)
        with self.assertRaises(ExportError):
            theme_snapshot(self.db, [])

    def test_the_file_holds_look_slide_settings_and_the_picture_but_not_where_it_is_used(self):
        picture = self.make_picture()
        style = dict(STYLE, background_image=picture)
        theme_id = self.db.add_theme("Easter", {"kind": "projector", "style": style, "lines_per_slide": 3,
                                                "scripture_split": "chars"})
        self.db.set_setting("default_theme", str(theme_id))
        path = self.bundle(theme_snapshot(self.db, [theme_id]))
        with zipfile.ZipFile(path) as zf:
            data = json.loads(zf.read(THEMES_MANIFEST))
            self.assertEqual(sorted(n for n in zf.namelist() if n != THEMES_MANIFEST), ["pictures/001.png"])
        entry = data["themes"][0]
        self.assertEqual((data["format"], data["version"]), ("churchlight-themes", 1))
        self.assertEqual(entry["name"], "Easter")
        self.assertEqual(entry["build"], {"lines_per_slide": 3, "scripture_split": "chars"})
        self.assertEqual(entry["picture"], "pictures/001.png")
        self.assertNotIn("background_image", entry["style"])
        self.assertNotIn("usage", entry)
        self.assertNotIn("id", entry)

    def test_file_names(self):
        self.assertEqual(themes_file_name([{"name": "Easter / Spring"}]), "Easter _ Spring (theme).zip")
        self.assertTrue(themes_file_name([{"name": "a"}, {"name": "b"}]).startswith("ChurchLight themes "))


class ImportTests(Base):
    def other_media(self):
        media = self.dir / "other-media"
        media.mkdir()
        return media

    def test_a_theme_travels_to_another_database(self):
        picture = self.make_picture()
        theme_id = self.db.add_theme("Easter", {"kind": "projector", "style": dict(STYLE, background_image=picture),
                                                "lines_per_slide": 3})
        overlay_id = self.db.add_theme("Lower", {"kind": "overlay", "style": {"font_size": 5.0, "v_pos": "top"}})
        path = self.bundle(theme_snapshot(self.db, [theme_id, overlay_id]))
        there = DatabaseManager(":memory:")
        self.addCleanup(there.close)
        media = self.other_media()
        report = import_themes(there, path, media)
        self.assertEqual(sorted(report.added), ["Easter", "Lower"])
        rows = {r["name"]: there.get_theme_settings(r["id"]) for r in there.list_themes()}
        easter = rows["Easter"]
        self.assertEqual((easter["kind"], easter["lines_per_slide"]), ("projector", 3))
        self.assertEqual(easter["style"]["reference_pos"], "above")
        self.assertTrue(easter["style"]["balance_lines"])
        self.assertRegex(easter["style"]["background_image"], r"^backgrounds/[0-9a-f]{16}\.png$")
        self.assertEqual((media / easter["style"]["background_image"]).read_bytes(), PNG)
        self.assertEqual(rows["Lower"]["kind"], "overlay")
        self.assertTrue(rows["Lower"]["style"]["band"])

    def test_importing_never_makes_a_default_or_changes_a_setting(self):
        theme_id = self.db.add_theme("Easter", {"kind": "projector", "style": dict(STYLE)})
        path = self.bundle(theme_snapshot(self.db, [theme_id]))
        there = DatabaseManager(":memory:")
        self.addCleanup(there.close)
        import_themes(there, path, self.other_media())
        for key in ("default_theme", "default_overlay_theme", "bible_theme", "confidence_theme"):
            self.assertIsNone(there.get_setting(key))

    def test_the_same_theme_twice_is_skipped_and_a_changed_one_gets_a_new_name(self):
        theme_id = self.db.add_theme("Easter", {"kind": "projector", "style": dict(STYLE)})
        path = self.bundle(theme_snapshot(self.db, [theme_id]))
        report = import_themes(self.db, path, self.media)
        self.assertEqual((report.added, report.duplicates), ([], 1))
        settings = self.db.get_theme_settings(theme_id)
        settings["style"]["font_size"] = 9.0
        self.db.update_theme(theme_id, settings=settings)
        report = import_themes(self.db, path, self.media)
        self.assertEqual(report.added, ["Easter (2)"])
        report = import_themes(self.db, path, self.media)               # already there now, under the new name too
        self.assertEqual(report.added, [])                                # and not added a third time
        self.assertEqual(sorted(r["name"] for r in self.db.list_themes())[:2], ["Easter", "Easter (2)"])

    def test_the_same_picture_is_recognised_as_the_same_theme(self):
        picture = self.make_picture()
        theme_id = self.db.add_theme("Easter", {"kind": "projector", "style": dict(STYLE, background_image=picture)})
        path = self.bundle(theme_snapshot(self.db, [theme_id]))
        report = import_themes(self.db, path, self.media)
        self.assertEqual((report.added, report.duplicates), ([], 1))
        self.assertEqual(len(list((self.media / "backgrounds").iterdir())), 1)       # no stray copy

    def test_settings_from_a_newer_version_are_skipped_and_reported(self):
        path = self.dir / "new.zip"
        make_zip(path, manifest({"name": "Future", "kind": "projector",
                                 "style": dict(STYLE, hologram=True, font_size=999),
                                 "build": {"lines_per_slide": 3, "magic": 1}}))
        report = import_themes(self.db, path, self.media)
        self.assertEqual(report.added, ["Future"])
        settings = self.db.get_theme_settings(self.db.list_themes()[0]["id"])
        self.assertEqual(settings["style"]["font_family"], "Georgia, serif")
        self.assertNotIn("hologram", settings["style"])
        self.assertNotIn("font_size", settings["style"])
        self.assertEqual(settings["lines_per_slide"], 3)
        self.assertIn("hologram", " ".join(report.warnings))
        self.assertIn("font_size", " ".join(report.warnings))

    def test_a_theme_of_an_unknown_kind_or_without_a_name_is_skipped(self):
        path = self.dir / "odd.zip"
        make_zip(path, manifest({"name": "Hologram", "kind": "hologram", "style": {}},
                                {"name": "  ", "kind": "projector", "style": {}},
                                "not a theme",
                                {"name": "Fine", "kind": "confidence", "style": {"font_size": 12}}))
        report = import_themes(self.db, path, self.media)
        self.assertEqual(report.added, ["Fine"])
        self.assertEqual(len(report.warnings), 3)

    def test_bad_files_are_refused_in_plain_words(self):
        for name, build, message in [
            ("a.zip", lambda p: p.write_bytes(b"nope"), "not a zip"),
            ("b.zip", lambda p: zipfile.ZipFile(p, "w").close(), "no themes.json"),
            ("c.zip", lambda p: make_zip(p, {"format": "other", "version": 1, "themes": [{}]}), "not a ChurchLight themes"),
            ("d.zip", lambda p: make_zip(p, manifest({"name": "x"}, version=99)), "newer version"),
            ("e.zip", lambda p: make_zip(p, manifest()), "no themes"),
        ]:
            path = self.dir / name
            build(path)
            with self.assertRaises(ImporterError, msg=name) as caught:
                import_themes(self.db, path, self.media)
            self.assertIn(message, str(caught.exception), name)
        self.assertEqual(list(self.db.list_themes()), [])

    def test_pictures_must_be_real_pictures_with_the_expected_names(self):
        path = self.dir / "pics.zip"
        make_zip(path, manifest(
            {"name": "Fake", "kind": "projector", "style": {}, "picture": "pictures/001.png"},
            {"name": "Sneaky", "kind": "projector", "style": {}, "picture": "../../evil.png"},
            {"name": "Good", "kind": "projector", "style": {}, "picture": "pictures/002.png"}),
            {"pictures/001.png": b"not a picture", "pictures/002.png": PNG})
        report = import_themes(self.db, path, self.media)
        self.assertEqual(sorted(report.added), ["Fake", "Good", "Sneaky"])
        by_name = {r["name"]: self.db.get_theme_settings(r["id"])["style"] for r in self.db.list_themes()}
        self.assertNotIn("background_image", by_name["Fake"])
        self.assertNotIn("background_image", by_name["Sneaky"])
        self.assertIn("background_image", by_name["Good"])
        self.assertEqual(len(list((self.media / "backgrounds").iterdir())), 1)

    def test_two_themes_sharing_a_picture_store_it_once(self):
        picture = self.make_picture()
        ids = [self.db.add_theme(n, {"kind": "projector", "style": dict(STYLE, background_image=picture, font_size=s)})
               for n, s in (("One", 6.0), ("Two", 7.0))]
        path = self.bundle(theme_snapshot(self.db, ids))
        with zipfile.ZipFile(path) as zf:
            self.assertEqual([n for n in zf.namelist() if n.startswith("pictures/")], ["pictures/001.png"])
        there = DatabaseManager(":memory:")
        self.addCleanup(there.close)
        media = self.other_media()
        import_themes(there, path, media)
        used = {there.get_theme_settings(r["id"])["style"]["background_image"] for r in there.list_themes()}
        self.assertEqual(len(used), 1)


class ControllerAndRouteTests(Base):
    def setUp(self):
        super().setUp()
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        outputs = [Output("projector", "projector")]
        self.c = OperatorController(self.db, outputs, media_root=str(self.media))
        self.c.imports = ImportManager(self.c)
        self.addCleanup(self.c.imports.close)
        self.api = OperatorApi(self.c)
        self.server = OutputServer(self.c.session, outputs, operator=self.api).start()
        self.addCleanup(self.server.close)
        self.port = self.server.address[1]
        self.theme = self.c.save_theme("Easter", dict(STYLE), None, {"lines_per_slide": 3}, "projector")

    def get(self, path):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        try:
            conn.request("GET", path)
            r = conn.getresponse()
            return r.status, dict(r.getheaders()), r.read()
        finally:
            conn.close()

    def test_a_theme_downloads_as_a_file_and_imports_through_the_api(self):
        before = set(Path(tempfile.gettempdir()).glob("churchlight-themes-*.zip"))
        status, headers, body = self.get(f"/api/export?kind=themes&ids={self.theme}")
        self.assertEqual(status, 200)
        self.assertIn("Easter (theme).zip", headers["Content-Disposition"])
        for _ in range(50):                      # the server removes it just after the last byte is sent
            left = set(Path(tempfile.gettempdir()).glob("churchlight-themes-*.zip")) - before
            if not left:
                break
            time.sleep(0.1)
        self.assertEqual(left, set())            # the temporary file is removed
        self.c.delete_theme(self.theme)
        batch = self.api.call("import_batch")["batch"]
        self.c.imports.save_upload(batch, "Easter (theme).zip", io.BytesIO(body), len(body), "themes")
        version = self.c.version
        result = self.api.call("theme_import", {"batch": batch})
        self.assertEqual(result["added"], ["Easter"])
        self.assertGreater(self.c.version, version)           # the page is told, so its theme list refreshes
        self.assertIn("Easter", [t["name"] for t in self.api.state()["themes"]])
        self.assertEqual([t["name"] for t in self.c.theme_details()], ["Easter"])
        self.assertEqual(self.c.theme_details()[0]["build"], {"lines_per_slide": 3})
        self.assertFalse((self.c.imports.upload_root / batch).exists())          # the upload is cleaned up

    def test_export_all_with_nothing_of_your_own_is_a_clear_answer(self):
        self.c.delete_theme(self.theme)
        self.assertEqual(self.get("/api/export?kind=themes&all=1")[0], 400)

    def test_a_wrong_file_is_refused_and_cleaned_up(self):
        batch = self.api.call("import_batch")["batch"]
        data = b"just some text"
        self.c.imports.save_upload(batch, "x.zip", io.BytesIO(data), len(data), "themes")
        with self.assertRaises(Exception) as caught:
            self.api.call("theme_import", {"batch": batch})
        self.assertIn("zip", str(caught.exception).lower())
        self.assertFalse((self.c.imports.upload_root / batch).exists())
        with self.assertRaises(ControllerError):
            self.c.imports.save_upload(self.api.call("import_batch")["batch"], "x.png", io.BytesIO(PNG), len(PNG), "themes")


if __name__ == "__main__":
    unittest.main()
