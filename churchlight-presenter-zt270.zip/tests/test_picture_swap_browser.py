# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A slideshow picture that is slow to arrive must not leave an empty screen (a "background flicker")."""
import struct
import time
import unittest
import zlib

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.server.app import OutputServer
from churchlight_presenter.ui.controller import OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


def tiny_png(shade):
    def chunk(kind, data):
        body = kind + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body))
    row = b"\x00" + bytes([shade, shade, shade]) * 2
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 2, 2, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(row * 2)) + chunk(b"IEND", b""))


def picture_payload(name, version):
    slide = {"kind": "image", "item_type": "presentation", "text": "", "segments": [], "label": name, "reference": "",
             "verse_numbers": [], "continued": False, "image_path": f"decks/{name}.png", "theme_id": None,
             "title_first": False, "source_item_id": None, "style": None, "transition": None, "transition_ms": 0,
             "image_fit": "fit"}
    return {"schema": 1, "version": version, "output": "projector", "layout": "projector", "audience": "public",
            "theme_id": None, "blank": False, "base": slide, "overlay": None, "transitions": True, "preload": []}


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class PictureSwapTests(unittest.TestCase):
    def test_the_old_picture_stays_until_the_new_one_has_loaded(self):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        outputs = [Output("projector", "projector")]
        controller = OperatorController(db, outputs)
        server = OutputServer(controller.session, outputs).start()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        pictures = {"a": tiny_png(40), "b": tiny_png(200)}

        def slow(route):
            time.sleep(0.25)                                   # a picture that takes a moment to arrive
            route.fulfill(body=pictures[route.request.url.rsplit("/", 1)[1].split(".")[0]], content_type="image/png")

        page = browser.new_page(viewport={"width": 640, "height": 360})
        page.route("**/media/**", slow)
        page.add_init_script("window.fetch = () => new Promise(() => {});")
        page.goto(f"http://127.0.0.1:{server.address[1]}/view/projector")
        empty_frames = page.evaluate("""async ([a, b]) => {
            const root = document.getElementById('root');
            await render(a, root);
            await new Promise((resolve) => setTimeout(resolve, 600));
            let empty = 0, stop = false;
            const look = () => {
                const img = root.querySelector('.frame:last-child img');
                if (!img || !(img.complete && img.naturalWidth > 0)) empty++;
                if (!stop) requestAnimationFrame(look);
            };
            look();
            await render(b, root);
            await new Promise((resolve) => setTimeout(resolve, 600));
            stop = true;
            return [empty, root.children.length];
        }""", [picture_payload("a", 1), picture_payload("b", 2)])
        self.assertEqual(empty_frames, [0, 1])          # never empty, and only the new picture is left in the end


if __name__ == "__main__":
    unittest.main()
