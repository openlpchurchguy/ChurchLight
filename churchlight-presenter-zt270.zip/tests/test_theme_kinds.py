# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Themes for three kinds of output: projector, overlay (lower third) and the confidence monitor."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

STYLE = {"font_family": "Arial", "font_size": 6, "color": "#ffffff"}
STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


class Base(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db)
        self.api = OperatorApi(self.c)
        self.proj = self.c.save_theme("Proj", dict(STYLE, color="#111111"))
        self.over = self.c.save_theme("Over", dict(STYLE, color="#222222, "[:7], v_pos="top", h_pos="right"),
                                      kind="overlay")
        self.conf = self.c.save_theme("Conf", dict(STYLE, color="#ffe600", font_size=15), kind="confidence")
        self.c.new_service("S")
        self.c.add_announcement("Hello", "words")
        self.item = self.c.service_rows()[0].item_id

    def live(self):
        self.c.go_live_service_item(self.item)
        return self.c.payloads()


class KindTests(Base):
    def test_a_theme_has_a_kind_that_cannot_change(self):
        kinds = {t["name"]: t["kind"] for t in self.c.theme_details()}
        self.assertEqual(kinds, {"Proj": "projector", "Over": "overlay", "Conf": "confidence"})
        with self.assertRaisesRegex(ControllerError, "cannot be changed"):
            self.c.save_theme("Over", STYLE, self.over, kind="projector")
        self.c.save_theme("Over", dict(STYLE, v_pos="middle"), self.over)       # saving without a kind is fine
        self.assertEqual({t["id"]: t["kind"] for t in self.c.theme_details()}[self.over], "overlay")

    def test_old_themes_without_a_kind_are_projector_themes(self):
        old = self.db.add_theme("Old", {"style": {"color": "#ffffff"}})
        self.assertEqual({t["id"]: t["kind"] for t in self.c.theme_details()}[old], "projector")
        self.c.set_service_theme(old)                                          # usable as a projector theme

    def test_the_wrong_kind_is_refused_everywhere(self):
        for call in (lambda: self.c.set_service_theme(self.over), lambda: self.c.set_service_theme(self.proj, "overlay"),
                     lambda: self.c.set_item_theme(self.item, self.conf), lambda: self.c.set_bible_theme(self.over),
                     lambda: self.c.set_default_theme(self.conf), lambda: self.c.set_confidence_theme(self.proj)):
            with self.assertRaisesRegex(ControllerError, "theme"):
                call()
        with self.assertRaises(ControllerError):
            self.c.set_service_theme(self.proj, "confidence")                  # not chosen per service

    def test_overlays_are_always_translucent(self):
        low = self.c.save_theme("Solid", dict(STYLE, band=False, band_color="#000000"), kind="overlay")
        style = {t["id"]: t["style"] for t in self.c.theme_details()}[low]
        self.assertTrue(style["band"])
        self.assertEqual(style["band_color"], "#000000e6")
        faint = self.c.save_theme("Faint", dict(STYLE, band_color="#000000"[:7] + "40"), kind="overlay")
        self.assertEqual({t["id"]: t["style"] for t in self.c.theme_details()}[faint]["band_color"], "#00000040")


class OutputTests(Base):
    def test_each_output_uses_its_own_kind_of_theme(self):
        self.c.set_service_theme(self.proj)
        self.c.set_service_theme(self.over, "overlay")
        self.c.set_confidence_theme(self.conf)
        payloads = self.live()
        self.assertEqual(payloads["projector"]["base"]["style"]["color"], "#111111")
        self.assertEqual(payloads["lower-third"]["base"]["style"]["color"], "#222222")
        self.assertEqual(payloads["lower-third"]["base"]["style"]["v_pos"], "top")
        self.assertEqual(payloads["confidence"]["base"]["style"]["color"], "#ffe600")
        self.assertEqual(payloads["confidence"]["base"]["style"]["font_size"], 15.0)

    def test_swapping_the_overlay_theme_for_one_item_or_the_service(self):
        other = self.c.save_theme("Over 2", dict(STYLE, color="#333333", v_pos="bottom"), kind="overlay")
        self.c.set_service_theme(self.over, "overlay")
        self.assertEqual(self.live()["lower-third"]["base"]["style"]["color"], "#222222")
        self.c.set_item_theme(self.item, other, "overlay")
        self.assertEqual(self.c.payloads()["lower-third"]["base"]["style"]["color"], "#333333")
        self.assertEqual(self.c.service_rows()[0].overlay_theme_id, other)
        self.c.set_item_theme(self.item, None, "overlay")
        self.assertEqual(self.c.payloads()["lower-third"]["base"]["style"]["color"], "#222222")
        # the projector look is unaffected by overlay choices
        self.assertIsNone(self.c.payloads()["projector"]["base"]["style"])

    def test_no_confidence_theme_means_no_style_and_it_never_follows_the_service(self):
        self.c.set_service_theme(self.proj)
        self.assertIsNone(self.live()["confidence"]["base"]["style"])

    def test_the_confidence_monitor_keeps_showing_while_the_screens_are_blanked(self):
        self.c.set_confidence_theme(self.conf)
        self.c.go_live_service_item(self.item)
        self.c.session.set_blank(True)
        payloads = self.c.payloads()
        self.assertIsNone(payloads["projector"]["base"])
        self.assertIsNone(payloads["lower-third"]["base"])
        self.assertEqual(payloads["confidence"]["base"]["text"], "words")
        self.assertTrue(payloads["confidence"]["blank"])

    def test_the_confidence_payload_never_carries_notes(self):
        self.assertEqual(self.live()["confidence"]["audience"], "confidence")
        self.assertNotIn("notes", self.c.payloads()["confidence"]["base"])

    def test_the_web_server_gets_the_confidence_theme_too(self):
        import json as _json
        import urllib.request
        server = self.c.serve()
        self.addCleanup(self.c.close)
        self.c.set_confidence_theme(self.conf)
        self.c.go_live_service_item(self.item)
        data = _json.load(urllib.request.urlopen(f"{server.url}/out/confidence"))
        self.assertEqual(data["base"]["style"]["color"], "#ffe600")


class DefaultsTests(Base):
    def test_new_services_start_with_both_defaults(self):
        self.c.set_default_theme(self.proj)
        self.c.set_default_theme(self.over, "overlay")
        self.c.new_service("Next")
        row = self.db.get_service(self.c.service_id)
        self.assertEqual((row["theme_id"], row["overlay_theme_id"]), (self.proj, self.over))

    def test_deleting_clears_every_assignment_it_held(self):
        self.c.set_default_theme(self.over, "overlay")
        self.c.set_confidence_theme(self.conf)
        self.c.set_service_theme(self.over, "overlay")
        self.c.set_item_theme(self.item, self.over, "overlay")
        usage = {t["id"]: t["usage"] for t in self.c.theme_details()}
        self.assertEqual((usage[self.over]["services"], usage[self.over]["items"]), (1, 1))
        self.assertTrue(usage[self.conf]["confidence"])
        self.c.delete_theme(self.over)
        self.c.delete_theme(self.conf)
        self.assertIsNone(self.c.default_overlay_theme_id)
        self.assertIsNone(self.c.confidence_theme_id)
        self.assertIsNone(self.db.get_service(self.c.service_id)["overlay_theme_id"])
        self.assertIsNone(self.c.styles.confidence_theme_id)

    def test_the_api(self):
        self.api.call("service_theme", {"id": self.over, "kind": "overlay"})
        self.api.call("default_theme", {"id": self.over, "kind": "overlay"})
        self.api.call("confidence_theme", {"id": self.conf})
        self.api.call("item_theme", {"item_id": self.item, "id": self.over, "kind": "overlay"})
        state = self.api.state()
        self.assertEqual(state["service"]["overlay_theme_id"], self.over)
        self.assertEqual((state["default_overlay_theme"], state["confidence_theme"]), (self.over, self.conf))
        self.assertEqual(state["items"][0]["overlay_theme_id"], self.over)
        self.assertEqual({t["kind"] for t in state["themes"]}, {"projector", "overlay", "confidence"})
        made = self.api.call("theme_save", {"name": "New conf", "style": STYLE, "kind": "confidence"})
        self.assertIn("id", made)
        for bad in ({"id": self.over, "kind": "confidence"}, {"id": self.over, "kind": "nope"}):
            with self.assertRaises(ApiError):
                self.api.call("service_theme", bad)
        with self.assertRaises(ApiError):
            self.api.call("theme_save", {"name": "X", "style": STYLE, "kind": "nope"})

    def test_the_confidence_output_is_in_the_default_outputs(self):
        self.assertIn("confidence", [o["name"] for o in self.api.state()["outputs"]])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PositionScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "output.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def css(self, style, placement="lower"):
        return dict(self.js(f"m.styleToCss({json.dumps(style)}, '{placement}')"))

    def test_corners_and_centers(self):
        top_right = self.css({"v_pos": "top", "h_pos": "right", "box_width": 40, "margin": 3})
        self.assertEqual((top_right["top"], top_right["bottom"], top_right["right"], top_right["left"]),
                         ("3vh", "auto", "3vh", "auto"))
        self.assertEqual(top_right["width"], "40%")
        self.assertNotIn("transform", top_right)
        middle = self.css({"v_pos": "middle", "h_pos": "center"})
        self.assertEqual(middle["transform"], "translateY(-50%) translateX(-50%)")
        bottom_left = self.css({"v_pos": "bottom", "h_pos": "left"})
        self.assertEqual((bottom_left["bottom"], bottom_left["left"]), ("4vh", "4vh"))

    def test_a_height_cap_limits_the_box(self):
        capped = self.css({"v_pos": "bottom", "max_height": 25})
        self.assertEqual((capped["max-height"], capped["overflow"]), ("25vh", "hidden"))
        self.assertNotIn("max-height", self.css({"v_pos": "bottom", "max_height": 0}))

    def test_a_theme_without_a_position_leaves_the_page_style_alone(self):
        self.assertEqual(self.js("m.boxPosition({color:'#fff'})"), [])
        self.assertNotIn("width", self.css({"color": "#ffffff"}))

    def test_positions_only_apply_to_the_overlay_placement(self):
        self.assertNotIn("transform", self.css({"v_pos": "middle", "h_pos": "center"}, "full"))

    def test_the_confidence_layout_replaces_the_slide_with_a_verse(self):
        payload = {"layout": "confidence", "audience": "confidence", "blank": True,
                   "base": {"kind": "song", "text": "a", "segments": [], "verse_numbers": []},
                   "overlay": {"kind": "scripture", "text": "v", "reference": "John 3:16", "segments": [],
                               "verse_numbers": []}}
        view = self.js(f"m.viewModel({json.dumps(payload)})")
        self.assertEqual([layer["placement"] for layer in view["layers"]], ["confidence"])
        self.assertEqual(view["layers"][0]["view"]["reference"], "John 3:16")
        self.assertTrue(view["blank"] and view["confidence"])


if __name__ == "__main__":
    unittest.main()
