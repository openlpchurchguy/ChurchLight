# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Settings: Everyday and Advanced groups, a caption and a "?" under every title, and a bar that looks clickable."""
import re
import unittest
from pathlib import Path

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


class MarkupTests(unittest.TestCase):
    def test_everyday_and_advanced_hold_the_right_folds_in_order(self):
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        everyday = html[html.index('class="settings-group">Everyday'):html.index('settings-advanced')]
        advanced = html[html.index('settings-advanced'):html.index('id="build-note"')]
        self.assertEqual(re.findall(r'data-settings-fold="(\w+)"', everyday), ["windows", "screens", "notice", "themes"])
        self.assertEqual(re.findall(r'data-settings-fold="(\w+)"', advanced), ["advanced", "pdf", "triggers", "clicker", "keys", "anykeys"])

    def test_every_fold_has_a_caption_and_a_longer_sentence(self):
        js = (STATIC / "operator.js").read_text(encoding="utf-8")
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        for name in re.findall(r'data-settings-fold="(\w+)"', html):
            self.assertRegex(js, name + r': \["[^"]{15,}",\s*"[^"]{40,}"\]', name)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1500, "height": 1000})
        self.page.goto(server.url.rstrip("/") + "/operator")
        self.page.wait_for_selector("#connection")
        self.page.evaluate("wizardHide(); showView('shortcuts')")

    def test_the_question_mark_shows_a_sentence_without_opening_the_section_and_escape_hides_it(self):
        fold = "details[data-settings-fold=windows]"
        self.assertEqual(self.page.get_attribute(fold, "open"), None)                 # starts folded
        self.assertTrue(self.page.is_hidden(fold + " .fold-why"))
        self.page.click(fold + " .fold-help")
        self.assertTrue(self.page.is_visible(fold + " .fold-why"))
        self.assertEqual(self.page.get_attribute(fold + " .fold-help", "aria-expanded"), "true")
        self.assertEqual(self.page.get_attribute(fold, "open"), None)                 # the section did not open
        self.page.keyboard.press("Escape")
        self.assertTrue(self.page.is_hidden(fold + " .fold-why"))
        self.page.click(fold + " .fold-help")
        self.page.click(fold + " .fold-help")
        self.assertTrue(self.page.is_hidden(fold + " .fold-why"))                     # again hides it

    def test_the_whole_bar_opens_the_section_and_has_a_chevron_at_the_right_end(self):
        fold = "details[data-settings-fold=notice]"
        box = self.page.eval_on_selector(fold, "e => { const r = e.getBoundingClientRect(); const s = e.querySelector('summary').getBoundingClientRect(); return [r.width, s.width, r.left, s.left]; }")
        self.assertAlmostEqual(box[0], box[1], delta=2)                               # the bar is as wide as the section
        self.page.click(fold + " summary", position={"x": box[1] - 40, "y": 10})      # far right, away from the words
        self.assertTrue(self.page.eval_on_selector(fold, "e => e.open"))
        chevron = self.page.eval_on_selector(fold + " summary", "e => getComputedStyle(e, '::after').content")
        self.assertIn("▸", chevron)

    def test_advanced_is_one_folded_heading_holding_five_sections(self):
        advanced = "details[data-settings-fold=advanced]"
        self.assertEqual(self.page.locator(advanced + " details[data-settings-fold]").count(), 5)
        self.assertEqual(self.page.get_attribute(advanced, "open"), None)
        self.page.click("#settings-fold-all")                                         # Open all opens it too
        self.assertTrue(self.page.eval_on_selector(advanced, "e => e.open"))
