# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Long videos (up to 8 GB) are accepted, a disk too full to hold one is explained before anything is written."""
import io
import shutil
import tempfile
import unittest
from collections import namedtuple
from pathlib import Path
from unittest import mock

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui import imports as imports_module
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.imports import ImportManager

GB = 1024 ** 3
Usage = namedtuple("Usage", "total used free")


class BigVideoTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        self.c.imports = ImportManager(self.c)
        self.addCleanup(self.c.imports.close)

    def save(self, length):
        batch = self.c.imports.new_batch()
        return batch, lambda: self.c.imports.save_upload(batch, "Camp.mp4", io.BytesIO(b"x" * 10), length, "media")

    def test_the_limit_is_eight_gigabytes_for_the_file_and_the_batch(self):
        self.assertEqual(imports_module.MAX_FILE_BYTES["media"], 8 * GB)
        self.assertGreaterEqual(imports_module.MAX_BATCH_BYTES, 8 * GB)
        _, save = self.save(8 * GB + 1)
        with self.assertRaisesRegex(ControllerError, "too large"):
            save()

    def test_a_file_the_disk_cannot_hold_is_refused_in_plain_words_with_nothing_written(self):
        batch, save = self.save(5 * GB)
        with mock.patch.object(imports_module.shutil, "disk_usage", return_value=Usage(100 * GB, 98 * GB, 2 * GB)):
            with self.assertRaises(ControllerError) as problem:
                save()
        text = str(problem.exception)
        self.assertIn("Camp.mp4", text)
        self.assertIn("5.0 GB", text)
        self.assertIn("2.0 GB free", text)
        self.assertEqual(list((self.tmp / "media" / ".uploads" / batch).iterdir()), [])

    def test_a_file_that_fits_is_stored(self):
        batch, save = self.save(10)
        with mock.patch.object(imports_module.shutil, "disk_usage", return_value=Usage(100 * GB, 10 * GB, 90 * GB)):
            self.assertEqual(save(), "Camp.mp4")


if __name__ == "__main__":
    unittest.main()
