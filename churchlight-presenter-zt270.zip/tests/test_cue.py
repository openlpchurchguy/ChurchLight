# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Cue and take: a verse run is added to the service and made ready, then taken live on its own."""
import unittest

from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.operator_api import ApiError
from tests.test_verse_tray import deck_live, make


class CueTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.c.new_service("S")
        deck_live(self.c)
        self.c.load_tray("John 3")

    def items(self):
        return [(r["verse_start"], r["verse_end"]) for r in self.db.get_service_items(self.c.service_id)]

    def live(self):
        return self.c.session.state().base

    def test_cueing_adds_the_verse_to_the_end_of_the_chapter_and_changes_nothing_on_screen(self):
        before = self.live()
        ids = self.c.cue_tray([2], to_end=True)
        self.assertEqual(self.items(), [(2, 6)])                  # one item, verse 2 to the end of the chapter
        self.assertEqual(self.c.cue["item_id"], ids[0])
        self.assertEqual(self.live(), before)                     # the screens did not change
        self.assertIsNone(self.c.session.state().overlay)

    def test_without_to_end_the_chosen_verses_stay_as_chosen(self):
        self.c.cue_tray([2, 3])
        self.assertEqual(self.items(), [(2, 3)])

    def test_each_slide_is_one_verse_with_its_own_reference(self):
        self.c.cue_tray([2], to_end=True)
        self.c.take_cue()
        seen = []
        for _ in range(5):
            slide = self.live()
            seen.append((slide.verse_numbers, slide.reference, slide.title_first))
            self.c.next()
        self.assertEqual([ref for _, ref, _ in seen[:3]], ["John 3:2", "John 3:3", "John 3:4"])
        self.assertTrue(all(title for _, _, title in seen))
        self.assertEqual([n for n, _, _ in seen[:3]], [(2,), (3,), (4,)])
        self.assertTrue(all(len(n) == 1 for n, _, _ in seen))          # never two verses on one slide

    def test_take_puts_it_live_in_place_of_what_was_on_screen_and_next_steps_one_verse(self):
        self.c.cue_tray([2], to_end=True)
        self.c.take_cue()
        self.assertEqual((self.live().reference, self.live().verse_numbers), ("John 3:2", (2,)))
        self.assertIsNone(self.c.session.state().overlay)         # in place of the slideshow, not over it
        self.assertIsNone(self.c.cue)                             # taken: no longer ready
        self.c.next()
        self.assertEqual(self.live().verse_numbers, (3,))

    def test_take_with_nothing_ready_is_refused(self):
        with self.assertRaisesRegex(ControllerError, "Nothing is ready"):
            self.c.take_cue()

    def test_a_newer_cue_replaces_the_older_and_clear_cue_drops_it(self):
        first = self.c.cue_tray([1])[0]
        second = self.c.cue_tray([3], to_end=True)[0]
        self.assertNotEqual(first, second)
        self.assertEqual(self.c.cue["item_id"], second)
        self.c.clear_cue()
        self.assertIsNone(self.c.cue)

    def test_the_cue_goes_when_its_item_leaves_the_service_or_another_service_opens(self):
        item = self.c.cue_tray([2], to_end=True)[0]
        self.c.remove_item(item)
        self.assertIsNone(self.c.cue)
        self.c.cue_tray([2])
        self.assertIsNotNone(self.c.cue)
        self.c.new_service("Other")
        self.assertIsNone(self.c.cue)

    def test_blanked_screens_stay_blank_after_take(self):
        self.c.toggle_blank()
        self.c.cue_tray([2], to_end=True)
        self.c.take_cue()
        self.assertTrue(self.c.session.state().blank)
        self.assertEqual(self.live().verse_numbers, (2,))

    def test_cueing_needs_a_service_and_a_tray(self):
        self.c.clear_tray()
        with self.assertRaises(ControllerError):
            self.c.cue_tray([2])
        self.c.load_tray("John 3")
        self.c.service_id = None
        with self.assertRaisesRegex(ControllerError, "service"):
            self.c.cue_tray([2])


class CueApiTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.api.call("new_service", {"title": "S"})
        self.api.call("tray_load", {"text": "John 3"})

    def test_the_state_carries_the_ready_item(self):
        self.assertIsNone(self.api.state()["cue"])
        self.api.call("tray_cue", {"verses": [2], "to_end": True})
        self.assertEqual(self.api.state()["cue"]["title"], "John 3:2-6 (DEMO)")
        self.api.call("cue_take", {})
        state = self.api.state()
        self.assertIsNone(state["cue"])
        self.assertEqual(state["live"]["base"]["reference"], "John 3:2")

    def test_clearing_and_bad_arguments(self):
        self.api.call("tray_cue", {"verses": [2]})
        self.api.call("cue_clear", {})
        self.assertIsNone(self.api.state()["cue"])
        with self.assertRaises(ApiError):
            self.api.call("tray_cue", {"verses": [2], "to_end": "yes"})
        with self.assertRaises(ApiError):
            self.api.call("cue_take", {})


if __name__ == "__main__":
    unittest.main()
