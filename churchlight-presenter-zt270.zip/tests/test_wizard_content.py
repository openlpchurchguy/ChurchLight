# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Setup guide steps 5 and 6: add content and set options without leaving the guide."""
import io
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi
from tests.test_library_admin import TEXT
from tests.test_media_browser import wav_bytes
from tests.test_decks import make_pdf
from tests.test_setup_wizard import OUTPUTS

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:                                           # pragma: no cover
    HAVE_BROWSER = False


def until(check, seconds=8):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class WizardContentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        t = self.db.add_translation("KJV", "King James")
        self.db.add_verses(t, [("John", 3, 16, "For God so loved the world.")])
        self.c = OperatorController(self.db, OUTPUTS, translation="KJV", media_root=self.tmp / "media")
        server = self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        self.api = OperatorApi(self.c)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1400, "height": 1000})
        self.page.goto(server.url.rstrip("/") + "/operator")
        self.page.wait_for_selector("#wizard:not([hidden])")

    def step(self, title):
        while self.page.text_content("#wizard-title") != title:
            self.page.click("#wizard-next")

    def test_songs_and_media_are_added_in_step_five_and_the_guide_stays_open(self):
        song = self.tmp / "Amazing.txt"
        song.write_text(TEXT)
        sound = self.tmp / "Prelude.wav"
        sound.write_bytes(wav_bytes(5))
        self.step("Add your content")
        self.page.set_input_files("#wizard-body .wizard-add:has-text('Songs') input[type=file] >> nth=0", str(song))
        self.assertTrue(until(lambda: len(self.db.song_summaries()) >= 1))
        self.assertTrue(until(lambda: "Done" in (self.page.text_content("#wizard-job-songs") or "")))
        self.assertFalse(self.page.is_hidden("#wizard"))
        self.assertEqual(self.page.text_content("#wizard-title"), "Add your content")
        self.page.set_input_files("#wizard-body .wizard-add:last-of-type input[type=file]", str(sound))
        self.assertTrue(until(lambda: len(self.c.media_list()) == 1))
        self.assertTrue(until(lambda: "Added Prelude.wav" in (self.page.text_content("#wizard-log-media") or "")))
        self.assertFalse(self.page.is_hidden("#wizard"))

    def test_several_batches_are_listed_top_to_bottom_in_the_order_imported(self):
        first = self.tmp / "First.txt"
        first.write_text(TEXT)
        second = self.tmp / "Second.txt"
        second.write_text(TEXT.replace("alpha", "beta"))
        third = self.tmp / "Third.txt"
        third.write_text(TEXT.replace("alpha", "gamma"))
        self.step("Add your content")
        picker = "#wizard-body .wizard-add:has-text('Songs') input[type=file] >> nth=0"
        for n, path in enumerate((first, second, third), 1):
            self.page.set_input_files(picker, str(path))
            self.assertTrue(until(lambda n=n: len(self.db.song_summaries()) >= n, 15))
            self.assertTrue(until(lambda n=n: self.page.locator("#wizard-job-songs li").count() == n, 15))
        lines = self.page.locator("#wizard-job-songs li").all_text_contents()
        self.assertEqual(len(lines), 3)
        self.assertTrue(until(lambda: all("Done" in t for t in self.page.locator("#wizard-job-songs li").all_text_contents()), 15))
        self.assertEqual([t[:2] for t in self.page.locator("#wizard-job-songs li").all_text_contents()], ["1.", "2.", "3."])

    def test_a_bible_needs_its_short_name_and_a_slideshow_can_be_named(self):
        self.step("Add your content")
        self.assertEqual(self.page.locator("#wizard-body input[aria-label='Short name for the Bible']").count(), 1)
        self.assertEqual(self.page.locator("#wizard-body input[aria-label='Name of the slideshow']").count(), 1)

    def test_step_six_sets_the_theme_the_trigger_urls_and_the_home_picture_in_place(self):
        self.step("Look, clicker and Stream Deck")
        self.page.click("#wizard-body button:has-text('Dark')")
        self.assertEqual(self.page.evaluate("document.documentElement.dataset.theme"), "dark")
        self.assertFalse(self.page.is_hidden("#wizard"))
        projector = self.page.locator("#wizard-body select[aria-label='Projector theme']")
        if projector.count():
            options = projector.locator("option").all_text_contents()
            self.assertTrue(options)
        self.page.check("#wizard-body label:has-text('Turn remote button links on') input")
        self.assertTrue(until(lambda: self.api.state()["hook"]["on"]))
        self.page.wait_for_selector("#wizard-body input[aria-label='Address for: Next slide']")
        self.assertIn("/hook/", self.page.input_value("#wizard-body input[aria-label='Address for: Next slide']"))

    def test_step_five_says_the_kjv_is_included_and_keeps_earlier_install_imports_folded(self):
        self.step("Add your content")
        body = self.page.inner_text("#wizard-body")
        self.assertNotIn("King James Version", body.split("Another Bible")[0])                  # not in the intro any more
        bible = self.page.locator("#wizard-body .wizard-add:has-text('Another Bible')").inner_text()
        self.assertIn("already comes with the King James Version (KJV)", bible)                # it is in the Bible row
        fold = self.page.locator("#wizard-body details.wizard-earlier")
        self.assertEqual(fold.count(), 1)
        self.assertIsNone(fold.get_attribute("open"))
        self.assertIn("Moving from an earlier ChurchLight? (optional)", fold.locator("summary").inner_text())
        self.assertEqual(fold.locator(".wizard-add strong").all_text_contents(), ["An exported slideshow bundle", "Themes from a previous version"])
        last = self.page.eval_on_selector("#wizard-body", "e => e.lastElementChild.className")
        self.assertIn("wizard-earlier", last)                                  # at the very bottom

    def test_themes_from_an_earlier_version_import_inside_the_guide(self):
        import json, zipfile
        path = self.tmp / "themes.zip"
        with zipfile.ZipFile(path, "w") as zf:
            zf.writestr("themes.json", json.dumps({"format": "churchlight-themes", "version": 1, "themes": [
                {"name": "Old Sunday", "kind": "confidence", "style": {"font_size": 12}}]}))
        self.step("Add your content")
        self.page.evaluate("document.querySelector('#wizard-body details.wizard-earlier').open = true")
        self.page.set_input_files("#wizard-body .wizard-earlier .wizard-add:has-text('Themes from a previous version') input[type=file]", str(path))
        self.assertTrue(until(lambda: "Added 1 theme" in (self.page.text_content("#wizard-log-themes") or "")))
        self.assertTrue(any(t["name"] == "Old Sunday" for t in self.db.list_themes()))
        self.assertFalse(self.page.is_hidden("#wizard"))
        self.assertEqual(self.page.text_content("#wizard-title"), "Add your content")

    def test_the_home_picture_is_chosen_at_the_top_of_step_five(self):
        self.step("Add your content")
        png = self.tmp / "home.png"
        png.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 200)
        self.page.set_input_files("#wizard-body .wizard-add:has-text('Home screen picture') input[type=file]", str(png))
        self.assertTrue(until(lambda: self.c.home_screen()["image"] is not None))
        self.page.wait_for_selector("#wizard-body img.wizard-thumb")
        self.assertFalse(self.page.is_hidden("#wizard"))
        self.assertEqual(self.page.text_content("#wizard-title"), "Add your content")
        self.page.click("#wizard-body #wizard-home-box button:has-text('Remove')")
        self.assertTrue(until(lambda: self.c.home_screen()["image"] is None))

    def test_a_refused_file_is_explained_inside_the_guide_not_behind_it(self):
        bad = self.tmp / "notes.txt"
        bad.write_text("not a picture or a video")
        self.step("Add your content")
        self.page.set_input_files("#wizard-body .wizard-add:last-of-type input[type=file]", str(bad))
        self.page.wait_for_selector("#wizard-message:not([hidden])")
        self.assertIn("notes.txt", self.page.text_content("#wizard-message"))
        self.assertTrue(self.page.is_hidden("#message"))                 # the bar behind the guide stays empty
        self.page.click("#wizard-next")
        self.assertTrue(self.page.is_hidden("#wizard-message"))

    def test_several_pdfs_chosen_together_become_several_slideshows(self):
        pdfs = []
        for pages, name in ((2, "Sunday.pdf"), (3, "Easter.pdf"), (4, "Youth.pdf")):      # different pages, or they count as the same file
            f = self.tmp / name
            make_pdf(f, pages)
            pdfs.append(str(f))
        self.step("Add your content")
        self.page.set_input_files("#wizard-body .wizard-add:has-text('A slideshow') input[type=file] >> nth=0", pdfs)
        self.assertTrue(until(lambda: len(self.db.search_presentation()) == 3, 25))
        self.assertEqual(sorted(r["name"] for r in self.db.search_presentation()), ["Easter", "Sunday", "Youth"])
        self.assertFalse(self.page.is_hidden("#wizard"))

    def test_the_home_picture_appears_as_soon_as_the_server_has_it_even_when_the_page_hears_later(self):
        self.step("Add your content")
        self.assertEqual(self.page.locator("#wizard-body img.wizard-thumb").count(), 0)
        png = self.tmp / "home.png"
        png.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 200)
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, "home.png", io.BytesIO(png.read_bytes()), png.stat().st_size, "background")
        stored = self.api.call("background_import", {"batch": batch})
        self.api.call("home_set", {"image": stored["path"], "on": True})      # done behind the page's back
        self.page.wait_for_selector("#wizard-body img.wizard-thumb", timeout=8000)
        self.assertEqual(self.page.text_content("#wizard-title"), "Add your content")

    def test_no_button_in_steps_five_and_six_sends_you_to_another_tab(self):
        for title in ("Add your content", "Look, clicker and Stream Deck"):
            self.step(title)
            self.assertFalse(self.page.is_hidden("#wizard"))
            for tab in ("tab-songs", "tab-decks", "tab-bibles", "tab-themes"):
                self.assertEqual(self.page.get_attribute("#" + tab, "aria-pressed"), "false")
