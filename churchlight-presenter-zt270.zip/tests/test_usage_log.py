# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The song usage log: a row, in OpenLP's layout, each time a song goes live."""
import csv
import io
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from churchlight_presenter.core import usagelog
from churchlight_presenter.ui.operator_api import OperatorApi
from tests.test_library_admin import AdminBase, TEXT


class FormatTests(unittest.TestCase):
    def test_a_row_matches_the_sample_layout(self):
        song = {"title": "486. Faith Is the Victory", "copyright": None, "ccli_number": None, "author": "John Yates Ira F. Stanphill"}
        line = usagelog.format_row(datetime(2025, 7, 27, 11, 7, 50, 139472), song)
        self.assertEqual(line, '"","2025-07-27","11:07:50.139472","486. Faith Is the Victory","John Yates Ira F. Stanphill","","songs","display"\n')

    def test_commas_and_quotes_survive(self):
        song = {"title": 'Joyful, "Joyful"', "copyright": "(c) 1999", "ccli_number": "12345", "author": "A, B"}
        row = next(csv.reader(io.StringIO(usagelog.format_row(datetime(2025, 1, 2, 3, 4, 5), song))))
        self.assertEqual(row, ["12345", "2025-01-02", "03:04:05.000000", 'Joyful, "Joyful"', "A, B", "(c) 1999", "songs", "display"])


class LoggingTests(AdminBase):
    def setUp(self):
        super().setUp()
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.path = Path(tmp.name) / usagelog.FILE_NAME
        self.c.set_usage_log(self.path)
        self.c.create_song("Amazing Grace", "John Newton", TEXT, ccli="12345")
        self.c.create_song("Plain Song", "Someone", TEXT)

    def rows(self):
        if not self.path.exists():
            return []
        return list(csv.reader(self.path.open(encoding="utf-8", newline="")))

    def test_a_song_sent_live_is_logged_once_however_many_slides_it_has(self):
        self.c.go_live_entry(self.entry("song", "Amazing Grace"))
        self.c.next()
        self.c.next()
        rows = self.rows()
        self.assertEqual(len(rows), 1)
        self.assertEqual([rows[0][0], rows[0][3], rows[0][4], rows[0][5]], ["12345", "Amazing Grace", "John Newton", ""])
        self.assertEqual(rows[0][6:], ["songs", "display"])

    def test_going_live_again_after_clearing_logs_again(self):
        self.c.go_live_entry(self.entry("song", "Amazing Grace"))
        self.c.session.clear()
        self.c.go_live_entry(self.entry("song", "Amazing Grace"))
        self.assertEqual(len(self.rows()), 2)

    def test_a_service_logs_each_song_as_it_goes_live(self):
        self.c.new_service("Sunday")
        for name in ("Amazing Grace", "Plain Song"):
            self.c.add_entry(self.entry("song", name))
        self.c.next_item()
        self.c.next_item()
        self.assertEqual([r[3] for r in self.rows()], ["Amazing Grace", "Plain Song"])

    def test_nothing_is_written_without_a_log_file(self):
        self.c.set_usage_log(None)
        self.c.go_live_entry(self.entry("song", "Amazing Grace"))
        self.assertEqual(self.rows(), [])

    def test_the_download_gives_the_file(self):
        self.c.go_live_entry(self.entry("song", "Amazing Grace"))
        name, kind, body = OperatorApi(self.c).export_usage()
        self.assertEqual(name, "song_usage.csv")
        self.assertIn(b'"Amazing Grace"', body)


if __name__ == "__main__":
    unittest.main()
