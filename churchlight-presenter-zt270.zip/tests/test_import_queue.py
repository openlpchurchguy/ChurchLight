# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Uploads from the page go one at a time, so two big ones can never use up the browser's connections to the program."""
import unittest

from tests.test_media_page import PageBase, until, HAVE_BROWSER


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class ImportQueueTests(PageBase):
    def test_two_imports_started_together_upload_one_after_the_other(self):
        page = self.page
        page.evaluate("""() => {
          window.__active = 0; window.__max = 0;
          const real = uploadOne;
          uploadOne = async (...args) => {
            window.__active += 1; window.__max = Math.max(window.__max, window.__active);
            await new Promise((r) => setTimeout(r, 400));
            try { return await real(...args); } finally { window.__active -= 1; }
          };
          const png = (n) => new File([new Uint8Array([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a,n,0,0,0,0,0,0,0,0,0,0,0])], "pic" + n + ".png");
          window.__first = importMedia([png(1)]);
          window.__second = importMedia([png(2)]);
        }""")
        self.assertTrue(until(lambda: len(self.c.media_list()) == 2, 15))
        self.assertEqual(page.evaluate("window.__max"), 1)


del PageBase

if __name__ == "__main__":
    unittest.main()
