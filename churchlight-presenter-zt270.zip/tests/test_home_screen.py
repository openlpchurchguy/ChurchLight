# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The home screen: a picture the projector shows while the screens are blanked, or while nothing is live."""
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import Output, build_payload
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
IMAGE = "backgrounds/0123456789abcdef.png"


class HomeCase(unittest.TestCase):
    def setUp(self):
        self.media = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.media, True)
        (self.media / "backgrounds").mkdir()
        (self.media / IMAGE).write_bytes(b"\x89PNG\r\n\x1a\n")
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.media)
        self.api = OperatorApi(self.c)


class PayloadTests(unittest.TestCase):
    HOME = {"image_path": IMAGE, "fit": "fit"}

    def payload(self, layout, blank, home=HOME):
        session = LiveSession()
        session.set_blank(blank)
        return build_payload(session.state(), Output("x", layout), home=home)

    def test_only_the_blanked_projector_gets_the_picture(self):
        self.assertEqual(self.payload("projector", True)["home"], self.HOME)
        self.assertNotIn("home", self.payload("projector", False))        # not blanked: the slide shows
        for layout in ("lower_third", "song_lower", "stage", "confidence", "verse_full"):
            self.assertNotIn("home", self.payload(layout, True), layout)
        self.assertNotIn("home", self.payload("projector", True, home=None))


class IdlePayloadTests(unittest.TestCase):
    def payload(self, layout="projector", blank=False, live=False, **flags):
        home = dict({"image_path": IMAGE, "fit": "fit", "when_blank": True, "when_idle": True}, **flags)
        session = LiveSession()
        session.set_blank(blank)
        if live:
            from churchlight_presenter.core.slides import Slide
            session.load([Slide("lyrics", "song", 1, text="line")])
            session.go_to(0)
        return build_payload(session.state(), Output("x", layout), home=home)

    def test_shows_while_nothing_is_live(self):
        self.assertEqual(self.payload()["home"], {"image_path": IMAGE, "fit": "fit"})

    def test_a_live_slide_replaces_it(self):
        self.assertNotIn("home", self.payload(live=True))

    def test_the_idle_switch_and_the_blank_switch_are_separate(self):
        self.assertNotIn("home", self.payload(when_idle=False))
        self.assertIn("home", self.payload(when_idle=False, blank=True))
        self.assertNotIn("home", self.payload(when_blank=False, blank=True))
        self.assertIn("home", self.payload(when_blank=False))

    def test_other_screens_never_get_it(self):
        for layout in ("lower_third", "song_lower", "stage", "confidence", "verse_full"):
            self.assertNotIn("home", self.payload(layout), layout)


class ControllerTests(HomeCase):
    def test_idle_projector_shows_the_picture_with_no_service(self):
        self.c.set_home_screen(image=IMAGE)
        self.assertEqual(self.c.payloads()["projector"]["home"]["image_path"], IMAGE)
        self.assertEqual(self.c.home_screen()["idle"], True)
        self.c.set_home_screen(idle=False)
        self.assertNotIn("home", self.c.payloads()["projector"])
        self.assertFalse(json.loads(self.db.get_setting("home_screen"))["idle"])

    def test_nothing_is_set_to_begin_with(self):
        self.assertEqual(self.c.home_screen(), {"image": None, "fit": "fit", "on": True, "idle": True})
        self.assertNotIn("home", self.c.payloads()["projector"])

    def test_a_chosen_picture_shows_while_blanked_on_the_projector_only(self):
        self.c.set_home_screen(image=IMAGE)
        self.c.toggle_blank()
        payloads = self.c.payloads()
        self.assertEqual(payloads["projector"]["home"], {"image_path": IMAGE, "fit": "fit"})
        self.assertTrue(all("home" not in p for n, p in payloads.items() if n != "projector"))
        self.c.toggle_blank()
        self.c.set_home_screen(idle=False)
        self.assertNotIn("home", self.c.payloads()["projector"])           # not blanked, and idle switched off

    def test_fit_and_the_on_off_switch(self):
        self.c.set_home_screen(image=IMAGE, fit="fill")
        self.c.toggle_blank()
        self.assertEqual(self.c.payloads()["projector"]["home"]["fit"], "fill")
        self.c.set_home_screen(on=False)
        self.assertNotIn("home", self.c.payloads()["projector"])
        self.assertEqual(self.c.home_screen()["image"], IMAGE)             # switched off, not forgotten
        self.c.set_home_screen(on=True, image=None)
        self.assertNotIn("home", self.c.payloads()["projector"])

    def test_only_pictures_this_program_stored_are_accepted(self):
        for bad in ("../x.png", "backgrounds/nothere.png", "/etc/passwd", "backgrounds/0123456789abcdef.png.exe",
                    "backgrounds/ffffffffffffffff.png"):                    # the last one is well formed but missing
            with self.assertRaises(ControllerError, msg=bad):
                self.c.set_home_screen(image=bad)
        with self.assertRaises(ControllerError):
            self.c.set_home_screen(fit="stretch")
        self.assertIsNone(self.c.home_screen()["image"])

    def test_it_is_remembered_and_the_picture_is_not_cleaned_up(self):
        self.c.set_home_screen(image=IMAGE, fit="fill")
        again = OperatorController(self.db, media_root=self.media)
        self.assertEqual(again.home_screen(), {"image": IMAGE, "fit": "fill", "on": True, "idle": True})
        again._prune_backgrounds(grace_seconds=-10)                         # would delete anything unused and old
        self.assertTrue((self.media / IMAGE).exists())
        self.c.set_home_screen(image=None)
        self.c._prune_backgrounds(grace_seconds=-10)
        self.assertFalse((self.media / IMAGE).exists())

    def test_damaged_storage_means_no_home_screen(self):
        self.db.set_setting("home_screen", "{bad")
        self.assertEqual(OperatorController(self.db, media_root=self.media).home_screen()["image"], None)

    def test_the_web_server_sends_it_too(self):
        self.c.set_home_screen(image=IMAGE)
        self.c.toggle_blank()
        server = self.c.serve(media_root=self.media)
        self.addCleanup(self.c.close)
        projector = next(o for o in self.c.outputs if o.name == "projector")
        self.assertEqual(server.payload_for(projector)["home"]["image_path"], IMAGE)


class ApiTests(HomeCase):
    def test_the_state_and_the_action(self):
        self.assertEqual(self.api.state()["home"]["image"], None)
        self.api.call("home_set", {"image": IMAGE, "fit": "fill"})
        self.assertEqual(self.api.state()["home"], {"image": IMAGE, "fit": "fill", "on": True, "idle": True})
        self.api.call("home_set", {"on": False})
        self.assertFalse(self.api.state()["home"]["on"])
        self.api.call("home_set", {"image": None})
        self.assertIsNone(self.api.state()["home"]["image"])

    def test_bad_arguments_are_plain_errors(self):
        for args in ({"image": 5}, {"on": "yes"}, {"fit": "stretch"}, {"image": "backgrounds/ffffffffffffffff.png"}):
            with self.assertRaises(ApiError, msg=str(args)):
                self.api.call("home_set", args)

    def test_only_the_projector_and_confidence_monitor_have_a_screen_shape(self):
        shapes = {o["name"]: o["layout"] for o in self.api.state()["outputs"]}
        for name, layout in shapes.items():
            if layout in ("projector", "confidence"):
                self.api.call("screen_shape_set", {"name": name, "shape": "4:3"})
            else:
                with self.assertRaises(ApiError, msg=name):
                    self.api.call("screen_shape_set", {"name": name, "shape": "4:3"})
        got = {o["layout"]: o["shape"] for o in self.api.state()["outputs"]}
        self.assertEqual((got["projector"], got["confidence"], got["lower_third"], got["stage"]), ("4:3", "4:3", "16:9", "16:9"))


@unittest.skipUnless(shutil.which("node"), "node is needed to run the page's own code")
class PageCodeTests(unittest.TestCase):
    def js(self, file, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / file)], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_the_output_page_gets_the_picture_only_when_sent(self):
        payload = ('{audience:"public",layout:"projector",blank:true,base:null,overlay:null,'
                   'home:{image_path:"backgrounds/a.png",fit:"fill"}}')
        self.assertEqual(self.js("output.js", f"m.viewModel({payload}).home"), {"image": "backgrounds/a.png", "fill": True})
        plain = '{audience:"public",layout:"projector",blank:true,base:null,overlay:null}'
        self.assertIsNone(self.js("output.js", f"m.viewModel({plain}).home"))

    def test_the_blank_button_talks_about_the_home_screen_only_when_there_is_one(self):
        home = '{image:"backgrounds/a.png",on:true}'
        self.assertEqual(self.js("operator.js", f"m.blankText(false, {home}, true)"), "Home screen (B)")
        self.assertEqual(self.js("operator.js", f"m.blankText(true, {home}, true)"), "Back to the service (B)")
        self.assertEqual(self.js("operator.js", "m.blankText(false, null, true)"), "Blank screens (B)")
        self.assertEqual(self.js("operator.js", "m.blankText(true, {image:null,on:true}, false)"), "Show screens again")
        self.assertEqual(self.js("operator.js", 'm.blankText(false, {image:"x",on:false}, false)'), "Blank screens")

    def test_the_shape_choice_is_offered_for_the_projector_and_confidence_only(self):
        for layout, expected in (("projector", True), ("confidence", True), ("lower_third", False), ("stage", False)):
            self.assertEqual(self.js("operator.js", f'm.hasScreenShape("{layout}")'), expected, layout)


if __name__ == "__main__":
    unittest.main()
