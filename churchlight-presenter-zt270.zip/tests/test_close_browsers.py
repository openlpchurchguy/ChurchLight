# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Shut down closes the browser windows ChurchLight opened (its own profile folder) and no other browser."""
import unittest

from churchlight_presenter import launcher

PROFILE = r"C:\Church Files\browser-profile"
PROCESSES = [
    (1, r'"C:\Edge\msedge.exe" --app=http://127.0.0.1:8000/operator --user-data-dir="C:\Church Files\browser-profile" --no-first-run'),
    (2, r'"C:\Edge\msedge.exe" --type=renderer --user-data-dir="C:\Church Files\browser-profile" --lang=en'),
    (3, r'"C:\Edge\msedge.exe" --user-data-dir=C:\Users\me\AppData\Local\Edge\User Data'),           # the church's own browser
    (4, r'"C:\Edge\msedge.exe" --user-data-dir="C:\Church Files\browser-profile2"'),                  # a folder with a similar name
    (5, r'"C:\Edge\msedge.exe" --kiosk --user-data-dir="C:\Church Files\browser-profile\screen-projector"'),
    (6, r'python -m churchlight_presenter --db "C:\Church Files\church.db"'),
    (7, None),
    (8, r'"C:\Edge\msedge.exe" --app=http://x'),                                                      # no profile folder at all
]


class MatchTests(unittest.TestCase):
    def test_only_browsers_started_with_the_programs_profile_folder_match(self):
        self.assertEqual(launcher.processes_using_profile(PROCESSES, PROFILE), [1, 2, 5])

    def test_forward_slashes_and_capitals_do_not_matter_and_the_program_itself_is_skipped(self):
        found = launcher.processes_using_profile(PROCESSES, "c:/church files/BROWSER-PROFILE/", own_pid=2)
        self.assertEqual(found, [1, 5])

    def test_no_profile_folder_matches_nothing(self):
        self.assertEqual(launcher.processes_using_profile(PROCESSES, None), [])
        self.assertEqual(launcher.processes_using_profile(PROCESSES, ""), [])


class CloseTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.alive = list(PROCESSES)

    def fake_taskkill(self, command, **kwargs):               # a stand-in for taskkill
        self.calls.append(command)
        if "/F" in command or self.polite_works:
            pid = int(command[command.index("/PID") + 1])
            self.alive = [p for p in self.alive if p[0] != pid]

    polite_works = True

    def close(self, **kwargs):
        return launcher.close_browsers_using(PROFILE, platform="win32", lister=lambda: list(self.alive), run=self.fake_taskkill,
                                             sleep=lambda s: None, own_pid=999, **kwargs)

    def test_it_asks_politely_and_only_about_its_own_browsers(self):
        self.assertEqual(self.close(), 3)                                          # how many it found
        self.assertEqual([c[2] for c in self.calls], ["1", "2", "5"])
        self.assertTrue(all("/F" not in c for c in self.calls))                  # nothing had to be forced
        self.assertEqual([p[0] for p in self.alive], [3, 4, 6, 7, 8])            # everything else is untouched

    def test_what_will_not_close_is_forced_after_the_wait(self):
        self.polite_works = False
        self.close()
        forced = [c[2] for c in self.calls if "/F" in c]
        self.assertEqual(forced, ["1", "2", "5"])
        self.assertEqual([p[0] for p in self.alive], [3, 4, 6, 7, 8])

    def test_with_no_wait_leftovers_are_forced_at_once(self):
        launcher.close_browsers_using(PROFILE, platform="win32", lister=lambda: list(self.alive), run=self.fake_taskkill,
                                      sleep=lambda s: self.fail("waited"), own_pid=999, wait=0)
        self.assertEqual([(c[2], "/F" in c) for c in self.calls], [("1", True), ("2", True), ("5", True)])

    def test_nothing_happens_off_windows_or_with_no_profile(self):
        self.assertEqual(launcher.close_browsers_using(PROFILE, platform="linux", lister=lambda: self.fail("listed")), 0)
        self.assertEqual(launcher.close_browsers_using(None, platform="win32", lister=lambda: self.fail("listed")), 0)

    def test_a_failing_list_is_harmless(self):
        def broken(*a, **k):
            raise OSError("no powershell")
        self.assertEqual(launcher.list_processes(platform="win32", run=broken), [])
        self.assertEqual(launcher.list_processes(platform="linux"), [])


if __name__ == "__main__":
    unittest.main()
