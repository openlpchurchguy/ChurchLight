# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import dataclasses
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.items import ItemRef, add_to_service
from churchlight_presenter.core.slides import (
    BuildSettings, Slide, SlideBuilder,
)

JOHN = 43


class BuilderCase(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.builder = SlideBuilder(self.db)

    def make_song(self, sections, order=None):
        return self.db.create_song_with_sections("Test Song", sections, order=order)


class SongSlideTests(BuilderCase):
    def test_arrangement_order_repeats_and_balanced_splitting(self):
        song = self.make_song(
            [("Verse 1", "verse", "a1\na2\na3\na4"),
             ("Chorus", "chorus", "c1\nc2\nc3\nc4\nc5\nc6")],
            order=["Verse 1", "Chorus", "Verse 1"])
        slides = self.builder.build_item(ItemRef.song(song))
        self.assertEqual([s.label for s in slides], ["Verse 1", "Chorus", "Chorus", "Verse 1"])
        self.assertEqual([s.text.count("\n") + 1 for s in slides], [4, 3, 3, 4])
        self.assertEqual([s.continued for s in slides], [False, False, True, False])
        for s in slides:
            self.assertEqual((s.kind, s.item_type, s.reference, s.source_item_id),
                             ("lyrics", "song", "Test Song", None))

    def test_five_lines_split_three_and_two_not_four_and_one(self):
        song = self.make_song([("Verse 1", "verse", "1\n2\n3\n4\n5")])
        slides = self.builder.build_item(ItemRef.song(song))
        self.assertEqual([s.text for s in slides], ["1\n2\n3", "4\n5"])

    def test_a_blank_line_forces_a_slide_break(self):
        song = self.make_song([("Verse 1", "verse", "a\nb\n\nc\nd")])
        slides = self.builder.build_item(ItemRef.song(song))
        self.assertEqual([s.text for s in slides], ["a\nb", "c\nd"])
        self.assertEqual([s.continued for s in slides], [False, True])

    def test_sections_without_lyrics_become_blank_placeholders(self):
        song = self.make_song([("Verse 1", "verse", "hello"),
                               ("Instrumental", "instrumental", "")])
        slides = self.builder.build_item(ItemRef.song(song))
        self.assertEqual([(s.kind, s.label, s.text) for s in slides],
                         [("lyrics", "Verse 1", "hello"), ("blank", "Instrumental", "")])

    def test_song_without_an_arrangement_plays_sections_in_order(self):
        song = self.db.insert_song("Bare")
        self.db.add_section(song, "V1", "x")
        self.db.add_section(song, "C", "y", section_type="chorus")
        slides = self.builder.build_item(ItemRef.song(song))
        self.assertEqual([s.label for s in slides], ["V1", "C"])

    def test_a_chosen_arrangement_is_used(self):
        song = self.make_song([("Verse 1", "verse", "a"), ("Chorus", "chorus", "b")])
        ids = [s["id"] for s in self.db.get_sections(song)]
        short = self.db.create_arrangement(song, "Short", [ids[1]])
        slides = self.builder.build_item(ItemRef.song(song, arrangement_id=short))
        self.assertEqual([s.label for s in slides], ["Chorus"])

    def test_title_override_becomes_the_reference(self):
        song = self.make_song([("Verse 1", "verse", "a")])
        slides = self.builder.build_item(ItemRef.song(song, title="Closing Song"))
        self.assertEqual(slides[0].reference, "Closing Song")

    def test_settings_layers_defaults_then_theme_then_item(self):
        song = self.make_song([("Verse 1", "verse", "a\nb\nc\nd")])
        self.assertEqual(len(self.builder.build_item(ItemRef.song(song))), 1)

        small = SlideBuilder(self.db, BuildSettings(lines_per_slide=2))
        self.assertEqual(len(small.build_item(ItemRef.song(song))), 2)

        theme = self.db.add_theme("Narrow", {"lines_per_slide": 2, "font": "Arial"})
        slides = self.builder.build_item(ItemRef.song(song, theme_id=theme))
        self.assertEqual([s.text for s in slides], ["a\nb", "c\nd"])
        self.assertTrue(all(s.theme_id == theme for s in slides))

        slides = self.builder.build_item(
            ItemRef.song(song, theme_id=theme, overrides={"lines_per_slide": 4}))
        self.assertEqual(len(slides), 1)

        with self.assertRaises(ValueError):
            self.builder.build_item(ItemRef.song(song, overrides={"lines_per_slide": 0}))
        with self.assertRaises(ValueError):
            self.builder.build_item(ItemRef.song(song, overrides={"scripture_split": "x"}))

    def test_missing_song_is_an_error(self):
        with self.assertRaises(ValueError):
            self.builder.build_item(ItemRef.song(999))


class ScriptureSlideTests(BuilderCase):
    def setUp(self):
        super().setUp()
        self.kjv = self.db.add_translation("KJV", "King James Version")
        self.db.add_verses(self.kjv, [
            ("John", 3, 16, "alpha alpha alpha alpha alpha"),      # 29 characters
            ("John", 3, 17, "bravo bravo bravo bravo bravo"),      # 29
            ("John", 3, 18, "charlie charlie charlie"),            # 23
        ])

    def passage(self, start, end=None, **kw):
        return ItemRef.passage(self.kjv, JOHN, 3, start, end, **kw)

    def test_a_single_verse(self):
        (slide,) = self.builder.build_item(self.passage(16))
        self.assertEqual((slide.kind, slide.item_type, slide.label), ("scripture", "scripture", "KJV"))
        self.assertEqual(slide.reference, "John 3:16")       # the full reference sits above the text
        self.assertTrue(slide.title_first)
        self.assertEqual(slide.verse_numbers, (16,))
        self.assertEqual(slide.segments, ((16, "alpha alpha alpha alpha alpha"),))
        self.assertFalse(slide.continued)

    def test_short_passages_share_one_slide_with_clean_text(self):
        (slide,) = self.builder.build_item(self.passage(16, 18))
        self.assertEqual(slide.reference, "John 3:16-18")
        self.assertEqual(slide.verse_numbers, (16, 17, 18))
        self.assertEqual(slide.text.count("alpha"), 5)
        self.assertNotIn("16", slide.text)  # numbers live in `segments`, not in the text

    def test_character_limit_packs_whole_verses(self):
        slides = self.builder.build_item(self.passage(16, 18, overrides={"scripture_max_chars": 60}))
        self.assertEqual([s.verse_numbers for s in slides], [(16, 17), (18,)])
        self.assertEqual([s.reference for s in slides], ["John 3:16-17", "John 3:18"])

    def test_an_item_can_ask_for_one_verse_per_slide_whatever_the_packing(self):
        slides = self.builder.build_item(self.passage(16, 18, overrides={"one_per_slide": True}))
        self.assertEqual([s.verse_numbers for s in slides], [(16,), (17,), (18,)])
        self.assertEqual([s.reference for s in slides], ["John 3:16", "John 3:17", "John 3:18"])

    def test_verse_mode_gives_each_verse_its_own_slide(self):
        slides = self.builder.build_item(self.passage(16, 18, overrides={"scripture_split": "verse"}))
        self.assertEqual([s.verse_numbers for s in slides], [(16,), (17,), (18,)])

    def test_a_long_verse_splits_and_keeps_its_verse_number(self):
        long_text = " ".join(["word"] * 30)  # 149 characters
        lng = self.db.add_translation("LNG", "Long")
        self.db.add_verses(lng, [("John", 3, 16, long_text), ("John", 3, 17, "short verse")])
        ref = ItemRef.passage(lng, JOHN, 3, 16, 17, overrides={"scripture_max_chars": 60})
        slides = self.builder.build_item(ref)
        self.assertEqual([s.verse_numbers for s in slides], [(16,), (16,), (16,), (17,)])
        self.assertEqual([s.continued for s in slides], [False, True, True, False])
        self.assertEqual([s.reference for s in slides],
                         ["John 3:16", "John 3:16", "John 3:16", "John 3:17"])
        self.assertEqual(" ".join(s.text for s in slides[:3]), long_text)
        self.assertTrue(all(len(s.text) <= 60 for s in slides))

    def test_passage_not_in_the_translation_is_an_error(self):
        with self.assertRaises(ValueError) as ctx:
            self.builder.build_item(self.passage(99))
        self.assertIn("not found", str(ctx.exception))

    def test_typed_reference_end_to_end(self):
        ref = ItemRef.from_reference(self.db, "kjv", "jn 3:17-18")
        slides = self.builder.build_item(ref)
        self.assertEqual([s.reference for s in slides], ["John 3:17-18"])


class OtherItemTests(BuilderCase):
    def test_presentation_pages_become_image_slides_with_notes(self):
        deck = self.db.add_presentation(
            "Easter Sermon", [("p/1.png", "Intro notes"), ("p/2.png", None)])
        slides = self.builder.build_item(ItemRef.presentation(deck))
        self.assertEqual([(s.kind, s.item_type, s.image_path, s.label, s.reference, s.notes)
                          for s in slides], [
            ("image", "presentation", "p/1.png", "Slide 1", "Easter Sermon", "Intro notes"),
            ("image", "presentation", "p/2.png", "Slide 2", "Easter Sermon", None)])

    def test_image_media(self):
        media = self.db.insert_media_asset("Cross", "bg/cross.png")
        (slide,) = self.builder.build_item(ItemRef.media(media))
        self.assertEqual((slide.kind, slide.item_type, slide.image_path, slide.label),
                         ("image", "media", "bg/cross.png", "Cross"))

    def test_video_and_sound_media_become_clip_slides(self):
        video = self.db.insert_media_asset("Loop", "media/loop.mp4", media_type="video", duration_ms=9500)
        song = self.db.insert_media_asset("Prelude", "media/prelude.mp3", media_type="audio")
        (clip,) = self.builder.build_item(ItemRef.media(video))
        (music,) = self.builder.build_item(ItemRef.media(song))
        self.assertEqual((clip.kind, clip.item_type, clip.image_path, clip.duration_ms, clip.label),
                         ("video", "media", "media/loop.mp4", 9500, "Loop"))
        self.assertEqual((music.kind, music.duration_ms), ("audio", 0))

    def test_announcement_text_is_split_like_lyrics(self):
        ref = ItemRef.announcement("Welcome", "l1\nl2\nl3\nl4\nl5")
        slides = self.builder.build_item(ref)
        self.assertEqual([s.text for s in slides], ["l1\nl2\nl3", "l4\nl5"])
        self.assertEqual({s.label for s in slides}, {"Welcome"})
        self.assertEqual({s.kind for s in slides}, {"text"})

    def test_announcement_without_a_body_shows_its_title(self):
        (slide,) = self.builder.build_item(ItemRef.announcement("Welcome"))
        self.assertEqual(slide.text, "Welcome")
        (empty,) = self.builder.build_item(ItemRef.announcement())
        self.assertEqual((empty.text, empty.label), ("", "Announcement"))

    def test_blank(self):
        (slide,) = self.builder.build_item(ItemRef.blank())
        self.assertEqual((slide.kind, slide.item_type, slide.label), ("blank", "blank", "Blank"))


class ServiceBuildTests(BuilderCase):
    def setUp(self):
        super().setUp()
        self.kjv = self.db.add_translation("KJV", "King James Version")
        self.db.add_verses(self.kjv, [("John", 3, 16, "For God so loved the world")])
        self.song = self.make_song([("Verse 1", "verse", "a\nb"), ("Chorus", "chorus", "c")])
        self.deck = self.db.add_presentation("Sermon", [("p/1.png", "n1"), ("p/2.png", "n2")])
        self.theme = self.db.add_theme("Default", {"lines_per_slide": 4})
        self.service = self.db.create_service("Sunday", "2026-10-18", theme_id=self.theme)
        self.ids = {
            "song": add_to_service(self.db, self.service, ItemRef.song(self.song)),
            "deck": add_to_service(self.db, self.service, ItemRef.presentation(self.deck)),
            "verse": add_to_service(self.db, self.service,
                                    ItemRef.passage(self.kjv, JOHN, 3, 16)),
            "blank": add_to_service(self.db, self.service, ItemRef.blank()),
        }

    def test_slides_follow_service_order_and_know_their_item(self):
        slides = self.builder.build_service(self.service)
        self.assertEqual([(s.item_type, s.source_item_id) for s in slides], [
            ("song", self.ids["song"]), ("song", self.ids["song"]),
            ("presentation", self.ids["deck"]), ("presentation", self.ids["deck"]),
            ("scripture", self.ids["verse"]), ("blank", self.ids["blank"])])

    def test_items_inherit_the_service_theme_unless_they_set_their_own(self):
        own = self.db.add_theme("Sermon")
        add_to_service(self.db, self.service, ItemRef.blank(theme_id=own))
        slides = self.builder.build_service(self.service)
        self.assertEqual({s.theme_id for s in slides[:-1]}, {self.theme})
        self.assertEqual(slides[-1].theme_id, own)

    def test_output_is_deterministic(self):
        self.assertEqual(self.builder.build_service(self.service),
                         self.builder.build_service(self.service))

    def test_an_item_that_cannot_be_built_becomes_a_placeholder_not_a_crash(self):
        item = add_to_service(self.db, self.service, ItemRef.song(self.db.insert_song("Empty")))      # a song with no parts
        slides = self.builder.build_service(self.service)
        self.assertEqual(len(slides), 7)
        last = slides[-1]
        self.assertEqual((last.kind, last.source_item_id), ("blank", item))
        self.assertTrue(last.label.startswith("Problem:"))

    def test_unknown_service(self):
        with self.assertRaises(ValueError):
            self.builder.build_service(999)

    def test_slides_are_immutable(self):
        slide = self.builder.build_service(self.service)[0]
        self.assertIsInstance(slide, Slide)
        with self.assertRaises(dataclasses.FrozenInstanceError):
            slide.text = "changed"


if __name__ == "__main__":
    unittest.main()
