# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import contextlib
import importlib.util
import io
import shutil
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_spec = importlib.util.spec_from_file_location("license_headers", ROOT / "tools" / "license_headers.py")
lh = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(lh)


class HeaderToolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        (self.tmp / "tests").mkdir()

    def write(self, name, text):
        path = self.tmp / "tests" / name
        path.write_text(text, encoding="utf-8")
        return path

    def test_notice_goes_after_a_shebang_and_before_the_docstring(self):
        path = self.write("a.py", '#!/usr/bin/env python3\n"""Doc."""\nx = 1\n')
        self.assertTrue(lh.add_notice(path))
        lines = path.read_text().splitlines()
        self.assertEqual(lines[0], "#!/usr/bin/env python3")
        self.assertTrue(lines[1].startswith("# SPDX-License-Identifier: "))
        self.assertEqual(lines[3], '"""Doc."""')
        compile(path.read_text(), str(path), "exec")

    def test_running_twice_changes_nothing_and_empty_files_work(self):
        path = self.write("b.py", "")
        self.assertTrue(lh.add_notice(path))
        before = path.read_text()
        self.assertFalse(lh.add_notice(path))
        self.assertEqual(path.read_text(), before)

    def test_check_mode_and_replace(self):
        path = self.write("c.py", "x = 1\n")
        self.assertEqual(lh.missing_headers(self.tmp), [path])
        with contextlib.redirect_stdout(io.StringIO()):      # the tool prints; a test run should not
            self.assertEqual(lh.main(["--check", "--project", str(self.tmp)]), 1)
            lh.main(["--project", str(self.tmp)])
            self.assertEqual(lh.main(["--check", "--project", str(self.tmp)]), 0)
        old = lh.SPDX
        try:
            lh.SPDX = "AGPL-3.0-only"
            lh.NOTICE[0] = "# SPDX-License-Identifier: AGPL-3.0-only"
            lh.add_notice(path, replace=True)
        finally:
            lh.SPDX = old
            lh.NOTICE[0] = f"# SPDX-License-Identifier: {old}"
        text = path.read_text()
        self.assertIn("AGPL-3.0-only", text)
        self.assertEqual(text.count("SPDX-License-Identifier"), 1)


class ProjectHeaderTests(unittest.TestCase):
    def test_every_source_file_carries_the_license_notice(self):
        missing = lh.missing_headers(ROOT)
        self.assertEqual(missing, [], "Run: python tools/license_headers.py")


if __name__ == "__main__":
    unittest.main()
