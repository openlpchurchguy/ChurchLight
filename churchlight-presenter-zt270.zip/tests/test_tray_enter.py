# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Enter in the tray's passage box with nothing typed: add the whole chapter to the service, then show verse 1."""
import json
import shutil
import subprocess
import time
import unittest
from pathlib import Path

from tests.test_verse_tray import deck_live, make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


def until(check, seconds=5):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class StepTests(unittest.TestCase):
    def step(self, entered, tray):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify(m.trayEnterStep({entered},{tray})))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_the_steps_in_order(self):
        tray = '{verses:[[1,"a"],[2,"b"]]}'
        self.assertEqual(self.step("{added:false,shown:false}", tray), "add")
        self.assertEqual(self.step("{added:true,shown:false}", tray), "show")
        self.assertEqual(self.step("{added:true,shown:true}", tray), "done")
        self.assertEqual(self.step("{added:false,shown:false}", "null"), "none")
        self.assertEqual(self.step("{added:false,shown:false}", "{verses:[]}"), "none")


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.c.new_service("Sunday")
        deck_live(self.c)
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            self.browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(self.browser.close)
        self.base = self.server.url.rstrip("/")

    def items(self):
        return [(r["verse_start"], r["verse_end"]) for r in self.db.get_service_items(self.c.service_id) if r["verse_start"] is not None]

    def open(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector("#tray-text", state="visible")
        return page

    def overlay_verses(self):
        slide = self.c.session.state().overlay
        return None if slide is None else list(slide.verse_numbers)

    def test_first_enter_adds_the_chapter_second_shows_verse_one(self):
        self.c.load_tray("John 3")
        page = self.open()
        until(lambda: page.get_attribute("#tray-jump", "placeholder").startswith("Enter adds"))
        page.focus("#tray-jump")
        page.keyboard.press("Enter")
        self.assertTrue(until(lambda: self.items() == [(1, 6)]))
        self.assertIsNone(self.overlay_verses())
        page.focus("#tray-jump")
        page.keyboard.press("Enter")
        self.assertTrue(until(lambda: self.overlay_verses() == [1]))
        self.assertEqual(self.items(), [(1, 6)])                       # added once, not twice
        page.focus("#tray-jump")
        page.keyboard.press("Enter")                                   # a third Enter changes nothing
        self.assertTrue(until(lambda: "already showing" in page.inner_text("#message")))
        self.assertEqual((self.items(), self.overlay_verses()), ([(1, 6)], [1]))

    def test_two_quick_enters_still_do_one_step_each(self):
        self.c.load_tray("John 3")
        page = self.open()
        until(lambda: page.get_attribute("#tray-jump", "placeholder").startswith("Enter adds"))
        page.focus("#tray-jump")
        page.keyboard.press("Enter")
        page.keyboard.press("Enter")                                   # no waiting in between
        self.assertTrue(until(lambda: self.overlay_verses() == [1]))
        self.assertEqual(self.items(), [(1, 6)])

    def test_a_chapter_loaded_with_ctrl_enter_is_already_in_the_service(self):
        page = self.open()
        page.fill("#tray-text", "John 3")
        page.press("#tray-text", "Control+Enter")
        self.assertTrue(until(lambda: self.items() == [(1, 6)]))
        self.assertTrue(until(lambda: page.get_attribute("#tray-jump", "placeholder").startswith("Enter adds"), 15))
        page.focus("#tray-jump")
        page.keyboard.press("Enter")                                    # goes straight to verse 1
        self.assertTrue(until(lambda: self.overlay_verses() == [1], 15))
        self.assertEqual(self.items(), [(1, 6)])

    def test_enter_with_nothing_typed_and_no_tray_does_nothing(self):
        page = self.open()
        page.focus("#tray-text")
        page.keyboard.press("Enter")
        time.sleep(0.3)
        self.assertEqual(self.items(), [])
        self.assertIsNone(self.overlay_verses())

    def test_enter_on_the_empty_passage_box_no_longer_adds_anything(self):
        self.c.load_tray("John 3")
        page = self.open()
        self.assertTrue(until(lambda: page.get_attribute("#tray-jump", "placeholder").startswith("Enter adds")))
        self.assertTrue(page.get_attribute("#tray-text", "placeholder").startswith("John 3"))
        page.focus("#tray-text")
        page.keyboard.press("Enter")
        time.sleep(0.4)
        self.assertEqual(self.items(), [])
        self.assertIsNone(self.overlay_verses())

    def test_a_typed_verse_number_still_cues_instead_of_adding_the_passage(self):
        self.c.load_tray("John 3")
        page = self.open()
        self.assertTrue(until(lambda: page.get_attribute("#tray-jump", "placeholder").startswith("Enter adds")))
        page.fill("#tray-jump", "2")
        page.press("#tray-jump", "Enter")
        self.assertTrue(until(lambda: page.is_visible("#tray-ready")))
        self.assertEqual(len(self.items()), 1)
        self.assertEqual(self.items()[0][0], 2)                        # starts at the typed verse, not the whole chapter


if __name__ == "__main__":
    unittest.main()
