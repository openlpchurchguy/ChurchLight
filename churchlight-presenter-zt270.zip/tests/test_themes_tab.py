# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Theme tab backend: saving, duplicating, deleting, the default and Bible themes, switching."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.themes import (STARTER_THEMES, ensure_starter_themes, theme_kind, validate_build,
                                                  validate_style)
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

STYLE = {"font_family": "Arial", "font_size": 6, "color": "#ffffff"}


class ThemeBase(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db)
        self.api = OperatorApi(self.c)


class StarterTests(ThemeBase):
    def test_starters_are_valid_and_cover_every_kind(self):
        for name, settings in STARTER_THEMES.items():
            validate_style(settings["style"])
            validate_build({k: v for k, v in settings.items() if k not in ("style", "kind")})
        self.assertEqual({s["kind"] for s in STARTER_THEMES.values()}, {"projector", "overlay", "confidence"})
        positions = {(s["style"]["v_pos"], s["style"]["h_pos"]) for s in STARTER_THEMES.values()
                     if s["kind"] == "overlay"}
        self.assertGreaterEqual(len(positions), 5)            # several places for the verse

    def test_an_empty_database_gets_everything_once(self):
        self.assertEqual(ensure_starter_themes(self.db), len(STARTER_THEMES))
        self.assertEqual(ensure_starter_themes(self.db), 0)
        for row in self.db.list_themes():
            self.db.delete_theme(row["id"])
        self.assertEqual(ensure_starter_themes(self.db), 0)        # a deleted starter does not come back

    def test_a_database_with_older_themes_gets_only_the_new_kinds(self):
        mine = self.db.add_theme("My old theme", {"style": {"color": "#123456"}})
        added = ensure_starter_themes(self.db)
        kinds = [theme_kind(self.db.get_theme_settings(r["id"])) for r in self.db.list_themes()]
        self.assertEqual(kinds.count("projector"), 1)              # nothing projector-like was added
        self.assertEqual(added, len(kinds) - 1)
        self.assertEqual(self.db.get_theme(mine)["name"], "My old theme")


class CrudTests(ThemeBase):
    def test_save_with_slide_settings_and_edit(self):
        tid = self.c.save_theme("Mine", STYLE, build={"lines_per_slide": 2})
        details = {t["id"]: t for t in self.c.theme_details()}
        self.assertEqual(details[tid]["build"], {"lines_per_slide": 2})
        self.assertEqual(details[tid]["style"]["font_size"], 6)
        self.c.save_theme("Mine 2", dict(STYLE, font_size=8), tid, {"scripture_split": "verse"})
        d = {t["id"]: t for t in self.c.theme_details()}[tid]
        self.assertEqual((d["name"], d["style"]["font_size"], d["build"]), ("Mine 2", 8, {"scripture_split": "verse"}))

    def test_bad_input_is_refused(self):
        with self.assertRaises(ControllerError):
            self.c.save_theme("  ", STYLE)
        with self.assertRaises(ControllerError):
            self.c.save_theme("X", {"font_size": 99})
        with self.assertRaises(ControllerError):
            self.c.save_theme("X", STYLE, build={"lines_per_slide": 0})
        self.c.save_theme("Dup", STYLE)
        with self.assertRaises(ControllerError):
            self.c.save_theme("Dup", STYLE)

    def test_duplicate_gets_a_free_name(self):
        tid = self.c.save_theme("A", STYLE)
        one, two = self.c.duplicate_theme(tid), self.c.duplicate_theme(tid)
        names = [t["name"] for t in self.c.theme_details()]
        self.assertEqual(sorted(names), ["A", "A copy", "A copy 2"])
        self.assertNotEqual(one, two)

    def test_delete_clears_assignments_and_reports_usage(self):
        tid = self.c.save_theme("A", STYLE)
        self.c.set_bible_theme(tid)
        self.c.set_default_theme(tid)
        self.c.new_service("S")
        self.assertEqual(self.c.theme_details()[0]["usage"],
                         {"services": 1, "items": 0, "songs": 0, "default": True, "bible": True, "verse_over": False, "confidence": False,
                          "outputs": 0})
        self.c.delete_theme(tid)
        self.assertIsNone(self.c.bible_theme_id)
        self.assertIsNone(self.c.default_theme_id)
        self.assertIsNone(self.db.get_service(self.c.service_id)["theme_id"])


class AssignmentTests(ThemeBase):
    def setUp(self):
        super().setUp()
        self.a = self.c.save_theme("A", dict(STYLE, color="#111111"))
        self.b = self.c.save_theme("B", dict(STYLE, color="#222222"))
        self.c.new_service("S")
        self.c.add_announcement("Hello", "body")

    def live_style(self):
        self.c.go_live_service_item(self.c.service_rows()[0].item_id)
        return self.c.payloads()["projector"]["base"]["style"]

    def test_new_services_use_the_default_theme(self):
        self.c.set_default_theme(self.b)
        self.c.new_service("T")
        self.assertEqual(self.db.get_service(self.c.service_id)["theme_id"], self.b)

    def test_service_then_item_theme(self):
        self.c.set_service_theme(self.a)
        self.assertEqual(self.live_style()["color"], "#111111")
        self.c.set_item_theme(self.c.service_rows()[0].item_id, self.b)
        self.assertEqual(self.c.service_rows()[0].theme_id, self.b)
        self.assertEqual(self.live_style()["color"], "#222222")
        self.c.set_item_theme(self.c.service_rows()[0].item_id, None)
        self.assertEqual(self.live_style()["color"], "#111111")

    def test_unknown_theme_is_refused(self):
        with self.assertRaises(ControllerError):
            self.c.set_bible_theme(999)
        with self.assertRaises(ControllerError):
            self.c.set_item_theme(999, self.a)

    def test_the_api_exposes_themes_and_switching(self):
        state = self.api.state()
        self.assertEqual([t["name"] for t in state["themes"]], ["A", "B"])
        self.api.call("service_theme", {"id": self.a})
        self.api.call("bible_theme", {"id": self.b})
        state = self.api.state()
        self.assertEqual((state["service"]["theme_id"], state["bible_theme"]), (self.a, self.b))
        self.api.call("bible_theme", {})
        self.assertIsNone(self.api.state()["bible_theme"])
        made = self.api.call("theme_save", {"name": "C", "style": STYLE})
        self.assertIn("id", made)
        with self.assertRaises(ApiError):
            self.api.call("theme_save", {"name": "C", "style": "no"})


class BibleThemeTests(ThemeBase):
    def setUp(self):
        super().setUp()
        t = self.db.add_translation("T", "Test") if hasattr(self.db, "add_translation") else None
        self.t = t

    def test_the_verse_over_theme_is_set_from_the_api_and_the_pages_have_the_pickers(self):
        over = self.c.save_theme("Box", {"font_size": 5}, kind="overlay")
        self.api.call("verse_over_theme", {"id": over})
        self.assertEqual(self.api.state()["verse_over_theme"], over)
        self.api.call("verse_over_theme", {})
        self.assertIsNone(self.api.state()["verse_over_theme"])
        html = (Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "operator.html").read_text(encoding="utf-8")
        for ident in ("assign-verse-over", "bibles-over-theme"):
            self.assertIn(f'id="{ident}"', html)

    def test_scripture_items_follow_the_bible_theme(self):
        if self.t is None:
            self.skipTest("no add_translation helper")
        self.db.add_verses(self.t, [(43, 3, 16, "For God so loved the world.")]) if hasattr(self.db, "add_verses") else self.skipTest("no add_verses")
        a = self.c.save_theme("Service look", dict(STYLE, color="#111111"))
        b = self.c.save_theme("Bible look", dict(STYLE, color="#222222"))
        o = self.c.save_theme("Overlay look", dict(STYLE, color="#333333"), kind="overlay")
        self.c.new_service("S")
        self.c.set_service_theme(a)
        self.c.set_service_theme(o, "overlay")
        self.c.set_bible_theme(b)
        self.c.translation = "T"
        self.c.add_verse("John 3:16")
        self.c.go_live_service_item(self.c.service_rows()[0].item_id)
        payloads = self.c.payloads()
        self.assertEqual(payloads["projector"]["base"]["style"]["color"], "#222222")
        # the lower third uses the overlay look: the Bible theme is for the projector only
        self.assertEqual(payloads["lower-third"]["base"]["style"]["color"], "#333333")
        self.c.set_item_theme(self.c.service_rows()[0].item_id, a)
        payloads = self.c.payloads()
        self.assertEqual(payloads["projector"]["base"]["style"]["color"], "#111111")
        self.assertEqual(payloads["lower-third"]["base"]["style"]["color"], "#333333")

    def test_tray_verses_follow_the_same_rule(self):
        if self.t is None:
            self.skipTest("no add_translation helper")
        self.db.add_verses(self.t, [(43, 3, 16, "For God so loved the world.")])
        a = self.c.save_theme("Service look", dict(STYLE, color="#111111"))
        b = self.c.save_theme("Bible look", dict(STYLE, color="#222222"))
        o = self.c.save_theme("Overlay look", dict(STYLE, color="#333333"), kind="overlay")
        self.c.new_service("S")
        self.c.set_service_theme(a)
        self.c.set_service_theme(o, "overlay")
        self.c.set_bible_theme(b)
        self.c.translation = "T"
        self.db.add_presentation("Deck", [("d/1.png", None)])
        self.c.go_live_entry(next(e for e in self.c.search_library("Deck") if e.kind == "presentation"))
        self.c.load_tray("John 3")
        self.c.show_tray_verses([16])
        payloads = self.c.payloads()
        self.assertEqual(payloads["projector"]["overlay"]["style"]["color"], "#222222")
        self.assertEqual(payloads["lower-third"]["overlay"]["style"]["color"], "#333333")


if __name__ == "__main__":
    unittest.main()


import json
import re
import shutil
import subprocess
from pathlib import Path

from churchlight_presenter.core.themes import STYLE_KEYS

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class ThemeScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "themes.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_colors_split_and_join(self):
        self.assertEqual(self.js("m.splitColor('#000000b0')")["hex"], "#000000")
        self.assertAlmostEqual(self.js("m.splitColor('#000000b0')")["alpha"], 176 / 255, places=3)
        self.assertEqual(self.js("m.splitColor('#fff')"), {"hex": "#ffffff", "alpha": 1})
        self.assertEqual(self.js("m.splitColor('nonsense')"), {"hex": "#000000", "alpha": 1})
        self.assertEqual(self.js("m.joinColor('#112233', 1)"), "#112233")
        self.assertEqual(self.js("m.joinColor('#112233', 0.5)"), "#11223380")

    def test_every_default_is_accepted_by_the_server_rules(self):
        defaults = self.js("m.THEME_DEFAULTS")
        self.assertEqual(set(defaults), set(STYLE_KEYS) - {"background_image"})   # the picture is optional
        validate_style(defaults)
        validate_build(self.js("m.BUILD_DEFAULTS"))
        for _, family in [(0, f[0]) for f in self.js("m.THEME_FONTS")]:
            validate_style({"font_family": family})

    def test_draft_fills_missing_settings_and_tracks_changes(self):
        draft = self.js("m.themeDraft({id:3,name:'A',style:{color:'#111111'},build:{}})")
        self.assertEqual(draft["style"]["color"], "#111111")
        self.assertEqual(draft["style"]["font_size"], 7)
        self.assertEqual(self.js("m.themeDraft(null).id"), None)
        self.assertNotEqual(self.js("m.draftKey(m.themeDraft(null))"),
                            self.js("(()=>{const d=m.themeDraft(null);d.style.color='#000000';return m.draftKey(d)})()"))

    def test_preview_payloads_look_like_real_ones(self):
        for key in ("lyrics", "bible", "announcement"):
            payload = self.js(f"m.previewPayload('{key}',{{color:'#abcdef'}},'projector')")
            self.assertEqual((payload["schema"], payload["audience"], payload["blank"]), (1, "public", False))
            self.assertEqual(payload["layout"], "projector")
            self.assertEqual(payload["base"]["style"], {"color": "#abcdef"})
        self.assertEqual(self.js("m.previewPayload('lyrics_short',{},'overlay').layout"), "lower_third")
        self.assertEqual(self.js("m.previewPayload('lyrics_short',{},'overlay').audience"), "public")
        conf = self.js("m.previewPayload('lyrics',{},'confidence')")
        self.assertEqual((conf["layout"], conf["audience"]), ("confidence", "confidence"))
        self.assertTrue(self.js("m.previewPayload('bible',{},'projector').base.title_first"))

    def test_kinds_and_controls(self):
        self.assertEqual(self.js("m.THEME_KINDS.map(k=>k.value)"), ["projector", "overlay", "confidence"])
        self.assertEqual(self.js("m.themeDraft(null,'overlay').kind"), "overlay")
        self.assertEqual(self.js("m.themeDraft(null,'overlay').style.band"), True)
        self.assertEqual(self.js("m.themeDraft({id:1,name:'x',style:{}}).kind"), "projector")
        keys = lambda kind: self.js(f"m.controlsFor('{kind}').map(c=>c.key)")
        self.assertIn("v_pos", keys("overlay"))
        self.assertNotIn("v_pos", keys("projector"))
        self.assertNotIn("v_pos", keys("confidence"))
        self.assertIn("reference_pos", keys("overlay"))
        self.assertNotIn("reference_pos", keys("projector"))
        self.assertIn("balance_lines", keys("projector"))
        self.assertIn("balance_lines", keys("overlay"))
        self.assertIn("balance_lines", keys("confidence"))
        self.assertTrue(self.js("m.themeDraft(null,'confidence').style.balance_lines"))      # on for a new monitor theme
        self.assertNotIn("lines_per_slide", keys("overlay"))
        self.assertIn("lines_per_slide", keys("projector"))
        self.assertNotIn("shadow", keys("confidence"))
        self.assertEqual(self.js("m.themeToSave(m.themeDraft(null,'confidence')).kind"), "confidence")

    def test_used_themes_come_first_and_each_section_is_alphabetical(self):
        themes = ("[{name:'Zed',usage:{services:1}},{name:'beta',usage:{}},{name:'Alpha',usage:{}},"
                  "{name:'Mid',usage:{default:true}},{name:'Aaa',usage:{confidence:true}}]")
        parts = self.js(f"m.themeSections({themes})")
        self.assertEqual([t["name"] for t in parts["inUse"]], ["Aaa", "Mid", "Zed"])
        self.assertEqual([t["name"] for t in parts["rest"]], ["Alpha", "beta"])

    def test_filter_matches_part_of_a_name_ignoring_case(self):
        names = lambda text: [t["name"] for t in self.js(
            f"m.filterThemes([{{name:'Overlay: Bottom left'}},{{name:'Deep blue'}}],{text!r})")]
        self.assertEqual(names("BOTTOM"), ["Overlay: Bottom left"])
        self.assertEqual(names("  "), ["Overlay: Bottom left", "Deep blue"])
        self.assertEqual(names("zzz"), [])

    def test_theme_list_is_grouped_by_kind(self):
        groups = self.js("m.groupThemes([{id:1,kind:'overlay'},{id:2},{id:3,kind:'confidence'}])")
        self.assertEqual([(g["kind"], [t["id"] for t in g["themes"]]) for g in groups],
                         [("projector", [2]), ("overlay", [1]), ("confidence", [3])])

    def test_the_import_summary_is_plain(self):
        self.assertEqual(self.js("m.themeImportSummary({added:['A'],duplicates:0})"), "Added 1 theme: A.")
        self.assertEqual(self.js("m.themeImportSummary({added:['A','B'],duplicates:2})"),
                         "Added 2 themes: A, B. 2 already here, skipped.")
        self.assertEqual(self.js("m.themeImportSummary({added:[],duplicates:1})"),
                         "Nothing new was added. 1 already here, skipped.")

    def test_usage_sentence(self):
        self.assertEqual(self.js("m.usageText({services:0,items:0,default:false,bible:false,outputs:0})"), "Not used yet")
        text = self.js("m.usageText({services:2,items:1,default:true,bible:true,outputs:0})")
        for part in ("new services", "Bible verses", "2 services", "1 item"):
            self.assertIn(part, text)
        self.assertIn("confidence monitor", self.js("m.usageText({services:0,items:0,confidence:true})"))


class ThemePageTests(unittest.TestCase):
    def test_the_export_and_import_buttons_are_on_the_settings_page_not_the_themes_tab(self):
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        settings = html[html.index('id="view-shortcuts"'):]
        themes = html[html.index('id="view-themes"'):html.index('id="view-shortcuts"')]
        for ident in ("theme-export-all", "theme-import", "file-themes"):
            self.assertIn(f'id="{ident}"', settings)
            self.assertNotIn(f'id="{ident}"', themes)
        self.assertNotIn('id="theme-export"', html)
        for ident in ("theme-export-pick", "theme-export-one", "theme-export-all", "theme-import", "file-themes", "theme-transfer-status"):
            self.assertIn(f'id="{ident}"', html)

    def test_the_page_has_the_tab_and_loads_the_script_first(self):
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        for ident in ("tab-themes", "view-themes", "theme-kind", "theme-show", "theme-filter", "assign-default-overlay", "assign-confidence", "service-overlay-theme", "theme-save", "theme-revert", "assign-bible", "bibles-theme", "assign-default",
                      "service-theme", "theme-frame"):
            self.assertIn(f'id="{ident}"', html)
        self.assertLess(html.index("themes.js"), html.index("operator.js"))
        self.assertNotRegex(html, r'\sstyle="')

    def test_only_the_parent_page_may_drive_the_sandbox_preview(self):
        js = (STATIC / "output.js").read_text(encoding="utf-8")
        self.assertIn("event.source !== window.parent", js)
        self.assertIn("event.origin !== location.origin", js)
