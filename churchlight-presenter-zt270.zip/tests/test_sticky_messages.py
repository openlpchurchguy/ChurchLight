# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Problems stay until cleared; notices fade; "Saved ✓" shows briefly after an edit is saved."""
import unittest

from tests.test_fold_all import until
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class StickyMessageTests(unittest.TestCase):
    def open(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        try:
            page.wait_for_selector("#wizard:not([hidden])", timeout=3000)     # a first run opens the guide by itself
        except Exception:
            pass
        page.evaluate("wizardHide()")
        return page

    def test_problem_stays_until_cleared(self):
        page = self.open()
        page.evaluate("showMessage('The projector is not set up. Open Settings, then Screens.')")
        self.assertTrue(page.is_visible("#message"))
        page.evaluate("showNotice('Added a song')")                 # a notice replaces it (newer message)
        page.evaluate("showMessage('Problem A')")
        page.evaluate("showMessage('')")                           # a success must not wipe a problem
        self.assertTrue(page.is_visible("#message"))
        self.assertEqual(page.inner_text("#message-text"), "Problem A")
        page.click("#message-clear")
        self.assertFalse(page.is_visible("#message"))

    def test_notice_fades_and_is_cleared_by_success(self):
        page = self.open()
        page.evaluate("showNotice('Added a song')")
        self.assertTrue(page.is_visible("#message"))
        page.evaluate("showMessage('')")
        self.assertFalse(page.is_visible("#message"))

    def test_saved_flash_only_for_edits_and_not_when_disconnected(self):
        page = self.open()
        page.evaluate("flashSaved()")
        self.assertEqual(page.inner_text("#connection"), "Saved ✓")
        self.assertTrue(until(lambda: page.inner_text("#connection") == "Connected", 5))
        self.assertTrue(page.evaluate("SAVED_ACTIONS.has('song_save') && !SAVED_ACTIONS.has('next') && !SAVED_ACTIONS.has('blank')"))
        page.evaluate("setConnection('Not connected: x', true); flashSaved()")
        self.assertEqual(page.inner_text("#connection"), "Not connected: x")

    def test_an_ordinary_notice_does_not_cover_a_problem_but_a_question_or_undo_does(self):
        page = self.open()
        page.evaluate("showMessage('The projector is not set up.')")
        page.evaluate("showNotice('Added a song')")
        self.assertEqual(page.inner_text("#message-text"), "The projector is not set up.")
        page.evaluate("showNotice('Removed Alpha.', () => {})")
        self.assertIn("Removed Alpha", page.inner_text("#message-text"))
        self.assertTrue(page.is_visible("#message-undo"))
