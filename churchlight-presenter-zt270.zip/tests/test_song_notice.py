# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The title and CCLI slide: its text, where it goes, and the choices that control it."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.items import ItemRef
from churchlight_presenter.core.slides import NOTICE_LABEL, SlideBuilder
from churchlight_presenter.core.songnotice import notice_lines, notice_position, notice_settings
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi

SETTINGS = {"position": "before", "writers": "Words and music by", "permission": "Used by Permission.",
            "song_number": True, "church_ccli": "12345"}


class TextTests(unittest.TestCase):
    def test_the_full_notice_follows_the_ccli_form(self):
        lines = notice_lines(SETTINGS, "Amazing Grace", "John Newton", "2010 Hillsong Music", "7068424")
        self.assertEqual(lines, ["Amazing Grace", "Words and music by John Newton",
                                 "© 2010 Hillsong Music. Used by Permission.", "CCLI Song #7068424 · CCLI License #12345"])

    def test_missing_pieces_are_left_out(self):
        self.assertEqual(notice_lines({**SETTINGS, "church_ccli": ""}, "T", "", "", ""), ["T"])
        self.assertEqual(notice_lines(SETTINGS, "T", "", "", ""), ["T", "CCLI License #12345"])
        self.assertEqual(notice_lines(SETTINGS, "T", "A B", "", "9"), ["T", "Words and music by A B", "CCLI Song #9 · CCLI License #12345"])

    def test_the_copyright_sign_is_not_doubled(self):
        for text in ("© 2010 Owner", "(c) 2010 Owner", "Copyright 2010 Owner"):
            line = notice_lines(SETTINGS, "T", "", text, "")[1]
            self.assertEqual(line.count("©") + line.lower().count("(c)") + line.count("Copyright"), 1, line)
            self.assertTrue(line.endswith("Used by Permission."), line)
        self.assertTrue(notice_lines(SETTINGS, "T", "", "2010 Owner.", "")[1].startswith("© 2010 Owner. Used"))

    def test_the_song_number_can_be_switched_off(self):
        lines = notice_lines({**SETTINGS, "song_number": False}, "T", "", "", "7068424")
        self.assertNotIn("CCLI Song", " ".join(lines))

    def test_the_wording_is_editable(self):
        lines = notice_lines({**SETTINGS, "writers": "Written by", "permission": ""}, "T", "A", "2010 B", "")
        self.assertEqual(lines[1:3], ["Written by A", "© 2010 B."])

    def test_position_rules(self):
        self.assertEqual(notice_position(SETTINGS, None, None), "before")
        self.assertEqual(notice_position(SETTINGS, "after", None), "after")
        self.assertIsNone(notice_position(SETTINGS, "never", None))
        self.assertIsNone(notice_position(SETTINGS, "after", {"notice": "off"}))
        self.assertIsNone(notice_position({**SETTINGS, "position": "off"}, None, None))
        self.assertEqual(notice_position({**SETTINGS, "position": "off"}, "before", None), "before")


class BuilderTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.song = self.db.create_song_with_sections(
            "Amazing Grace", [("Verse 1", "verse", "a\nb"), ("Chorus", "chorus", "c\nd")], author="John Newton", ccli_number="7068424")
        self.db.update_song(self.song, copyright="2010 Owner")
        self.builder = SlideBuilder(self.db)

    def kinds(self, **kw):
        return [s.kind for s in self.builder.build_item(ItemRef.song(self.song, **kw))]

    def test_off_by_default_so_nothing_changes_until_it_is_chosen(self):
        self.assertEqual(self.kinds(), ["lyrics", "lyrics"])

    def test_before_and_after(self):
        self.db.set_setting("notice_slide", "before")
        self.db.set_setting("church_ccli", "12345")
        slides = self.builder.build_item(ItemRef.song(self.song))
        self.assertEqual([s.kind for s in slides], ["notice", "lyrics", "lyrics"])
        self.assertEqual(slides[0].label, NOTICE_LABEL)
        self.assertEqual(slides[0].text.splitlines()[0], "Amazing Grace")
        self.assertIn("CCLI License #12345", slides[0].text)
        self.db.set_setting("notice_slide", "after")
        self.assertEqual(self.kinds(), ["lyrics", "lyrics", "notice"])

    def test_a_song_can_choose_and_an_item_can_skip(self):
        self.db.set_setting("notice_slide", "before")
        self.db.update_song(self.song, notice_slide="after")
        self.assertEqual(self.kinds(), ["lyrics", "lyrics", "notice"])
        self.db.update_song(self.song, notice_slide="never")
        self.assertEqual(self.kinds(), ["lyrics", "lyrics"])
        self.db.update_song(self.song, notice_slide=None)
        self.assertEqual(self.kinds(), ["notice", "lyrics", "lyrics"])
        self.assertEqual(self.kinds(overrides={"notice": "off"}), ["lyrics", "lyrics"])

    def test_the_notice_slide_is_not_one_of_the_songs_parts(self):
        self.db.set_setting("notice_slide", "before")
        parts = [s.part for s in self.builder.build_item(ItemRef.song(self.song))]
        self.assertEqual(parts, [-1, 0, 1])


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db)
        self.api = OperatorApi(self.c)
        self.c.new_service("Sunday")
        self.song = self.c.create_song("Grace", "Newton", "[Verse 1]\nline one\nline two", ccli="123", copyright_text="2010 Owner")
        self.c.add_entry(next(e for e in self.c.search_library("Grace") if e.kind == "song"))
        self.c.set_notice_settings("before", "Words and music by", "Used by Permission.", True)

    def slides(self):
        return [s.kind for s in self.c.session.slides]

    def test_settings_rebuild_the_service(self):
        self.assertEqual(self.slides(), ["notice", "lyrics"])
        self.c.set_notice_settings("after", "Written by", "", True)
        self.assertEqual(self.slides(), ["lyrics", "notice"])
        self.assertIn("Written by Newton", self.c.session.slides[1].text)
        self.c.set_notice_settings("off", "", "", False)
        self.assertEqual(self.slides(), ["lyrics"])
        with self.assertRaises(ControllerError):
            self.c.set_notice_settings("sideways", "", "", True)

    def test_the_church_number_change_shows_at_once(self):
        self.c.set_church_ccli("99887")
        self.assertIn("CCLI License #99887", self.c.session.slides[0].text)

    def test_the_item_skip_and_the_outline_row(self):
        item = self.c.service_rows()[0]
        outline = item.outline
        self.assertEqual([p["label"] for p in outline][0], NOTICE_LABEL)
        self.assertTrue(outline[0]["notice"])
        self.c.set_item_notice(item.item_id, True)
        self.assertEqual(self.slides(), ["lyrics"])
        outline = self.c.service_rows()[0].outline
        self.assertTrue(outline[0]["notice"] and outline[0]["skipped"])            # a row to switch it back on, where it would be (first)
        self.c.set_item_notice(item.item_id, False)
        self.assertEqual(self.slides(), ["notice", "lyrics"])
        self.c.set_notice_settings("after", "", "", True)
        self.c.set_item_notice(item.item_id, True)
        outline = self.c.service_rows()[0].outline
        self.assertTrue(outline[-1]["notice"] and outline[-1]["skipped"])          # "after the song": the left-out row is last

    def test_the_song_editor_carries_copyright_and_the_choice(self):
        song_id = self.c.service_rows() and next(e for e in self.c.search_library("Grace") if e.kind == "song").id
        info = self.c.song_for_editing(song_id)
        self.assertEqual((info["copyright"], info["notice"]), ("2010 Owner", ""))
        self.c.update_song(song_id, "Grace", "Newton", "[Verse 1]\nline one", copyright_text="2011 Other", notice="never")
        info = self.c.song_for_editing(song_id)
        self.assertEqual((info["copyright"], info["notice"]), ("2011 Other", "never"))
        self.assertEqual(self.slides(), ["lyrics"])
        self.c.update_song(song_id, "Grace", "Newton", "[Verse 1]\nline one", notice="")
        self.assertEqual(self.c.song_for_editing(song_id)["notice"], "")
        with self.assertRaises(ControllerError):
            self.c.update_song(song_id, "Grace", "Newton", "[Verse 1]\nline one", notice="sideways")

    def test_the_api_exposes_the_settings(self):
        self.assertEqual(self.api.state()["notice"]["position"], "before")
        self.api.call("notice_set", {"position": "off", "writers": "W", "permission": "P", "song_number": False})
        notice = self.api.state()["notice"]
        self.assertEqual((notice["position"], notice["writers"], notice["permission"], notice["song_number"]), ("off", "W", "P", False))


if __name__ == "__main__":
    unittest.main()
