# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""One button folds or opens every section of the Settings page."""
import json
import subprocess
import time
import unittest
from pathlib import Path

from tests.test_verse_tray import make


def until(check, seconds=10):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

JS = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "operator.js"


def js(expression):
    script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
    out = subprocess.run(["node", "-e", script, str(JS)], capture_output=True, text=True, timeout=30, check=True)
    return json.loads(out.stdout)


class PlanTests(unittest.TestCase):
    def test_any_open_section_means_fold_all(self):
        self.assertEqual(js("m.foldAllPlan([true,true,true])"), {"label": "Fold all", "openAll": False})
        self.assertEqual(js("m.foldAllPlan([true,false,false])"), {"label": "Fold all", "openAll": False})

    def test_only_when_everything_is_folded_does_it_open_all(self):
        self.assertEqual(js("m.foldAllPlan([false,false])"), {"label": "Open all", "openAll": True})
        self.assertEqual(js("m.foldAllPlan([])"), {"label": "Open all", "openAll": True})

    def test_every_settings_section_is_remembered(self):
        html = (JS.parent / "operator.html").read_text(encoding="utf-8")
        import re
        names = re.findall(r'data-settings-fold="(\w+)"', html)
        self.assertEqual(sorted(js("m.SETTINGS_FOLDS")), sorted(names))


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def test_fold_all_then_open_all_and_it_is_remembered(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.click("#tab-shortcuts")
        sections = "details[data-settings-fold]"
        total = page.locator(sections).count()
        self.assertGreater(total, 5)
        self.assertEqual(page.inner_text("#settings-fold-all"), "Open all")        # a first visit: everything is folded

        def open_count():
            return page.evaluate("document.querySelectorAll('details[data-settings-fold][open]').length")

        self.assertEqual(open_count(), 0)
        page.click("#settings-fold-all")
        self.assertTrue(until(lambda: page.evaluate(f"document.querySelectorAll('details[data-settings-fold][open]').length === {total}")))
        self.assertTrue(until(lambda: page.evaluate("document.getElementById('settings-fold-all').textContent === 'Fold all'")))
        page.reload()
        page.click("#tab-shortcuts")
        self.assertEqual(open_count(), 0)                                  # a reload starts folded again, nothing remembered
        page.click("#settings-fold-all")
        self.assertTrue(until(lambda: page.evaluate(f"document.querySelectorAll('details[data-settings-fold][open]').length === {total}")))
        page.click("#tab-run")
        page.click("#tab-shortcuts")
        self.assertEqual(open_count(), 0)                                  # leaving and returning starts folded again
        page.evaluate("goSettings('clicker')")
        self.assertTrue(until(lambda: page.evaluate("document.querySelector('details[data-settings-fold=clicker]').open")))
        self.assertTrue(until(lambda: page.evaluate("document.querySelector('details[data-settings-fold=advanced]').open")))
        self.assertEqual(open_count(), 2)                                  # a jump opens only the target (and Advanced around it)
        page.click("#tab-broadcast")
        self.assertEqual(page.evaluate("[document.getElementById('ts-proj').open, document.getElementById('ts-speak').open]"), [False, False])
        page.click("#ts-proj > summary")
        page.click("#tab-run")
        page.click("#tab-broadcast")
        self.assertEqual(page.evaluate("[document.getElementById('ts-proj').open, document.getElementById('ts-speak').open]"), [False, False])
        page.click("#tab-shortcuts")
        page.click(sections + " >> nth=1 >> summary")                       # open one by hand
        self.assertTrue(until(lambda: page.evaluate("document.getElementById('settings-fold-all').textContent === 'Fold all'")))
        page.click("#settings-fold-all")                                    # one open: it folds, not opens
        self.assertTrue(until(lambda: page.evaluate("document.querySelectorAll('details[data-settings-fold][open]').length === 0")))


if __name__ == "__main__":
    unittest.main()
