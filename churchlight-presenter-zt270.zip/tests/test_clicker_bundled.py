# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The clicker helper that comes with ChurchLight: a script built by the program and run with the bundled AutoHotkey."""
import json
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core import clickerhelper
from churchlight_presenter.core.clickerhelper import ClickerHelper, build_script, clean_rows
from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.operator_api import ApiError, TRIGGER_NAMES
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

TOKEN = "abcdefghijklmnopqrstuvwxyz0123"
ROOT = Path(__file__).resolve().parent.parent


class FakeProcess:
    def __init__(self):
        self.alive = True

    def poll(self):
        return None if self.alive else 0

    def terminate(self):
        self.alive = False

    def wait(self, timeout=None):
        return 0

    def kill(self):
        self.alive = False


class Recorder:
    def __init__(self):
        self.calls = []
        self.processes = []

    def __call__(self, args, **kwargs):
        script = Path(args[1])
        self.calls.append({"args": args, "script": script.read_bytes().decode("utf-8-sig")})
        process = FakeProcess()
        self.processes.append(process)
        return process


class BundleTests(unittest.TestCase):
    def test_the_autohotkey_files_are_in_the_vendor_folder(self):
        folder = ROOT / "vendor" / "autohotkey"
        self.assertEqual((folder / "AutoHotkey64.exe").read_bytes()[:2], b"MZ")
        self.assertIn("GNU GENERAL PUBLIC LICENSE", (folder / "license.txt").read_text(encoding="utf-8", errors="replace"))
        notice = (folder / "NOTICE.txt").read_text(encoding="utf-8")
        self.assertIn("2.0.31", notice)
        self.assertIn("github.com/AutoHotkey/AutoHotkey", notice)

    def test_the_helper_finds_the_bundled_exe(self):
        self.assertEqual(clickerhelper.VENDOR_DIR, ROOT / "vendor" / "autohotkey")
        self.assertTrue((clickerhelper.VENDOR_DIR / clickerhelper.EXE_NAME).is_file())


class ScriptTests(unittest.TestCase):
    def test_the_script_calls_the_trigger_url_and_passes_the_key_on_if_unanswered(self):
        text = build_script(8765, TOKEN, [{"key": "PgDn", "action": "next"}, {"key": ".", "action": "blank"}])
        self.assertIn('BaseUrl := "http://127.0.0.1:8765/hook/' + TOKEN + '/"', text)
        self.assertIn('$PgDn::Press("next", "PgDn")', text)
        self.assertIn('$.::Press("blank", ".")', text)
        self.assertIn("#Requires AutoHotkey v2.0", text)
        self.assertIn("^!F12::", text)
        self.assertIn('Send "{" . fallback . "}"', text)

    def test_the_script_closes_itself_when_the_program_has_closed(self):
        script = build_script(8123, "A" * 24, [{"key": "PgDn", "action": "next"}])
        self.assertIn("SetTimer CheckAlive, 5000", script)
        self.assertIn("http://127.0.0.1:8123/", script)
        self.assertIn("ExitApp", script)
        self.assertIn("Misses >= 3", script)       # a few quiet checks in a row, not one slow answer

    def test_nothing_but_listed_keys_and_actions_can_get_into_the_script(self):
        rows = [{"key": "a::MsgBox", "action": "next"}, {"key": "PgDn", "action": 'next"); Run("calc'},
                {"key": "PgUp", "action": "previous"}, {"key": "F13", "action": "next"}, "x", None,
                {"key": "pgup", "action": "blank"}]                 # the same key twice
        kept = clean_rows(rows, TRIGGER_NAMES)
        self.assertEqual(kept, [{"key": "PgUp", "action": "previous"}])
        with self.assertRaises(ValueError):
            build_script(8765, TOKEN, [{"key": "a::MsgBox", "action": "next"}])
        with self.assertRaises(ValueError):
            build_script(8765, TOKEN, [{"key": "PgDn", "action": 'x"); Run("calc'}])

    def test_a_bad_secret_or_port_is_refused(self):
        for port, token in ((8765, "short"), (8765, 'x"' * 12), (0, TOKEN), ("8765", TOKEN)):
            with self.assertRaises(ValueError):
                build_script(port, token, [{"key": "PgDn", "action": "next"}])

    def test_every_trigger_action_name_is_a_plain_word(self):
        for name in TRIGGER_NAMES:
            self.assertRegex(name, r"^[a-z_]{1,40}$")


class HelperTests(unittest.TestCase):
    def helper(self, windows=True):
        folder = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(folder, ignore_errors=True))
        rec = Recorder()
        return ClickerHelper(folder, exe=clickerhelper.VENDOR_DIR / clickerhelper.EXE_NAME, popen=rec, windows=windows), rec

    def test_it_runs_only_on_windows(self):
        helper, _ = self.helper(windows=False)
        self.assertFalse(helper.available())
        with self.assertRaises(OSError):
            helper.start(8765, TOKEN, [{"key": "PgDn", "action": "next"}])

    def test_start_writes_the_script_and_runs_the_bundled_exe(self):
        helper, rec = self.helper()
        helper.start(8765, TOKEN, [{"key": "PgDn", "action": "next"}])
        self.assertTrue(helper.running())
        self.assertTrue(rec.calls[0]["args"][0].endswith("AutoHotkey64.exe"))
        self.assertIn('$PgDn::Press("next", "PgDn")', rec.calls[0]["script"])

    def test_stop_ends_the_program_and_removes_the_script_with_the_secret(self):
        helper, rec = self.helper()
        helper.start(8765, TOKEN, [{"key": "PgDn", "action": "next"}])
        helper.stop()
        self.assertFalse(helper.running())
        self.assertFalse(rec.processes[0].alive)
        self.assertFalse(helper.script_path.exists())

    def test_starting_again_replaces_the_running_helper(self):
        helper, rec = self.helper()
        helper.start(8765, TOKEN, [{"key": "PgDn", "action": "next"}])
        helper.start(8765, TOKEN, [{"key": "PgUp", "action": "previous"}])
        self.assertFalse(rec.processes[0].alive)
        self.assertTrue(rec.processes[1].alive)
        self.assertEqual(len(rec.calls), 2)


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        self.folder = tempfile.mkdtemp()
        self.rec = Recorder()
        self.c.clicker = ClickerHelper(self.folder, exe=clickerhelper.VENDOR_DIR / clickerhelper.EXE_NAME,
                                       popen=self.rec, windows=True)
        self.addCleanup(lambda: __import__("shutil").rmtree(self.folder, ignore_errors=True))
        self.rows = [{"key": "PgDn", "action": "next"}, {"key": "PgUp", "action": "previous"}]

    def test_the_state_says_whether_the_helper_is_available_and_running(self):
        view = self.api.state()["clicker"]
        self.assertEqual((view["available"], view["running"], view["auto"], view["rows"]), (True, False, False, []))
        self.api.call("clicker_start", {"rows": self.rows})
        view = self.api.state()["clicker"]
        self.assertTrue(view["running"])
        self.assertEqual(view["rows"], self.rows)

    def test_start_uses_the_servers_port_and_the_current_secret(self):
        self.api.call("clicker_start", {"rows": self.rows})
        token = self.c.hook_settings()["token"]
        self.assertIn(f"http://127.0.0.1:{self.server.address[1]}/hook/{token}/", self.rec.calls[0]["script"])

    def test_bad_buttons_are_refused_and_nothing_runs(self):
        with self.assertRaises(ApiError):
            self.api.call("clicker_start", {"rows": [{"key": "a::MsgBox", "action": "next"}]})
        with self.assertRaises(ApiError):
            self.api.call("clicker_start", {"rows": "no"})
        self.assertEqual(self.rec.calls, [])

    def test_it_will_not_start_with_trigger_urls_off(self):
        self.c.set_hook(on=False)
        with self.assertRaises(ControllerError):
            self.c.start_clicker(self.rows)
        self.assertEqual(self.rec.calls, [])

    def test_a_new_secret_restarts_the_helper_with_the_new_secret(self):
        self.api.call("clicker_start", {"rows": self.rows})
        old = self.c.hook_settings()["token"]
        self.api.call("hook_new_token")
        new = self.c.hook_settings()["token"]
        self.assertNotEqual(old, new)
        self.assertEqual(len(self.rec.calls), 2)
        self.assertNotIn(old, self.rec.calls[1]["script"])
        self.assertIn(new, self.rec.calls[1]["script"])
        self.assertFalse(self.rec.processes[0].alive)

    def test_turning_trigger_urls_off_stops_the_helper(self):
        self.api.call("clicker_start", {"rows": self.rows})
        self.api.call("hook_set", {"on": False})
        self.assertFalse(self.c.clicker.running())

    def test_stop_and_closing_the_program_stop_it(self):
        self.api.call("clicker_start", {"rows": self.rows})
        self.api.call("clicker_stop")
        self.assertFalse(self.c.clicker.running())
        self.api.call("clicker_start", {"rows": self.rows})
        self.c.close()
        self.assertFalse(self.rec.processes[-1].alive)

    def test_start_with_the_program_only_when_asked(self):
        self.api.call("clicker_start", {"rows": self.rows})
        self.api.call("clicker_stop")
        self.assertFalse(self.c.auto_start_clicker())
        self.api.call("clicker_auto_set", {"on": True})
        self.assertTrue(self.api.state()["clicker"]["auto"])
        self.assertTrue(self.c.auto_start_clicker())
        self.assertTrue(self.c.clicker.running())

    def test_without_a_helper_nothing_is_available(self):
        self.c.clicker = None
        self.assertFalse(self.api.state()["clicker"]["available"])
        with self.assertRaises(ApiError):
            self.api.call("clicker_start", {"rows": self.rows})


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def test_the_start_button_runs_the_helper_and_restart_and_stop_follow(self):
        import time
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        rec = Recorder()
        folder = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(folder, ignore_errors=True))
        c.clicker = ClickerHelper(folder, exe=clickerhelper.VENDOR_DIR / clickerhelper.EXE_NAME, popen=rec, windows=True)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.click("#tab-shortcuts")
        page.evaluate("document.querySelectorAll('details[data-settings-fold]').forEach((d) => { d.open = true; })")     # Settings starts folded
        page.wait_for_selector("#clicker-start", state="visible")
        self.assertTrue(page.is_visible("#clicker-auto"))
        page.click("#clicker-start")
        end = time.time() + 5
        while time.time() < end and not c.clicker.running():
            time.sleep(0.05)
        self.assertTrue(c.clicker.running())
        self.assertIn('$PgDn::Press("next", "PgDn")', rec.calls[0]["script"])
        page.wait_for_selector("#clicker-stop", state="visible")
        self.assertIn("Restart", page.inner_text("#clicker-start"))
        page.click("#clicker-stop")
        end = time.time() + 5
        while time.time() < end and c.clicker.running():
            time.sleep(0.05)
        self.assertFalse(c.clicker.running())

    def test_the_service_toolbar_button_starts_and_stops_the_helper(self):
        import time
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        folder = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(folder, ignore_errors=True))
        c.clicker = ClickerHelper(folder, exe=clickerhelper.VENDOR_DIR / clickerhelper.EXE_NAME, popen=Recorder(), windows=True)
        c.new_service("S")                                  # the Service board (and its toolbar) shows once a service is open
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#btn-clicker", state="visible")
        self.assertEqual(page.inner_text("#btn-clicker"), "Clicker: off")
        page.click("#btn-clicker")
        end = time.time() + 5
        while time.time() < end and "on" not in page.inner_text("#btn-clicker"):
            time.sleep(0.05)
        self.assertTrue(c.clicker.running())
        self.assertEqual(page.inner_text("#btn-clicker"), "Clicker: on")
        self.assertIn("toggle-on", page.get_attribute("#btn-clicker", "class"))
        page.click("#btn-clicker")
        end = time.time() + 5
        while time.time() < end and c.clicker.running():
            time.sleep(0.05)
        self.assertFalse(c.clicker.running())

    def test_without_the_helper_only_the_download_is_offered(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        c.new_service("S")
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.click("#tab-shortcuts")
        page.evaluate("document.querySelectorAll('details[data-settings-fold]').forEach((d) => { d.open = true; })")     # Settings starts folded
        page.wait_for_selector("#clicker-download", state="visible")
        self.assertFalse(page.is_visible("#clicker-start"))
        page.click("#tab-run")
        self.assertFalse(page.is_visible("#btn-clicker"))                  # no toolbar button either
        page.click("#tab-shortcuts")
        page.evaluate("document.querySelectorAll('details[data-settings-fold]').forEach((d) => { d.open = true; })")     # Settings starts folded
        self.assertIn("Windows only", page.inner_text("#clicker-status"))


if __name__ == "__main__":
    unittest.main()
