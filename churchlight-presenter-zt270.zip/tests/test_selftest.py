# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_spec = importlib.util.spec_from_file_location("selftest", ROOT / "tools" / "selftest.py")
selftest = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(selftest)


class SelfTestTests(unittest.TestCase):
    def run_it(self, *extra):
        out = Path(tempfile.mkdtemp()) / "report.txt"
        code = selftest.main(["--skip-tests", "--out", str(out), *extra])
        return code, out.read_text(encoding="utf-8")

    def test_report_is_written_and_passes_on_a_healthy_install(self):
        import contextlib
        import io
        with contextlib.redirect_stdout(io.StringIO()):
            code, text = self.run_it()
        self.assertEqual(code, 0, text)
        for expected in ("[PASS] This computer", "[PASS] Demo scenario", "[PASS] Web server",
                         "OVERALL: PASS", "FTS5"):
            self.assertIn(expected, text)

    def test_a_bad_file_is_reported_not_raised(self):
        import contextlib
        import io
        with contextlib.redirect_stdout(io.StringIO()):
            code, text = self.run_it("--bible", str(ROOT / "nope.xml"))
        self.assertEqual(code, 1)
        self.assertIn("[FAIL]", text)
        self.assertIn("OVERALL: FAIL", text)

    def test_bible_lookups_find_single_verses(self):
        import contextlib
        import io
        from tests.test_song_bible_importers import SAMPLE, zefania
        path = Path(tempfile.mkdtemp()) / "demo.xml"
        path.write_text(zefania(SAMPLE))
        with contextlib.redirect_stdout(io.StringIO()):
            _, text = self.run_it("--bible", str(path))
        self.assertIn("John 3:16: found", text)
        self.assertIn("Genesis 1:1: found", text)
        self.assertIn("Psalm 23: not found", text)

    def test_the_report_never_contains_slide_text(self):
        import contextlib
        import io
        from tests.test_song_bible_importers import song_xml
        folder = Path(tempfile.mkdtemp())
        (folder / "s.xml").write_text(song_xml(verses=[("v1", None, "SECRET LYRIC WORDS")], order=""))
        with contextlib.redirect_stdout(io.StringIO()):
            code, text = self.run_it("--songs", str(folder))
        self.assertEqual(code, 0, text)
        self.assertNotIn("SECRET LYRIC", text)
        self.assertIn("imported 1", text)


if __name__ == "__main__":
    unittest.main()
