# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Hide the lower thirds on their own: the projector and the blank setting are not touched."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import Output, build_payload
from churchlight_presenter.core.slides import Slide
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
LAYOUTS = ("projector", "lower_third", "song_lower", "verse_lower", "stage", "confidence")


def live_session():
    session = LiveSession()
    session.load([Slide("lyrics", "song", 1, text="line one")])
    session.go_to(0)
    return session


class PayloadTests(unittest.TestCase):
    def test_only_the_lower_third_layouts_go_quiet(self):
        session = live_session()
        session.set_lower_hidden(True)
        for layout in LAYOUTS:
            payload = build_payload(session.state(), Output("x", layout))
            if layout in ("lower_third", "song_lower", "verse_lower"):
                self.assertIsNone(payload["base"], layout)
                self.assertTrue(payload["lower_hidden"], layout)
                self.assertFalse(payload["blank"], layout)             # not the blank setting
            else:
                self.assertIsNotNone(payload["base"], layout)
                self.assertNotIn("lower_hidden", payload, layout)

    def test_the_operators_own_preview_still_shows_it(self):
        session = live_session()
        session.set_lower_hidden(True)
        payload = build_payload(session.state(), Output("x", "lower_third"), peek=True)
        self.assertIsNotNone(payload["base"])

    def test_it_is_independent_of_blank_and_home(self):
        session = live_session()
        home = {"image_path": "backgrounds/0123456789abcdef.png", "fit": "fit", "when_blank": True, "when_idle": True}
        session.set_lower_hidden(True)
        self.assertFalse(session.state().blank)
        session.set_blank(True)
        session.set_lower_hidden(False)
        self.assertTrue(session.state().blank)                          # hiding / showing the lower third did not touch it
        self.assertIn("home", build_payload(session.state(), Output("p", "projector"), home=home))

    def test_toggle(self):
        session = live_session()
        self.assertTrue(session.toggle_lower_hidden())
        self.assertTrue(session.state().lower_hidden)
        self.assertTrue(session.toggle_lower_hidden())
        self.assertFalse(session.state().lower_hidden)


class ControllerTests(unittest.TestCase):
    def test_the_button_action_and_the_state(self):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db)
        api = OperatorApi(c)
        self.assertFalse(api.state()["live"]["lower_hidden"])
        self.assertTrue(api.call("lower_hide")["lower_hidden"])
        self.assertTrue(api.state()["live"]["lower_hidden"])
        self.assertFalse(api.state()["live"]["blank"])
        self.assertFalse(api.call("lower_hide")["lower_hidden"])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    def test_l_hides_the_lower_thirds(self):
        self.assertEqual(self.js("m.keyAction('l',{typing:false})"), {"action": "lower_hide"})


if __name__ == "__main__":
    unittest.main()
