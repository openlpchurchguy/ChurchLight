# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The Song Library and Slideshow Library pages: choose several, delete them together."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import OperatorController
from tests.test_library_admin import TEXT

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:                                           # pragma: no cover
    HAVE_BROWSER = False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BatchDeletePageTests(unittest.TestCase):
    def open(self):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db)
        db.set_setting("setup_done", "1")                    # no guide over the page
        self.ids = [c.create_song(f"Song {n}", "", TEXT) for n in range(4)]
        self.decks = [db.add_presentation(f"Deck {n}", [("a.png", None)]) for n in range(3)]
        self.c = c
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.click("#tab-songs") if page.locator("#tab-songs").count() else None
        return page

    def go_library(self, page):
        page.evaluate("showView('songs')")
        page.wait_for_selector("#song-list li")

    def test_choose_several_songs_and_delete_them_after_a_second_press(self):
        page = self.open()
        self.go_library(page)
        self.assertTrue(page.is_hidden("#song-select-bar"))
        page.click("#song-select-toggle")
        self.assertEqual(page.inner_text("#song-select-toggle"), "Done")
        page.check("input[aria-label='Select Song 0']")
        page.check("input[aria-label='Select Song 2']")
        self.assertIn("2 selected", page.inner_text("#song-select-bar"))
        page.click("#song-select-bar button.danger")                       # first press only asks
        self.assertIn("Sure? Delete 2", page.inner_text("#song-select-bar"))
        self.assertEqual(len(self.c.db.song_summaries()), 4)
        page.click("#song-select-bar button.danger")
        page.wait_for_selector("text=Deleted 2 songs")
        self.assertEqual(sorted(s["title"] for s in self.c.db.song_summaries()), ["Song 1", "Song 3"])
        page.wait_for_selector("#song-select-bar", state="hidden")         # back to the normal list
        self.assertEqual(page.inner_text("#song-select-toggle"), "Select several")

    def test_select_all_shown_only_takes_what_the_filter_shows(self):
        page = self.open()
        self.go_library(page)
        page.fill("#song-filter", "Song 3")
        page.click("#song-select-toggle")
        page.click("text=Select all shown")
        self.assertIn("1 selected", page.inner_text("#song-select-bar"))
        page.fill("#song-filter", "")                                       # the list changes: the hidden choice is not kept
        self.assertIn("1 selected", page.inner_text("#song-select-bar"))
        page.fill("#song-filter", "Song 1")
        self.assertIn("0 selected", page.inner_text("#song-select-bar"))
        self.assertTrue(page.is_disabled("#song-select-bar button.danger"))

    def test_a_song_used_in_a_service_cannot_be_chosen(self):
        page = self.open()
        self.c.new_service("Sunday")
        entry = next(e for e in self.c.search_library("Song 1") if e.kind == "song")
        self.c.add_entry(entry)
        page.reload()                                       # the list was drawn before the song was used
        self.go_library(page)
        page.click("#song-select-toggle")
        self.assertTrue(page.is_disabled("input[aria-label='Select Song 1']"))
        page.click("text=Select all shown")
        self.assertIn("3 selected", page.inner_text("#song-select-bar"))

    def test_slideshows_can_be_chosen_and_deleted_too(self):
        page = self.open()
        page.evaluate("showView('decks')")
        page.wait_for_selector("#deck-list li")
        page.click("#deck-select-toggle")
        page.check("input[aria-label='Select Deck 0']")
        page.check("input[aria-label='Select Deck 1']")
        page.click("#deck-select-bar button.danger")
        page.click("#deck-select-bar button.danger")
        page.wait_for_selector("text=Deleted 2 slideshows")
        self.assertEqual([r["name"] for r in self.c.db.presentation_summaries()], ["Deck 2"])


if __name__ == "__main__":
    unittest.main()
