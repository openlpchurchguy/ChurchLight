# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The clicker helper: key names, the AutoHotkey script text, and the Settings section that downloads it."""
import json
import shutil
import subprocess
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
ACTIONS = '[{name:"next"},{name:"previous"},{name:"blank"}]'


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class ScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_key_names_follow_autohotkey(self):
        for code, name in (("PageDown", "PgDn"), ("PageUp", "PgUp"), ("ArrowRight", "Right"), ("Period", "."),
                           ("KeyB", "b"), ("Digit5", "5"), ("F5", "F5"), ("Space", "Space"), ("Escape", "Esc")):
            self.assertEqual(self.js(f"m.ahkKeyName('{code}')"), name)
        for code in ("ShiftLeft", "ControlLeft", "MediaPlayPause", "F13", "Semicolon", ""):
            self.assertEqual(self.js(f"m.ahkKeyName('{code}')"), "")

    def test_rows_are_cleaned(self):
        rows = '[{key:"PgDn",action:"next"},{key:"pgdn",action:"blank"},{key:"",action:"next"},{key:"b",action:"nope"},{key:"b",action:"blank"},null]'
        self.assertEqual(self.js(f"m.cleanClickerRows({rows}, {ACTIONS})"),
                         [{"key": "PgDn", "action": "next"}, {"key": "b", "action": "blank"}])

    def test_the_script_has_the_address_the_keys_and_the_fallback(self):
        text = self.js('m.buildClickerScript("http://127.0.0.1:8765", "SECRETtoken_123", '
                       '[{key:"PgDn",action:"next"},{key:".",action:"blank"}])')
        self.assertIn("#Requires AutoHotkey v2.0", text)
        self.assertIn('BaseUrl := "http://127.0.0.1:8765/hook/SECRETtoken_123/"', text)
        self.assertIn('$PgDn::Press("next", "PgDn")', text)
        self.assertIn('$.::Press("blank", ".")', text)
        self.assertIn('Send "{" . fallback . "}"', text)          # ChurchLight not running: a normal key again
        self.assertIn("^!F12::", text)
        self.assertIn("\r\n", text)
        self.assertNotIn("\n\n\n\n", text)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, [Output("projector", "projector")])
        self.c.new_service("Sunday")
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            self.browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(self.browser.close)
        self.base = self.server.url.rstrip("/")

    def settings(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000}, accept_downloads=True)
        page.goto(self.base + "/operator")
        page.click("#tab-shortcuts")
        page.evaluate("document.querySelectorAll('details[data-settings-fold]').forEach((d) => { d.open = true; })")     # Settings starts folded
        page.wait_for_selector("#clicker-list li", state="attached")
        return page

    def test_pick_a_button_and_download_a_working_script(self):
        page = self.settings()
        self.assertEqual(page.locator("#clicker-list li").count(), 3)
        page.click("#clicker-add")                                   # a new row, already listening
        page.keyboard.press("F5")
        self.assertEqual(page.locator("#clicker-list .clicker-key").last.inner_text(), "F5")
        page.locator("#clicker-list select").last.select_option("next_item")
        with page.expect_download() as info:
            page.click("#clicker-download")
        download = info.value
        self.assertEqual(download.suggested_filename, "ChurchLight-clicker.ahk")
        text = Path(download.path()).read_text(encoding="utf-8")
        token = self.c.hook_settings()["token"]
        self.assertIn(f"/hook/{token}/", text)
        self.assertIn('$F5::Press("next_item", "F5")', text)
        self.assertIn('$PgDn::Press("next", "PgDn")', text)

    def test_a_pressed_key_does_not_run_the_page_shortcuts_and_duplicates_are_refused(self):
        page = self.settings()
        page.click("#clicker-add")
        page.keyboard.press("PageDown")                              # already taken by the first row
        self.assertIn("already used", page.inner_text("#clicker-status"))
        page.keyboard.press("Shift")
        self.assertIn("cannot use", page.inner_text("#clicker-status"))
        page.keyboard.press("Escape")                                # give up; the empty row stays empty
        self.assertEqual(page.locator("#clicker-list .clicker-key").last.inner_text(), "(none)")

    def test_download_is_off_while_trigger_urls_are_off(self):
        self.c.set_hook(on=False)
        page = self.settings()
        self.assertTrue(page.is_disabled("#clicker-download"))
        self.assertIn("Turn Remote button links on", page.inner_text("#clicker-status"))


if __name__ == "__main__":
    unittest.main()
