# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The editor's slide title box saves a title and the thumbnail shows it."""
import time
import unittest

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class TitleBoxTests(unittest.TestCase):
    def test_typing_a_title_saves_it_and_names_the_thumbnail(self):
        db, c, api = make()
        self.addCleanup(db.close)
        deck = c.db.search_presentations("Deck")[0]["id"] if hasattr(c.db, "search_presentations") else \
            c.db.conn.execute("SELECT id FROM presentations WHERE name = 'Deck'").fetchone()[0]
        c.new_service("S")
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#tab-decks", state="visible")
        page.evaluate("(id) => openDeckEditor(id)", deck)
        page.wait_for_selector("#de-grid .de-card", state="attached")
        page.click("#de-grid .de-card >> nth=1")
        page.fill("#de-slide-title", "Offering")
        page.press("#de-slide-title", "Enter")
        end = time.time() + 5
        while time.time() < end and not page.query_selector("#de-grid .de-title"):
            time.sleep(0.05)
        self.assertEqual(page.inner_text("#de-grid .de-title"), "Offering")
        self.assertEqual([p["title"] for p in c.deck_for_editing(deck)["pages"]], ["", "Offering", ""])
        page.click("#de-grid .de-card >> nth=0")          # another slide: the box follows the selection
        self.assertEqual(page.input_value("#de-slide-title"), "")
        page.click("#de-grid .de-card >> nth=1")
        self.assertEqual(page.input_value("#de-slide-title"), "Offering")


if __name__ == "__main__":
    unittest.main()
