# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The Settings tab's shut-down button closes the whole program, after a second press to confirm."""
import threading
import time
import unittest

from churchlight_presenter import __main__ as entry
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


class ShutdownTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)

    def test_the_action_only_raises_the_flag(self):
        self.assertFalse(self.c.shutdown_requested.is_set())
        self.api.call("shutdown", {})
        self.assertTrue(self.c.shutdown_requested.is_set())

    def test_trigger_urls_cannot_shut_the_program_down(self):
        from churchlight_presenter.ui.operator_api import TRIGGER_NAMES
        self.assertNotIn("shutdown", TRIGGER_NAMES)

    def test_the_main_loop_returns_once_asked_and_not_before(self):
        entry.SHUTDOWN_GRACE_SECONDS = 0
        self.addCleanup(setattr, entry, "SHUTDOWN_GRACE_SECONDS", 1.0)
        done = threading.Event()
        threading.Thread(target=lambda: (entry._wait_until_stopped(self.c.shutdown_requested), done.set()), daemon=True).start()
        time.sleep(0.2)
        self.assertFalse(done.is_set())
        self.c.request_shutdown()
        self.assertTrue(done.wait(3))

    def test_closing_stops_the_clicker_helper(self):
        class Helper:
            stopped = 0
            def stop(self): Helper.stopped += 1
        self.c.clicker = Helper()
        self.c.close()
        self.assertEqual(Helper.stopped, 1)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def test_two_presses_shut_down_and_the_page_says_so(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.click("#tab-shortcuts")
        page.wait_for_selector("#shutdown-btn", state="visible")
        before = page.eval_on_selector("#shutdown-btn", "e => e.getBoundingClientRect().width")
        page.click("#shutdown-btn")
        self.assertEqual(page.inner_text("#shutdown-btn"), "Yes, shut down")
        after = page.eval_on_selector("#shutdown-btn", "e => e.getBoundingClientRect().width")
        self.assertGreaterEqual(after, before - 0.6)                       # the button does not shrink, so nothing next to it moves
        self.assertFalse(c.shutdown_requested.is_set())
        page.click("#shutdown-btn")
        end = time.time() + 5
        while time.time() < end and not c.shutdown_requested.is_set():
            time.sleep(0.05)
        self.assertTrue(c.shutdown_requested.is_set())
        page.wait_for_selector("text=ChurchLight has shut down")


if __name__ == "__main__":
    unittest.main()
