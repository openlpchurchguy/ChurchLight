# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import io
import shutil
import tempfile
import unittest
import zipfile
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.importers.decks import (
    DeckImportError, import_deck, import_image_folder, main, render_pdf_with_poppler,
)

def make_pdf(path, pages):
    """A valid PDF of blank pages, written by hand so the tests need no library."""
    objects = [b"<< /Type /Catalog /Pages 2 0 R >>",
               ("<< /Type /Pages /Kids [%s] /Count %d >>" % (
                   " ".join(f"{3 + i} 0 R" for i in range(pages)), pages)).encode()]
    objects += [b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 120] >>"] * pages
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")      # (BytesIO(initial) would start writing at 0 and overwrite the header)
    offsets = []
    for n, body in enumerate(objects, start=1):
        offsets.append(out.tell())
        out.write(f"{n} 0 obj\n".encode() + body + b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode())
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    Path(path).write_bytes(out.getvalue())


def fake_renderer(count):
    """Stands in for poppler: writes `count` tiny files named like pdftoppm's."""
    def render(pdf, out_dir, dpi):
        out_dir.mkdir(parents=True, exist_ok=True)
        files = []
        for n in range(1, count + 1):
            f = out_dir / f"page-{n:02d}.png"
            f.write_bytes(b"\x89PNG fake %d" % n)
            files.append(f)
        return files
    return render


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.media = self.tmp / "media"
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)


class ImportDeckTests(Base):
    def test_the_same_file_is_not_imported_twice_unless_forced(self):
        pdf = self.tmp / "a.pdf"
        pdf.write_bytes(b"%PDF fake")
        first = import_deck(self.db, pdf, self.media, renderer=fake_renderer(2))
        again = import_deck(self.db, pdf, self.media, renderer=fake_renderer(2))
        self.assertTrue(again.duplicate)
        self.assertEqual(again.page_count, 2)
        self.assertEqual(again.presentation_id, first.presentation_id)
        self.assertEqual(len(self.db.search_presentation()), 1)
        forced = import_deck(self.db, pdf, self.media, renderer=fake_renderer(2), force=True)
        self.assertNotEqual(forced.presentation_id, first.presentation_id)

    def test_a_pdf_alone_has_no_notes_and_no_warning(self):
        pdf = self.tmp / "a.pdf"
        pdf.write_bytes(b"%PDF fake")
        result = import_deck(self.db, pdf, self.media, renderer=fake_renderer(1))
        self.assertEqual((result.notes_count, result.warnings), (0, ()))

    def test_bad_input_is_refused_before_anything_is_written(self):
        with self.assertRaisesRegex(DeckImportError, "not found"):
            import_deck(self.db, self.tmp / "missing.pdf", self.media)
        odd = self.tmp / "a.docx"
        odd.write_bytes(b"x")
        with self.assertRaisesRegex(DeckImportError, r"must be \.pdf"):
            import_deck(self.db, odd, self.media)
        deck = self.tmp / "a.pptx"
        deck.write_bytes(b"x")
        with self.assertRaisesRegex(DeckImportError, r"must be \.pdf"):         # presentation files are not accepted
            import_deck(self.db, deck, self.media)
        self.assertEqual(self.db.search_presentation(), [])

    def test_a_failed_import_leaves_no_files_and_no_database_rows(self):
        pdf = self.tmp / "a.pdf"
        pdf.write_bytes(b"%PDF fake")

        def broken(pdf_path, out_dir, dpi):
            out_dir.mkdir(parents=True)
            (out_dir / "page-1.png").write_bytes(b"x")
            raise DeckImportError("renderer died")

        with self.assertRaisesRegex(DeckImportError, "renderer died"):
            import_deck(self.db, pdf, self.media, renderer=broken)
        self.assertEqual(self.db.search_presentation(), [])
        self.assertEqual(list(self.media.iterdir()), [])           # temp work folder is gone too

    def test_a_database_failure_removes_the_images_it_moved(self):
        pdf = self.tmp / "a.pdf"
        pdf.write_bytes(b"%PDF fake")

        class Failing:
            def find_presentation_by_hash(self, h):
                return None

            def add_presentation(self, *a, **k):
                raise RuntimeError("disk full")

        with self.assertRaises(RuntimeError):
            import_deck(Failing(), pdf, self.media, renderer=fake_renderer(2))
        self.assertEqual([p for p in self.media.rglob("*") if p.is_file()], [])


class ImageFolderTests(Base):
    def test_images_are_copied_in_natural_order(self):
        folder = self.tmp / "slides"
        folder.mkdir()
        for name in ("slide10.png", "slide2.png", "slide1.jpg", "readme.txt"):
            (folder / name).write_bytes(name.encode())
        result = import_image_folder(self.db, folder, self.media)
        pages = self.db.get_presentation_pages(result.presentation_id)
        self.assertEqual(result.page_count, 3)
        self.assertEqual([(self.media / p["image_path"]).read_bytes() for p in pages],
                         [b"slide1.jpg", b"slide2.png", b"slide10.png"])
        self.assertTrue((folder / "slide1.jpg").exists())            # originals untouched
        self.assertTrue(import_image_folder(self.db, folder, self.media).duplicate)

    def test_empty_or_missing_folders_are_refused(self):
        with self.assertRaisesRegex(DeckImportError, "not a folder"):
            import_image_folder(self.db, self.tmp / "nope", self.media)
        (self.tmp / "empty").mkdir()
        with self.assertRaisesRegex(DeckImportError, "no images"):
            import_image_folder(self.db, self.tmp / "empty", self.media)


class CommandLineTests(Base):
    def test_a_friendly_message_instead_of_a_traceback(self):
        out = io.StringIO()
        code = main([str(self.tmp / "missing.pdf"), "--db", str(self.tmp / "c.db"),
                     "--media", str(self.media)], out=out)
        self.assertEqual(code, 1)
        self.assertIn("Import failed", out.getvalue())

    def test_importing_an_image_folder_end_to_end(self):
        folder = self.tmp / "s"
        folder.mkdir()
        (folder / "1.png").write_bytes(b"x")
        out = io.StringIO()
        argv = [str(folder), "--db", str(self.tmp / "c.db"), "--media", str(self.media)]
        self.assertEqual(main(argv, out=out), 0)
        self.assertIn("Imported: presentation 1, 1 pages", out.getvalue())
        self.assertEqual(main(argv, out=out), 0)
        self.assertIn("Already there", out.getvalue())


@unittest.skipUnless(shutil.which("pdftoppm"), "poppler (pdftoppm) is not installed")
class RealPopplerTests(Base):
    def test_a_real_pdf_becomes_numbered_images(self):
        pdf = self.tmp / "three.pdf"
        make_pdf(pdf, 3)
        pages = render_pdf_with_poppler(pdf, self.tmp / "out", dpi=50)
        self.assertEqual(len(pages), 3)
        self.assertTrue(all(p.read_bytes().startswith(b"\x89PNG") for p in pages))

    def test_pages_stay_in_order_past_nine(self):
        pdf = self.tmp / "twelve.pdf"
        make_pdf(pdf, 12)
        names = [p.name for p in render_pdf_with_poppler(pdf, self.tmp / "out", dpi=20)]
        self.assertEqual(names, [f"page-{n:02d}.png" for n in range(1, 13)])

    def test_import_deck_end_to_end_with_poppler(self):
        pdf = self.tmp / "d.pdf"
        make_pdf(pdf, 2)
        result = import_deck(self.db, pdf, self.media, dpi=40)
        self.assertEqual(result.page_count, 2)

    def test_a_broken_pdf_gives_a_clear_error(self):
        bad = self.tmp / "bad.pdf"
        bad.write_bytes(b"this is not a pdf")
        with self.assertRaisesRegex(DeckImportError, "could not be read"):
            render_pdf_with_poppler(bad, self.tmp / "out")


if __name__ == "__main__":
    unittest.main()
