# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""End to end: database -> slide builder -> live session -> per-output payloads."""
import io
import json
import unittest

from churchlight_presenter.demo import main, run_demo


class DemoScenarioTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.slides, cls.steps = run_demo()
        cls.by_step = [s["payloads"] for s in cls.steps]

    def test_the_service_builds_in_order(self):
        kinds = [(s.item_type, s.label) for s in self.slides]
        self.assertEqual(kinds, [
            ("song", "Verse 1"), ("song", "Verse 1"), ("song", "Chorus"),
            ("announcement", "Welcome"),
            ("presentation", "Slide 1"), ("presentation", "Slide 2"),
            ("presentation", "Slide 3"),
        ])
        # five lines at four per slide split 3 + 2, and the second slide is marked continued
        self.assertEqual([s.continued for s in self.slides[:2]], [False, True])

    def test_nothing_is_live_until_the_operator_picks_a_slide(self):
        for payload in self.by_step[0].values():
            self.assertEqual((payload["base"], payload["overlay"]), (None, None))

    def test_the_deck_slide_goes_live_and_only_the_stage_sees_its_notes(self):
        step = self.by_step[1]
        self.assertEqual(step["projector"]["base"]["label"], "Slide 2")
        self.assertNotIn("notes", step["projector"]["base"])
        self.assertEqual(step["stage"]["base"]["notes"], "Main point. Mention John 3:16.")
        self.assertEqual(step["stage"]["next"]["label"], "Slide 3")
        self.assertIsNone(step["verse-lower"]["base"])       # a deck is not a verse

    def test_the_verse_appears_over_the_deck_without_moving_it(self):
        step = self.by_step[2]
        projector = step["projector"]
        self.assertEqual(projector["base"]["label"], "Slide 2")
        self.assertEqual(projector["overlay"]["reference"], "John 3:16")
        self.assertEqual(projector["overlay"]["verse_numbers"], [16])
        self.assertFalse(projector["overlay"]["continued"])
        self.assertEqual(step["verse-lower"]["overlay"]["reference"], "John 3:16")
        self.assertEqual(step["stage"]["overlay"]["reference"], "John 3:16")
        self.assertEqual(step["stage"]["position"]["index"], 5)

    def test_a_long_verse_keeps_its_number_across_slides(self):
        first, second, third = (self.by_step[i]["projector"]["overlay"] for i in (2, 3, 4))
        self.assertEqual((first["reference"], first["verse_numbers"], first["continued"]),
                         ("John 3:16", [16], False))
        self.assertEqual((second["reference"], second["verse_numbers"], second["continued"]),
                         ("John 3:16", [16], True))
        self.assertEqual((third["reference"], third["verse_numbers"], third["continued"]),
                         ("John 3:17", [17], False))
        # the two pieces together are the whole verse, nothing lost or added
        verse16 = " ".join(piece["text"] for piece in (first, second))
        self.assertIn("[Demo text for John 3:16]", verse16)
        self.assertTrue(verse16.endswith("across two slides."))

    def test_hiding_the_verse_leaves_the_deck_where_it_was(self):
        step = self.by_step[5]
        self.assertIsNone(step["projector"]["overlay"])
        self.assertEqual(step["projector"]["base"]["label"], "Slide 2")

    def test_the_deck_then_moves_on(self):
        step = self.by_step[6]
        self.assertEqual(step["projector"]["base"]["label"], "Slide 3")
        self.assertIsNone(step["stage"]["base"]["notes"])

    def test_public_payloads_never_contain_notes_at_any_step(self):
        for payloads in self.by_step:
            for name in ("projector", "verse-lower"):
                text = json.dumps(payloads[name])
                self.assertNotIn("notes", text)
                self.assertNotIn("Main point", text)
                self.assertNotIn("Welcome everyone", text)

    def test_every_payload_is_plain_json(self):
        for payloads in self.by_step:
            for payload in payloads.values():
                self.assertEqual(json.loads(json.dumps(payload)), payload)

    def test_the_command_line_printout_runs_and_shows_the_key_moments(self):
        out = io.StringIO()
        main(out)
        text = out.getvalue()
        for expected in ("SLIDES BUILT FOR THE SERVICE", "John 3:16", "continued",
                         "notes: \"Main point. Mention John 3:16.\"",
                         "WHAT CROSSES THE LINE", '"schema": 1'):
            self.assertIn(expected, text)


if __name__ == "__main__":
    unittest.main()
