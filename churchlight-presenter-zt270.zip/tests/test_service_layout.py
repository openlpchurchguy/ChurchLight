# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The Service tab's fixed control strip, Plan/Run toggle and foldable, resizable tools panel."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.ui.controller import LibraryEntry
from tests.test_live_previews import until
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
HTML = (STATIC / "operator.html").read_text(encoding="utf-8")
CSS = (STATIC / "operator.css").read_text(encoding="utf-8")


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PureTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_the_panel_height_is_kept_between_12_and_60_percent(self):
        self.assertEqual(self.js("[m.clampDock(5), m.clampDock(99), m.clampDock(30.4), m.clampDock('x')]"), [12, 60, 30, 24])

    def test_a_saved_dock_that_is_damaged_gives_the_defaults(self):
        self.assertEqual(self.js("m.parseDock(null)"), {"vh": 24, "folded": False})
        self.assertEqual(self.js("m.parseDock('{{')"), {"vh": 24, "folded": False})
        self.assertEqual(self.js("m.parseDock('{\"vh\":40,\"folded\":true}')"), {"vh": 40, "folded": True})

    def test_the_mode_is_run_only_when_saved_as_run(self):
        self.assertEqual(self.js("[m.parseRunMode('run'), m.parseRunMode('x'), m.parseRunMode(null)]"), ["run", "plan", "plan"])


class StructureTests(unittest.TestCase):
    def test_the_controls_sit_in_a_toolbar_across_the_top_of_the_service_tab(self):
        run = HTML[HTML.index('id="view-run"'):]
        bar = run[run.index('id="run-toolbar"'):run.index('data-panel="service"')]
        for ident in ("btn-previous", "btn-next", "btn-blank", "btn-words", "btn-lower", "btn-clear", "live-title", "position"):
            self.assertIn(f'id="{ident}"', bar)
        self.assertIn("grid-column: 1 / -1", CSS[CSS.index(".run-toolbar {"):][:60])

    def test_the_header_has_countdown_and_alert_chips(self):
        top = HTML[:HTML.index("</header>")]
        self.assertIn('id="chip-countdown"', top)
        self.assertIn('id="chip-alert"', top)

    def test_the_toggle_and_dock_controls_exist(self):
        for ident in ("mode-plan", "mode-run", "rb-resize", "rb-collapse"):
            self.assertIn(f'id="{ident}"', HTML)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.c.new_service("S")
        self.song = self.c.create_song("Long Song", "", "[V1]\none\n\n[C]\ntwo\n\n[V2]\nthree\n\n[B]\nfour")
        self.c.add_entry(LibraryEntry("song", self.song, ""))
        self.c.set_service_verse_split("verse")
        self.c.add_verse("jn 3:1-4")
        server = self.c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1400, "height": 900})
        self.page.goto(server.url.rstrip("/") + "/operator")
        self.page.wait_for_selector("#items li", state="attached")

    def test_the_go_button_is_first_on_every_item_row_and_still_goes_live(self):
        rows = self.page.locator("#items li.item-row")
        self.assertEqual(rows.count(), 2)                               # a song and a Bible item
        for n in range(2):
            first = rows.nth(n).locator(".item-main > *").first
            self.assertEqual(first.inner_text(), "Go")
            self.assertEqual(rows.nth(n).locator(".item-actions button", has_text="Go").count(), 0)   # no second Go on the right
        rows.nth(1).locator(".item-main > button.item-go").click()
        self.assertTrue(until(lambda: self.c.service_rows()[1].is_live))

    def test_run_mode_hides_the_library_and_plan_mode_brings_it_back(self):
        page = self.page
        self.assertTrue(page.is_visible("#library-box"))
        page.click("#mode-run")
        self.assertFalse(page.is_visible("#library-box"))
        self.assertTrue(page.is_visible("#items"))
        page.click("#mode-plan")
        self.assertTrue(page.is_visible("#library-box"))

    def test_the_mode_is_remembered_after_a_reload(self):
        self.page.click("#mode-run")
        self.page.reload()
        self.page.wait_for_selector("#items li", state="attached")
        self.assertFalse(self.page.is_visible("#library-box"))

    def test_the_slash_key_goes_back_to_plan_and_searches(self):
        self.page.click("#mode-run")
        self.page.keyboard.press("/")
        self.assertTrue(self.page.is_visible("#library-box"))
        self.assertTrue(until(lambda: self.page.evaluate("document.activeElement.id") == "search"))

    def test_the_toolbar_spans_both_columns_and_names_what_is_live(self):
        page = self.page
        bar = page.locator("#run-toolbar").bounding_box()
        service = page.locator(".col.service").bounding_box()
        live = page.locator(".col.live").bounding_box()
        self.assertLess(bar["y"] + bar["height"], min(service["y"], live["y"]) + 2)
        self.assertGreater(bar["width"], service["width"] + live["width"] - 10)
        self.assertEqual(page.inner_text("#live-title"), "")
        self.api.call("go_item", {"item_id": self.c.service_rows()[0].item_id})
        self.assertTrue(until(lambda: page.inner_text("#live-title") == "Long Song"))

    def test_the_chips_show_a_countdown_and_an_alert(self):
        page = self.page
        self.assertFalse(page.is_visible("#chip-countdown"))
        self.assertFalse(page.is_visible("#chip-alert"))
        self.api.call("countdown_start", {"minutes": 5})
        self.api.call("alert_set", {"text": "Wrap up"})
        self.assertTrue(until(lambda: page.is_visible("#chip-countdown") and page.is_visible("#chip-alert")))
        self.assertIn("Countdown", page.inner_text("#chip-countdown"))
        self.assertIn("Wrap up", page.inner_text("#chip-alert"))

    def test_the_blank_words_and_lower_third_buttons_change_color_when_on_and_there_are_no_banners(self):
        page = self.page
        for gone in ("blank-banner", "words-banner", "lower-banner"):
            self.assertNotIn(f'id="{gone}"', HTML)
        for button in ("btn-blank", "btn-words", "btn-lower"):
            self.assertEqual(page.get_attribute("#" + button, "aria-pressed"), "false")
        for action, button in (("blank", "btn-blank"), ("text_hide", "btn-words"), ("lower_hide", "btn-lower")):
            self.api.call(action)
            self.assertTrue(until(lambda: page.get_attribute("#" + button, "aria-pressed") == "true"))
            self.assertIn("toggle-on", page.get_attribute("#" + button, "class"))
        colors = {b: page.evaluate(f"getComputedStyle(document.getElementById('{b}')).backgroundColor")
                  for b in ("btn-blank", "btn-words", "btn-lower", "btn-clear")}
        self.assertEqual(len({colors["btn-blank"], colors["btn-words"], colors["btn-lower"]}), 1)      # the same "on" color
        self.assertNotEqual(colors["btn-blank"], colors["btn-clear"])                                  # unlike an ordinary button
        for action, button in (("blank", "btn-blank"), ("text_hide", "btn-words"), ("lower_hide", "btn-lower")):
            self.api.call(action)
            self.assertTrue(until(lambda: page.get_attribute("#" + button, "aria-pressed") == "false"))

    def test_the_page_itself_has_no_scroll_bar_at_common_window_sizes(self):
        page = self.page
        for width, height in ((1400, 900), (1280, 720), (1100, 1392), (1920, 1080)):
            page.set_viewport_size({"width": width, "height": height})
            self.assertTrue(until(lambda: page.evaluate("document.documentElement.scrollHeight <= window.innerHeight + 1")),
                            f"the page scrolls at {width}x{height}")
        page.set_viewport_size({"width": 1400, "height": 900})
        page.evaluate("showMessage('A message appears above the board')")          # the board makes room for it
        self.assertTrue(until(lambda: page.evaluate("document.documentElement.scrollHeight <= window.innerHeight + 1")))

    def test_folding_the_panel_shrinks_it_and_open_brings_it_back(self):
        page = self.page
        full = page.evaluate("document.getElementById('run-bottom').getBoundingClientRect().height")
        page.click("#rb-collapse")
        folded = page.evaluate("document.getElementById('run-bottom').getBoundingClientRect().height")
        self.assertLess(folded, full / 2)
        self.assertFalse(page.is_visible("#rb-bible"))
        page.click("#rb-collapse")
        self.assertTrue(page.is_visible("#rb-bible"))

    def test_the_panel_arrow_keys_resize_it_and_it_is_remembered(self):
        page = self.page
        start = page.evaluate("document.getElementById('run-bottom').getBoundingClientRect().height")
        page.focus("#rb-resize")
        for _ in range(3):
            page.keyboard.press("ArrowUp")
        grown = page.evaluate("document.getElementById('run-bottom').getBoundingClientRect().height")
        self.assertGreater(grown, start + 30)
        page.reload()
        page.wait_for_selector("#items li", state="attached")
        again = page.evaluate("document.getElementById('run-bottom').getBoundingClientRect().height")
        self.assertAlmostEqual(again, grown, delta=2)

    def test_dragging_the_edge_resizes_the_panel(self):
        page = self.page
        box = page.locator("#rb-resize").bounding_box()
        page.mouse.move(box["x"] + 50, box["y"] + 3)
        page.mouse.down()
        page.mouse.move(box["x"] + 50, box["y"] - 150, steps=5)
        page.mouse.up()
        grown = page.evaluate("document.getElementById('run-bottom').getBoundingClientRect().height")
        self.assertGreater(grown, 330)

    def test_the_g_key_opens_a_folded_panel_and_the_verse_box(self):
        page = self.page
        page.click("#rb-collapse")
        page.keyboard.press("t")
        self.assertTrue(page.is_visible("#rb-bible"))
        self.assertTrue(until(lambda: page.evaluate("document.activeElement.id") == "tray-text"))

    def test_jumping_to_a_song_part_still_works_in_run_mode_with_the_panel_folded(self):
        page = self.page
        page.click("#mode-run")
        page.click("#rb-collapse")
        self.assertTrue(page.is_visible("#items"))
        page.click("#items li:first-child button.more")
        buttons = page.query_selector_all("#items li:first-child .outline-slides .slide-bar")
        self.assertEqual(len(buttons), 4)
        buttons[2].click()                                         # the third slide of the song
        page.wait_for_selector("#items li:first-child .outline-slides li.slide-live", state="attached")
        slides = page.query_selector_all("#items li:first-child .outline-slides li")
        self.assertEqual([("slide-live" in (li.get_attribute("class") or "")) for li in slides], [False, False, True, False])

    def test_jumping_to_a_bible_verse_still_works_in_run_mode(self):
        page = self.page
        page.click("#mode-run")
        page.click("#items li:nth-child(2) button.more")
        buttons = page.query_selector_all("#items li:nth-child(2) .item-slide-list .slide-bar")
        self.assertGreater(len(buttons), 1)
        buttons[1].click()
        self.assertTrue(until(lambda: self.c.session.state().base_index == self.c.service_rows()[1].slide_numbers[1]))


if __name__ == "__main__":
    unittest.main()
