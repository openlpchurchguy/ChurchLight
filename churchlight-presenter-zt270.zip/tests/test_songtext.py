# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.songtext import (
    SongTextError, format_song_text, parse_song_text, section_type_for)

SAMPLE = """[Verse 1]
line a1
line a2

[Chorus]
line c1

[Verse 2]
line b1

Order: Verse 1, Chorus, Verse 2, Chorus"""


class ParseTests(unittest.TestCase):
    def test_headings_lyrics_types_and_order(self):
        parsed = parse_song_text(SAMPLE)
        self.assertEqual(parsed.sections, [("Verse 1", "verse", "line a1\nline a2"),
                                           ("Chorus", "chorus", "line c1"),
                                           ("Verse 2", "verse", "line b1")])
        self.assertEqual(parsed.order, ["Verse 1", "Chorus", "Verse 2", "Chorus"])

    def test_without_an_order_line_each_part_is_sung_once(self):
        self.assertEqual(parse_song_text("[A]\nx\n[B]\ny").order, ["A", "B"])

    def test_lyrics_with_no_headings_become_numbered_verses(self):
        parsed = parse_song_text("one\ntwo\n\nthree\n\n\nfour\nfive\n")
        self.assertEqual([(l, t, w) for l, t, w in parsed.sections],
                         [("Verse 1", "verse", "one\ntwo"), ("Verse 2", "verse", "three"),
                          ("Verse 3", "verse", "four\nfive")])

    def test_windows_line_endings_and_trailing_spaces(self):
        parsed = parse_song_text("[Verse 1]\r\nhello   \r\nworld\r\n\r\n[Chorus]\r\nla\r\n")
        self.assertEqual(parsed.sections[0][2], "hello\nworld")

    def test_order_names_match_ignoring_case_and_spaces(self):
        parsed = parse_song_text("[Verse 1]\nx\n[Chorus]\ny\norder:  chorus ,verse 1")
        self.assertEqual(parsed.order, ["Chorus", "Verse 1"])

    def test_section_types_from_names(self):
        for label, kind in (("Verse 3", "verse"), ("CHORUS", "chorus"), ("Pre-Chorus", "pre_chorus"),
                            ("Bridge 2", "bridge"), ("Ending", "outro"), ("Tag", "tag"),
                            ("Intro", "intro"), ("Whatever", "other"), ("V1", "verse"), ("C2", "chorus")):
            self.assertEqual(section_type_for(label), kind, label)

    def test_every_mistake_has_a_plain_sentence(self):
        cases = {
            "": "no words",
            "   \n\n": "no words",
            "words\n[Verse 1]\nx": "heading",
            "[A]\nx\n[a]\ny": "both called",
            "[A]\nx\n[B]\n": "no words",
            "[A]\nx\nOrder: A, Z": "[Z]",
            "[A]\nx\nOrder: A\nOrder: A": "more than one",
            "just words\nOrder: A": "needs headings",
            "x" * 70000: "too long",
        }
        for text, fragment in cases.items():
            with self.assertRaises(SongTextError, msg=text[:20]) as caught:
                parse_song_text(text)
            self.assertIn(fragment, str(caught.exception))
        with self.assertRaises(SongTextError):
            parse_song_text(None)
        with self.assertRaises(SongTextError):
            parse_song_text("\n".join(f"[P{i}]\nw" for i in range(81)))

    def test_a_line_that_looks_like_order_inside_lyrics_is_still_an_order_line(self):
        # documented: a line starting with "Order:" is always the order line
        with self.assertRaises(SongTextError):
            parse_song_text("[A]\nx\nOrder: nonsense")

    def test_brackets_inside_a_line_are_just_words(self):
        parsed = parse_song_text("[A]\nsing [softly] now")
        self.assertEqual(parsed.sections[0][2], "sing [softly] now")


class FormatTests(unittest.TestCase):
    def test_round_trip(self):
        parsed = parse_song_text(SAMPLE)
        text = format_song_text([(l, w) for l, _, w in parsed.sections], parsed.order)
        self.assertEqual(text, SAMPLE)
        again = parse_song_text(text)
        self.assertEqual((again.sections, again.order), (parsed.sections, parsed.order))

    def test_no_order_line_when_the_order_is_just_the_sections(self):
        self.assertNotIn("Order:", format_song_text([("A", "x"), ("B", "y")], ["A", "B"]))


class ReplaceSongTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.id = self.db.create_song_with_sections(
            "Old", [("Verse 1", "verse", "old words"), ("Chorus", "chorus", "old chorus")],
            order=["Verse 1", "Chorus", "Verse 1"], author="Ann")

    def test_replacing_changes_everything_and_search_follows(self):
        self.db.replace_song(self.id, "New Title", [("Verse 1", "verse", "fresh zebra words")],
                             order=["Verse 1"], author="Bo")
        song = self.db.get_song(self.id)
        self.assertEqual((song["title"], song["author"]), ("New Title", "Bo"))
        self.assertEqual([s["label"] for s in self.db.get_sections(self.id)], ["Verse 1"])
        arrangement = self.db.get_default_arrangement(self.id)
        self.assertEqual([r["lyrics"] for r in self.db.get_arrangement_sections(arrangement["id"])],
                         ["fresh zebra words"])
        self.assertEqual([r["id"] for r in self.db.search_songs("zebra")], [self.id])
        self.assertEqual(self.db.search_songs("old"), [])
        self.assertEqual(self.db.search_songs("Old"), [])

    def test_author_is_kept_when_not_given(self):
        self.db.replace_song(self.id, "T", [("A", "verse", "x")])
        self.assertEqual(self.db.get_song(self.id)["author"], "Ann")

    def test_a_bad_order_changes_nothing(self):
        with self.assertRaises(ValueError):
            self.db.replace_song(self.id, "T", [("A", "verse", "x")], order=["B"])
        self.assertEqual(self.db.get_song(self.id)["title"], "Old")
        self.assertEqual(len(self.db.get_sections(self.id)), 2)

    def test_unknown_song_and_empty_song(self):
        with self.assertRaises(ValueError):
            self.db.replace_song(999, "T", [("A", "verse", "x")])
        with self.assertRaises(ValueError):
            self.db.replace_song(self.id, "T", [])

    def test_service_items_survive_an_edit(self):
        service = self.db.create_service("S", "2026-10-25")
        item = self.db.add_service_item(service, "song", song_id=self.id)
        self.db.replace_song(self.id, "T", [("A", "verse", "x")])
        self.assertEqual(self.db.get_service_item(item)["song_id"], self.id)

    def test_summaries_count_service_uses(self):
        service = self.db.create_service("S", "2026-10-25")
        self.db.add_service_item(service, "song", song_id=self.id)
        self.db.add_service_item(service, "song", song_id=self.id)
        pid = self.db.add_presentation("Deck", [("a.png", None)])
        self.assertEqual([(r["title"], r["uses"]) for r in self.db.song_summaries()], [("Old", 1)])
        self.assertEqual([(r["name"], r["page_count"], r["uses"]) for r in self.db.presentation_summaries()],
                         [("Deck", 1, 0)])
        self.db.rename_presentation(pid, "Renamed")
        self.assertEqual(self.db.get_presentation(pid)["name"], "Renamed")
        t = self.db.add_translation("DEMO", "Demo")
        self.db.add_verses(t, [("John", 3, 16, "x")])
        rows = self.db.translation_summaries()
        self.assertEqual((rows[0]["abbreviation"], rows[0]["verse_count"], rows[0]["uses"]), ("DEMO", 1, 0))
        self.assertTrue(self.db.delete_translation(t))
        self.assertEqual(self.db.translation_summaries(), [])


if __name__ == "__main__":
    unittest.main()
