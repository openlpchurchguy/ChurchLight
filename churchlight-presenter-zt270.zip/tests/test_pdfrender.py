# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import os
import shutil
import struct
import sys
import tempfile
import types
import unittest
import zlib
from pathlib import Path
from unittest import mock

from churchlight_presenter.importers import pdfrender
from churchlight_presenter.importers.common import ImporterError, encode_png
from churchlight_presenter.importers.decks import DeckImportError, import_deck
from churchlight_presenter.core.database import DatabaseManager
from tests.test_decks import make_pdf


def decode_png(data):
    """(width, height, rows of RGB bytes) from a PNG made by encode_png."""
    assert data[:8] == b"\x89PNG\r\n\x1a\n"
    width, height = struct.unpack(">II", data[16:24])
    raw = zlib.decompress(data[data.index(b"IDAT") + 4:data.index(b"IEND") - 8])
    step = 1 + width * 3
    return width, height, [raw[y * step + 1:(y + 1) * step] for y in range(height)]


class FakeBitmap:
    def __init__(self, width, height, channels, rgb, stride_pad=0):
        self.width, self.height, self.n_channels, self.rev_byteorder = width, height, channels, rgb
        self.stride = width * channels + stride_pad
        row = bytes(range(10, 10 + width * channels)) + b"\xee" * stride_pad
        self.buffer = row * height
        self.closed = False

    def close(self):
        self.closed = True


class FakePage:
    def __init__(self, bitmap, size=(200, 120)):
        self.bitmap, self.size, self.scales, self.closed = bitmap, size, [], False

    def get_size(self):
        return self.size

    def render(self, scale=1, **kwargs):
        self.scales.append(scale)
        return self.bitmap

    def close(self):
        self.closed = True


def fake_module(pages, error=None):
    module = types.ModuleType("pypdfium2")

    class PdfDocument:
        def __init__(self, path):
            if error:
                raise error
            self.pages, self.closed = pages, False
            module.last = self

        def __len__(self):
            return len(self.pages)

        def __getitem__(self, i):
            return self.pages[i]

        def close(self):
            self.closed = True

    module.PdfDocument = PdfDocument
    return module


class PngTests(unittest.TestCase):
    def test_encode_round_trips(self):
        rows = [bytes([1, 2, 3, 4, 5, 6]), bytes([7, 8, 9, 10, 11, 12])]
        self.assertEqual(decode_png(encode_png(2, 2, rows)), (2, 2, rows))

    def test_wrong_row_size_is_refused(self):
        with self.assertRaises(ValueError):
            encode_png(2, 1, [b"123"])

    def test_bitmap_rows_ignore_stride_padding(self):
        data = (b"\x01\x02\x03\x04\x05\x06" + b"\xff\xff") * 2
        self.assertEqual(pdfrender.bitmap_rows(data, 2, 2, 8, 3, True), [b"\x01\x02\x03\x04\x05\x06"] * 2)

    def test_bgr_is_swapped_to_rgb(self):
        self.assertEqual(pdfrender.bitmap_rows(b"\x01\x02\x03", 1, 1, 3, 3, False), [b"\x03\x02\x01"])

    def test_four_channels_drop_the_extra_byte(self):
        self.assertEqual(pdfrender.bitmap_rows(b"\x01\x02\x03\xff", 1, 1, 4, 4, True), [b"\x01\x02\x03"])
        self.assertEqual(pdfrender.bitmap_rows(b"\x01\x02\x03\xff", 1, 1, 4, 4, False), [b"\x03\x02\x01"])

    def test_gray_becomes_rgb(self):
        self.assertEqual(pdfrender.bitmap_rows(b"\x07", 1, 1, 1, 1, True), [b"\x07\x07\x07"])

    def test_short_or_odd_data_is_an_import_error(self):
        with self.assertRaises(ImporterError):
            pdfrender.bitmap_rows(b"\x01", 2, 2, 6, 3, True)
        with self.assertRaises(ImporterError):
            pdfrender.bitmap_rows(b"\x01" * 8, 2, 1, 8, 2, True)


class PdfiumRenderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def render(self, module, dpi=144):
        with mock.patch.dict(sys.modules, {"pypdfium2": module}):
            return pdfrender.render_pdf_with_pdfium(self.tmp / "x.pdf", self.tmp / "out", dpi)

    def test_pages_become_numbered_pngs_with_the_right_pixels(self):
        pages = [FakePage(FakeBitmap(3, 2, 3, True, stride_pad=2)), FakePage(FakeBitmap(3, 2, 4, True))]
        module = fake_module(pages)
        files = self.render(module)
        self.assertEqual([f.name for f in files], ["page-001.png", "page-002.png"])
        width, height, rows = decode_png(files[0].read_bytes())
        self.assertEqual((width, height), (3, 2))
        self.assertEqual(rows[0], bytes(range(10, 19)))
        self.assertEqual(decode_png(files[1].read_bytes())[2][0], bytes([10, 11, 12, 14, 15, 16, 18, 19, 20]))

    def test_dpi_sets_the_scale_and_everything_is_closed(self):
        page = FakePage(FakeBitmap(1, 1, 3, True))
        module = fake_module([page])
        self.render(module, dpi=144)
        self.assertEqual(page.scales, [2.0])
        self.assertTrue(page.closed and page.bitmap.closed and module.last.closed)

    def test_huge_pages_are_scaled_down(self):
        page = FakePage(FakeBitmap(1, 1, 3, True), size=(7200, 3600))
        self.render(fake_module([page]), dpi=300)
        self.assertAlmostEqual(7200 * page.scales[0], pdfrender.MAX_LONG_SIDE, delta=1)

    def test_an_older_library_without_rev_byteorder_is_read_as_bgr(self):
        class OldPage(FakePage):
            def render(self, scale=1, **kwargs):
                if kwargs:
                    raise TypeError("unexpected keyword")
                return self.bitmap
        bitmap = FakeBitmap(1, 1, 3, False)
        del bitmap.rev_byteorder
        bitmap.buffer = b"\x01\x02\x03"
        files = self.render(fake_module([OldPage(bitmap)]))
        self.assertEqual(decode_png(files[0].read_bytes())[2], [b"\x03\x02\x01"])

    def test_unreadable_pdf_and_empty_pdf_give_plain_errors(self):
        with self.assertRaisesRegex(ImporterError, "could not be read"):
            self.render(fake_module([], error=RuntimeError("Failed to load document")))
        with self.assertRaisesRegex(ImporterError, "no pages"):
            self.render(fake_module([]))

    def test_a_failure_while_drawing_is_an_import_error_and_closes_the_document(self):
        class Broken(FakePage):
            def render(self, scale=1, **kwargs):
                raise RuntimeError("boom")
        module = fake_module([Broken(None)])
        with self.assertRaisesRegex(ImporterError, "could not be drawn"):
            self.render(module)
        self.assertTrue(module.last.closed)

    def test_missing_library_says_how_to_install_it(self):
        with mock.patch.dict(sys.modules, {"pypdfium2": None}):
            with self.assertRaisesRegex(ImporterError, "pip install pypdfium2"):
                pdfrender.render_pdf_with_pdfium(self.tmp / "x.pdf", self.tmp / "o")


class ChoosingTests(unittest.TestCase):
    def test_prefers_pdfium_then_poppler_then_explains(self):
        poppler = object()
        with mock.patch.object(pdfrender, "pdfium_available", return_value=True):
            self.assertIs(pdfrender.default_renderer(poppler), pdfrender.render_pdf_with_pdfium)
            self.assertEqual(pdfrender.renderer_name(), "pypdfium2")
        with mock.patch.object(pdfrender, "pdfium_available", return_value=False):
            with mock.patch("shutil.which", return_value="/usr/bin/pdftoppm"):
                self.assertIs(pdfrender.default_renderer(poppler), poppler)
                self.assertEqual(pdfrender.renderer_name(), "poppler")
            with mock.patch("shutil.which", return_value=None):
                with self.assertRaisesRegex(ImporterError, "pip install pypdfium2"):
                    pdfrender.default_renderer(poppler)
                self.assertIsNone(pdfrender.renderer_name())

    def test_import_deck_reports_a_missing_renderer_as_a_deck_error(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        make_pdf(tmp / "d.pdf", 1)
        with mock.patch.object(pdfrender, "pdfium_available", return_value=False), \
                mock.patch("shutil.which", return_value=None), DatabaseManager(":memory:") as db:
            with self.assertRaises(DeckImportError):
                import_deck(db, tmp / "d.pdf", tmp / "m")

    def test_import_deck_uses_the_default_renderer(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        make_pdf(tmp / "d.pdf", 2)
        seen = []

        def renderer(pdf, out_dir, dpi):
            seen.append(dpi)
            out_dir.mkdir(parents=True)
            for n in (1, 2):
                (out_dir / f"page-{n:03d}.png").write_bytes(encode_png(1, 1, [b"\0\0\0"]))
            return sorted(out_dir.glob("*.png"))
        with mock.patch.object(pdfrender, "default_renderer", return_value=renderer), \
                DatabaseManager(":memory:") as db:
            result = import_deck(db, tmp / "d.pdf", tmp / "m")
        self.assertEqual((result.page_count, seen), (2, [150]))


@unittest.skipUnless(pdfrender.pdfium_available(), "pypdfium2 is not installed")
class RealPdfiumTests(unittest.TestCase):
    def test_a_real_pdf_renders_to_real_pngs(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        make_pdf(tmp / "t.pdf", 3)
        files = pdfrender.render_pdf_with_pdfium(tmp / "t.pdf", tmp / "o", dpi=144)
        self.assertEqual(len(files), 3)
        width, height, rows = decode_png(files[0].read_bytes())
        self.assertEqual((width, height), (400, 240))          # 200 x 120 points at 2x
        self.assertEqual(rows[0][:3], b"\xff\xff\xff")          # blank pages are white

    def test_garbage_is_a_plain_error(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        (tmp / "bad.pdf").write_bytes(b"not a pdf")
        with self.assertRaises(ImporterError):
            pdfrender.render_pdf_with_pdfium(tmp / "bad.pdf", tmp / "o")


if __name__ == "__main__":
    unittest.main()
