# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Replace slides from a new PDF: page N replaces slide N, only the picture changes."""
import json
import shutil
import subprocess
import time
import unittest
from pathlib import Path

from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.imports import ImportJob
from tests.test_deck_editor_b import Base
from tests.test_decks import make_pdf

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


def png(tag):
    """A different picture per tag (same header, different bytes, so the pictures differ on disk)."""
    from tests.test_deck_editor_b import PNG
    return PNG + tag.encode()


class ReplaceBase(Base):
    def make_source(self, name, tags, folder="decks/new"):
        paths = []
        for n, tag in enumerate(tags, start=1):
            rel = f"{folder}/page-{n:03d}.png"
            (self.media / rel).parent.mkdir(parents=True, exist_ok=True)
            (self.media / rel).write_bytes(png(tag))
            paths.append(rel)
        return self.db.add_presentation(name, [(p, None) for p in paths]), paths

    def finished_job(self, source, deck=None):
        self._job_ids = getattr(self, "_job_ids", 900) + 1
        job = ImportJob(self._job_ids, "deck", "New pages", status="done", replace_for=deck or self.deck, deck_id=source)
        self.c.imports._jobs.append(job)
        return job.id

    def setUp(self):
        import tempfile
        from churchlight_presenter.core.database import DatabaseManager
        from churchlight_presenter.ui.controller import OperatorController
        from churchlight_presenter.ui.operator_api import OperatorApi
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.media = self.tmp / "media"
        self.db = DatabaseManager(":memory:", shared=True)       # the import runs on its own thread
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.media)
        self.c.serve(media_root=self.media)
        self.addCleanup(self.c.close)
        self.api = OperatorApi(self.c)
        self.deck, self.paths = self.make_deck("Welcome", 4, "decks/aaa")
        for n, page in enumerate(self.pages(), start=1):          # the deck's own pictures: files a, b, c, d
            rel = page["image_path"]
            (self.media / rel).write_bytes(png("abcd"[n - 1]))
        pages = self.pages()
        self.db.update_presentation_page(pages[1]["id"], notes="Remember the offering")
        self.c.set_deck_page_title(self.deck, pages[1]["id"], "Offering")
        self.c.skip_deck_pages(self.deck, [pages[2]["id"]], True)


class PlanTests(ReplaceBase):
    def test_changed_same_added_and_extra_are_counted(self):
        source, _ = self.make_source("New", ["a", "X", "c", "d", "e", "f"])
        plan = self.c.deck_replace_plan(self.deck, self.finished_job(source))
        self.assertEqual((plan["changed"], plan["same"], plan["added"], plan["extra"]), ([2], [1, 3, 4], 2, []))
        source, _ = self.make_source("Short", ["a", "X"], "decks/short")
        plan = self.c.deck_replace_plan(self.deck, self.finished_job(source))
        self.assertEqual((plan["changed"], plan["same"], plan["added"], plan["extra"]), ([2], [1], 0, [3, 4]))

    def test_planning_changes_nothing(self):
        before = self.images()
        source, _ = self.make_source("New", ["X", "Y", "Z", "W"])
        self.c.deck_replace_plan(self.deck, self.finished_job(source))
        self.assertEqual(self.images(), before)
        self.assertIsNotNone(self.db.get_presentation(source))

    def test_a_job_for_another_slideshow_or_not_done_is_refused(self):
        other, _ = self.make_deck("Other", 2, "decks/other")
        source, _ = self.make_source("New", ["a"])
        job = self.finished_job(source, deck=other)
        with self.assertRaises(ControllerError):
            self.c.deck_replace_plan(self.deck, job)
        running = ImportJob(901, "deck", "x", status="running", replace_for=self.deck)
        self.c.imports._jobs.append(running)
        with self.assertRaises(ControllerError):
            self.c.deck_replace_plan(self.deck, 901)
        with self.assertRaises(ControllerError):
            self.c.deck_replace_plan(self.deck, 12345)


class ApplyTests(ReplaceBase):
    def test_pictures_change_and_everything_else_stays(self):
        before = {p["page_number"]: p for p in self.pages()}
        source, new_paths = self.make_source("New", ["a", "X", "c", "Y"])
        self.c.replace_deck_slides(self.deck, self.finished_job(source))
        after = self.pages()
        self.assertEqual([p["image_path"] for p in after][0], before[1]["image_path"])       # identical: untouched
        self.assertEqual(after[1]["image_path"], new_paths[1])                                  # changed: the new picture
        self.assertEqual(after[3]["image_path"], new_paths[3])
        self.assertEqual(after[1]["title"], "Offering")                                         # title, notes, skip stay
        self.assertEqual(after[1]["notes"], "Remember the offering")
        self.assertTrue(after[2]["skipped"])
        self.assertEqual([p["page_number"] for p in after], [1, 2, 3, 4])

    def test_kept_slides_are_left_alone_and_the_identical_choice_is_separate(self):
        before = self.images()
        source, new_paths = self.make_source("New", ["a", "X", "c", "Y"])           # slides 2 and 4 differ; 1 and 3 are identical
        plan = self.c.replace_deck_slides(self.deck, self.finished_job(source), keep=[2])
        self.assertEqual(plan["replaced"], [4])
        after = self.images()
        self.assertEqual((after[0], after[1], after[2]), (before[0], before[1], before[2]))
        self.assertEqual(after[3], new_paths[3])
        self.assertFalse((self.media / new_paths[1]).is_file())                     # the kept slide's new copy is not left behind
        source, new_paths = self.make_source("New2", ["a", "Z", "c", "d"], "decks/new2")
        plan = self.c.replace_deck_slides(self.deck, self.finished_job(source), replace_same=True, keep=[2])
        self.assertEqual(plan["replaced"], [1, 3, 4])                              # identical ones too, except the kept slide
        self.assertEqual(self.images()[0], new_paths[0])
        self.assertEqual(self.images()[1], before[1])

    def test_keeping_every_slide_changes_nothing(self):
        before = self.images()
        source, _ = self.make_source("New", ["X", "Y", "Z", "W"])
        plan = self.c.replace_deck_slides(self.deck, self.finished_job(source), keep=[1, 2, 3, 4])
        self.assertEqual(plan["replaced"], [])
        self.assertEqual(self.images(), before)
        self.assertIsNone(self.db.get_presentation(source))

    def test_the_choices_must_be_numbers(self):
        source, _ = self.make_source("New", ["X"])
        with self.assertRaises(ControllerError):
            self.c.replace_deck_slides(self.deck, self.finished_job(source), keep=["1"])

    def test_the_plan_lists_each_slide_with_both_pictures(self):
        source, new_paths = self.make_source("New", ["a", "X"])
        plan = self.c.deck_replace_plan(self.deck, self.finished_job(source))
        self.assertEqual([(s["number"], s["same"]) for s in plan["slides"]], [(1, True), (2, False)])
        self.assertEqual(plan["slides"][1]["new"], new_paths[1])
        self.assertEqual(plan["slides"][1]["title"], "Offering")

    def test_the_temporary_slideshow_goes_and_so_do_unused_files(self):
        source, new_paths = self.make_source("New", ["a", "X", "c", "d"])
        old_second = self.images()[1]
        self.c.replace_deck_slides(self.deck, self.finished_job(source))
        self.assertIsNone(self.db.get_presentation(source))
        self.assertTrue((self.media / new_paths[1]).is_file())                                  # in use by the slideshow now
        self.assertFalse((self.media / new_paths[0]).is_file())                                 # identical page: its copy is not needed
        self.assertFalse((self.media / old_second).is_file())                                   # the replaced picture is gone

    def test_new_pages_are_added_at_the_end(self):
        source, new_paths = self.make_source("New", ["a", "b", "c", "d", "e", "f"])
        plan = self.c.replace_deck_slides(self.deck, self.finished_job(source))
        self.assertEqual(plan["added"], 2)
        self.assertEqual(self.images()[-2:], new_paths[4:])
        self.assertEqual(len(self.pages()), 6)

    def test_slides_the_new_pdf_lacks_are_kept_but_skipped_unless_removal_is_asked(self):
        source, _ = self.make_source("Short", ["a", "X"])
        self.c.replace_deck_slides(self.deck, self.finished_job(source))
        self.assertEqual(len(self.pages()), 4)
        self.assertEqual([bool(p["skipped"]) for p in self.pages()], [False, False, True, True])
        source, _ = self.make_source("Short", ["a", "X"], "decks/short2")
        self.c.replace_deck_slides(self.deck, self.finished_job(source), remove_extra=True)
        self.assertEqual(len(self.pages()), 2)
        self.assertEqual([p["page_number"] for p in self.pages()], [1, 2])

    def test_a_live_slideshow_is_not_changed(self):
        self.go_live()
        source, _ = self.make_source("New", ["X", "Y", "Z", "W"])
        with self.assertRaisesRegex(ControllerError, "live"):
            self.c.replace_deck_slides(self.deck, self.finished_job(source))
        self.assertIsNotNone(self.db.get_presentation(source))

    def test_cancel_throws_the_new_pages_away(self):
        before = self.images()
        source, new_paths = self.make_source("New", ["X", "Y", "Z", "W"])
        self.c.cancel_deck_replacement(self.deck, self.finished_job(source))
        self.assertIsNone(self.db.get_presentation(source))
        self.assertEqual(self.images(), before)
        self.assertFalse(any((self.media / p).is_file() for p in new_paths))

    def test_a_service_that_uses_the_slideshow_follows(self):
        self.c.new_service("Sunday")
        entry = next(e for e in self.c.search_library("Welcome") if e.kind == "presentation")
        self.c.add_entry(entry)
        source, new_paths = self.make_source("New", ["a", "X", "c", "d"])
        self.c.replace_deck_slides(self.deck, self.finished_job(source))
        self.assertEqual(self.c.session.slides[1].image_path, new_paths[1])


class EndToEndTests(ReplaceBase):
    def wait(self, job_id):
        end = time.time() + 60
        while time.time() < end:
            job = next(j for j in self.c.imports.jobs() if j["id"] == job_id)
            if job["status"] in ("done", "failed"):
                return job
            time.sleep(0.1)
        self.fail("the import did not finish")

    def test_a_real_pdf_goes_through_the_import_and_is_applied(self):
        pdf = self.tmp / "new.pdf"
        make_pdf(pdf, 6)
        batch = self.c.imports.new_batch()
        data = pdf.read_bytes()
        import io
        self.c.imports.save_upload(batch, "new.pdf", io.BytesIO(data), len(data), "deck")
        job_id = self.c.imports.start("deck", batch, name="New pages", replace_for=self.deck)
        job = self.wait(job_id)
        self.assertEqual(job["status"], "done", job)
        self.assertEqual(job["replace_for"], self.deck)
        plan = self.c.deck_replace_plan(self.deck, job_id)
        self.assertEqual((plan["new_pages"], plan["added"]), (6, 2))
        self.assertEqual(len(plan["changed"]), 4)                  # the fixture pictures differ from the rendered pages
        self.c.replace_deck_slides(self.deck, job_id)
        self.assertEqual(len(self.pages()), 6)
        self.assertEqual(self.pages()[1]["title"], "Offering")
        self.assertIsNone(self.db.get_presentation(job["deck_id"]))
        self.assertTrue(all((self.media / p).is_file() for p in self.images()))

    def test_the_same_pdf_again_still_makes_its_own_copy(self):
        pdf = self.tmp / "same.pdf"
        make_pdf(pdf, 2)
        import io
        data = pdf.read_bytes()
        ids = []
        for _ in range(2):
            batch = self.c.imports.new_batch()
            self.c.imports.save_upload(batch, "same.pdf", io.BytesIO(data), len(data), "deck")
            job_id = self.c.imports.start("deck", batch, replace_for=self.deck)
            self.assertEqual(self.wait(job_id)["status"], "done")
            ids.append(next(j for j in self.c.imports.jobs() if j["id"] == job_id)["deck_id"])
        self.assertNotEqual(ids[0], ids[1])                        # not "already in the library"

    def test_only_a_slideshow_can_be_replaced_from_a_file(self):
        batch = self.upload(("a.png", png("a")))
        with self.assertRaises(ControllerError):
            self.c.imports.start("songs", batch, replace_for=self.deck)


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class TextTests(unittest.TestCase):
    def js(self, expr):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expr}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_ranges(self):
        self.assertEqual(self.js("m.numberRanges([1,2,3,5,7,8])"), "1–3, 5, 7–8")
        self.assertEqual(self.js("m.numberRanges([])"), "")
        self.assertEqual(self.js("m.numberRanges([4])"), "4")

    def test_the_summary_says_what_will_happen(self):
        text = self.js('m.replacePlanText({changed:[1,2],same:[3,4,5],added:2,extra:[8,9]})')
        self.assertIn("Slides 1–5 are checked: 2 changed, 3 look identical.", text)
        self.assertIn("2 new pages will be added at the end.", text)
        self.assertIn("Slides 8–9 are not in the new PDF and will be kept but skipped, unless you tick the box to remove them.", text)
        self.assertIn("all look identical", self.js('m.replacePlanText({changed:[],same:[1,2],added:0,extra:[]})'))
        self.assertEqual(self.js('m.replacePlanText({changed:[],same:[],added:0,extra:[]})'), "The new PDF has nothing to change.")


if __name__ == "__main__":
    unittest.main()
