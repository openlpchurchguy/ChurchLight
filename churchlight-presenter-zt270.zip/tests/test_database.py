# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Tests for the database layer. Run from the repo root with:

    PYTHONPATH=src python3 -m unittest discover -s tests -v
"""
import sqlite3
import unittest
from datetime import date

from churchlight_presenter.core.database import DatabaseManager, item_overrides
from churchlight_presenter.core.migrations import MIGRATIONS, migrate


def positions(db, service_id):
    return [r["position"] for r in db.get_service_items(service_id)]


def item_ids(db, service_id):
    return [r["id"] for r in db.get_service_items(service_id)]


class DbCase(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)

    def make_song(self, title="Amazing Grace"):
        return self.db.create_song_with_sections(
            title,
            [("Verse 1", "verse", "Amazing grace how sweet the sound"),
             ("Chorus", "chorus", "My chains are gone")],
            order=["Verse 1", "Chorus", "Verse 1"],
            author="Newton", ccli_number="123")


class MigrationTests(unittest.TestCase):
    def test_fresh_database_is_latest_version(self):
        with DatabaseManager(":memory:") as db:
            version = db.conn.execute("PRAGMA user_version").fetchone()[0]
            self.assertEqual(version, len(MIGRATIONS))
            self.assertEqual(
                db.conn.execute("SELECT COUNT(*) FROM bible_books").fetchone()[0], 66)
            self.assertEqual(db.conn.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_upgrade_from_v2_keeps_existing_service_items(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        migrate(conn, MIGRATIONS[:2])
        conn.execute("INSERT INTO songs (title, ccli_number) VALUES ('Old Song', '9')")
        conn.execute("INSERT INTO services (title, service_date) VALUES ('S', '2026-01-04')")
        conn.execute(
            "INSERT INTO service_items (service_id, position, item_type, song_id, overrides)"
            " VALUES (1, 0, 'song', 1, '{\"lines\": 2}')")
        conn.execute(
            "INSERT INTO service_items (service_id, position, item_type, title)"
            " VALUES (1, 1, 'announcement', 'Welcome')")
        conn.commit()

        self.assertEqual(migrate(conn), len(MIGRATIONS))

        rows = conn.execute("SELECT * FROM service_items ORDER BY position").fetchall()
        self.assertEqual([r["item_type"] for r in rows], ["song", "announcement"])
        self.assertEqual(rows[0]["overrides"], '{"lines": 2}')
        self.assertEqual(rows[1]["title"], "Welcome")
        self.assertIsNone(rows[0]["theme_id"])
        self.assertIsNone(rows[0]["presentation_id"])
        # the view was recreated and still works
        usage = conn.execute("SELECT * FROM song_usage").fetchall()
        self.assertEqual([r["ccli_number"] for r in usage], ["9"])
        # the index survived the rebuild
        self.assertIsNotNone(conn.execute(
            "SELECT 1 FROM sqlite_master WHERE name = 'idx_service_items'").fetchone())
        self.assertEqual(conn.execute("PRAGMA foreign_key_check").fetchall(), [])
        # new item type works, and its CHECK is enforced
        conn.execute("INSERT INTO presentations (name) VALUES ('Deck')")
        conn.execute(
            "INSERT INTO service_items (service_id, position, item_type, presentation_id)"
            " VALUES (1, 2, 'presentation', 1)")
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO service_items (service_id, position, item_type)"
                " VALUES (1, 3, 'presentation')")
        conn.close()

    def test_reopening_is_a_no_op(self):
        import os
        import tempfile
        path = os.path.join(tempfile.mkdtemp(), "t.db")
        DatabaseManager(path).close()
        DatabaseManager(path).close()

    def test_failed_migration_rolls_back_completely(self):
        conn = sqlite3.connect(":memory:")
        conn.execute("PRAGMA foreign_keys = ON")
        bad = MIGRATIONS[:1] + [(2, "broken", "CREATE TABLE ok(x); CREATE TABLE ok(x);")]
        with self.assertRaises(sqlite3.Error):
            migrate(conn, bad)
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], 1)
        self.assertIsNone(conn.execute(
            "SELECT 1 FROM sqlite_master WHERE name = 'ok'").fetchone())

    def test_version_gaps_and_newer_databases_are_rejected(self):
        conn = sqlite3.connect(":memory:")
        with self.assertRaises(ValueError):
            migrate(conn, [(1, "a", "SELECT 1;"), (3, "gap", "SELECT 1;")])
        newer = sqlite3.connect(":memory:")
        newer.execute(f"PRAGMA user_version = {len(MIGRATIONS) + 1}")
        with self.assertRaises(RuntimeError):
            migrate(newer)


class SongTests(DbCase):
    def test_arrangement_plays_sections_in_order_with_repeats(self):
        sid = self.make_song()
        arr = self.db.get_default_arrangement(sid)
        labels = [r["label"] for r in self.db.get_arrangement_sections(arr["id"])]
        self.assertEqual(labels, ["Verse 1", "Chorus", "Verse 1"])

    def test_full_text_search_stays_in_sync(self):
        sid = self.make_song()
        self.assertEqual(len(self.db.search_songs("sweet")), 1)
        self.assertEqual(len(self.db.search_songs("newt")), 1)  # author, prefix
        section = self.db.get_sections(sid)[0]
        self.db.update_section(section["id"], lyrics="I once was lost")
        self.assertEqual(self.db.search_songs("sweet"), [])
        self.assertEqual(len(self.db.search_songs("lost")), 1)
        self.assertEqual(self.db.search_songs('"'), [])  # hostile input is safe
        self.db.delete_song(sid)
        self.assertEqual(self.db.search_songs("lost"), [])

    def test_new_default_arrangement_replaces_old(self):
        sid = self.make_song()
        ids = [s["id"] for s in self.db.get_sections(sid)]
        short = self.db.create_arrangement(sid, "Short", ids[:1], is_default=True)
        self.assertEqual(self.db.get_default_arrangement(sid)["id"], short)

    def test_arrangement_rejects_sections_of_another_song(self):
        a, b = self.make_song("A"), self.make_song("B")
        foreign = [s["id"] for s in self.db.get_sections(b)]
        before = self.db.conn.execute("SELECT COUNT(*) FROM arrangements").fetchone()[0]
        with self.assertRaises(ValueError):
            self.db.create_arrangement(a, "Bad", foreign)
        after = self.db.conn.execute("SELECT COUNT(*) FROM arrangements").fetchone()[0]
        self.assertEqual(before, after)

    def test_failed_create_song_with_sections_leaves_nothing_behind(self):
        with self.assertRaises(ValueError):
            self.db.create_song_with_sections(
                "X", [("V1", "verse", "a")], order=["Nope"])
        self.assertEqual(self.db.conn.execute("SELECT COUNT(*) FROM songs").fetchone()[0], 0)

    def test_partial_update_and_clearing_a_field(self):
        sid = self.db.insert_song("T", author="A", notes="n")
        self.db.update_song(sid, notes=None)
        row = self.db.get_song(sid)
        self.assertEqual((row["author"], row["notes"]), ("A", None))
        self.assertFalse(self.db.update_song(sid))  # nothing to change
        self.assertFalse(self.db.update_song(9999, title="x"))

    def test_like_search_treats_wildcards_literally(self):
        self.db.insert_song("100% Pure")
        self.assertEqual(len(self.db.search_song(title="100%")), 1)
        self.assertEqual(len(self.db.search_song(title="_")), 0)


class ScriptureTests(DbCase):
    def setUp(self):
        super().setUp()
        self.kjv = self.db.add_translation("KJV", "King James Version")
        self.db.add_verses(self.kjv, [
            ("John", 3, 16, "For God so loved the world"),
            ("John", 3, 17, "For God sent not his Son"),
        ])

    def test_passage_lookup_and_search(self):
        passage = self.db.get_passage("KJV", "John", 3, 16, 17)
        self.assertEqual([r["verse"] for r in passage], [16, 17])
        self.assertEqual(len(self.db.search_scripture("so loved", "KJV")), 1)

    def test_unknown_book_is_an_error(self):
        with self.assertRaises(ValueError):
            self.db.get_passage("KJV", "Hezekiah", 1, 1)


class ThemeTests(DbCase):
    def test_settings_round_trip_as_a_dict(self):
        tid = self.db.add_theme("Worship", {"font": "Arial", "size": 54})
        self.assertEqual(self.db.get_theme_settings(tid), {"font": "Arial", "size": 54})
        self.db.update_theme(tid, settings={"font": "Georgia"})
        self.assertEqual(self.db.get_theme_settings(tid), {"font": "Georgia"})
        self.assertIsNone(self.db.get_theme_settings(9999))

    def test_theme_names_are_unique(self):
        self.db.add_theme("A")
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.add_theme("A")

    def test_deleting_a_theme_unsets_it_on_items_and_services(self):
        tid = self.db.add_theme("Sermon")
        sid = self.db.create_service("Sunday", "2026-10-18", theme_id=tid)
        item = self.db.add_service_item(sid, "blank", theme_id=tid)
        self.db.delete_theme(tid)
        self.assertIsNone(self.db.get_service(sid)["theme_id"])
        self.assertIsNone(self.db.get_service_item(item)["theme_id"])


class PresentationTests(DbCase):
    def test_pages_are_numbered_and_notes_kept(self):
        pid = self.db.add_presentation(
            "Easter Sermon",
            [("p/1.png", "Intro"), ("p/2.png", None), "p/3.png"],
            source_type="pdf", file_hash="abc")
        self.assertEqual(self.db.get_presentation(pid)["page_count"], 3)
        pages = self.db.get_presentation_pages(pid)
        self.assertEqual([p["page_number"] for p in pages], [1, 2, 3])
        self.assertEqual(pages[0]["notes"], "Intro")
        self.assertIsNone(pages[2]["notes"])
        self.assertEqual(self.db.find_presentation_by_hash("abc")["id"], pid)
        self.assertIsNone(self.db.find_presentation_by_hash("nope"))

    def test_bad_input_is_rejected_and_nothing_is_saved(self):
        with self.assertRaises(ValueError):
            self.db.add_presentation("Empty", [])
        with self.assertRaises(ValueError):
            self.db.add_presentation("Blank path", [("", None)])
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.add_presentation("Bad type", ["a.png"], source_type="keynote")
        self.assertEqual(self.db.search_presentation(), [])

    def test_search_and_note_editing(self):
        pid = self.db.add_presentation("Easter Sermon", ["a.png"])
        self.db.add_presentation("Christmas", ["b.png"])
        self.assertEqual([r["name"] for r in self.db.search_presentation("easter")],
                         ["Easter Sermon"])
        page = self.db.get_presentation_pages(pid)[0]
        self.db.update_presentation_page(page["id"], notes="John 3:16")
        self.assertEqual(self.db.get_presentation_pages(pid)[0]["notes"], "John 3:16")

    def test_cannot_delete_a_presentation_a_service_uses(self):
        pid = self.db.add_presentation("Deck", ["a.png", "b.png"])
        sid = self.db.create_service("Sunday", "2026-10-18")
        item = self.db.add_service_item(sid, "presentation", presentation_id=pid)
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.delete_presentation(pid)
        self.db.remove_service_item(item)
        self.assertTrue(self.db.delete_presentation(pid))
        self.assertEqual(self.db.conn.execute(
            "SELECT COUNT(*) FROM presentation_pages").fetchone()[0], 0)  # cascade


class ServiceTests(DbCase):
    def setUp(self):
        super().setUp()
        self.sid = self.db.create_service("Sunday", "2026-10-18")

    def add_blank(self, **kw):
        return self.db.add_service_item(self.sid, "announcement", **kw)

    # services
    def test_dates_are_validated_and_normalized(self):
        other = self.db.create_service("Wed", date(2026, 10, 21))
        self.assertEqual(self.db.get_service(other)["service_date"], "2026-10-21")
        with self.assertRaises(ValueError):
            self.db.create_service("Bad", "10/18/2026")
        with self.assertRaises(ValueError):
            self.db.update_service(self.sid, service_date="soon")

    def test_list_services_newest_first_with_range(self):
        self.db.create_service("Later", "2026-11-01")
        self.assertEqual([r["title"] for r in self.db.list_services()], ["Later", "Sunday"])
        self.assertEqual(
            [r["title"] for r in self.db.list_services(date_from="2026-10-20")], ["Later"])
        self.assertEqual(
            [r["title"] for r in self.db.list_services(date_to=date(2026, 10, 18))], ["Sunday"])

    def test_deleting_a_service_removes_its_items_but_not_content(self):
        song = self.make_song()
        self.db.add_service_item(self.sid, "song", song_id=song)
        self.assertTrue(self.db.delete_service(self.sid))
        self.assertEqual(self.db.conn.execute(
            "SELECT COUNT(*) FROM service_items").fetchone()[0], 0)
        self.assertIsNotNone(self.db.get_song(song))

    def test_duplicate_service_copies_items_independently(self):
        song = self.make_song()
        self.db.add_service_item(self.sid, "song", song_id=song, overrides={"lines": 2})
        self.add_blank(title="Welcome")
        new = self.db.duplicate_service(self.sid, "2026-10-25")
        copied = self.db.get_service_items(new)
        self.assertEqual([r["item_type"] for r in copied], ["song", "announcement"])
        self.assertEqual(item_overrides(copied[0]), {"lines": 2})
        self.db.remove_service_item(copied[1]["id"])
        self.assertEqual(len(self.db.get_service_items(self.sid)), 2)
        with self.assertRaises(ValueError):
            self.db.duplicate_service(9999, "2026-10-25")

    # ordering
    def test_append_and_insert_keep_positions_contiguous(self):
        a = self.add_blank(title="Welcome")
        b = self.db.add_service_item(self.sid, "blank")
        c = self.add_blank(position=1, title="Prayer")
        self.assertEqual(item_ids(self.db, self.sid), [a, c, b])
        self.assertEqual(positions(self.db, self.sid), [0, 1, 2])
        d = self.add_blank(position=99)  # too large -> appended
        e = self.add_blank(position=-5)  # too small -> first
        self.assertEqual(item_ids(self.db, self.sid)[0], e)
        self.assertEqual(item_ids(self.db, self.sid)[-1], d)
        self.assertEqual(positions(self.db, self.sid), list(range(5)))

    def test_remove_closes_the_gap(self):
        ids = [self.add_blank() for _ in range(3)]
        self.assertTrue(self.db.remove_service_item(ids[0]))
        self.assertEqual(positions(self.db, self.sid), [0, 1])
        self.assertFalse(self.db.remove_service_item(ids[0]))

    def test_move_and_reorder(self):
        a, b, c = (self.add_blank() for _ in range(3))
        self.db.move_service_item(c, 0)
        self.assertEqual(item_ids(self.db, self.sid), [c, a, b])
        self.db.reorder_service_items(self.sid, [b, a, c])
        self.assertEqual(item_ids(self.db, self.sid), [b, a, c])
        with self.assertRaises(ValueError):
            self.db.reorder_service_items(self.sid, [a, b])        # missing one
        with self.assertRaises(ValueError):
            self.db.reorder_service_items(self.sid, [a, a, b, c])  # duplicate
        self.assertEqual(item_ids(self.db, self.sid), [b, a, c])   # unchanged

    def test_services_are_ordered_independently(self):
        other = self.db.create_service("Wed", "2026-10-21")
        self.add_blank()
        self.db.add_service_item(other, "blank")
        self.assertEqual(positions(self.db, self.sid), [0])
        self.assertEqual(positions(self.db, other), [0])

    # validation
    def test_required_references_are_checked_per_type(self):
        with self.assertRaises(ValueError):
            self.db.add_service_item(self.sid, "song")
        with self.assertRaises(ValueError):
            self.db.add_service_item(self.sid, "scripture", chapter=3, verse_start=16)
        with self.assertRaises(ValueError):
            self.db.add_service_item(self.sid, "presentation")
        with self.assertRaises(ValueError):
            self.db.add_service_item(self.sid, "karaoke")
        with self.assertRaises(TypeError):
            self.db.add_service_item(self.sid, "blank", color="red")
        self.assertEqual(self.db.get_service_items(self.sid), [])

    def test_arrangement_must_belong_to_the_song(self):
        a, b = self.make_song("A"), self.make_song("B")
        arr_b = self.db.get_default_arrangement(b)["id"]
        with self.assertRaises(ValueError):
            self.db.add_service_item(self.sid, "song", song_id=a, arrangement_id=arr_b)
        item = self.db.add_service_item(self.sid, "song", song_id=a)
        with self.assertRaises(ValueError):
            self.db.update_service_item(item, arrangement_id=arr_b)
        own = self.db.get_default_arrangement(a)["id"]
        self.assertTrue(self.db.update_service_item(item, arrangement_id=own))

    def test_scripture_item_by_name_and_reversed_range_rejected(self):
        self.db.add_translation("KJV", "King James Version")
        item = self.db.add_service_item(
            self.sid, "scripture", book="john", translation="kjv",
            chapter=3, verse_start=16, verse_end=17)
        self.assertEqual(self.db.get_service_item(item)["book_id"], 43)
        with self.assertRaises(ValueError):
            self.db.add_service_item(
                self.sid, "scripture", book="John", translation="KJV",
                chapter=3, verse_start=17, verse_end=16)
        with self.assertRaises(ValueError):
            self.db.add_service_item(
                self.sid, "scripture", book="John", translation="NIV",
                chapter=3, verse_start=1)

    def test_overrides_round_trip_and_can_be_cleared(self):
        item = self.add_blank(overrides={"lines_per_slide": 2})
        self.assertEqual(item_overrides(self.db.get_service_item(item)), {"lines_per_slide": 2})
        self.db.update_service_item(item, overrides=None)
        self.assertEqual(item_overrides(self.db.get_service_item(item)), {})
        self.db.update_service_item(item, overrides={"a": 1})
        self.assertEqual(item_overrides(self.db.get_service_item(item)), {"a": 1})

    # protection of content
    def test_a_song_in_a_service_cannot_be_deleted(self):
        song = self.make_song()
        item = self.db.add_service_item(self.sid, "song", song_id=song)
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.delete_song(song)
        self.assertIsNotNone(self.db.get_song(song))
        self.db.remove_service_item(item)
        self.assertTrue(self.db.delete_song(song))

    def test_song_usage_view_lists_only_songs(self):
        song = self.make_song()
        self.db.add_service_item(self.sid, "song", song_id=song)
        self.add_blank()
        usage = self.db.conn.execute("SELECT * FROM song_usage").fetchall()
        self.assertEqual([(r["title"], r["ccli_number"]) for r in usage],
                         [("Amazing Grace", "123")])

    # outline
    def test_outline_has_readable_titles_for_every_item_type(self):
        song = self.make_song()
        self.db.add_translation("KJV", "King James Version")
        pres = self.db.add_presentation("Easter Sermon", ["a.png"])
        media = self.db.insert_media_asset("Cross Loop", "bg/cross.mp4", media_type="video")
        self.db.add_service_item(self.sid, "song", song_id=song)
        self.db.add_service_item(self.sid, "scripture", book="John", translation="KJV",
                                 chapter=3, verse_start=16, verse_end=17)
        self.db.add_service_item(self.sid, "scripture", book="Romans", translation="KJV",
                                 chapter=8, verse_start=28)
        self.db.add_service_item(self.sid, "presentation", presentation_id=pres)
        self.db.add_service_item(self.sid, "media", media_id=media)
        self.db.add_service_item(self.sid, "announcement")
        self.db.add_service_item(self.sid, "blank")
        self.db.add_service_item(self.sid, "song", song_id=song, title="Closing Song")
        titles = [r["display_title"] for r in self.db.get_service_outline(self.sid)]
        self.assertEqual(titles, [
            "Amazing Grace", "John 3:16-17 (KJV)", "Romans 8:28 (KJV)",
            "Easter Sermon", "Cross Loop", "Announcement", "Blank", "Closing Song"])


if __name__ == "__main__":
    unittest.main()
