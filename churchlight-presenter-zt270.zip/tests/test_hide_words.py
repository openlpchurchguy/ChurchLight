# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Hide the words: the public screens keep the theme's background and lose the text."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.outputs import LAYOUTS, Output, build_payload
from churchlight_presenter.ui.globalkeys import ACTIONS
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.test_verse_tray import deck_live, make

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "output.js"


class HideWordsTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.c.new_service("S")
        deck_live(self.c)
        self.c.load_tray("John 3")
        self.c.show_tray_verses([1])

    def payload(self, layout):
        name = {"projector": "projector", "lower_third": "lower-third", "confidence": "confidence", "stage": "stage"}[layout]
        return build_payload(self.c.session.state(), Output(name, layout))

    def test_toggle_reports_and_marks_public_payloads_only(self):
        self.assertNotIn("text_hidden", self.payload("projector"))
        self.assertTrue(self.api.call("text_hide", {})["text_hidden"])
        self.assertTrue(self.api.state()["live"]["text_hidden"])
        self.assertTrue(self.payload("projector")["text_hidden"])
        self.assertTrue(self.payload("lower_third")["text_hidden"])
        self.assertTrue(self.payload("confidence")["text_hidden"])       # the confidence monitor goes quiet too
        self.assertNotIn("text_hidden", self.payload("stage"))
        self.assertFalse(self.api.call("text_hide", {})["text_hidden"])
        self.assertNotIn("text_hidden", self.payload("projector"))

    def test_the_slide_is_kept_so_the_words_can_come_back(self):
        before = self.payload("projector")["overlay"]
        self.c.toggle_text_hidden()
        self.assertEqual(self.payload("projector")["overlay"], before)

    def test_blanking_wins_over_hiding(self):
        self.c.toggle_text_hidden()
        self.c.toggle_blank()
        self.assertNotIn("text_hidden", self.payload("projector"))

    def test_the_confidence_monitor_can_keep_its_words(self):
        outputs = [Output(n, n) for n in ("projector", "lower_third", "confidence", "stage")]
        self.c = OperatorController(self.db, outputs)
        self.api = OperatorApi(self.c)
        deck_live(self.c)
        self.c.load_tray("John 3")
        self.c.show_tray_verses([1])
        self.c.toggle_text_hidden()
        self.assertTrue(self.api.state()["confidence_hides_words"])                # on unless a church turns it off
        self.api.call("confidence_words_set", {"value": False})
        self.assertFalse(self.api.state()["confidence_hides_words"])
        pays = self.c.payloads()
        self.assertTrue(pays["projector"]["text_hidden"])                           # the projector still hides its words
        self.assertTrue(pays["lower_third"]["text_hidden"])
        self.assertNotIn("text_hidden", pays["confidence"])
        self.assertNotIn("text_hidden", pays["stage"])
        self.assertFalse(OperatorController(self.db, outputs).confidence_hides_words())     # kept across a restart
        self.api.call("confidence_words_set", {"value": True})
        self.assertTrue(self.c.payloads()["confidence"]["text_hidden"])
        with self.assertRaises(ApiError):
            self.api.call("confidence_words_set", {"value": "no"})

    def test_the_served_page_and_the_settings_checkbox_follow_the_choice(self):
        import json as _json
        import time
        import urllib.request
        outputs = [Output(n, n) for n in ("projector", "confidence")]
        self.c = OperatorController(self.db, outputs)
        deck_live(self.c)
        self.c.toggle_text_hidden()
        server = self.c.serve()
        self.addCleanup(server.close)
        fetch = lambda name: _json.load(urllib.request.urlopen(server.url.rstrip("/") + "/out/" + name))
        self.assertTrue(fetch("confidence").get("text_hidden"))
        self.c.set_confidence_hides_words(False)
        self.assertNotIn("text_hidden", fetch("confidence"))
        self.assertTrue(fetch("projector").get("text_hidden"))
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            return
        with sync_playwright() as pw:
            browser = pw.chromium.launch()
            page = browser.new_page()
            page.goto(server.url.rstrip("/") + "/operator")
            page.click("#tab-shortcuts")
            page.evaluate("document.querySelectorAll('details[data-settings-fold]').forEach((d) => { d.open = true; })")     # Settings starts folded
            page.wait_for_selector("#conf-hide-words", state="visible")
            end = time.time() + 5
            while page.is_checked("#conf-hide-words") and time.time() < end:
                time.sleep(0.05)
            self.assertFalse(page.is_checked("#conf-hide-words"))
            page.check("#conf-hide-words")
            end = time.time() + 5
            while not self.c.confidence_hides_words() and time.time() < end:
                time.sleep(0.05)
            self.assertTrue(self.c.confidence_hides_words())
            browser.close()

    def test_there_is_a_global_key_action(self):
        self.assertIn(("hide_text", "Hide the words (keep the background)", "toggle_text_hidden"), ACTIONS)


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageTests(unittest.TestCase):
    def view(self, payload):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify(m.viewModel({json.dumps(payload)})))"
        out = subprocess.run(["node", "-e", script, str(STATIC)], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def slide(self, **more):
        base = {"kind": "lyrics", "text": "Amazing grace", "segments": [], "label": "V1", "reference": "Hymn", "style": {"band": True}}
        base.update(more)
        return base

    def test_hiding_the_words_over_a_picture_slide_changes_nothing_the_page_would_draw(self):
        def key(payload):
            script = (f"const m=require(process.argv[1]);console.log(JSON.stringify(m.screenKey(m.viewModel({json.dumps(payload)}))))")
            out = subprocess.run(["node", "-e", script, str(STATIC)], capture_output=True, text=True, timeout=30, check=True)
            return json.loads(out.stdout)
        picture = {"kind": "image", "text": "", "segments": [], "label": "Deck", "reference": "", "image_path": "decks/a.png",
                   "image_fit": "fit", "style": {"font_size": 7}}
        shown = {"layout": "projector", "audience": "public", "base": picture, "overlay": None}
        hidden = dict(shown, text_hidden=True)
        self.assertEqual(key(shown), key(hidden))                      # same screen: the page does not redraw (no blink)
        words = {"layout": "projector", "audience": "public", "base": self.slide(), "overlay": None}
        self.assertNotEqual(key(words), key(dict(words, text_hidden=True)))   # words really go: the page does redraw
        self.assertNotEqual(key(shown), key(dict(shown, blank=True)))

    def test_the_projector_keeps_an_empty_layer_for_the_background(self):
        vm = self.view({"layout": "projector", "audience": "public", "text_hidden": True, "base": self.slide(), "overlay": None})
        self.assertEqual(len(vm["layers"]), 1)
        self.assertEqual(vm["layers"][0]["view"]["parts"], [])
        self.assertEqual(vm["layers"][0]["view"]["reference"], "")

    def test_the_confidence_monitor_loses_its_words_too_but_keeps_its_black_screen(self):
        vm = self.view({"layout": "confidence", "audience": "confidence", "text_hidden": True, "base": self.slide(), "overlay": None})
        self.assertEqual(len(vm["layers"]), 1)
        self.assertEqual(vm["layers"][0]["view"]["parts"], [])
        self.assertEqual(vm["layers"][0]["view"]["reference"], "")

    def test_a_lower_third_disappears_entirely(self):
        vm = self.view({"layout": "lower_third", "audience": "public", "text_hidden": True, "base": self.slide(), "overlay": None})
        self.assertEqual(vm["layers"], [])

    def test_a_picture_is_not_hidden(self):
        vm = self.view({"layout": "projector", "audience": "public", "text_hidden": True,
                        "base": self.slide(kind="image", text="", image_path="d/1.png"), "overlay": None})
        self.assertEqual(len(vm["layers"]), 1)
        self.assertEqual(vm["layers"][0]["view"]["image"], "d/1.png")

    def test_a_verse_over_a_picture_leaves_just_the_picture(self):
        vm = self.view({"layout": "projector", "audience": "public", "text_hidden": True,
                        "base": self.slide(kind="image", text="", image_path="d/1.png"),
                        "overlay": self.slide(kind="scripture", text="For God", segments=[[16, "For God"]], reference="John 3:16")})
        self.assertEqual([l["placement"] for l in vm["layers"]], ["full"])
        self.assertEqual(vm["layers"][0]["view"]["image"], "d/1.png")


if __name__ == "__main__":
    unittest.main()


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class BlankRedrawTests(unittest.TestCase):
    def same(self, prev, nxt):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify(m.sameBlankScreen({json.dumps(prev)},{json.dumps(nxt)})))"
        out = subprocess.run(["node", "-e", script, str(STATIC)], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def payload(self, **more):
        base = {"layout": "projector", "audience": "public", "blank": True, "base": None, "overlay": None,
                "home": {"image_path": "backgrounds/aaaaaaaaaaaaaaaa.png", "fit": "fit"}}
        base.update(more)
        return base

    def test_a_new_slide_under_the_blank_changes_nothing_on_screen(self):
        self.assertTrue(self.same(self.payload(version=1), self.payload(version=2)))

    def test_a_different_home_picture_or_fit_redraws(self):
        other = {"image_path": "backgrounds/bbbbbbbbbbbbbbbb.png", "fit": "fit"}
        self.assertFalse(self.same(self.payload(), self.payload(home=other)))
        self.assertFalse(self.same(self.payload(), self.payload(home={"image_path": "backgrounds/aaaaaaaaaaaaaaaa.png", "fit": "fill"})))

    def test_unblanking_or_blanking_redraws(self):
        self.assertFalse(self.same(self.payload(blank=False), self.payload()))
        self.assertFalse(self.same(self.payload(), self.payload(blank=False)))

    def test_the_speaker_monitor_and_stage_always_redraw(self):
        self.assertFalse(self.same(self.payload(audience="confidence"), self.payload(audience="confidence")))
        self.assertFalse(self.same(self.payload(audience="stage"), self.payload(audience="stage")))

    def test_a_changed_layout_redraws(self):
        self.assertFalse(self.same(self.payload(), self.payload(layout="lower_third")))
