# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A clip that has just gone live starts a moment later, so the screens can put the slide up first."""
import json
import subprocess
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.live import LiveSession, clip_position
from churchlight_presenter.ui.controller import LibraryEntry
from tests.test_media_playback import MP3, MP4, Base

OUTPUT_JS = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "output.js"


def node(expression):
    script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
    out = subprocess.run(["node", "-e", script, str(OUTPUT_JS)], capture_output=True, text=True, timeout=30, check=True)
    return json.loads(out.stdout)


class PositionTests(unittest.TestCase):
    def test_before_its_start_time_a_playing_clip_is_held_at_its_start(self):
        view = {"pos": 0.0, "at": 100.5, "playing": True, "loop": False, "duration": 20.0}
        self.assertEqual(clip_position(view, 100.0), 0.0)
        self.assertEqual(clip_position(view, 100.5), 0.0)
        self.assertAlmostEqual(clip_position(view, 103.5), 3.0)

    def test_the_screen_does_the_same_sum(self):
        view = {"pos": 2.0, "at": 100.5, "playing": True, "loop": False, "duration": 20.0}
        self.assertEqual(node(f"m.clipPosition({json.dumps(view)}, 100.0)"), 2.0)
        self.assertEqual(node(f"m.clipPosition({json.dumps(view)}, 103.5)"), 5.0)


class ScreenTransitionTests(unittest.TestCase):
    def test_the_screen_plays_no_transition_onto_or_off_a_video_page(self):
        def plan(prev_kind, next_kind):
            prev = {"base": {"kind": prev_kind, "image_path": "a", "text": "x", "item_type": "presentation", "source_item_id": 1}}
            nxt = {"transitions": True, "base": {"kind": next_kind, "image_path": "b", "text": "y", "item_type": "presentation", "source_item_id": 1,
                                                   "transition": "dissolve", "transition_ms": 800}}
            return node(f"m.planTransition({json.dumps(prev)}, {json.dumps(nxt)})")
        self.assertIsNotNone(plan("image", "image"))
        self.assertIsNone(plan("image", "video"))
        self.assertIsNone(plan("video", "image"))


class LeadTests(Base):
    def setUp(self):
        super().setUp()
        self.video = self.add("Welcome.mp4", MP4, 20)
        self.music = self.add("Hymn.mp3", MP3, 30)
        self.deck = self.db.add_presentation("Notices", [("decks/a.png", None)])
        self.c.add_deck_library(self.deck, [self.video])
        self.c.new_service("Sunday")
        self.item = self.c.add_entry(LibraryEntry("presentation", self.deck, ""))

    def lead(self):
        media = self.c.session.state().media
        return media["at"] - media["now"] if "now" in media else media["at"] - time.time()

    def go(self, slide):
        self.c.go_live_service_item(self.item)
        self.c.go_to_slide(slide)

    def test_a_new_video_starts_half_a_second_after_it_goes_live(self):
        self.go(1)
        at = self.c.session.state().media
        self.assertTrue(0.3 < at["at"] - time.time() <= LiveSession.START_LEAD + 0.05)
        self.assertEqual(at["pos"], 0.0)
        self.assertTrue(at["playing"])

    def test_a_video_page_ignores_its_transition_because_the_screen_plays_none_for_it(self):
        self.c.remove_item(self.item)
        self.db.conn.execute("UPDATE presentation_pages SET transition = 'dissolve', transition_ms = 800 WHERE presentation_id = ?", (self.deck,))
        self.db.conn.commit()
        item = self.c.add_entry(LibraryEntry("presentation", self.deck, ""))        # built after the change
        self.c.go_live_service_item(item)
        self.c.go_to_slide(1)
        wait = self.c.session.state().media["at"] - time.time()
        self.assertLessEqual(wait, LiveSession.START_LEAD + 0.05, wait)

    def test_a_pages_sound_waits_for_the_transition_of_a_picture_page(self):
        self.c.remove_item(self.item)
        deck = self.db.add_presentation("Pictures", [("decks/a.png", None), ("decks/b.png", None)])
        self.db.conn.execute("UPDATE presentation_pages SET transition = 'dissolve', transition_ms = 2000 WHERE presentation_id = ?", (deck,))
        self.db.conn.commit()
        self.c.set_deck_pages_sound(deck, [p["id"] for p in self.db.get_presentation_pages(deck)], sound_id=self.music)
        item = self.c.add_entry(LibraryEntry("presentation", deck, ""))
        self.c.go_live_service_item(item)
        self.c.go_to_slide(1)
        wait = self.c.session.state().page_sound["at"] - time.time()
        self.assertTrue(2.0 < wait <= LiveSession.START_LEAD + 2.0 + 0.05, wait)

    def test_arriving_from_another_item_waits_only_the_short_moment(self):
        self.c.remove_item(self.item)
        movie = self.db.add_presentation("Movie only", [("decks/b.png", None)])
        self.c.add_deck_library(movie, [self.video])
        self.db.conn.execute("UPDATE presentation_pages SET transition = 'dissolve', transition_ms = 800 WHERE presentation_id = ?", (movie,))
        self.db.conn.commit()
        song = self.db.insert_song("Opening")
        self.db.add_section(song, "Verse 1", "words")
        song_item = self.c.add_entry(LibraryEntry("song", song, ""))
        movie_item = self.c.add_entry(LibraryEntry("presentation", movie, ""))
        self.c.go_live_service_item(song_item)
        self.c.go_to_slide(len(self.c.session.slides) - 1)         # straight from the song onto the movie's video page
        wait = self.c.session.state().media["at"] - time.time()
        self.assertLessEqual(wait, LiveSession.START_LEAD + 0.05, wait)

    def test_pause_restart_and_resume_are_immediate(self):
        self.go(1)
        self.c.session.media_restart()
        media = self.c.session.state().media
        self.assertLess(abs(media["at"] - time.time()), 0.1)
        self.c.session.media_pause()
        self.c.session.media_play()
        self.assertLess(abs(self.c.session.state().media["at"] - time.time()), 0.1)

    def test_the_end_timer_counts_from_the_start_time(self):
        self.go(1)
        view = self.c.session.state().media
        target = self.c._clip_target(view)
        self.assertIsNotNone(target)
        expected = 20.0 + (view["at"] - self.c.session.now()) + self.c.CLIP_GRACE
        self.assertAlmostEqual(target[1], expected, delta=0.05)
        self.assertGreater(target[1], 20.0 + self.c.CLIP_GRACE)

    def test_a_pages_own_sound_starts_with_the_same_wait(self):
        self.c.set_deck_pages_sound(self.deck, [p["id"] for p in self.db.get_presentation_pages(self.deck)], sound_id=self.music)
        self.c.go_live_service_item(self.item)
        sound = self.c.session.state().page_sound
        self.assertTrue(0.3 < sound["at"] - time.time() <= LiveSession.START_LEAD + 0.05)


if __name__ == "__main__":
    unittest.main()
