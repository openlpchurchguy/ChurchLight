# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Video and sound in the program: the library, the live clip's controls, the music layer, moving on at the end."""
import io
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.test_autoplay import TimerBase

MP4 = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 64
MP3 = b"ID3\x03\x00\x00\x00\x00\x00\x00" + b"\x00" * 64
WAV = b"RIFF\x24\x00\x00\x00WAVEfmt " + b"\x00" * 64


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        self.c.serve(media_root=self.tmp / "media", operator=True)
        self.addCleanup(self.c.close)
        self.api = OperatorApi(self.c)

    def upload(self, name, data):
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, name, io.BytesIO(data), len(data), "media")
        return batch

    def add(self, name, data, seconds):
        return self.c.add_media_file(self.upload(name, data), seconds)


class LibraryTests(Base):
    def test_adding_video_and_sound_lists_them_with_their_length(self):
        video = self.add("Welcome video.mp4", MP4, 12.5)
        sound = self.add("Prelude.mp3", MP3, 180)
        rows = {r["id"]: r for r in self.c.library_overview()["media"]}
        self.assertEqual((rows[video]["kind"], rows[video]["seconds"], rows[video]["name"]), ("video", 12.5, "Welcome video"))
        self.assertEqual((rows[sound]["kind"], rows[sound]["seconds"]), ("audio", 180.0))
        self.assertGreater(rows[video]["size"], 0)
        self.assertTrue((self.tmp / "media" / self.db.get_media_asset(video)["path"]).is_file())

    def test_wav_is_accepted_and_the_wrong_kind_of_file_is_refused_in_plain_words(self):
        self.assertTrue(self.add("tone.wav", WAV, 3))
        for name, data in (("clip.mp4", b"not a video at all"), ("clip.mp3", b"\x00\x00\x00\x00"), ("clip.wav", b"RIFFxxxxAVI "),
                           ("clip.mov", MP4)):
            with self.subTest(name=name):
                try:
                    batch = self.upload(name, data)
                except ControllerError:
                    continue                                  # refused already at upload: an ending that is not allowed
                with self.assertRaises(ControllerError) as caught:
                    self.c.add_media_file(batch, 1)
                self.assertIn("MP4", str(caught.exception))
        self.assertEqual(len(self.c.library_overview()["media"]), 1)

    def test_a_silly_length_is_stored_as_unknown(self):
        for seconds in (-5, 10 ** 9, "abc", None):
            media = self.add("a.mp3", MP3, seconds)
            self.assertIsNone(self.db.get_media_asset(media)["duration_ms"])

    def test_rename_and_delete_remove_the_file_but_not_while_used_or_playing(self):
        video = self.add("a.mp4", MP4, 10)
        path = self.tmp / "media" / self.db.get_media_asset(video)["path"]
        self.c.rename_media(video, "  Opening  ")
        self.assertEqual(self.c.media_list()[0]["name"], "Opening")
        with self.assertRaises(ControllerError):
            self.c.rename_media(video, " ")
        self.c.new_service("Sunday")
        item = self.c.add_entry(LibraryEntry("media", video, ""))
        with self.assertRaises(ControllerError) as caught:
            self.c.delete_media(video)
        self.assertIn("service", str(caught.exception))
        self.c.remove_item(item)
        self.c.go_live_entry(LibraryEntry("media", video, ""))
        with self.assertRaises(ControllerError):
            self.c.delete_media(video)                        # it is on screen
        self.c.clear()
        self.c.delete_media(video)
        self.assertFalse(path.exists())
        self.assertEqual(self.c.media_list(), [])

    def test_pictures_are_listed_with_the_video_and_sound(self):
        self.db.insert_media_asset("Cross", "bg/cross.png", media_type="image")
        (row,) = self.c.media_list()
        self.assertEqual((row["kind"], row["name"], row["decks"]), ("image", "Cross", 0))


class PlaybackTests(Base):
    def setUp(self):
        super().setUp()
        self.video = self.add("a.mp4", MP4, 60)
        self.song = self.add("b.mp3", MP3, 200)
        self.c.new_service("Sunday")

    def live(self):
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))
        return self.c.session.state().media

    def test_sending_a_video_live_starts_it_and_the_controls_move_it(self):
        view = self.live()
        self.assertEqual((view["kind"], view["playing"], view["duration"]), ("video", True, 60.0))
        self.c.media_control("pause")
        self.assertFalse(self.c.session.state().media["playing"])
        self.c.media_control("seek", 30)
        self.assertEqual(self.c.session.state().media["pos"], 30)
        self.c.media_control("loop", True)
        self.c.media_control("volume", 0.4)
        self.c.media_control("mute", True)
        view = self.c.session.state().media
        self.assertEqual((view["loop"], view["volume"], view["muted"]), (True, 0.4, True))
        self.c.media_toggle()
        self.assertTrue(self.c.session.state().media["playing"])
        self.c.media_control("restart")
        self.assertEqual(self.c.session.state().media["pos"], 0.0)

    def test_controls_refuse_when_nothing_is_playing(self):
        with self.assertRaises(ControllerError):
            self.c.media_control("pause")
        with self.assertRaises(ControllerError):
            self.c.sound_control("pause")
        with self.assertRaises(ControllerError):
            self.c.media_control("explode")
        self.c.media_control("volume", 0.5)                   # the volume can be set before anything plays

    def test_music_plays_under_the_slides_and_survives_changing_slides(self):
        self.c.play_music(self.song, loop=True)
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))
        self.c.clear()
        music = self.c.session.state().sound
        self.assertEqual((music["src"], music["loop"], music["playing"]), (self.db.get_media_asset(self.song)["path"], True, True))
        self.c.sound_control("pause")
        self.c.sound_control("volume", 0.2)
        self.assertFalse(self.c.session.state().sound["playing"])
        self.c.sound_toggle()
        self.assertTrue(self.c.session.state().sound["playing"])
        self.c.sound_control("stop")
        self.assertIsNone(self.c.session.state().sound)

    def test_only_a_sound_file_can_be_music_and_the_music_is_protected_from_deletion(self):
        with self.assertRaises(ControllerError):
            self.c.play_music(self.video)
        self.c.play_music(self.song)
        with self.assertRaises(ControllerError):
            self.c.delete_media(self.song)

    def test_the_sound_comes_from_the_first_projector_screen_only(self):
        names = [o.name for o in self.c.outputs if o.layout == "projector"]
        self.assertEqual(self.c.sound_output(), names[0])
        payloads = self.c.payloads()
        self.live()
        payloads = self.c.payloads()
        sounds = {n: p["media"]["plays_sound"] for n, p in payloads.items() if "media" in p}
        self.assertEqual(sounds, {names[0]: True})

    def test_the_run_page_view_and_the_api(self):
        self.live()
        view = self.api.state()["clips"]
        self.assertEqual((view["live"]["kind"], view["advance"]), ("video", True))
        for action, args in (("media_pause", {}), ("media_seek", {"seconds": 12}), ("media_loop", {"on": True}),
                             ("media_volume", {"volume": 0.5}), ("media_mute", {"on": False}), ("media_play", {}),
                             ("media_restart", {}), ("media_advance", {"on": False}), ("music_play", {"id": self.song, "loop": True}),
                             ("music_seek", {"seconds": 5}), ("music_volume", {"volume": 0.1}), ("music_mute", {"on": True}),
                             ("music_loop", {"on": False}), ("music_pause", {}), ("music_resume", {}), ("music_restart", {}),
                             ("music_stop", {})):
            with self.subTest(action=action):
                self.assertTrue(self.api.call(action, args)["ok"])
        self.assertFalse(self.c.media_advance)
        for action, args in (("media_volume", {"volume": 2}), ("media_seek", {"seconds": -1}), ("media_loop", {"on": "yes"}),
                             ("music_play", {"id": "x"}), ("media_rename", {"id": self.video, "name": 5})):
            with self.subTest(bad=action):
                with self.assertRaises(ApiError):
                    self.api.call(action, args)

    def test_a_clip_can_be_added_to_the_service_and_the_buttons_work(self):
        self.api.call("add", {"kind": "media", "id": self.video})
        self.assertEqual(self.api.state()["items"][0]["type"], "media")
        self.api.call("go_entry", {"kind": "media", "id": self.video})
        self.api.trigger("media_toggle")
        self.assertFalse(self.c.session.state().media["playing"])
        self.api.trigger("media_restart")
        self.assertTrue(self.c.session.state().media["playing"])
        self.c.play_music(self.song)
        self.api.trigger("music_toggle")
        self.assertFalse(self.c.session.state().sound["playing"])


class AdvanceTests(TimerBase):
    """The program moves on when a clip ends (the timer runs on a shrunk clock)."""

    def setUp(self):
        super().setUp()
        self.c.serve(media_root=self.tmp / "media", operator=True)
        self.addCleanup(self.c.close)
        self.c.new_service("Sunday")
        self.c.CLIP_GRACE = 0.0

    def clip(self, name, seconds, kind="video"):
        suffix = ".mp4" if kind == "video" else ".mp3"
        data = MP4 if kind == "video" else MP3
        rel = f"media/{name}{suffix}"
        (self.tmp / "media" / "media").mkdir(parents=True, exist_ok=True)
        (self.tmp / "media" / rel).write_bytes(data)
        return self.db.insert_media_asset(name, rel, kind, None, int(seconds * 1000))

    def test_the_next_slide_comes_up_when_a_video_ends(self):
        clip = self.clip("a", 2)
        first = self.c.add_entry(LibraryEntry("media", clip, ""))
        self.c.add_entry(LibraryEntry("presentation", self.deck, ""))
        self.c.go_live_service_item(first)
        self.assertEqual(self.c.session.state().base.kind, "video")
        self.assertTrue(self.wait_for(lambda: self.c.session.state().base.kind != "video"))
        self.assertFalse(self.c.session.state().media)

    def test_nothing_moves_when_advance_is_off_or_the_clip_loops_or_was_paused(self):
        clip = self.clip("a", 1)
        first = self.c.add_entry(LibraryEntry("media", clip, ""))
        self.c.add_entry(LibraryEntry("presentation", self.deck, ""))
        self.c.set_media_advance(False)
        self.c.go_live_service_item(first)
        self.assertFalse(self.wait_for(lambda: self.c.session.state().base.kind != "video", 0.3))
        self.assertFalse(self.c.session.state().media["playing"])      # it ended and stopped on its last frame
        self.c.set_media_advance(True)
        self.c.media_control("loop", True)
        self.c.media_control("restart")
        self.assertFalse(self.wait_for(lambda: self.c.session.state().base.kind != "video", 0.3))
        self.c.media_control("loop", False)
        self.c.media_control("pause")
        self.assertFalse(self.wait_for(lambda: self.c.session.state().base.kind != "video", 0.3))

    def test_the_last_slide_stays_put_and_the_music_just_stops_playing_at_its_end(self):
        clip = self.clip("a", 1)
        self.c.go_live_entry(LibraryEntry("media", clip, ""))
        self.assertTrue(self.wait_for(lambda: not self.c.session.state().media["playing"]))
        self.assertEqual(self.c.session.state().base.kind, "video")
        song = self.clip("m", 1, "audio")
        self.c.play_music(song)
        self.assertTrue(self.wait_for(lambda: not self.c.session.state().sound["playing"]))
        self.assertIsNotNone(self.c.session.state().sound)
