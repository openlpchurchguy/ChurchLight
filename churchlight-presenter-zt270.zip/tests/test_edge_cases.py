# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Edge cases found by probing the reference parser and the service builder."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.items import ItemRef, add_to_service
from churchlight_presenter.core.scripture_ref import ReferenceParseError, parse_reference
from churchlight_presenter.core.slides import SlideBuilder

JOHN = 43


class ParseEdgeCases(unittest.TestCase):
    def test_input_that_is_not_text_is_a_parse_error(self):
        for bad in (None, 3, b"john 3"):
            with self.assertRaises(ReferenceParseError):
                parse_reference(bad)

    def test_absurd_numbers_are_rejected_before_reaching_the_database(self):
        for text in ("john 99999999999999999999:1", "john 3:99999999999999999999",
                     "john 3:1-99999999999999999999", "john 1000"):
            with self.assertRaises(ReferenceParseError):
                parse_reference(text)

    def test_the_largest_real_numbers_still_work(self):
        self.assertEqual(parse_reference("ps 150").chapter, 150)
        self.assertEqual(parse_reference("ps 119:176").verse_start, 176)

    def test_one_chapter_books_reject_any_other_chapter(self):
        for text in ("jude 2:1", "3 john 2:1", "obad 3:4"):
            with self.assertRaises(ReferenceParseError):
                parse_reference(text)
        self.assertEqual(parse_reference("jude 1:5").verse_start, 5)
        self.assertEqual(parse_reference("jude 5").verse_start, 5)


class ServiceResilience(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.kjv = self.db.add_translation("KJV", "King James Version")
        self.db.add_verses(self.kjv, [("John", 3, 16, "For God so loved the world")])
        self.builder = SlideBuilder(self.db)
        self.good = self.db.create_song_with_sections("Good", [("V1", "verse", "la la")])
        self.service = self.db.create_service("Sunday", "2026-10-25")

    def test_a_missing_verse_becomes_a_visible_placeholder(self):
        add_to_service(self.db, self.service, ItemRef.song(self.good))
        bad = add_to_service(
            self.db, self.service, ItemRef.passage(self.kjv, JOHN, 3, 1))  # verse not stored
        add_to_service(self.db, self.service, ItemRef.blank())

        slides = self.builder.build_service(self.service)

        self.assertEqual([s.kind for s in slides], ["lyrics", "blank", "blank"])
        self.assertTrue(slides[1].label.startswith("Problem:"))
        self.assertIn("John 3:1", slides[1].label)
        self.assertEqual(slides[1].source_item_id, bad)

    def test_a_song_with_no_sections_is_reported_not_silently_dropped(self):
        empty = self.db.insert_song("Empty")
        add_to_service(self.db, self.service, ItemRef.song(empty))
        (slide,) = self.builder.build_service(self.service)
        self.assertTrue(slide.label.startswith("Problem:"))
        self.assertIn("no sections", slide.label)

    def test_a_video_is_a_clip_slide_not_a_placeholder(self):
        video = self.db.insert_media_asset("loop", "bg/loop.mp4", media_type="video", duration_ms=5000)
        add_to_service(self.db, self.service, ItemRef.media(video))
        (slide,) = self.builder.build_service(self.service)
        self.assertEqual((slide.kind, slide.duration_ms, slide.label), ("video", 5000, "loop"))

    def test_building_one_item_live_still_raises_so_the_library_can_report_it(self):
        with self.assertRaises(ValueError):
            self.builder.build_item(ItemRef.passage(self.kjv, JOHN, 3, 1))
        with self.assertRaises(ValueError):
            self.builder.build_item(ItemRef.song(self.db.insert_song("Empty")))


if __name__ == "__main__":
    unittest.main()
