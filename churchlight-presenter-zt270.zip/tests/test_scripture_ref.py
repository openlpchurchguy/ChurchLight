# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import unittest

from churchlight_presenter.core.scripture_ref import (
    BOOK_NAMES, ReferenceParseError, book_candidates, format_reference, parse_reference,
)

JOHN, PSALMS, SONG, ROMANS, COR1, JOHN1, JOHN3, JUDE, OBADIAH, TIM2, REV = (
    43, 19, 22, 45, 46, 62, 64, 65, 31, 55, 66)


def parse(text):
    ref = parse_reference(text)
    return (ref.book_id, ref.chapter, ref.verse_start, ref.verse_end)


class ParseTests(unittest.TestCase):
    def test_separators_and_spacing(self):
        for text in ("John 3:16", "john 3:16", "JOHN 3:16", "  john   3 : 16 ",
                     "john 3.16", "john 3 16", "jn3:16", "Jn. 3.16"):
            self.assertEqual(parse(text), (JOHN, 3, 16, None), text)

    def test_verse_ranges(self):
        for text in ("john 3:16-18", "john 3:16 - 18", "john 3 16-18", "john 3:16–18"):
            self.assertEqual(parse(text), (JOHN, 3, 16, 18), text)

    def test_a_range_of_one_verse_is_a_single_verse(self):
        self.assertEqual(parse("john 3:16-16"), (JOHN, 3, 16, None))

    def test_whole_chapter(self):
        self.assertEqual(parse("ps 23"), (PSALMS, 23, None, None))
        self.assertEqual(parse("Psalm 119"), (PSALMS, 119, None, None))

    def test_numbered_books_in_every_style(self):
        for text in ("1 John 1:9", "1john 1:9", "I John 1:9", "i john 1:9",
                     "first john 1:9", "1st john 1:9", "1 jn 1:9", "1jn1:9"):
            self.assertEqual(parse(text), (JOHN1, 1, 9, None), text)
        self.assertEqual(parse("2nd Timothy 3:16"), (TIM2, 3, 16, None))
        self.assertEqual(parse("1 cor 13"), (COR1, 13, None, None))
        self.assertEqual(parse("1cor13:4-7"), (COR1, 13, 4, 7))

    def test_multi_word_book_names(self):
        self.assertEqual(parse("Song of Solomon 2:1"), (SONG, 2, 1, None))
        self.assertEqual(parse("song 2:1"), (SONG, 2, 1, None))

    def test_unambiguous_prefix_works(self):
        self.assertEqual(parse("revel 21:1"), (REV, 21, 1, None))
        self.assertEqual(parse("roma 8:28"), (ROMANS, 8, 28, None))

    def test_single_chapter_books_treat_a_bare_number_as_a_verse(self):
        self.assertEqual(parse("Jude 5"), (JUDE, 1, 5, None))
        self.assertEqual(parse("jude 3-5"), (JUDE, 1, 3, 5))
        self.assertEqual(parse("3 John 4"), (JOHN3, 1, 4, None))
        self.assertEqual(parse("Obadiah 1:3"), (OBADIAH, 1, 3, None))
        self.assertEqual(parse("Jude 1:5"), (JUDE, 1, 5, None))

    def test_every_canonical_name_finds_its_own_book(self):
        for book_id, name in enumerate(BOOK_NAMES, start=1):
            self.assertEqual(parse(f"{name} 1:1")[0], book_id, name)


class ParseErrorTests(unittest.TestCase):
    def assertRejects(self, text, fragment=None):
        with self.assertRaises(ReferenceParseError) as ctx:
            parse_reference(text)
        if fragment:
            self.assertIn(fragment.lower(), str(ctx.exception).lower())

    def test_errors_are_value_errors_too(self):
        self.assertTrue(issubclass(ReferenceParseError, ValueError))

    def test_bad_input(self):
        self.assertRejects("", "book")
        self.assertRejects("   ", "book")
        self.assertRejects("3:16", "book")
        self.assertRejects("john", "chapter")
        self.assertRejects("1 john", "chapter")
        self.assertRejects("xyzzy 3:1", "unknown")

    def test_a_prefix_that_fits_several_books_takes_the_first_in_bible_order(self):
        self.assertEqual(parse("jo 3:16")[0], 6)       # Joshua, before Job and John
        self.assertEqual(parse("ph 1:1")[0], 50)       # Philippians, before Philemon
        self.assertEqual(parse("lev 3"), (3, 3, None, None))
        self.assertEqual(parse("joh 3:16")[0], JOHN)
        self.assertEqual(parse("phile 1")[0], 57)

    def test_autofill_hint(self):
        from churchlight_presenter.core.scripture_ref import reference_hint
        self.assertEqual(reference_hint("lev 3"), "Leviticus 3")
        self.assertEqual(reference_hint("lev"), "Leviticus")
        self.assertEqual(reference_hint("1 jo 1:9"), "1 John 1:9")
        self.assertEqual(reference_hint("ph"), "Philippians")
        self.assertEqual(reference_hint("zzz 3"), "")
        self.assertEqual(reference_hint(""), "")
        self.assertEqual(reference_hint("3"), "")
        self.assertEqual(reference_hint(None), "")

    def test_impossible_numbers(self):
        self.assertRejects("john 0:1", "start at 1")
        self.assertRejects("john 3:0", "start at 1")
        self.assertRejects("john 3:18-16", "ends before")

    def test_unsupported_forms_say_so(self):
        self.assertRejects("psalm 23-24", "chapter ranges")
        self.assertRejects("john 3:16-4:2", "cross chapters")


class HelperTests(unittest.TestCase):
    def test_book_candidates_for_type_ahead(self):
        self.assertEqual(book_candidates("joh"), [JOHN])
        self.assertEqual(book_candidates("ph"), [50, 57])
        self.assertEqual(book_candidates("1 jo"), [JOHN1])
        self.assertIn(JOHN, book_candidates("jo"))
        self.assertEqual(book_candidates(""), [])
        self.assertEqual(book_candidates("zzz"), [])

    def test_format_reference(self):
        self.assertEqual(format_reference("John", 3), "John 3")
        self.assertEqual(format_reference("John", 3, 16), "John 3:16")
        self.assertEqual(format_reference("John", 3, 16, 17), "John 3:16-17")
        self.assertEqual(format_reference("John", 3, 16, 16), "John 3:16")

    def test_66_books(self):
        self.assertEqual(len(BOOK_NAMES), 66)
        self.assertEqual(BOOK_NAMES[42], "John")


if __name__ == "__main__":
    unittest.main()
