# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The Live box shows two output previews side by side, each changeable."""
import json
import shutil
import subprocess
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
OUTPUTS = [Output("projector", "projector"), Output("lower", "lower_third"), Output("stage", "stage")]


def until(check, seconds=5):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class ChoiceTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")],
                             capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_each_slot_defaults_to_its_own_output(self):
        outs = '[{name:"a"},{name:"b"},{name:"c"}]'
        self.assertEqual(self.js(f"m.chosenLiveOutput({outs}, '', 0).name"), "a")
        self.assertEqual(self.js(f"m.chosenLiveOutput({outs}, '', 1).name"), "b")
        self.assertEqual(self.js(f"m.chosenLiveOutput({outs}, 'c', 1).name"), "c")
        self.assertIsNone(self.js(f"m.chosenLiveOutput({outs}, 'none', 1)"))
        self.assertEqual(self.js(f"m.chosenLiveOutput({outs}, 'gone', 1).name"), "b")

    def test_a_single_output_leaves_the_second_slot_empty(self):
        self.assertIsNone(self.js("m.chosenLiveOutput([{name:'a'}], '', 1)"))


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, OUTPUTS)
        self.c.new_service("Sunday")
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            self.browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(self.browser.close)
        self.base = self.server.url.rstrip("/")

    def open(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector("#live-frame iframe", state="attached")
        return page

    def titles(self, page):
        return [page.get_attribute(f"#{ident} iframe", "title") for ident in ("live-frame", "live-frame-2")]

    def test_two_different_outputs_show_side_by_side(self):
        page = self.open()
        page.wait_for_selector("#live-frame-2 iframe", state="attached")
        self.assertEqual(self.titles(page), ["Live preview of projector", "Live preview of lower"])
        a, b = page.locator("#live-frame").bounding_box(), page.locator("#live-frame-2").bounding_box()
        self.assertLess(abs(a["y"] - b["y"]), 5)
        self.assertLess(a["x"] + a["width"], b["x"] + 1)

    def test_each_slot_can_be_changed_or_turned_off_and_is_remembered(self):
        page = self.open()
        page.wait_for_selector("#live-frame-2 iframe", state="attached")
        page.select_option("#live-output-2", "stage")
        self.assertTrue(until(lambda: page.get_attribute("#live-frame-2 iframe", "title") == "Live preview of stage"))
        page.select_option("#live-output", "none")
        self.assertTrue(until(lambda: page.is_hidden("#live-frame")))
        self.assertTrue(page.is_visible("#live-frame-2"))
        page.reload()
        page.wait_for_selector("#live-frame-2 iframe", state="attached")
        self.assertTrue(page.is_hidden("#live-frame"))
        self.assertEqual(page.get_attribute("#live-frame-2 iframe", "title"), "Live preview of stage")


if __name__ == "__main__":
    unittest.main()
