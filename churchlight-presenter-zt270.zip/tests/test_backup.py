# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Automatic database backups, the start-up health check and restoring a copy."""
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core import backup
from churchlight_presenter.core.database import DatabaseManager


def make_db(path, title="Song"):
    with DatabaseManager(path) as db:
        db.set_setting("marker", title)


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = str(Path(self.tmp.name) / "church.db")

    def test_nothing_to_copy_for_a_new_start(self):
        self.assertIsNone(backup.make_backup(self.db))
        Path(self.db).write_bytes(b"")
        self.assertIsNone(backup.make_backup(self.db))
        self.assertEqual(backup.list_backups(self.db), [])
        backup.check(self.db)                              # a missing or empty file is a normal first start

    def test_a_copy_is_a_whole_working_database(self):
        make_db(self.db, "hello")
        copy = backup.make_backup(self.db)
        self.assertTrue(copy.name.startswith("church-") and "-v" in copy.name)
        with DatabaseManager(str(copy)) as db:
            self.assertEqual(db.get_setting("marker"), "hello")

    def test_a_second_start_soon_after_makes_no_new_copy(self):
        make_db(self.db)
        self.assertIsNotNone(backup.make_backup(self.db, now=1_000_000))
        self.assertIsNone(backup.make_backup(self.db, now=1_000_000 + 60))
        self.assertEqual(len(backup.list_backups(self.db)), 1)

    def test_only_the_newest_copies_are_kept(self):
        make_db(self.db)
        for i in range(6):
            now = 1_700_000_000 + i * 3600
            copy = backup.make_backup(self.db, keep=3, now=now)
            os.utime(copy, (now, now))
        names = [p.name for p in backup.list_backups(self.db)]
        self.assertEqual(len(names), 3)
        self.assertEqual(names, sorted(names, reverse=True))

    def test_a_damaged_database_is_reported_in_plain_words(self):
        make_db(self.db)
        backup.make_backup(self.db)
        Path(self.db).write_bytes(b"this is not a database" * 100)
        with self.assertRaises(backup.DatabaseDamaged) as caught:
            backup.check(self.db)
        self.assertIn("--restore-backup", str(caught.exception))

    def test_restore_brings_back_the_newest_healthy_copy(self):
        make_db(self.db, "good")
        backup.make_backup(self.db)
        Path(self.db).write_bytes(b"broken" * 200)
        used = backup.restore_latest(self.db)
        with DatabaseManager(self.db) as db:
            self.assertEqual(db.get_setting("marker"), "good")
        self.assertTrue(Path(self.db + ".damaged").exists())
        self.assertTrue(used.name.endswith(".db"))

    def test_restore_with_no_copy_says_so(self):
        with self.assertRaises(backup.DatabaseDamaged):
            backup.restore_latest(self.db)

    def test_a_failed_backup_never_raises(self):
        make_db(self.db)
        Path(self.tmp.name, backup.FOLDER).write_text("a file where the folder should be")
        self.assertIsNone(backup.make_backup(self.db))


class StartupTests(unittest.TestCase):
    def test_main_refuses_a_damaged_database_without_crashing(self):
        from churchlight_presenter.__main__ import main
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "church.db"
            db.write_bytes(b"junk" * 500)
            self.assertEqual(main(["--db", str(db), "--no-server", "--log-file", str(Path(tmp) / "x.log")]), 2)

    def test_restore_flag_without_copies_fails_cleanly(self):
        from churchlight_presenter.__main__ import main
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(main(["--db", str(Path(tmp) / "church.db"), "--restore-backup",
                                   "--log-file", str(Path(tmp) / "x.log")]), 2)


if __name__ == "__main__":
    unittest.main()
