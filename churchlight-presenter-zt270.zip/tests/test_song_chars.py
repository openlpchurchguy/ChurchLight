# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Characters per line: a long lyric line counts as the several screen lines it will take, so the theme's maximum is real lines."""
import unittest

from churchlight_presenter.core.slides import BuildSettings, _song_chunks
from churchlight_presenter.core.themes import BUILD_KEYS

SHORT = "Amazing grace how sweet the sound"                                 # 33 characters
LONG = "That saved a wretch like me, I once was lost but now am found"       # 61 characters


def settings(per=4, chars=40):
    return BuildSettings(lines_per_slide=per, chars_per_line=chars, song_count="characters")


class ChunkTests(unittest.TestCase):
    def test_zero_counts_lines_as_written_exactly_as_before(self):
        lines = [LONG] * 5
        self.assertEqual([len(c) for c in _song_chunks(lines, settings(chars=0))], [3, 2])
        self.assertEqual([len(c) for c in _song_chunks([SHORT] * 10, settings(chars=0))], [4, 3, 3])

    def test_a_long_line_counts_as_two(self):
        lines = [SHORT, LONG, SHORT]                                        # 1 + 2 + 1 = 4: one slide
        self.assertEqual(_song_chunks(lines, settings()), [lines])
        lines = [SHORT, LONG, SHORT, SHORT]                                 # 5 lines of room needed: two slides
        chunks = _song_chunks(lines, settings())
        self.assertEqual(len(chunks), 2)
        self.assertEqual([line for chunk in chunks for line in chunk], lines)        # order and text are kept

    def test_no_slide_holds_more_than_the_maximum(self):
        lines = [LONG, SHORT, LONG, LONG, SHORT, SHORT, LONG]
        for chunk in _song_chunks(lines, settings()):
            cost = sum(-(-len(line) // 40) for line in chunk)
            self.assertLessEqual(cost, 4, chunk)

    def test_slides_are_kept_even(self):
        chunks = _song_chunks([SHORT] * 10, settings(per=4, chars=40))
        self.assertEqual([len(c) for c in chunks], [4, 3, 3])

    def test_a_line_longer_than_a_whole_slide_splits_at_word_breaks(self):
        huge = " ".join(["wonderful"] * 40)                                  # 399 characters: 10 screen lines at 40
        chunks = _song_chunks([huge], settings(per=4, chars=40))
        pieces = [line for chunk in chunks for line in chunk]
        self.assertGreater(len(chunks), 1)
        self.assertEqual(" ".join(pieces), huge)                            # nothing is lost
        for piece in pieces:
            self.assertLessEqual(len(piece), 4 * 40)

    def test_each_part_starts_its_own_count(self):
        self.assertEqual(_song_chunks([SHORT], settings()), [[SHORT]])
        self.assertEqual(_song_chunks([], settings()), [])


class BuilderTests(unittest.TestCase):
    def test_a_theme_and_an_item_can_set_the_limit(self):
        from churchlight_presenter.core.database import DatabaseManager
        from churchlight_presenter.core.items import ItemRef
        from churchlight_presenter.core.slides import SlideBuilder
        db = DatabaseManager(":memory:")
        self.addCleanup(db.close)
        song = db.create_song_with_sections("Test", [("Verse 1", "verse", "\n".join([SHORT, LONG, SHORT, SHORT]))])
        builder = SlideBuilder(db)
        self.assertEqual(len(builder.build_item(ItemRef.song(song))), 1)                  # off: four lines as written
        theme = db.add_theme("Narrow", {"lines_per_slide": 4, "chars_per_line": 40, "song_count": "characters"})
        slides = builder.build_item(ItemRef.song(song, theme_id=theme))
        self.assertEqual(len(slides), 2)                                                  # the long line counts as two
        slides = builder.build_item(ItemRef.song(song, theme_id=theme, overrides={"chars_per_line": 0}))
        self.assertEqual(len(slides), 1)                                                  # an item can turn it off


class SongCountTests(unittest.TestCase):
    def test_lines_mode_ignores_the_character_limit(self):
        from churchlight_presenter.core.database import DatabaseManager
        from churchlight_presenter.core.items import ItemRef
        from churchlight_presenter.core.slides import SlideBuilder
        db = DatabaseManager(":memory:")
        self.addCleanup(db.close)
        song = db.create_song_with_sections("Test", [("Verse 1", "verse", "\n".join([SHORT, LONG, SHORT, SHORT]))])
        builder = SlideBuilder(db)
        for mode, expected in (("lines", 1), ("screen", 2), ("characters", 2)):
            theme = db.add_theme(mode, {"lines_per_slide": 4, "chars_per_line": 40, "song_count": mode})
            self.assertEqual(len(builder.build_item(ItemRef.song(song, theme_id=theme))), expected, mode)
        old = db.add_theme("Old", {"lines_per_slide": 4, "chars_per_line": 40})        # no choice saved: lines
        self.assertEqual(len(builder.build_item(ItemRef.song(song, theme_id=old))), 1)

    def test_lines_on_the_screen_uses_the_themes_own_text_size(self):
        from churchlight_presenter.core.database import DatabaseManager
        from churchlight_presenter.core.items import ItemRef
        from churchlight_presenter.core.slides import SlideBuilder
        from churchlight_presenter.core.themes import projector_line_chars
        db = DatabaseManager(":memory:")
        self.addCleanup(db.close)
        wide = "Amazing grace how sweet the sound that saved a wretch like me"
        song = db.create_song_with_sections("Test", [("Verse 1", "verse", "\n".join([wide, wide, "short", "short"]))])
        builder = SlideBuilder(db)
        builder.use_capacity = True
        small = db.add_theme("Small", {"lines_per_slide": 4, "song_count": "screen", "style": {"font_size": 4}})
        big = db.add_theme("Big", {"lines_per_slide": 4, "song_count": "screen", "style": {"font_size": 9}})
        lines = db.add_theme("Lines", {"lines_per_slide": 4, "song_count": "lines", "style": {"font_size": 9}})
        count = lambda t: len(builder.build_item(ItemRef.song(song, theme_id=t)))
        self.assertGreater(projector_line_chars({"font_size": 4}), projector_line_chars({"font_size": 9}))
        self.assertEqual(count(small), 1)            # both long lines fit on one drawn line each: 4 lines
        self.assertGreater(count(big), 1)            # big text wraps them, so they take more lines than the slide allows
        self.assertEqual(count(lines), 1)            # counting lines in the song ignores the wrapping

    def test_the_choice_is_checked(self):
        self.assertEqual(BUILD_KEYS["song_count"]("screen"), "screen")
        self.assertEqual(BUILD_KEYS["song_count"]("characters"), "screen")           # the first name of it
        with self.assertRaises(ValueError):
            BUILD_KEYS["song_count"]("words")
        with self.assertRaises(ValueError):
            BuildSettings(song_count="words")


class SettingTests(unittest.TestCase):
    def test_the_theme_accepts_zero_to_150(self):
        self.assertEqual(BUILD_KEYS["chars_per_line"](0), 0)
        self.assertEqual(BUILD_KEYS["chars_per_line"](40), 40)
        for bad in (-1, 151, "x"):
            with self.assertRaises(ValueError):
                BUILD_KEYS["chars_per_line"](bad)

    def test_the_build_setting_checks_its_value(self):
        self.assertEqual(BuildSettings().chars_per_line, 0)
        for bad in (-1, True, 2.5):
            with self.assertRaises(ValueError):
                BuildSettings(chars_per_line=bad)


if __name__ == "__main__":
    unittest.main()
