# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The sound comes out of ChurchLight's own window; OBS pages and test windows stay silent."""
import unittest

from churchlight_presenter.ui.controller import LibraryEntry
from tests.test_media_browser import MediaBrowserTests as Base, until


class HearTests(Base):
    def operator(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector("#tab-run")
        return page

    def hear_audio(self, page):
        page.wait_for_timeout(50)                      # lets the browser tell us about new frames
        frame = next((f for f in page.frames if "hear=1" in f.url), None)
        if frame is None:
            return None
        return frame.evaluate("""() => { const a = document.querySelector('audio');
            return a ? { paused: a.paused, muted: a.muted } : null; }""")

    def test_the_operator_page_plays_the_sound_in_a_hidden_copy_of_the_sound_screen(self):
        page = self.operator()
        self.c.new_service("Sunday")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: (self.hear_audio(page) or {}).get("paused") is False, 15))
        self.assertFalse(self.hear_audio(page)["muted"])
        self.assertIn("this ChurchLight window", page.text_content("#clip-where"))

    def test_the_sound_frame_is_on_the_other_loopback_name_so_it_has_connections_of_its_own(self):
        page = self.operator()
        self.c.new_service("Sunday")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: self.hear_audio(page) is not None, 15))
        frame = next(f for f in page.frames if "hear=1" in f.url)
        self.assertTrue(frame.url.startswith("http://localhost:"), frame.url)                  # the operator page is on 127.0.0.1
        mirror = self.browser.new_page()
        mirror.goto(self.base.replace("127.0.0.1", "localhost") + "/operator")
        mirror.wait_for_selector("#tab-run")
        self.c.play_music(self.sound)
        def mirror_frame():
            mirror.wait_for_timeout(50)
            return any(f.url.startswith("http://127.0.0.1:") and "hear=1" in f.url for f in mirror.frames)
        self.assertTrue(until(mirror_frame, 15))

    def test_the_sound_still_plays_from_that_frame_under_the_browsers_normal_autoplay_rules(self):
        strict = self.browser.browser_type.launch()                  # no "allow autoplay" flag: a click on the page is what permits sound
        self.addCleanup(strict.close)
        page = strict.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector("#tab-run")
        page.mouse.click(10, 10)
        self.c.new_service("Sunday")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: (self.hear_audio(page) or {}).get("paused") is False, 15))

    def test_the_sound_page_plays_a_videos_sound_without_a_video_player(self):
        page = self.operator()
        self.c.new_service("Sunday")
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))
        self.assertTrue(until(lambda: self.hear_audio(page) is not None, 15))
        frame = next(f for f in page.frames if "hear=1" in f.url)
        self.assertEqual(frame.evaluate("document.querySelectorAll('video').length"), 0)       # no second picture to decode

    def test_the_setting_turns_it_off_and_on(self):
        page = self.operator()
        self.c.new_service("Sunday")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: self.hear_audio(page) is not None, 15))
        page.evaluate("showView('shortcuts')")
        page.eval_on_selector("#hear-on", "e => { for (let n = e.parentElement; n; n = n.parentElement) if (n.tagName === 'DETAILS') n.open = true; }")
        page.eval_on_selector("#hear-on", "e => e.click()")
        self.assertTrue(until(lambda: self.hear_audio(page) is None))
        page.eval_on_selector("#hear-on", "e => e.click()")
        self.assertTrue(until(lambda: (self.hear_audio(page) or {}).get("paused") is False, 15))

    def test_every_other_page_is_silent_unless_its_address_asks_for_sound(self):
        self.c.play_music(self.sound)
        obs = self.browser.new_page()
        obs.add_init_script("window.obsstudio = {pluginVersion: '2.0'}")
        obs.goto(f"{self.base}/view/main")
        plain = self.page("main")                                           # a browser tab, an XSplit web page
        kiosk = self.page("main", "?kiosk=1")
        for page in (obs, plain, kiosk):
            self.assertTrue(until(lambda: self.audio(page) is not None))
            self.assertTrue(self.audio(page)["muted"])
        loud = self.page("main", "?sound=on")
        self.assertTrue(until(lambda: self.audio(loud) is not None))
        self.assertFalse(self.audio(loud)["muted"])

    def test_a_second_operator_window_on_this_computer_stays_quiet(self):
        context = self.browser.new_context(viewport={"width": 1400, "height": 1000})        # the same browser: its windows share the lock
        first = context.new_page()
        first.goto(self.base + "/operator")
        first.wait_for_selector("#tab-run")
        self.c.new_service("Sunday")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: (self.hear_audio(first) or {}).get("paused") is False, 15))
        second = context.new_page()
        second.goto(self.base + "/operator")
        second.wait_for_selector("#tab-run")
        self.assertTrue(until(lambda: "Another ChurchLight window" in (second.text_content("#clip-where") or ""), 15))
        self.assertIsNone(self.hear_audio(second))
        self.assertIsNotNone(self.hear_audio(first))


del Base                                  # so the base tests are not run a second time here

if __name__ == "__main__":
    unittest.main()
