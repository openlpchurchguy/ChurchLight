# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Importer tests. All song and Bible text here is made-up placeholder text."""
import io
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.items import ItemRef
from churchlight_presenter.core.slides import SlideBuilder
from churchlight_presenter.importers import bibles, songs
from churchlight_presenter.importers.common import ImporterError, parse_xml

OL = "http://openlyrics.info/namespace/2009/song"


def song_xml(title="Placeholder Song", verses=None, order="v1 c v2 c", extra_props="",
             authors=("Ann Author", "Bob Writer")):
    verses = verses if verses is not None else [
        ('v1', None, "First line one<br/>First line two"),
        ('c', None, "Chorus line one<br/>Chorus <chord name=\"G\"/>line two"),
        ('v2', None, "Second line one<br/>Second line two"),
    ]
    body = "".join(
        f'<verse name="{n}"' + (f' lang="{l}"' if l else "") + f"><lines>{t}</lines></verse>"
        for n, l, t in verses)
    author_xml = "".join(f"<author>{a}</author>" for a in authors)
    return (f'<?xml version="1.0" encoding="UTF-8"?><song xmlns="{OL}" version="0.8">'
            f"<properties><titles><title>{title}</title></titles><authors>{author_xml}</authors>"
            f"<copyright>2000 Placeholder</copyright><ccliNo>12345</ccliNo><key>G</key>"
            f"<verseOrder>{order}</verseOrder>{extra_props}</properties>"
            f"<lyrics>{body}</lyrics></song>")


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)

    def write(self, name, text, mode="w"):
        path = self.tmp / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if mode == "w":
            path.write_text(text, encoding="utf-8")
        else:
            path.write_bytes(text)
        return path


class ParseOpenLyricsTests(unittest.TestCase):
    def test_fields_sections_and_order(self):
        song = songs.parse_openlyrics(song_xml())
        self.assertEqual((song.title, song.author, song.copyright, song.ccli_number,
                          song.default_key), ("Placeholder Song", "Ann Author, Bob Writer",
                                              "2000 Placeholder", "12345", "G"))
        self.assertEqual(song.sections, [
            ("Verse 1", "verse", "First line one\nFirst line two"),
            ("Chorus", "chorus", "Chorus line one\nChorus line two"),   # the chord is gone
            ("Verse 2", "verse", "Second line one\nSecond line two")])
        self.assertEqual(song.order, ["Verse 1", "Chorus", "Verse 2", "Chorus"])

    def test_no_verse_order_means_document_order(self):
        song = songs.parse_openlyrics(song_xml(order=""))
        self.assertEqual(song.order, ["Verse 1", "Chorus", "Verse 2"])

    def test_unknown_names_in_the_order_are_skipped_with_a_warning(self):
        song = songs.parse_openlyrics(song_xml(order="v1 x9 c"))
        self.assertEqual(song.order, ["Verse 1", "Chorus"])
        self.assertIn("x9", song.warnings[0])

    def test_section_types_and_labels(self):
        verses = [("v1", None, "a"), ("c2", None, "b"), ("b", None, "c"), ("p", None, "d"),
                  ("i", None, "e"), ("e", None, "f"), ("o", None, "g"), ("z9", None, "h")]
        song = songs.parse_openlyrics(song_xml(verses=verses, order=""))
        self.assertEqual([(l, t) for l, t, _ in song.sections], [
            ("Verse 1", "verse"), ("Chorus 2", "chorus"), ("Bridge", "bridge"),
            ("Pre-Chorus", "pre_chorus"), ("Intro", "intro"), ("Ending", "outro"),
            ("Other", "other"), ("z9", "other")])

    def test_markup_inside_lines_keeps_its_words_and_indentation_is_ignored(self):
        xml = song_xml(verses=[("v1", None, "\n      Hello <tag name='i'>gentle</tag> world\n"
                                            "      <br/>   next   line  \n")], order="")
        self.assertEqual(songs.parse_openlyrics(xml).sections[0][2], "Hello gentle world\nnext line")

    def test_a_second_language_is_left_out_with_a_warning(self):
        verses = [("v1", "en", "English"), ("v1", "de", "Deutsch")]
        song = songs.parse_openlyrics(song_xml(verses=verses, order=""))
        self.assertEqual([s[2] for s in song.sections], ["English"])
        self.assertIn("'de'", song.warnings[0])

    def test_repeated_verse_names_get_distinct_labels(self):
        song = songs.parse_openlyrics(song_xml(verses=[("v1", None, "a"), ("v1", None, "b")], order=""))
        self.assertEqual([s[0] for s in song.sections], ["Verse 1", "Verse 1 (2)"])

    def test_comments_become_notes_and_empty_verses_are_dropped(self):
        xml = song_xml(extra_props="<comments><comment>Capo 2</comment></comments>",
                       verses=[("v1", None, "words"), ("v2", None, "   ")], order="v1 v2")
        song = songs.parse_openlyrics(xml)
        self.assertEqual((song.notes, [s[0] for s in song.sections], song.order),
                         ("Capo 2", ["Verse 1"], ["Verse 1"]))

    def test_bad_documents_have_clear_errors(self):
        for data, message in (("not xml", "not valid XML"),
                              ("<other/>", "not an OpenLyrics song"),
                              (song_xml(verses=[]), "no lyrics"),
                              ('<!DOCTYPE s [<!ENTITY a "b">]><song/>', "unsafe")):
            with self.assertRaisesRegex(ImporterError, message):
                songs.parse_openlyrics(data)

    def test_older_documents_without_a_namespace_still_read(self):
        xml = song_xml().replace(f' xmlns="{OL}"', "")
        self.assertEqual(songs.parse_openlyrics(xml).title, "Placeholder Song")


class ImportSongsTests(Base):
    def test_a_song_lands_in_the_library_and_builds_slides(self):
        path = self.write("one.xml", song_xml())
        report = songs.import_openlyrics(self.db, path)
        self.assertEqual((len(report.imported), report.duplicates, report.failed), (1, 0, []))
        row = self.db.get_song(report.imported[0])
        self.assertEqual((row["title"], row["author"], row["ccli_number"]),
                         ("Placeholder Song", "Ann Author, Bob Writer", "12345"))
        slides = SlideBuilder(self.db).build_item(ItemRef.song(row["id"]))
        self.assertEqual([s.label for s in slides], ["Verse 1", "Chorus", "Verse 2", "Chorus"])
        self.assertEqual(self.db.search_songs("Chorus line")[0]["id"], row["id"])   # searchable

    def test_the_same_song_is_not_added_twice_but_a_different_one_with_the_same_title_is(self):
        songs.import_openlyrics(self.db, self.write("a.xml", song_xml()))
        again = songs.import_openlyrics(self.db, self.write("b.xml", song_xml()))
        self.assertEqual((len(again.imported), again.duplicates), (0, 1))
        other = songs.import_openlyrics(self.db, self.write(
            "c.xml", song_xml(verses=[("v1", None, "different words")], order="")))
        self.assertEqual(len(other.imported), 1)
        forced = songs.import_openlyrics(self.db, self.write("d.xml", song_xml()), force=True)
        self.assertEqual(len(forced.imported), 1)
        self.assertEqual(len(self.db.search_song()), 3)

    def test_a_folder_imports_what_it_can_and_reports_the_rest(self):
        self.write("good.xml", song_xml(title="Good"))
        self.write("sub/also.xml", song_xml(title="Also"))
        self.write("broken.xml", "<song><oops")
        self.write("empty.xml", song_xml(title="Empty", verses=[]))
        self.write("notes.docx", "ignored")
        report = songs.import_openlyrics(self.db, self.tmp)
        self.assertEqual(len(report.imported), 2)
        self.assertEqual(sorted(name for name, _ in report.failed), ["broken.xml", "empty.xml"])

    def test_a_song_without_a_title_uses_the_file_name(self):
        path = self.write("Amazing Thing.xml", song_xml(title=""))
        report = songs.import_openlyrics(self.db, path)
        self.assertEqual(self.db.get_song(report.imported[0])["title"], "Amazing Thing")
        self.assertIn("file name", report.warnings[0][1])

    def test_missing_and_empty_inputs(self):
        with self.assertRaisesRegex(ImporterError, "not found"):
            songs.import_openlyrics(self.db, self.tmp / "nope.xml")
        (self.tmp / "empty").mkdir()
        with self.assertRaisesRegex(ImporterError, "no song files"):
            songs.import_openlyrics(self.db, self.tmp / "empty")

    def test_command_line(self):
        self.write("s.xml", song_xml())
        out = io.StringIO()
        code = songs.main([str(self.tmp / "s.xml"), "--db", str(self.tmp / "c.db")], out=out)
        self.assertEqual(code, 0)
        self.assertIn("Imported 1 songs", out.getvalue())
        self.assertEqual(songs.main([str(self.tmp / "none.xml"), "--db", str(self.tmp / "c.db")],
                                    out=io.StringIO()), 1)


# ---------------------------------------------------------------------------
def zefania(books, extra_info=""):
    body = ""
    for number, chapters in books:
        body += f'<BIBLEBOOK bnumber="{number}">'
        for c, verses in chapters:
            body += f'<CHAPTER cnumber="{c}">' + "".join(
                f'<VERS vnumber="{v}">{t}</VERS>' for v, t in verses) + "</CHAPTER>"
        body += "</BIBLEBOOK>"
    return ('<?xml version="1.0" encoding="UTF-8"?><XMLBIBLE biblename="Demo Bible">'
            f"<INFORMATION><title>Demo Bible Title</title><identifier>demo1</identifier>"
            f"<language>en</language><rights>Placeholder rights</rights>{extra_info}</INFORMATION>"
            f"{body}</XMLBIBLE>")


SAMPLE = [(43, [(3, [(16, "Placeholder sixteen."), (17, "Placeholder seventeen.")])]),
          (1, [(1, [(1, "Placeholder genesis one.")])])]


class BibleTests(Base):
    def test_zefania_end_to_end_and_typed_references_work(self):
        report = bibles.import_bible(self.db, self.write("demo.xml", zefania(SAMPLE)))
        self.assertEqual((report.abbreviation, report.verse_count, report.book_count),
                         ("DEMO1", 3, 2))
        trans = self.db.get_translation("DEMO1")
        self.assertEqual((trans["name"], trans["language"], trans["license_notes"]),
                         ("Demo Bible", "en", "Placeholder rights"))
        ref = ItemRef.from_reference(self.db, "DEMO1", "jn 3:16-17")
        slides = SlideBuilder(self.db).build_item(ref)
        self.assertEqual(slides[0].reference, "John 3:16-17")
        self.assertIn("Placeholder sixteen.", slides[0].text)

    def test_options_override_the_file(self):
        report = bibles.import_bible(self.db, self.write("d.xml", zefania(SAMPLE)),
                                     abbreviation="xyz", name="Mine", language="es",
                                     license_notes="Mine to use")
        trans = self.db.get_translation("XYZ")
        self.assertEqual((report.abbreviation, trans["name"], trans["language"],
                          trans["license_notes"]), ("XYZ", "Mine", "es", "Mine to use"))

    def test_footnotes_are_left_out_and_inline_markup_keeps_its_words(self):
        xml = zefania([(43, [(1, [(1, "In <STYLE>the</STYLE> start<NOTE>a footnote</NOTE> was\n  words.")])])])
        bibles.import_bible(self.db, self.write("n.xml", xml))
        self.assertEqual(self.db.get_passage("DEMO1", "John", 1, 1)[0]["text"], "In the start was words.")

    def test_book_names_work_when_numbers_are_missing(self):
        xml = zefania(SAMPLE).replace('bnumber="43"', 'bname="John"')
        bibles.import_bible(self.db, self.write("b.xml", xml))
        self.assertEqual(len(self.db.get_passage("DEMO1", "John", 3, 16, 17)), 2)

    def test_csv_with_header_abbreviations_and_commas_in_text(self):
        text = ('Book,Chapter,Verse,Text\nJn,3,16,"Placeholder, with a comma."\n'
                "john,3,17,Placeholder seventeen.\n43,3,18,Eighteen\n\n")
        report = bibles.import_bible(self.db, self.write("c.csv", text), "CSV1", "Csv")
        self.assertEqual(report.verse_count, 3)
        self.assertEqual(self.db.get_passage("CSV1", "John", 3, 16)[0]["text"],
                         "Placeholder, with a comma.")

    def test_tsv_and_a_byte_order_mark(self):
        data = "﻿John\t3\t16\tTab separated.\n".encode("utf-8")
        bibles.import_bible(self.db, self.write("t.tsv", data, mode="b"), "TSV1")
        self.assertEqual(self.db.get_passage("TSV1", "John", 3, 16)[0]["text"], "Tab separated.")

    def test_duplicate_verses_keep_the_first_and_warn(self):
        dup = [(43, [(3, [(16, "first"), (16, "second")])])]
        report = bibles.import_bible(self.db, self.write("d.xml", zefania(dup)))
        self.assertEqual(report.verse_count, 1)
        self.assertEqual(self.db.get_passage("DEMO1", "John", 3, 16)[0]["text"], "first")
        self.assertIn("twice", report.warnings[0])

    def test_a_translation_cannot_be_installed_twice(self):
        path = self.write("d.xml", zefania(SAMPLE))
        bibles.import_bible(self.db, path)
        with self.assertRaisesRegex(ImporterError, "already installed"):
            bibles.import_bible(self.db, path)

    def test_a_bad_file_leaves_nothing_behind(self):
        bad = [(43, [(3, [(16, "ok")])]), (99, [(1, [(1, "no such book")])])]
        with self.assertRaisesRegex(ImporterError, "between 1 and 66"):
            bibles.import_bible(self.db, self.write("x.xml", zefania(bad)))
        self.assertIsNone(self.db.get_translation("DEMO1"))

    def test_input_errors_are_clear(self):
        cases = [("a.csv", "Gen,1,1\n", "expected book"),
                 ("b.csv", "Gen,x,1,text\nGen,one,1,t\n", "not a number"),
                 ("c.csv", "Nowhere,1,1,text\n", "Unknown book"),
                 ("d.csv", "Gen,0,1,text\n", "1 or more"),
                 ("e.xml", "<other/>", "not Zefania"),
                 ("f.xml", zefania([]), "no verses"),
                 ("g.pdf", "x", "must be .xml")]
        for name, content, message in cases:
            with self.assertRaisesRegex(ImporterError, message, msg=name):
                bibles.import_bible(self.db, self.write(name, content))
        with self.assertRaisesRegex(ImporterError, "not found"):
            bibles.import_bible(self.db, self.tmp / "missing.xml")

    def test_a_full_size_bible_is_fast_enough(self):
        import time
        chapters = [(c, [(v, f"Placeholder {c}:{v}") for v in range(1, 31)]) for c in range(1, 51)]
        books = [(n, chapters) for n in range(1, 21)]           # 30,000 verses
        path = self.write("big.xml", zefania(books))
        started = time.monotonic()
        report = bibles.import_bible(self.db, path)
        self.assertEqual(report.verse_count, 30000)
        self.assertLess(time.monotonic() - started, 20)

    def test_command_line(self):
        path = self.write("d.xml", zefania(SAMPLE))
        out = io.StringIO()
        code = bibles.main([str(path), "--db", str(self.tmp / "c.db"), "--abbr", "dm"], out=out)
        self.assertEqual(code, 0)
        self.assertIn("Imported DM: 3 verses in 2 books", out.getvalue())
        self.assertEqual(bibles.main([str(path), "--db", str(self.tmp / "c.db"), "--abbr", "dm"],
                                     out=io.StringIO()), 1)


class CommonTests(unittest.TestCase):
    def test_namespaces_are_stripped_and_entities_refused(self):
        root = parse_xml('<a xmlns="http://x"><b xmlns:q="http://q"><q:c/></b></a>')
        self.assertEqual([n.tag for n in root.iter()], ["a", "b", "c"])
        with self.assertRaises(ImporterError):
            parse_xml('<!DOCTYPE x [<!ENTITY a "b">]><x>&a;</x>')


if __name__ == "__main__":
    unittest.main()



class OtherSongFormatTests(unittest.TestCase):
    """Plain text (SongSelect style), ChordPro and OpenSong files."""

    def setUp(self):
        import tempfile
        from pathlib import Path
        self.dir = Path(tempfile.mkdtemp())

    def write(self, name, text):
        path = self.dir / name
        path.write_text(text, encoding="utf-8")
        return path

    def test_songselect_style_text(self):
        from churchlight_presenter.importers.songfiles import parse_song_file
        p = self.write("Amazing Grace.txt", "Amazing Grace\n\nVerse 1\nAmazing grace\nHow sweet\n\nChorus\nMy chains\n\n"
                       "Verse 2\nThrough many\n\nChorus\nMy chains\n\nCCLI Song # 22025\nJohn Newton\n"
                       "\u00a9 Public Domain\nFor use solely with the SongSelect Terms of Use. www.ccli.com\nCCLI License # 1\n")
        song = parse_song_file(p)
        self.assertEqual((song.title, song.author, song.ccli_number), ("Amazing Grace", "John Newton", "22025"))
        self.assertEqual([s[0] for s in song.sections], ["Verse 1", "Chorus", "Verse 2"])
        self.assertEqual(song.order, ["Verse 1", "Chorus", "Verse 2", "Chorus"])
        self.assertNotIn("ccli", " ".join(s[2] for s in song.sections).lower())

    def test_plain_lyrics_without_headings_become_verses_titled_from_the_file(self):
        from churchlight_presenter.importers.songfiles import parse_song_file
        song = parse_song_file(self.write("My Song.txt", "one\ntwo\n\nthree\n"))
        self.assertEqual(song.title, "My Song")
        self.assertEqual([s[0] for s in song.sections], ["Verse 1", "Verse 2"])

    def test_chordpro_drops_chords_and_keeps_structure(self):
        from churchlight_presenter.importers.songfiles import parse_song_file
        song = parse_song_file(self.write("a.cho", "{title: Hi}\n{artist: Bob}\n{start_of_verse}\n[G]Hello [C]world\n"
                                          "{end_of_verse}\n{start_of_chorus}\nLa [D]la\n{end_of_chorus}\n{chorus}\n"))
        self.assertEqual((song.title, song.author), ("Hi", "Bob"))
        self.assertEqual(song.sections[0][2], "Hello world")
        self.assertEqual(song.order, ["Verse 1", "Chorus", "Chorus"])

    def test_opensong_without_an_extension(self):
        from churchlight_presenter.importers.songfiles import parse_song_file
        song = parse_song_file(self.write("How Great", '<song><title>How Great</title><author>Carl</author>'
                                          '<presentation>V1 C V1</presentation><lyrics>[V1]\n.G C\n Then sings\n[C]\n How great|Thou art</lyrics></song>'))
        self.assertEqual(song.title, "How Great")
        self.assertEqual(song.sections[0][2], "Then sings")
        self.assertEqual(song.sections[1][2], "How great\nThou art")
        self.assertEqual(song.order, ["Verse 1", "Chorus", "Verse 1"])

    def test_a_folder_of_mixed_formats_imports_and_skips_duplicates(self):
        from churchlight_presenter.core.database import DatabaseManager
        self.write("a.txt", "Verse 1\nOne\ntwo\n")
        self.write("b.cho", "{title: B}\nHello [G]there\n")
        db = DatabaseManager(self.dir / "t.db")
        report = songs.import_openlyrics(db, self.dir)
        self.assertEqual((len(report.imported), len(report.failed)), (2, 0))
        self.assertEqual(songs.import_openlyrics(db, self.dir).duplicates, 2)
