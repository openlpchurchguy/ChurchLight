# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A deck's picture size: fit, fill or stretch, and pictures that always grow to the screen."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import PUBLIC_SLIDE_FIELDS
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


def make():
    db = DatabaseManager(":memory:", shared=True)
    deck = db.add_presentation("Deck", [("d/1.png", None), ("d/2.png", None)])
    c = OperatorController(db)
    c.new_service("S")
    c.add_entry(LibraryEntry("presentation", deck, ""))
    return db, c, OperatorApi(c), deck


class PictureSizeTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api, self.deck = make()
        self.addCleanup(self.db.close)

    def slides(self):
        return self.c.session.slides

    def test_a_deck_starts_as_fit_and_its_slides_say_so(self):
        self.assertEqual(self.db.get_presentation(self.deck)["image_fit"], "fit")
        self.assertEqual({s.image_fit for s in self.slides()}, {"fit"})
        self.assertIn("image_fit", PUBLIC_SLIDE_FIELDS)

    def test_changing_it_updates_the_slides_already_loaded(self):
        self.api.call("deck_image_fit", {"id": self.deck, "fit": "fill"})
        self.assertEqual({s.image_fit for s in self.slides()}, {"fill"})
        self.api.call("deck_image_fit", {"id": self.deck, "fit": "stretch"})
        self.assertEqual({s.image_fit for s in self.slides()}, {"stretch"})

    def test_it_shows_in_the_library_overview(self):
        self.api.call("deck_image_fit", {"id": self.deck, "fit": "fill"})
        self.assertEqual(self.api.manage()["decks"][0]["image_fit"], "fill")

    def test_bad_choices_are_refused(self):
        with self.assertRaises(ApiError):
            self.api.call("deck_image_fit", {"id": self.deck, "fit": "zoom"})
        with self.assertRaises(ApiError):
            self.api.call("deck_image_fit", {"id": 999, "fit": "fill"})

    def test_it_goes_out_to_the_public_pages(self):
        self.api.call("deck_image_fit", {"id": self.deck, "fit": "stretch"})
        self.c.go_live_service_item(self.c.service_rows()[0].item_id)
        payload = self.c.payloads()["projector"]
        self.assertEqual(payload["base"]["image_fit"], "stretch")

    def test_the_database_only_accepts_the_three_values(self):
        import sqlite3
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.conn.execute("UPDATE presentations SET image_fit = 'zoom'")


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageTests(unittest.TestCase):
    def test_the_page_puts_the_choice_on_the_picture_layer(self):
        script = ("const m=require(process.argv[1]);"
                  "const v=(f)=>m.viewModel({layout:'projector',audience:'public',base:{kind:'image',image_path:'d/1.png',image_fit:f},overlay:null}).layers[0].view.fit;"
                  "console.log(JSON.stringify([v('fill'),v('stretch'),v(undefined)]))")
        out = subprocess.run(["node", "-e", script, str(STATIC / "output.js")], capture_output=True, text=True, timeout=30, check=True)
        self.assertEqual(json.loads(out.stdout), ["fill", "stretch", "fit"])

    def test_the_stylesheet_scales_pictures_up_to_the_screen(self):
        css = (STATIC / "output.css").read_text(encoding="utf-8")
        self.assertIn(".layer.image img { width: 100%; height: 100%;", css)
        self.assertIn("object-fit: cover", css)
        self.assertIn("object-fit: fill", css)


if __name__ == "__main__":
    unittest.main()
