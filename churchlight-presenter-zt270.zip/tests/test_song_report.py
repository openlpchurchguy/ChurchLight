# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The Report button: one running list of the songs used, a section per service (name and date)."""
import unittest

from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.test_library_admin import AdminBase, TEXT

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


class ReportBase(AdminBase):
    def setUp(self):
        super().setUp()
        self.api = OperatorApi(self.c)
        self.c.create_song("Amazing Grace", "John Newton", TEXT, ccli="4755360")
        self.c.create_song("Plain Song", "", TEXT)
        self.c.create_song("Third Song", "Ann", TEXT, ccli="123")

    def start(self, title, songs=()):
        self.c.new_service(title)
        for name in songs:
            self.c.add_entry(self.entry("song", name))

    def sections(self):
        return self.c.song_report()["sections"]


class ReportTests(ReportBase):
    def test_it_lists_the_songs_of_the_service_under_its_name_and_date(self):
        self.start("Sunday Worship", ["Amazing Grace", "Plain Song"])
        reply = self.c.report_service()
        self.assertEqual((reply["title"], reply["songs"], reply["replaced"]), ("Sunday Worship", 2, False))
        (section,) = self.sections()
        self.assertEqual(section["title"], "Sunday Worship")
        self.assertEqual(section["date"], self.db.get_service(self.c.service_id)["service_date"])
        self.assertEqual([(s["title"], s["author"], s["ccli"]) for s in section["songs"]],
                         [("Amazing Grace", "John Newton", "4755360"), ("Plain Song", "", "")])

    def test_only_songs_count_and_in_service_order(self):
        self.start("S", ["Third Song"])
        self.c.add_announcement("Welcome", "Good morning")        # not a song: left out
        self.c.add_entry(self.entry("song", "Amazing Grace"))
        self.c.report_service()
        self.assertEqual([s["title"] for s in self.sections()[0]["songs"]], ["Third Song", "Amazing Grace"])

    def test_a_song_used_twice_is_listed_once(self):
        self.start("S", ["Amazing Grace", "Plain Song", "Amazing Grace"])
        self.assertEqual(self.c.report_service()["songs"], 2)

    def test_pressing_it_again_updates_the_same_section(self):
        self.start("Sunday", ["Amazing Grace"])
        self.c.report_service()
        self.c.add_entry(self.entry("song", "Plain Song"))
        reply = self.c.report_service()
        self.assertTrue(reply["replaced"])
        (section,) = self.sections()
        self.assertEqual([s["title"] for s in section["songs"]], ["Amazing Grace", "Plain Song"])

    def test_each_service_gets_its_own_section_in_one_list(self):
        self.start("Sunday 8:30", ["Amazing Grace"])
        self.c.report_service()
        self.start("Sunday 11:00", ["Plain Song", "Third Song"])
        self.c.report_service()
        titles = sorted(s["title"] for s in self.sections())
        self.assertEqual(titles, ["Sunday 11:00", "Sunday 8:30"])
        text = self.c.song_report()["text"]
        self.assertIn("Sunday 8:30 — ", text)
        self.assertIn("1. Amazing Grace (John Newton, CCLI 4755360)", text)
        self.assertIn("2. Third Song (Ann, CCLI 123)", text)
        self.assertIn("1. Plain Song\n", text + "\n")

    def test_the_list_keeps_a_song_as_it_was_reported(self):
        self.start("S", ["Amazing Grace"])
        self.c.report_service()
        song = self.entry("song", "Amazing Grace").id
        self.c.update_song(song, "Renamed", "Someone", TEXT, ccli="999")
        self.assertEqual(self.sections()[0]["songs"][0]["title"], "Amazing Grace")
        self.c.report_service()                           # reporting again takes the song's current details
        self.assertEqual(self.sections()[0]["songs"][0]["title"], "Renamed")

    def test_a_service_with_no_songs_or_no_service_is_refused_and_nothing_changes(self):
        with self.assertRaises(ControllerError):
            self.c.report_service()
        self.start("Empty")
        with self.assertRaises(ControllerError):
            self.c.report_service()
        self.assertEqual(self.sections(), [])

    def test_removing_a_section(self):
        self.start("A", ["Amazing Grace"])
        self.c.report_service()
        self.start("B", ["Plain Song"])
        self.c.report_service()
        gone = next(s for s in self.sections() if s["title"] == "A")["section"]
        self.c.remove_report_section(gone)
        self.assertEqual([s["title"] for s in self.sections()], ["B"])
        with self.assertRaises(ControllerError):
            self.c.remove_report_section(gone)
        for bad in (True, "1", None):
            with self.assertRaises(ControllerError):
                self.c.remove_report_section(bad)

    def test_deleting_a_service_keeps_its_section_and_a_reused_id_cannot_overwrite_it(self):
        self.start("Old", ["Amazing Grace"])
        old_id = self.c.service_id
        self.c.report_service()
        self.db.delete_service(old_id)
        self.assertEqual([s["title"] for s in self.sections()], ["Old"])
        self.start("New", ["Plain Song"])                 # SQLite may hand out the same id again
        self.c.report_service()
        self.assertEqual(sorted(s["title"] for s in self.sections()), ["New", "Old"])

    def test_the_rows_are_stored_in_the_database(self):
        self.start("S", ["Amazing Grace"])
        self.c.report_service()
        self.assertEqual(len(self.db.get_song_report()), 1)


class ApiTests(ReportBase):
    def test_actions(self):
        self.start("S", ["Amazing Grace"])
        reply = self.api.call("report_service")
        self.assertEqual(reply["reported"]["songs"], 1)
        listed = self.api.call("report_list")["report"]
        self.assertEqual(len(listed["sections"]), 1)
        self.api.call("report_remove", {"section": listed["sections"][0]["section"]})
        self.assertEqual(self.api.call("report_list")["report"]["sections"], [])

    def test_errors_are_plain_words(self):
        with self.assertRaises(ApiError) as caught:
            self.api.call("report_service")
        self.assertIn("Open a service", str(caught.exception))
        with self.assertRaises(ApiError):
            self.api.call("report_remove", {})


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class ButtonTests(ReportBase):
    def test_the_button_and_the_list_on_the_service_tab(self):
        import time
        self.db.close()                                   # the page needs a database that other threads may use
        self.setUp_shared()
        self.start("Sunday Worship", ["Amazing Grace", "Plain Song"])
        server = self.c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#report-btn", state="visible")
        page.click("#report-btn")
        self.assertEqual(page.inner_text("#report-btn"), "Sure?")           # the second press confirms, in the same place
        page.click("#report-btn")
        end = time.time() + 5
        while time.time() < end and "Added the report" not in page.inner_text("#message"):
            time.sleep(0.05)
        self.assertIn("Sunday Worship", page.inner_text("#message"))
        self.assertIn("2 songs", page.inner_text("#message"))
        self.assertFalse(page.is_visible("#report-list-btn"))             # the list is on the Song Library tab only
        page.click("#tab-songs")
        page.click("#report-list-btn")
        page.wait_for_selector("#report-sections .report-section", state="visible")
        self.assertIn("Sunday Worship", page.inner_text("#report-sections h4"))
        self.assertEqual(len(page.query_selector_all("#report-sections li")), 2)
        page.click("#tab-run")
        page.click("#report-btn")                         # again: updated, still one section
        page.click("#report-btn")
        end = time.time() + 5
        while time.time() < end and "Updated the report" not in page.inner_text("#message"):
            time.sleep(0.05)
        self.assertIn("Updated the report", page.inner_text("#message"))
        page.click("#tab-songs")
        self.assertEqual(len(page.query_selector_all("#report-sections .report-section")), 1)
        page.click("#tab-run")
        page.click("#mode-run")
        self.assertFalse(page.is_visible("#report-btn"))                  # Plan side only

    def setUp_shared(self):
        from churchlight_presenter.core.database import DatabaseManager
        from churchlight_presenter.ui.controller import OperatorController
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        from tests.test_library_admin import TEXT as text
        self.c.create_song("Amazing Grace", "John Newton", text, ccli="4755360")
        self.c.create_song("Plain Song", "", text)


if __name__ == "__main__":
    unittest.main()
