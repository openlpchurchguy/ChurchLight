# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The deck editor (Stage C): a delay and a transition for each slide, and how they combine with the
deck's and the service's settings."""
import sqlite3
import time
import unittest

from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.test_autoplay import TimerBase


class Base(TimerBase):
    def setUp(self):
        super().setUp()
        self.api = OperatorApi(self.c)

    def ids(self, deck=None):
        return [p["id"] for p in self.db.get_presentation_pages(deck or self.deck)]

    def slides(self):
        return self.c.session.slides

    def entry(self):
        return next(e for e in self.c.search_library("Welcome") if e.kind == "presentation")


class StorageTests(Base):
    def test_migration_ten_adds_empty_settings_to_existing_pages(self):
        from churchlight_presenter.core import migrations
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        migrations.migrate(conn, migrations.MIGRATIONS[:9])
        conn.execute("INSERT INTO presentations (name) VALUES ('Old')")
        conn.execute("INSERT INTO presentation_pages (presentation_id, page_number, image_path) VALUES (1, 1, 'x.png')")
        migrations.migrate(conn)
        row = conn.execute("SELECT * FROM presentation_pages").fetchone()
        self.assertEqual((row["auto_seconds"], row["transition"], row["transition_ms"]), (None, None, None))
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], 20)
        conn.close()

    def test_the_database_refuses_out_of_range_values(self):
        page = self.ids()[0]
        for sql in ("UPDATE presentation_pages SET auto_seconds = 601 WHERE id = ?",
                    "UPDATE presentation_pages SET transition = 'wipe' WHERE id = ?",
                    "UPDATE presentation_pages SET transition_ms = 2100 WHERE id = ?"):
            with self.assertRaises(sqlite3.IntegrityError):
                self.db.conn.execute(sql, (page,))

    def test_the_editor_view_carries_the_deck_and_page_settings(self):
        a = self.ids()[0]
        self.c.set_deck_autoplay(self.deck, 4, "loop")
        self.c.set_deck_pages_timing(self.deck, [a], seconds=7, transition="dissolve", ms=800)
        info = self.c.deck_for_editing(self.deck)
        self.assertEqual(info["deck"], {"auto_seconds": 4, "end_action": "loop", "transition": "none", "transition_ms": 500})
        first, second = info["pages"][:2]
        self.assertEqual((first["auto_seconds"], first["transition"], first["transition_ms"]), (7, "dissolve", 800))
        self.assertEqual((second["auto_seconds"], second["transition"], second["transition_ms"]), (None, None, None))


class SettingTests(Base):
    def test_several_slides_can_be_set_at_once_and_put_back(self):
        a, b, c = self.ids()
        self.c.set_deck_pages_timing(self.deck, [a, c], seconds=3)
        self.assertEqual([p["auto_seconds"] for p in self.db.get_presentation_pages(self.deck)], [3, None, 3])
        self.c.set_deck_pages_timing(self.deck, [a], seconds=None)
        self.assertEqual([p["auto_seconds"] for p in self.db.get_presentation_pages(self.deck)], [None, None, 3])

    def test_delay_and_transition_are_set_independently(self):
        a = self.ids()[0]
        self.c.set_deck_pages_timing(self.deck, [a], seconds=5)
        self.c.set_deck_pages_timing(self.deck, [a], transition="circle_out", ms=1000)
        row = self.db.get_presentation_pages(self.deck)[0]
        self.assertEqual((row["auto_seconds"], row["transition"], row["transition_ms"]), (5, "circle_out", 1000))
        self.c.set_deck_pages_timing(self.deck, [a], transition=None, ms=None)
        row = self.db.get_presentation_pages(self.deck)[0]
        self.assertEqual((row["auto_seconds"], row["transition"], row["transition_ms"]), (5, None, None))

    def test_bad_values_change_nothing(self):
        a = self.ids()[0]
        bad = [dict(seconds=601), dict(seconds=-1), dict(seconds=1.5), dict(seconds=True),
               dict(transition="wipe", ms=500), dict(transition="dissolve", ms=150),
               dict(transition="dissolve", ms=3000), dict(transition="dissolve"), dict(ms=500),
               dict(transition=None, ms=500), dict()]
        for args in bad:
            with self.assertRaises(ControllerError, msg=str(args)):
                self.c.set_deck_pages_timing(self.deck, [a], **args)
        row = self.db.get_presentation_pages(self.deck)[0]
        self.assertEqual((row["auto_seconds"], row["transition"], row["transition_ms"]), (None, None, None))

    def test_a_page_of_another_deck_or_nothing_chosen_is_refused(self):
        other = self.make_deck("Other", 2)
        with self.assertRaises(ControllerError):
            self.c.set_deck_pages_timing(self.deck, [self.ids(other)[0]], seconds=2)
        with self.assertRaises(ControllerError):
            self.c.set_deck_pages_timing(self.deck, [], seconds=2)

    def test_a_live_deck_cannot_be_changed(self):
        self.live_alone()
        with self.assertRaisesRegex(ControllerError, "live"):
            self.c.set_deck_pages_timing(self.deck, [self.ids()[0]], seconds=2)

    def test_the_api_changes_only_what_it_is_given(self):
        a = self.ids()[0]
        self.api.call("deck_pages_timing", {"id": self.deck, "pages": [a], "seconds": 6})
        self.api.call("deck_pages_timing", {"id": self.deck, "pages": [a], "transition": "dissolve", "ms": 400})
        row = self.db.get_presentation_pages(self.deck)[0]
        self.assertEqual((row["auto_seconds"], row["transition"], row["transition_ms"]), (6, "dissolve", 400))
        self.api.call("deck_pages_timing", {"id": self.deck, "pages": [a], "seconds": None})
        self.assertIsNone(self.db.get_presentation_pages(self.deck)[0]["auto_seconds"])
        self.assertEqual(self.db.get_presentation_pages(self.deck)[0]["transition"], "dissolve")
        with self.assertRaises(ApiError):
            self.api.call("deck_pages_timing", {"id": self.deck, "pages": [a]})
        with self.assertRaises(ApiError):
            self.api.call("deck_pages_timing", {"id": self.deck, "pages": [a], "seconds": 999})

    def test_duplicates_keep_the_settings_but_copies_and_splits_do_not(self):
        a = self.ids()[0]
        self.c.set_deck_pages_timing(self.deck, [a], seconds=9, transition="dissolve", ms=300)
        (copy,) = self.c.duplicate_deck_pages(self.deck, [a])
        row = next(p for p in self.db.get_presentation_pages(self.deck) if p["id"] == copy)
        self.assertEqual((row["auto_seconds"], row["transition"], row["transition_ms"]), (9, "dissolve", 300))
        other = self.make_deck("Other", 1)
        self.c.add_deck_pages_from(other, self.deck, [a])
        self.assertEqual(self.db.get_presentation_pages(other)[-1]["auto_seconds"], None)
        new = self.c.split_deck(self.deck, [a], "Split")
        self.assertEqual(self.db.get_presentation_pages(new)[0]["transition"], None)


class BuilderTests(Base):
    def test_a_slides_own_delay_beats_the_deck_and_the_service(self):
        a, b, c = self.ids()
        self.c.set_deck_autoplay(self.deck, 5, "stop")
        self.c.set_deck_pages_timing(self.deck, [b], seconds=3)
        self.c.set_deck_pages_timing(self.deck, [c], seconds=0)
        slides = self.c.preview(self.entry())
        self.assertEqual([s.auto_seconds for s in slides], [5, 3, 0])
        self.c.new_service("Sunday")
        self.c.add_entry(self.entry())
        item = self.c.service_rows()[0].item_id
        self.c.set_item_autoplay(item, 8, "stop")
        self.assertEqual([s.auto_seconds for s in self.slides()], [8, 3, 0])      # the service overrides the deck only

    def test_a_slides_own_transition_beats_the_decks(self):
        a, b, c = self.ids()
        self.c.set_deck_transition(self.deck, "dissolve", 600)
        self.c.set_deck_pages_timing(self.deck, [b], transition="circle_in", ms=1000)
        self.c.set_deck_pages_timing(self.deck, [c], transition="none", ms=500)
        slides = self.c.preview(self.entry())
        self.assertEqual([(s.transition, s.transition_ms) for s in slides],
                         [("dissolve", 600), ("circle_in", 1000), ("none", 0)])

    def test_a_slide_can_have_a_transition_when_the_deck_has_none(self):
        self.c.set_deck_pages_timing(self.deck, [self.ids()[1]], transition="dissolve", ms=700)
        slides = self.c.preview(self.entry())
        self.assertEqual([(s.transition, s.transition_ms) for s in slides],
                         [("none", 0), ("dissolve", 700), ("none", 0)])

    def test_a_service_shows_the_new_timing_at_once(self):
        self.c.new_service("Sunday")
        self.c.add_entry(self.entry())
        self.c.set_deck_pages_timing(self.deck, [self.ids()[2]], seconds=4)
        self.assertEqual([s.auto_seconds for s in self.slides()], [0, 0, 4])

    def test_skipped_slides_keep_their_settings_but_are_not_built(self):
        a, b, c = self.ids()
        self.c.set_deck_pages_timing(self.deck, [b], seconds=4)
        self.c.skip_deck_pages(self.deck, [b], True)
        self.assertEqual(len(self.c.preview(self.entry())), 2)
        self.c.skip_deck_pages(self.deck, [b], False)
        self.assertEqual([s.auto_seconds for s in self.c.preview(self.entry())], [0, 4, 0])


class TimerTests(Base):
    def test_a_manual_deck_can_have_one_timed_slide(self):
        self.c.set_deck_pages_timing(self.deck, [self.ids()[0]], seconds=1)
        self.live_alone()
        self.assertTrue(self.wait_for(lambda: self.index() == 1))
        time.sleep(0.15)
        self.assertEqual(self.index(), 1)                  # slide 2 follows the deck (manual): it waits

    def test_a_timed_deck_can_wait_on_one_slide(self):
        self.c.set_deck_autoplay(self.deck, 1, "stop")
        self.c.set_deck_pages_timing(self.deck, [self.ids()[1]], seconds=0)
        self.live_alone()
        self.assertTrue(self.wait_for(lambda: self.index() == 1))
        time.sleep(0.15)
        self.assertEqual(self.index(), 1)
        self.assertFalse(self.c.timer_view()["available"])
        self.c.next()                                      # the operator moves on; the deck's timing resumes
        self.assertEqual(self.index(), 2)

    def test_a_slower_slide_takes_its_own_time(self):
        self.c.set_deck_autoplay(self.deck, 1, "stop")
        self.c.set_deck_pages_timing(self.deck, [self.ids()[0]], seconds=10)       # 10 * 20 ms
        self.live_alone()
        time.sleep(0.08)
        self.assertEqual(self.index(), 0)
        self.assertTrue(self.wait_for(lambda: self.index() == 1))


if __name__ == "__main__":
    unittest.main()
