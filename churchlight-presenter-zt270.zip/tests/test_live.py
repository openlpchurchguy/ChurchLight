# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import dataclasses
import threading
import unittest

from churchlight_presenter.core.live import LiveSession, LiveState
from churchlight_presenter.core.slides import Slide


def slides(n, item_ids=None):
    return [Slide("lyrics", "song", item_ids[i] if item_ids else None, text=f"line {i}")
            for i in range(n)]


def verse_overlay():
    return [Slide("scripture", "scripture", None, text="piece one", reference="John 3:16",
                  verse_numbers=(16,)),
            Slide("scripture", "scripture", None, text="piece two", reference="John 3:16",
                  verse_numbers=(16,), continued=True)]


class NavigationTests(unittest.TestCase):
    def test_a_new_session_has_nothing_live(self):
        state = LiveSession().state()
        self.assertEqual((state.base, state.base_index, state.base_count, state.next_base),
                         (None, None, 0, None))
        self.assertFalse(state.overlay_loaded)

    def test_loading_puts_nothing_on_screen_and_next_starts_at_the_first_slide(self):
        session = LiveSession(slides(3))
        self.assertIsNone(session.state().base)
        self.assertTrue(session.next())
        self.assertEqual(session.state().base_index, 0)

    def test_next_and_previous_stop_at_the_ends(self):
        session = LiveSession(slides(3))
        self.assertFalse(session.previous())          # nothing live yet
        self.assertEqual([session.next() for _ in range(4)], [True, True, True, False])
        self.assertEqual(session.state().base_index, 2)
        self.assertEqual([session.previous() for _ in range(3)], [True, True, False])
        self.assertEqual(session.state().base_index, 0)
        self.assertFalse(LiveSession().next())        # empty list

    def test_go_to_validates_the_index(self):
        session = LiveSession(slides(3))
        self.assertTrue(session.go_to(2))
        self.assertFalse(session.go_to(2))            # already there
        for bad in (-1, 3, 99):
            with self.assertRaises(IndexError):
                session.go_to(bad)
        self.assertEqual(session.state().base_index, 2)

    def test_go_to_item_jumps_to_the_first_slide_of_a_service_item(self):
        session = LiveSession(slides(5, item_ids=[1, 1, 2, 2, 3]))
        session.go_to_item(2)
        self.assertEqual(session.state().base_index, 2)
        with self.assertRaises(ValueError):
            session.go_to_item(99)

    def test_the_next_slide_is_derived_from_the_list(self):
        items = slides(3)
        session = LiveSession(items)
        self.assertEqual(session.state().next_base, items[0])   # nothing live: the first
        session.go_to(1)
        self.assertEqual(session.state().next_base, items[2])
        session.go_to(2)
        self.assertIsNone(session.state().next_base)

    def test_clear_takes_everything_off_but_keeps_blank(self):
        session = LiveSession(slides(3))
        session.go_to(1)
        session.show_overlay(verse_overlay())
        session.set_blank(True)
        self.assertTrue(session.clear())
        state = session.state()
        self.assertEqual((state.base, state.overlay, state.overlay_loaded, state.blank),
                         (None, None, False, True))
        self.assertFalse(session.clear())             # already clear


class OverlayTests(unittest.TestCase):
    def test_an_overlay_does_not_move_the_slide_underneath(self):
        deck = slides(5)
        session = LiveSession(deck)
        session.go_to(3)
        session.show_overlay(verse_overlay())
        state = session.state()
        self.assertEqual(state.base, deck[3])
        self.assertEqual(state.base_index, 3)
        self.assertEqual(state.overlay.text, "piece one")
        session.hide_overlay()
        self.assertEqual(session.state().base, deck[3])
        self.assertIsNone(session.state().overlay)

    def test_overlay_slides_step_independently_of_the_base(self):
        session = LiveSession(slides(5))
        session.go_to(3)
        session.show_overlay(verse_overlay())
        self.assertTrue(session.overlay_next())
        state = session.state()
        self.assertEqual((state.overlay.text, state.overlay.continued, state.overlay_index,
                          state.overlay_count, state.base_index), ("piece two", True, 1, 2, 3))
        self.assertFalse(session.overlay_next())      # at the end
        self.assertTrue(session.overlay_previous())
        self.assertFalse(session.overlay_previous())  # at the start
        self.assertEqual(session.state().base_index, 3)

    def test_a_hidden_overlay_can_be_brought_back_without_rebuilding_it(self):
        session = LiveSession(slides(2))
        session.show_overlay(verse_overlay())
        self.assertTrue(session.hide_overlay())
        self.assertFalse(session.hide_overlay())      # already hidden
        state = session.state()
        self.assertTrue(state.overlay_loaded)
        self.assertIsNone(state.overlay)
        self.assertTrue(session.show_overlay())       # no arguments: re-show
        self.assertEqual(session.state().overlay.text, "piece one")
        self.assertFalse(session.show_overlay())      # already showing

    def test_show_overlay_needs_slides_the_first_time(self):
        session = LiveSession(slides(2))
        with self.assertRaises(ValueError):
            session.show_overlay()
        with self.assertRaises(ValueError):
            session.show_overlay([])
        with self.assertRaises(IndexError):
            session.show_overlay(verse_overlay(), index=5)

    def test_loading_a_new_list_drops_the_overlay_but_keeps_blank(self):
        session = LiveSession(slides(2))
        session.go_to(1)
        session.show_overlay(verse_overlay())
        session.set_blank(True)
        session.load(slides(4))
        state = session.state()
        self.assertEqual((state.base, state.overlay_loaded, state.base_count, state.blank),
                         (None, False, 4, True))

    def test_clear_overlay_forgets_it(self):
        session = LiveSession(slides(2))
        session.show_overlay(verse_overlay())
        self.assertTrue(session.clear_overlay())
        self.assertFalse(session.state().overlay_loaded)
        self.assertFalse(session.clear_overlay())
        with self.assertRaises(ValueError):
            session.show_overlay()


class BlankTests(unittest.TestCase):
    def test_blank_toggles_and_only_reports_real_changes(self):
        session = LiveSession(slides(1))
        self.assertTrue(session.set_blank(True))
        self.assertFalse(session.set_blank(True))
        self.assertTrue(session.state().blank)
        self.assertTrue(session.toggle_blank())
        self.assertFalse(session.state().blank)


class VersionAndListenerTests(unittest.TestCase):
    def test_the_version_rises_only_on_real_changes(self):
        session = LiveSession(slides(2))
        start = session.version
        session.next()
        self.assertEqual(session.version, start + 1)
        session.go_to(0)                      # already there
        session.previous()                    # at the start
        session.hide_overlay()                # nothing to hide
        session.set_blank(False)              # already not blank
        self.assertEqual(session.version, start + 1)
        self.assertEqual(session.state().version, session.version)

    def test_listeners_hear_about_changes_with_the_new_state(self):
        session = LiveSession(slides(3))
        heard = []
        session.subscribe(heard.append)
        session.next()
        session.next()
        session.next()
        session.next()                        # at the end: no change, no call
        self.assertEqual([s.base_index for s in heard], [0, 1, 2])
        self.assertEqual([s.version for s in heard], [1, 2, 3])
        self.assertTrue(all(isinstance(s, LiveState) for s in heard))

    def test_unsubscribe_stops_the_calls(self):
        session = LiveSession(slides(3))
        heard = []
        unsubscribe = session.subscribe(heard.append)
        session.next()
        unsubscribe()
        unsubscribe()                         # harmless twice
        session.next()
        self.assertEqual(len(heard), 1)

    def test_a_listener_that_fails_cannot_break_the_session_or_other_listeners(self):
        session = LiveSession(slides(3))
        heard = []

        def broken(state):
            raise RuntimeError("renderer crashed")

        session.subscribe(broken)
        session.subscribe(heard.append)
        with self.assertLogs("churchlight_presenter.core.live", level="ERROR"):
            self.assertTrue(session.next())
        self.assertEqual(session.state().base_index, 0)
        self.assertEqual(len(heard), 1)

    def test_a_listener_may_call_back_into_the_session(self):
        session = LiveSession(slides(3))
        seen = []
        session.subscribe(lambda state: seen.append(session.state().base_index))
        session.next()
        self.assertEqual(seen, [0])

    def test_many_threads_advancing_at_once_stay_consistent(self):
        session = LiveSession(slides(100))
        errors = []

        def worker():
            try:
                for _ in range(50):
                    session.next()
                    session.state()
            except Exception as err:  # noqa: BLE001
                errors.append(err)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(errors, [])
        self.assertEqual(session.state().base_index, 99)   # 400 presses, 100 slides
        self.assertEqual(session.version, 100)             # one bump per real move

    def test_a_snapshot_is_immutable(self):
        state = LiveSession(slides(1)).state()
        with self.assertRaises(dataclasses.FrozenInstanceError):
            state.version = 99


if __name__ == "__main__":
    unittest.main()
