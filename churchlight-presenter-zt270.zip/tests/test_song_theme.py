# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A song's own theme, and library items sent straight live looking like the open service."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.core.themes import validate_style
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi


class SongThemeTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.service_theme = self.db.add_theme("Service look", {"kind": "projector", "style": {"font_size": 6}})
        self.patriotic = self.db.add_theme("Patriotic", {"kind": "projector", "style": {"color": "#ff0000"}})
        self.lower = self.db.add_theme("Lower", {"kind": "overlay", "style": {"font_size": 5}})
        self.song = self.db.create_song_with_sections("Anthem", [("Verse 1", "verse", "o say can you see")])
        self.plain = self.db.create_song_with_sections("Plain", [("Verse 1", "verse", "la la")])
        self.c = OperatorController(self.db, [Output("projector", "projector")])
        self.api = OperatorApi(self.c)
        self.c.new_service("Sunday")
        self.db.update_service(self.c.service_id, theme_id=self.service_theme)

    def live_theme(self, song_id):
        entry = next(e for e in self.c.search_library("") if e.kind == "song" and e.id == song_id)
        self.c.go_live_entry(entry)
        return self.c.session.state().base.theme_id

    def add_song(self, song_id):
        self.c.add_entry(next(e for e in self.c.search_library("") if e.kind == "song" and e.id == song_id))

    def test_a_song_sent_straight_to_live_uses_the_open_services_theme(self):
        self.assertEqual(self.live_theme(self.plain), self.service_theme)

    def test_with_no_service_open_it_uses_the_programs_starting_theme(self):
        self.db.set_setting("default_theme", str(self.patriotic))
        self.c.service_id = None
        self.assertEqual(self.live_theme(self.plain), self.patriotic)

    def test_a_songs_own_theme_beats_the_services_theme_live_and_in_the_service(self):
        self.api.call("song_save", {"id": self.song, "title": "Anthem", "author": "", "text": "[Verse 1]\no say can you see",
                                    "theme_id": self.patriotic})
        self.assertEqual(self.db.get_song(self.song)["theme_id"], self.patriotic)
        self.assertEqual(self.live_theme(self.song), self.patriotic)
        self.assertEqual(self.live_theme(self.plain), self.service_theme)        # other songs still follow the service
        self.add_song(self.song)
        built = [s for s in self.c.builder.build_service(self.c.service_id) if s.item_type == "song"]
        self.assertEqual({s.theme_id for s in built}, {self.patriotic})

    def test_an_items_own_theme_beats_the_songs(self):
        self.db.update_song(self.song, theme_id=self.patriotic)
        self.add_song(self.song)
        item = self.db.get_service_outline(self.c.service_id)[0]["id"]
        self.api.call("item_theme", {"item_id": item, "kind": "projector", "id": self.service_theme})
        built = [s for s in self.c.builder.build_service(self.c.service_id) if s.item_type == "song"]
        self.assertEqual({s.theme_id for s in built}, {self.service_theme})

    def test_saving_without_a_theme_keeps_it_and_null_clears_it(self):
        base = {"id": self.song, "title": "Anthem", "author": "", "text": "[Verse 1]\no say can you see"}
        self.api.call("song_save", dict(base, theme_id=self.patriotic))
        self.api.call("song_save", base)                                         # the editor of an older page: no key
        self.assertEqual(self.db.get_song(self.song)["theme_id"], self.patriotic)
        self.api.call("song_save", dict(base, theme_id=None))
        self.assertIsNone(self.db.get_song(self.song)["theme_id"])

    def test_the_editor_gets_the_songs_theme_and_new_songs_can_have_one(self):
        self.db.update_song(self.song, theme_id=self.patriotic)
        self.assertEqual(self.c.song_for_editing(self.song)["theme_id"], self.patriotic)
        made = self.api.call("song_save", {"title": "New", "author": "", "text": "[Verse 1]\nhi", "theme_id": self.patriotic})
        self.assertEqual(self.db.get_song(made["id"])["theme_id"], self.patriotic)

    def test_only_an_existing_projector_theme_is_accepted(self):
        base = {"id": self.song, "title": "Anthem", "author": "", "text": "[Verse 1]\nx"}
        for bad in (self.lower, 9999):
            with self.assertRaises(ApiError):
                self.api.call("song_save", dict(base, theme_id=bad))
        self.assertIsNone(self.db.get_song(self.song)["theme_id"])

    def test_deleting_the_theme_sends_the_song_back_to_following_the_service(self):
        self.db.update_song(self.song, theme_id=self.patriotic)
        usage = [t for t in self.c.theme_details() if t["id"] == self.patriotic][0]["usage"]
        self.assertEqual(usage["songs"], 1)
        self.c.delete_theme(self.patriotic)
        self.assertIsNone(self.db.get_song(self.song)["theme_id"])
        self.assertEqual(self.live_theme(self.song), self.service_theme)


if __name__ == "__main__":
    unittest.main()
