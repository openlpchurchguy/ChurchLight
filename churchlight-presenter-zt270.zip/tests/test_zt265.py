# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""zt265: toolbar order, click-to-deselect, two-press buttons that disengage, the media filter, Export all with video slideshows."""
import time
import unittest

from churchlight_presenter.ui.operator_api import ApiError
from tests.test_media_playback import MP4, Base
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


def until(check, seconds=8):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.1)
    return False


class ExportAllTests(Base):
    def setUp(self):
        super().setUp()
        folder = self.tmp / "media" / "decks"
        folder.mkdir(parents=True)
        (folder / "a.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"\0" * 50)
        self.plain = self.db.add_presentation("Plain", [("decks/a.png", None)])
        self.video_deck = self.db.add_presentation("Movie", [("decks/a.png", None)])
        video = self.add("Welcome.mp4", MP4, 20)
        self.c.add_deck_library(self.video_deck, [video])

    def test_the_library_knows_which_slideshows_have_video(self):
        flags = {d["name"]: d["has_video"] for d in self.c.library_overview()["decks"]}
        self.assertEqual(flags, {"Plain": False, "Movie": True})

    def test_export_all_is_refused_when_one_has_video_and_says_how_to_move_it(self):
        with self.assertRaises(ApiError) as caught:
            self.api.export_slideshows([], everything=True)
        self.assertIn("video", str(caught.exception))
        self.assertIn("Media Library", str(caught.exception))

    def test_skipping_video_exports_the_rest(self):
        name, kind, path = self.api.export_slideshows([], everything=True, skip_video=True)
        self.addCleanup(path.unlink)
        self.assertEqual((name, kind), ("Plain.zip", "application/zip"))
        import zipfile
        self.assertTrue(any(n.endswith(".png") for n in zipfile.ZipFile(path).namelist()))

    def test_nothing_is_left_when_every_slideshow_has_video(self):
        self.db.delete_presentation(self.plain)
        with self.assertRaises(ApiError) as caught:
            self.api.export_slideshows([], everything=True, skip_video=True)
        self.assertIn("Every slideshow has video", str(caught.exception))


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        db, c, api = make()
        self.addCleanup(db.close)
        self.deck = db.add_presentation("Easter", [("decks/a.png", None), ("decks/b.png", None)])
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1400, "height": 1000})
        self.page.goto(server.url.rstrip("/") + "/operator")
        try:
            self.page.wait_for_selector("#wizard:not([hidden])", timeout=3000)
            self.page.evaluate("wizardHide()")
        except Exception:
            pass

    def editor(self):
        self.page.evaluate(f"openDeckEditor({self.deck})")
        self.page.wait_for_selector("#de-grid .de-card")

    def test_row_one_is_left_aligned_in_the_new_order_and_blue(self):
        self.editor()
        page = self.page
        xs = [page.locator(s).bounding_box()["x"] for s in ("#de-add", "#de-all", "#de-menu-from > summary", "#de-menu-replace > summary")]
        self.assertEqual(xs, sorted(xs))
        self.assertLess(xs[-1], 500)                                       # all packed at the left
        self.assertEqual(page.inner_text("#de-add"), "Add pictures")
        blue = [page.evaluate(f"getComputedStyle(document.querySelector('{s}')).backgroundColor") for s in
                ("#de-add", "#de-all", "#de-menu-from > summary", "#de-menu-replace > summary")]
        self.assertEqual(len(set(blue)), 1)
        page.click("#de-menu-from > summary")
        option = page.evaluate("getComputedStyle(document.getElementById('de-library-open')).backgroundColor")
        self.assertNotEqual(option, blue[0])                              # the options in the menu are not blue

    def test_row_one_buttons_line_up_the_same_top_and_height(self):
        self.editor()
        boxes = [self.page.locator(s).bounding_box() for s in ("#de-add", "#de-all", "#de-menu-from > summary", "#de-menu-replace > summary")]
        self.assertEqual({round(b["y"]) for b in boxes}, {round(boxes[0]["y"])})
        self.assertEqual({round(b["height"]) for b in boxes}, {round(boxes[0]["height"])})

    def test_clicking_empty_space_deselects_and_a_slide_selects_again(self):
        self.editor()
        page = self.page
        self.assertEqual(page.locator("#de-grid .de-card.selected").count(), 1)       # first slide is selected on opening
        box = page.locator("#de-grid").bounding_box()
        page.mouse.click(box["x"] + box["width"] - 10, box["y"] + box["height"] - 10)
        self.assertTrue(until(lambda: page.locator("#de-grid .de-card.selected").count() == 0))
        self.assertIn("none yet", page.inner_text("#de-sel-label"))
        page.click("#de-grid .de-card >> nth=0")
        self.assertTrue(until(lambda: page.locator("#de-grid .de-card.selected").count() == 1))
        help_box = page.locator("#de-grid").locator("xpath=preceding-sibling::p[1]").bounding_box()                 # the hint line inside the Slides box counts as empty space too
        page.mouse.click(help_box["x"] + help_box["width"] - 4, help_box["y"] + help_box["height"] / 2)
        self.assertTrue(until(lambda: page.locator("#de-grid .de-card.selected").count() == 0))
        page.click("#de-grid .de-card >> nth=0")
        page.click("#de-sel-label")                                                       # the bar's own text deselects too; its buttons do not
        self.assertTrue(until(lambda: page.locator("#de-grid .de-card.selected").count() == 0))
        page.click("#de-all")
        self.assertEqual(page.locator("#de-grid .de-card.selected").count(), 2)

    def test_a_two_press_button_goes_back_when_something_else_is_pressed(self):
        page = self.page
        page.click("#tab-decks")
        page.wait_for_selector("#deck-list .row")
        rows = page.locator("#deck-list .row").count()
        delete = page.locator("#deck-list .row button", has_text="Delete").first
        delete.click()
        self.assertEqual(delete.inner_text(), "Yes, delete")
        page.click("#tab-songs")
        page.click("#tab-decks")
        self.assertEqual(page.locator("#deck-list .row button", has_text="Delete").first.inner_text(), "Delete")
        delete = page.locator("#deck-list .row button", has_text="Delete").first
        delete.click()
        page.mouse.click(5, 300)                                          # empty page space
        self.assertTrue(until(lambda: delete.inner_text() == "Delete"))
        self.assertEqual(page.locator("#deck-list .row").count(), rows)    # nothing was deleted

    def test_the_media_panel_filter_narrows_and_keeps_choices(self):
        self.editor()
        page = self.page
        self.assertTrue(until(lambda: page.evaluate("manage.decks.length > 0")))          # the library has loaded, so it will not overwrite the test data
        page.evaluate("manage.media = [{id: 1, name: 'Cross', kind: 'image', path: 'media/x.png'}, {id: 2, name: 'Welcome clip', kind: 'video', path: 'media/y.mp4'}];"
                      " deckEdit.library = [1]; $('de-library').hidden = false; drawLibraryPicker()")
        self.assertEqual(page.locator("#de-library-grid .de-card").count(), 2)
        box, grid = page.locator("#de-library-filter").bounding_box(), page.locator("#de-library-grid").bounding_box()
        self.assertGreaterEqual(grid["y"] - (box["y"] + box["height"]), 8)         # the files never touch the filter box
        page.fill("#de-library-filter", "wel")
        self.assertTrue(until(lambda: page.locator("#de-library-grid .de-card").count() == 1))
        self.assertEqual(page.evaluate("deckEdit.library"), [1])            # the picture chosen before filtering stays chosen
        self.assertEqual(page.inner_text("#de-library-add"), "Add 1 file")
        page.fill("#de-library-filter", "zzz")
        self.assertIn("No files match", page.inner_text("#de-library-grid"))

    def test_export_all_asks_first_only_when_a_slideshow_has_video(self):
        page = self.page
        page.click("#tab-decks")
        page.wait_for_selector("#deck-list .row")
        page.evaluate("window.__dl = []; downloadFile = (u) => window.__dl.push(u)")
        page.click("#deck-export-all")
        self.assertEqual([u for u in page.evaluate("window.__dl") if u], ["/api/export?kind=slideshows&all=1"])       # no video: straight away
        page.evaluate("manage.decks.push({id: 99, name: 'Movie', pages: 1, uses: 0, has_video: true}); drawDeckList()")
        page.click("#deck-export-all")
        self.assertEqual(page.inner_text("#deck-export-all"), "Yes, export the other 2")
        self.assertIn("Movie", page.inner_text("#message"))
        self.assertEqual(len([u for u in page.evaluate("window.__dl") if u]), 1)
        page.click("#deck-export-all")
        self.assertEqual(page.evaluate("window.__dl")[-1], "/api/export?kind=slideshows&all=1&skip_video=1")


if __name__ == "__main__":
    unittest.main()
