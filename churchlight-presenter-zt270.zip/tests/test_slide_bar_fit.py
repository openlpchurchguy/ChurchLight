# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Slide bars in a Bible passage's list stay inside the service area, however long the verse is."""
import unittest

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class SlideBarFitTests(unittest.TestCase):
    def test_long_verses_do_not_push_the_list_wider_than_the_page(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.new_service("S")
        c.set_service_verse_split("verse")
        long = "For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life. " * 3
        db.add_verses(db.add_translation("LONG", "Long"), [("John", 3, n, long) for n in range(1, 5)])
        c.add_verse("jn 3:1-4", translation="LONG")
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        for width in (700, 1000, 1400):
            page = browser.new_page(viewport={"width": width, "height": 900})
            page.goto(server.url.rstrip("/") + "/operator")
            page.wait_for_selector(".item-slide-list li", state="attached")
            if not page.is_visible(".item-slide-list"):
                page.click("button.more")
            over = page.evaluate("""() => {
              const list = document.querySelector('.item-slide-list').closest('li, .service-item, section') ;
              const limit = document.querySelector('.item-slide-list').getBoundingClientRect();
              const bars = [...document.querySelectorAll('.item-slide-list .slide-bar')];
              return { wider: bars.filter(b => b.getBoundingClientRect().right > limit.right + 1).length,
                       page: document.documentElement.scrollWidth - document.documentElement.clientWidth };
            }""")
            self.assertEqual(over["wider"], 0, width)
            self.assertLessEqual(over["page"], 0, width)
            page.close()


if __name__ == "__main__":
    unittest.main()
