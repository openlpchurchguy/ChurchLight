# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The toolbar button that closes (or reopens) every service item's drop-down list."""
import unittest

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class FoldItemsTests(unittest.TestCase):
    def test_collapse_and_open_all(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.new_service("S")
        c.set_service_verse_split("verse")
        c.add_verse("jn 3:1-4")
        c.add_entry(next(e for e in c.search_library("Deck") if e.kind == "presentation"))
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#items .item-options", state="attached")
        self.assertTrue(page.is_visible("#btn-fold-items"))
        self.assertTrue(page.is_disabled("#btn-fold-items"))                  # all closed, nothing live
        page.click("#items li:nth-child(1) button.more")
        page.click("#items li:nth-child(2) button.more")
        self.assertEqual(page.inner_text("#btn-fold-items"), "Collapse items (C)")
        self.assertEqual(page.locator("#items .item-options:visible").count(), 2)
        page.click("#btn-fold-items")                                        # nothing is live: all close
        self.assertEqual(page.locator("#items .item-options:visible").count(), 0)
        self.assertTrue(page.is_disabled("#btn-fold-items"))                  # nothing closed-and-live to open
        page.click("#items li:nth-child(1) .item-go")                         # make the first item live
        page.wait_for_selector("#items li:nth-child(1).live")
        self.assertTrue(page.is_visible("#items li.live .item-options"))      # a live item opens by itself
        page.click("#btn-fold-items")
        self.assertEqual(page.locator("#items .item-options:visible").count(), 0)      # the live item closes too
        self.assertEqual(page.inner_text("#btn-fold-items"), "Open live item (C)")
        page.click("#btn-fold-items")                                         # the same button opens only the live item
        self.assertEqual(page.locator("#items .item-options:visible").count(), 1)
        self.assertTrue(page.is_visible("#items li.live .item-options"))
        self.assertEqual(page.inner_text("#btn-fold-items"), "Collapse items (C)")
        page.click("#items li:nth-child(2) button.more")                      # another one opened by hand
        page.click("#btn-fold-items")
        self.assertEqual(page.locator("#items .item-options:visible").count(), 0)
        page.click("#items li:nth-child(2) .item-go")                         # a new live item opens by itself
        page.wait_for_selector("#items li:nth-child(2).live")
        self.assertTrue(page.is_visible("#items li.live .item-options"))

    def test_the_c_key_does_the_same_and_the_button_names_it(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.new_service("S")
        c.set_service_verse_split("verse")
        c.add_verse("jn 3:1-4")
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#items .item-go")
        page.click("#items .item-go")
        page.wait_for_selector("#items li.live .item-options")
        self.assertIn("(C)", page.inner_text("#btn-fold-items"))
        page.keyboard.press("c")
        self.assertEqual(page.locator("#items .item-options:visible").count(), 0)
        page.keyboard.press("c")
        self.assertEqual(page.locator("#items .item-options:visible").count(), 1)
        page.click("#search")                                    # typing in a box: C is just a letter
        page.keyboard.press("c")
        self.assertEqual(page.locator("#items .item-options:visible").count(), 1)
        self.assertEqual(page.input_value("#search"), "c")

    def test_go_on_the_live_item_only_opens_it(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.new_service("S")
        c.set_service_verse_split("verse")
        c.add_verse("jn 3:1-4")
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#items .item-go")
        page.click("#items .item-go")
        page.wait_for_selector("#items li.live")
        first = c.session.state().base_index
        page.click("#btn-next")                                               # move to the second slide
        for _ in range(50):
            if c.session.state().base_index != first:
                break
            page.wait_for_timeout(100)
        where = c.session.state().base_index
        self.assertNotEqual(where, first)
        page.click("#btn-fold-items")
        self.assertEqual(page.locator("#items .item-options:visible").count(), 0)
        page.click("#items li.live .item-go")                                 # Go on what is live: it only opens
        self.assertTrue(page.is_visible("#items li.live .item-options"))
        page.wait_for_timeout(300)
        self.assertEqual(c.session.state().base_index, where)                 # the slide did not move or restart

if __name__ == "__main__":
    unittest.main()
