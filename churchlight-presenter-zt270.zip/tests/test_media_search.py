# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The search bar in the service order also finds Media Library files, with filters for each kind."""
import io
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi
from tests.test_media_browser import MP4, wav_bytes
from tests.test_media_page import PageBase, until, HAVE_BROWSER

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 200


class SearchBase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        self.api = OperatorApi(self.c)
        self.song = self.c.create_song("Welcome Song", "", "Hello there\nfriends")
        self.picture = self.add("Welcome Picture.png", PNG, None)
        self.video = self.add("Welcome Video.mp4", MP4, 90)
        self.sound = self.add("Welcome Prelude.wav", wav_bytes(5), 5)
        self.other = self.add("Offering Video.mp4", MP4 + b"1", 30)

    def add(self, name, data, seconds):
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, name, io.BytesIO(data), len(data), "media")
        return self.c.add_media_file(batch, seconds)


class SearchTests(SearchBase):
    def test_a_search_finds_media_files_beside_songs_and_slideshows(self):
        found = self.api.library("welcome")
        self.assertEqual({(e["kind"], e["title"]) for e in found},
                         {("song", "Welcome Song"), ("media", "Welcome Picture"),
                          ("media", "Welcome Video"), ("media", "Welcome Prelude")})
        by_title = {e["title"]: e for e in found}
        self.assertEqual(by_title["Welcome Video"]["media_type"], "video")
        self.assertEqual(by_title["Welcome Video"]["detail"], "Video 1:30")
        self.assertEqual(by_title["Welcome Prelude"]["detail"], "Sound 0:05")
        self.assertEqual(by_title["Welcome Picture"]["detail"], "Picture")

    def test_each_filter_narrows_to_one_kind(self):
        for kind, titles in (("image", {"Welcome Picture"}), ("audio", {"Welcome Prelude"}),
                             ("video", {"Welcome Video", "Offering Video"}), ("song", {"Welcome Song"})):
            self.assertEqual({e["title"] for e in self.api.library("", kind)}, titles, kind)
        self.assertEqual({e["title"] for e in self.api.library("offering", "video")}, {"Offering Video"})
        self.assertEqual(self.api.library("offering", "audio"), [])

    def test_the_dropdown_under_the_box_offers_media_too_and_respects_the_filter(self):
        names = {e["title"] for e in self.api.suggest("welc")}
        self.assertEqual(names, {"Welcome Song", "Welcome Picture", "Welcome Video", "Welcome Prelude"})
        self.assertEqual([e["title"] for e in self.api.suggest("welc", "audio")], ["Welcome Prelude"])
        self.assertEqual([e["kind"] for e in self.api.suggest("welc", "song")], ["song"])

    def test_a_found_file_can_be_added_to_the_service_and_sent_live(self):
        self.c.new_service("Sunday")
        entry = next(e for e in self.api.library("offering") if e["kind"] == "media")
        self.api.call("add", {"kind": "media", "id": entry["id"]})
        self.assertEqual(len(self.db.get_service_items(self.c.service_id)), 1)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class SearchPageTests(PageBase):
    def test_the_box_lists_media_and_the_kind_menu_filters_it(self):
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, "Cross Picture.png", io.BytesIO(PNG), len(PNG), "media")
        self.c.add_media_file(batch, None)
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, "Cross Clip.mp4", io.BytesIO(MP4), len(MP4), "media")
        self.c.add_media_file(batch, 12)
        page = self.page
        page.fill("#search", "cross")
        self.assertTrue(until(lambda: page.locator("#results li").count() == 2))
        self.assertIn("PICTURE", page.inner_text("#results"))
        page.select_option("#search-kind", "video")
        self.assertTrue(until(lambda: page.locator("#results li").count() == 1))
        self.assertIn("Cross Clip", page.inner_text("#results"))
        self.assertIn("Video 0:12", page.inner_text("#results"))
        page.click("#results li button:has-text('Add')")
        self.assertTrue(until(lambda: len(self.c.db.get_service_items(self.c.service_id)) == 1))


del PageBase

if __name__ == "__main__":
    unittest.main()
