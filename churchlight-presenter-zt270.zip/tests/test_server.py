# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The output server, tested over real loopback HTTP. No windows, no browser."""
import http.client
import json
import shutil
import subprocess
import tempfile
import threading
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import LAYOUTS, Output, build_payload
from churchlight_presenter.core.slides import Slide
from churchlight_presenter.demo import run_demo
from churchlight_presenter.server.app import STATIC_DIR, OutputServer

NOTE = "SECRET-SPEAKER-NOTE"
PNG = (b"\x89PNG\r\n\x1a\n" + b"\0" * 16)


def deck(n):
    return Slide("image", "presentation", 3, label=f"Slide {n}", image_path=f"deck/{n}.png",
                 notes=NOTE)


def verse():
    return Slide("scripture", "scripture", None, text="verse text", segments=((16, "verse text"),), label="DEMO",
                 reference="John 3:16", verse_numbers=(16,))


def song(n):
    return Slide("lyrics", "song", 1, text=f"line {n}", label="Verse 1", reference="Demo Song")


OUTPUTS = [Output("projector", "projector", kind="native", screen=1),
           Output("verse-lower", "verse_lower"), Output("stage", "stage")]


class ServerCase(unittest.TestCase):
    slides = ()
    media = None
    source_url = None

    def setUp(self):
        self.session = LiveSession(self.slides or [deck(1), deck(2), deck(3)])
        self.server = OutputServer(self.session, OUTPUTS, media_root=self.media,
                                   source_url=self.source_url).start()
        self.addCleanup(self.server.close)
        self.port = self.server.address[1]

    def request(self, path, method="GET", timeout=5):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=timeout)
        try:
            conn.request(method, path)
            response = conn.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            conn.close()

    def get_json(self, path):
        status, headers, body = self.request(path)
        return status, json.loads(body)


class PortTests(unittest.TestCase):
    def test_a_second_server_on_a_busy_port_is_refused_not_shared(self):
        first = OutputServer(LiveSession(), OUTPUTS).start()
        self.addCleanup(first.close)
        with self.assertRaises(OSError):
            OutputServer(LiveSession(), OUTPUTS, port=first.address[1])

    def test_address_reuse_is_off_on_windows_only(self):
        import sys
        from churchlight_presenter.server.app import _Httpd
        self.assertEqual(_Httpd.allow_reuse_address, sys.platform != "win32")


class PayloadRouteTests(ServerCase):
    def test_binds_to_this_computer_only_by_default(self):
        self.assertEqual(self.server.address[0], "127.0.0.1")
        self.assertTrue(self.server.url.startswith("http://127.0.0.1:"))

    def test_out_matches_build_payload_and_follows_the_session(self):
        status, payload = self.get_json("/out/projector")
        self.assertEqual(status, 200)
        self.assertEqual(payload.pop("build"), self.server.build)       # the page-files stamp rides along
        self.assertEqual(payload, build_payload(self.session.state(), OUTPUTS[0]))
        self.session.go_to(1)
        _, payload = self.get_json("/out/projector")
        self.assertEqual(payload["base"]["label"], "Slide 2")
        self.assertEqual(payload["version"], self.session.version)

    def test_notes_reach_the_stage_only_even_over_http(self):
        self.session.go_to(1)
        self.session.show_overlay([deck(3)])
        for name in ("projector", "verse-lower"):
            _, headers, body = self.request(f"/out/{name}")
            self.assertNotIn(NOTE.encode(), body, name)
        _, stage = self.get_json("/out/stage")
        self.assertEqual(stage["base"]["notes"], NOTE)

    def test_responses_are_never_cached(self):
        _, headers, _ = self.request("/out/stage")
        self.assertEqual(headers["Cache-Control"], "no-store")
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")

    def test_peek_shows_the_slide_through_a_blank_only_when_asked(self):
        self.session.go_to(0)
        first = self.session.state().base
        self.session.set_blank(True)
        self.assertIsNone(self.get_json("/out/projector")[1]["base"])
        status, peeked = self.get_json("/out/projector?peek=1")
        self.assertEqual(status, 200)
        self.assertEqual((peeked["base"]["image_path"], peeked["blank"], peeked["peek_blank"]),
                         (first.image_path, False, True))

    def test_unknown_output_is_a_json_404(self):
        status, body = self.get_json("/out/nope")
        self.assertEqual(status, 404)
        self.assertIn("nope", body["error"])
        self.assertEqual(self.request("/view/nope")[0], 404)

    def test_other_paths_and_methods(self):
        for path in ("/out", "/out/", "/out/stage/extra", "/view", "/x", "/static/", "/media"):
            self.assertEqual(self.request(path)[0], 404, path)
        self.assertEqual(self.request("/out/stage", method="POST")[0], 501)

    def test_head_gives_headers_and_no_body(self):
        status, headers, body = self.request("/out/stage", method="HEAD")
        self.assertEqual((status, body), (200, b""))
        self.assertGreater(int(headers["Content-Length"]), 0)

    def test_outputs_can_change_while_running(self):
        self.server.set_outputs(OUTPUTS + [Output("extra", "lower_third")])
        self.assertEqual(self.request("/out/extra")[0], 200)
        self.server.set_outputs(OUTPUTS[:1])
        self.assertEqual(self.request("/out/stage")[0], 404)
        with self.assertRaises(ValueError):
            self.server.set_outputs([OUTPUTS[0], OUTPUTS[0]])


class PollingTests(ServerCase):
    def test_since_the_current_version_means_nothing_new(self):
        version = self.session.version
        status, _, body = self.request(f"/out/stage?since={version}")
        self.assertEqual((status, body), (304, b""))

    def test_a_different_version_gets_the_payload(self):
        self.session.next()
        status, payload = self.get_json(f"/out/stage?since={self.session.version - 1}")
        self.assertEqual(status, 200)
        self.assertEqual(payload["version"], self.session.version)

    def test_a_version_from_before_a_restart_still_gets_the_payload(self):
        status, _ = self.get_json(f"/out/stage?since={self.session.version + 500}")
        self.assertEqual(status, 200)       # the page's version is ahead of ours: resync

    def test_long_poll_answers_as_soon_as_something_changes(self):
        version = self.session.version
        threading.Timer(0.2, self.session.next).start()
        started = time.monotonic()
        status, payload = self.get_json(f"/out/projector?since={version}&wait=10")
        self.assertEqual(status, 200)
        self.assertLess(time.monotonic() - started, 3)
        self.assertEqual(payload["base"]["label"], "Slide 1")

    def test_long_poll_gives_up_with_304_after_the_wait(self):
        started = time.monotonic()
        status, _, _ = self.request(f"/out/stage?since={self.session.version}&wait=0.3")
        self.assertEqual(status, 304)
        self.assertGreaterEqual(time.monotonic() - started, 0.25)

    def test_many_waiting_pages_are_all_released_by_one_change(self):
        version = self.session.version
        results = []

        def waiter(name):
            results.append(self.request(f"/out/{name}?since={version}&wait=10")[0])

        threads = [threading.Thread(target=waiter, args=(n,))
                   for n in ("projector", "verse-lower", "stage") * 3]
        for t in threads:
            t.start()
        time.sleep(0.3)
        self.session.next()
        for t in threads:
            t.join(5)
        self.assertEqual(results, [200] * 9)

    def test_the_wait_is_capped(self):
        # nobody can park a request for an hour: huge values are accepted but clamped
        from churchlight_presenter.server import app
        self.assertLessEqual(app.MAX_WAIT, 30)

    def test_bad_numbers_are_refused(self):
        for query in ("since=abc", "since=1.5", "since=1&wait=x", "since=1&wait=-1",
                      "since=1&wait=nan", "since=1&wait=inf"):
            self.assertEqual(self.request(f"/out/stage?{query}")[0], 400, query)

    def test_closing_releases_waiting_requests_quickly(self):
        done = []
        version = self.session.version
        t = threading.Thread(target=lambda: done.append(
            self.request(f"/out/stage?since={version}&wait=20")[0]))
        t.start()
        time.sleep(0.3)
        started = time.monotonic()
        self.server.close()
        t.join(5)
        self.assertLess(time.monotonic() - started, 4)
        self.assertEqual(done, [304])
        self.server.close()                  # closing twice is harmless
        with self.assertRaises(OSError):
            self.request("/out/stage", timeout=1)


class PageAndStaticTests(ServerCase):
    def test_index_lists_the_outputs_and_escapes_names(self):
        status, _, body = self.request("/")
        text = body.decode()
        self.assertEqual(status, 200)
        for name in ("projector", "verse-lower", "stage"):
            self.assertIn(f'href="/view/{name}"', text)
        self.assertNotIn("/source", text)         # no source URL configured

    def test_view_serves_the_page_with_a_locked_down_policy(self):
        status, headers, body = self.request("/view/projector")
        self.assertEqual(status, 200)
        self.assertIn(b"/static/output.js", body)
        self.assertIn("script-src 'self'", headers["Content-Security-Policy"])
        self.assertIn("text/html", headers["Content-Type"])

    def test_only_the_pages_own_files_are_served(self):
        for name, kind in (("output.js", "javascript"), ("output.css", "css")):
            status, headers, body = self.request(f"/static/{name}")
            self.assertEqual(status, 200)
            self.assertIn(kind, headers["Content-Type"])
            self.assertEqual(body, (STATIC_DIR / name).read_bytes())
        for bad in ("../app.py", "..%2Fapp.py", "app.py", "%2e%2e/app.py", "__init__.py"):
            self.assertEqual(self.request(f"/static/{bad}")[0], 404, bad)

    def test_no_source_link_means_no_source_route(self):
        self.assertEqual(self.request("/source")[0], 404)


class SourceLinkTests(ServerCase):
    source_url = "https://example.org/churchlight-source"

    def test_agpl_source_offer(self):
        status, headers, _ = self.request("/source")
        self.assertEqual((status, headers["Location"]), (302, self.source_url))
        self.assertIn(b'href="/source"', self.request("/")[2])


class MediaTests(ServerCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.media = self.tmp / "media"
        (self.media / "deck").mkdir(parents=True)
        (self.media / "deck" / "1.png").write_bytes(PNG)
        (self.media / "deck" / "notes.txt").write_text("not an image")
        (self.media / "deck" / "a b.jpg").write_bytes(b"jpg")
        (self.tmp / "secret.png").write_bytes(b"outside")
        super().setUp()

    def test_images_inside_the_media_folder_are_served(self):
        status, headers, body = self.request("/media/deck/1.png")
        self.assertEqual((status, headers["Content-Type"], body), (200, "image/png", PNG))
        self.assertEqual(self.request("/media/deck/a%20b.jpg")[0], 200)

    def test_nothing_outside_the_folder_or_not_an_image_is_served(self):
        for bad in ("/media/deck/notes.txt", "/media/../secret.png", "/media/%2e%2e/secret.png",
                    "/media/deck/%2e%2e/%2e%2e/secret.png", "/media/deck/..%2f..%2fsecret.png",
                    "/media/deck/missing.png", "/media/deck", "/media//deck/1.png",
                    "/media/deck%5c1.png", "/media/%2fetc%2fpasswd.png"):
            self.assertEqual(self.request(bad)[0], 404, bad)

    def test_a_link_pointing_out_of_the_folder_is_refused(self):
        link = self.media / "deck" / "escape.png"
        try:
            link.symlink_to(self.tmp / "secret.png")
        except (OSError, NotImplementedError):
            self.skipTest("symbolic links not available")
        self.assertEqual(self.request("/media/deck/escape.png")[0], 404)


class NoMediaFolderTests(ServerCase):
    def test_without_a_media_folder_no_images_are_served(self):
        self.assertEqual(self.request("/media/deck/1.png")[0], 404)


class DemoServiceOverHttpTests(unittest.TestCase):
    def test_the_demo_scenario_through_the_server(self):
        slides, _ = run_demo()
        session = LiveSession(slides)
        with OutputServer(session, OUTPUTS) as server:
            def get(name):
                conn = http.client.HTTPConnection(*server.address, timeout=5)
                try:
                    conn.request("GET", f"/out/{name}")
                    return json.loads(conn.getresponse().read())
                finally:
                    conn.close()

            session.go_to(next(i for i, s in enumerate(slides) if s.item_type == "presentation") + 1)
            session.show_overlay([Slide("scripture", "scripture", None, text="v",
                                        segments=((16, "v"),), reference="John 3:16",
                                        verse_numbers=(16,))])
            projector, stage = get("projector"), get("stage")
            self.assertEqual(projector["overlay"]["reference"], "John 3:16")
            self.assertNotIn("notes", json.dumps(projector))
            self.assertEqual(stage["base"]["notes"], "Main point. Mention John 3:16.")


# ---------------------------------------------------------------------------
# The page's own logic, run under node when it is installed
# ---------------------------------------------------------------------------
JS = STATIC_DIR / "output.js"


def view_model(payload):
    script = ("const {viewModel}=require(process.argv[1]);"
              "console.log(JSON.stringify(viewModel(JSON.parse(process.argv[2]))))")
    out = subprocess.run(["node", "-e", script, str(JS), json.dumps(payload)],
                         capture_output=True, text=True, timeout=30, check=True)
    return json.loads(out.stdout)


def slide_dict(**kw):
    base = dict(kind="lyrics", item_type="song", source_item_id=1, text="", segments=[],
                label="", reference="", verse_numbers=[], continued=False, image_path=None,
                theme_id=None)
    base.update(kw)
    return base


def payload(layout, base=None, overlay=None, **kw):
    audience = LAYOUTS[layout].audience
    data = dict(schema=1, version=1, output="x", layout=layout, audience=audience,
                theme_id=None, blank=False, base=base, overlay=overlay)
    data.update(kw)
    return data


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageLogicTests(unittest.TestCase):
    verse = slide_dict(kind="scripture", item_type="scripture", text="In the beginning",
                       segments=[[1, "In the beginning"]], reference="Genesis 1:1",
                       verse_numbers=[1], label="DEMO")
    picture = slide_dict(kind="image", item_type="presentation", image_path="deck/1.png",
                         label="Slide 1")

    def test_every_layout_is_known_to_the_page(self):
        for name, layout in LAYOUTS.items():
            if layout.audience == "public":
                vm = view_model(payload(name, base=self.verse))
                self.assertNotIn("unknownLayout", vm, name)

    def test_a_verse_over_a_deck_stacks_on_the_projector(self):
        vm = view_model(payload("projector", base=self.picture, overlay=self.verse))
        self.assertEqual([l["placement"] for l in vm["layers"]], ["full", "lower"])
        self.assertEqual(vm["layers"][1]["view"]["reference"], "Genesis 1:1")

    def test_a_verse_replaces_the_base_where_they_would_share_a_spot(self):
        other = dict(self.verse, text="other", segments=[[2, "other"]], reference="Genesis 1:2")
        vm = view_model(payload("verse_lower", base=self.verse, overlay=other))
        self.assertEqual(len(vm["layers"]), 1)
        self.assertEqual(vm["layers"][0]["view"]["reference"], "Genesis 1:2")

    def test_a_lower_band_never_draws_a_picture(self):
        vm = view_model(payload("lower_third", base=self.picture))
        self.assertEqual(vm["layers"], [])

    def test_the_reference_is_shown_for_verses_and_continued_pieces_say_so(self):
        piece = dict(self.verse, continued=True)
        view = view_model(payload("verse_full", base=piece))["layers"][0]["view"]
        self.assertEqual((view["reference"], view["continued"]), ("Genesis 1:1", True))

    def test_verse_numbers_are_never_drawn_only_the_verse_text(self):
        one = view_model(payload("verse_full", base=self.verse))["layers"][0]["view"]
        self.assertIsNone(one["parts"][0]["number"])
        two = dict(self.verse, segments=[[1, "a"], [2, "b"]], verse_numbers=[1, 2],
                   reference="Genesis 1:1-2")
        view = view_model(payload("verse_full", base=two))["layers"][0]["view"]
        self.assertEqual([(p["number"], p["text"]) for p in view["parts"]], [(None, "a"), (None, "b")])

    def test_lyrics_do_not_print_the_song_title_on_the_public_screen(self):
        lyrics = slide_dict(text="line a\nline b", reference="Demo Song")
        view = view_model(payload("song_full", base=lyrics))["layers"][0]["view"]
        self.assertEqual(view["reference"], "")
        self.assertEqual([p["text"] for p in view["parts"]], ["line a", "line b"])

    def test_a_peeking_preview_draws_the_slide_and_a_blanked_label(self):
        vm = view_model(payload("projector", base=self.picture, peek_blank=True))
        self.assertEqual(len(vm["layers"]), 1)
        self.assertTrue(vm["peekBlank"])
        self.assertFalse(view_model(payload("projector", base=self.picture))["peekBlank"])

    def test_blank_public_payload_draws_nothing(self):
        self.assertEqual(view_model(payload("projector", blank=True))["layers"], [])

    def test_the_stage_view_has_notes_next_and_positions(self):
        base = dict(self.picture, notes="remember this")
        vm = view_model(payload(
            "ppt_notes", base=base, next=self.picture, blank=True, overlay=self.verse,
            position={"index": 1, "count": 5, "overlay_index": 0, "overlay_count": 2}))
        self.assertEqual((vm["notes"], vm["position"], vm["overlayPosition"], vm["blank"]),
                         ("remember this", "2 of 5", "1 of 2", True))
        self.assertEqual(vm["next"]["image"], "deck/1.png")

    def test_the_stage_view_copes_with_nothing_live(self):
        vm = view_model(payload("stage", position={"index": None, "count": 0,
                                                   "overlay_index": None, "overlay_count": 0}))
        self.assertEqual((vm["position"], vm["current"], vm["notes"]), ("", None, ""))

    def test_the_page_never_builds_html_from_slide_text(self):
        source = JS.read_text(encoding="utf-8")
        for forbidden in ("innerHTML", "outerHTML", "insertAdjacentHTML", "document.write", "eval("):
            self.assertNotIn(forbidden, source)

    def test_the_page_file_parses(self):
        subprocess.run(["node", "--check", str(JS)], check=True, timeout=30)


if __name__ == "__main__":
    unittest.main()


class BuildStampTests(unittest.TestCase):
    def test_payloads_carry_a_stamp_of_the_page_files(self):
        from churchlight_presenter.core.live import LiveSession
        from churchlight_presenter.core.outputs import Output
        from churchlight_presenter.server.app import OutputServer
        server = OutputServer(LiveSession(), [Output("projector", "projector")])
        stamp = server.payload_for(Output("projector", "projector"))["build"]
        self.assertRegex(stamp, r"^[0-9a-f]{12}$")
        self.assertEqual(stamp, OutputServer(LiveSession(), [Output("projector", "projector")]).build)
