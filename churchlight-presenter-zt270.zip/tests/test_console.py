# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import io
import unittest

from churchlight_presenter.ui.console import Console
from tests.test_controller import OUTPUTS, make_controller


def run(controller, *lines):
    out = io.StringIO()
    Console(controller, stdin=io.StringIO("\n".join(lines) + "\n"), stdout=out).cmdloop(intro="")
    return out.getvalue()


class ConsoleTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make_controller()
        self.addCleanup(self.db.close)

    def test_a_whole_service_from_the_prompt(self):
        text = run(self.c, "new Sunday", "find sermon", "add 1", "find alpha", "add 1",
                   "addverse jn 3:17", "service", "go 1", "n", "verse jn 3:16", "vn", "hide",
                   "again", "blank", "status", "quit")
        for expected in ("Started service 1", "Added Sermon", "Added Alpha Song",
                         "  3. John 3:17 (DEMO)", "Slide 2", "Showing John 3:16 in 2 slides",
                         "(continued)", "VERSE [2/2]", "SCREENS BLANKED"):
            self.assertIn(expected, text)
        self.assertNotIn("Traceback", text)

    def test_mistakes_give_a_message_not_a_crash(self):
        text = run(self.c, "add 1", "new", "go x", "find", "add 99", "verse nonsense",
                   "slide 99", "move 1", "remove 1", "bogus", "quit")
        self.assertGreaterEqual(text.count("!"), 8)
        self.assertNotIn("Traceback", text)

    def test_live_from_the_library_and_look(self):
        self.c.serve()
        self.addCleanup(self.c.close)
        text = run(self.c, "find beta", "look 1", "live 1", "outputs", "quit")
        self.assertIn("/view/projector", text)
        self.assertIn("?preview", text)
        self.assertIn("b1 / b2", text)
        self.assertIn("projector", text)
        self.assertEqual(self.c.mode, "item")

    def test_themes_from_the_prompt(self):
        text = run(self.c, "themes", 'theme Warm color=#ffeecc font_size=8 font_family="Georgia, serif"',
                   "theme Warm font_size=9", "themes", "usetheme projector 1", "live 1",
                   "theme Bad font_size=99", "theme Bad2 nonsense", "usetheme nope 1", "quit")
        self.assertIn("No themes yet", text)
        self.assertIn("Made theme 1.", text)
        self.assertIn("Updated theme 1.", text)
        self.assertIn("1. Warm  font_size=9.0", text)
        self.assertEqual(self.c.styles.get(1), {"font_size": 9.0})
        self.assertGreaterEqual(text.count("!"), 3)

    def test_add_verse_with_a_space_and_a_bare_reference_both_work(self):
        text = run(self.c, "new S", "add verse jn 3:16", "jn 3:17", "service", "quit")
        self.assertIn("Added jn 3:16.", text)
        self.assertIn("That is only a preview", text)
        self.assertIn("[Demo 3:17] short.", text)
        self.assertIn("John 3:16 (DEMO)", text)
        self.assertEqual(len(self.c.service_rows()), 1)         # previewing added nothing
        self.assertIsNone(self.c.session.state().overlay)        # ... and showed nothing

    def test_unknown_words_get_a_helpful_message_not_python_jargon(self):
        text = run(self.c, "blah blah", "john", "jn 9:99", "quit")
        self.assertNotIn("Unknown syntax", text)
        self.assertIn("I don't know the command 'blah'", text)
        self.assertIn("I don't know the command 'john'", text)
        self.assertIn("verse jn 3:16", text)
        self.assertIn("John 9:99 was not found", text)           # reads as a reference, so says why

    def test_number_messages_say_what_to_do(self):
        text = run(self.c, "add 1", "add x", "new S", "go 1", "find song", "add 5", "quit")
        self.assertIn("There are no search results yet (search first, e.g.: find chorus)", text)
        self.assertIn("Give the number of a search result, like: add 1", text)
        self.assertIn("There are no service rows yet (see them with: service)", text)
        self.assertIn("There is no search result 5; choose 1 to 2", text)

    def test_end_of_input_leaves_cleanly(self):
        run(self.c, "status")           # no quit: end of input stops the loop


if __name__ == "__main__":
    unittest.main()
