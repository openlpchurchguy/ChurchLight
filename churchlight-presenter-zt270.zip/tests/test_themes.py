# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import http.client
import json
import logging
import shutil
import subprocess
import unittest

from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import Output, build_payload
from churchlight_presenter.core.slides import Slide
from churchlight_presenter.core.themes import STYLE_KEYS, ThemeStyles, safe_style, validate_style
from churchlight_presenter.server.app import STATIC_DIR
from tests.test_controller import entry, make_controller


class ValidationTests(unittest.TestCase):
    def test_good_styles_are_cleaned(self):
        style = {"font_family": " Georgia, serif ", "font_size": 7, "color": "#FFFFFF",
                 "line_height": 1.4, "align": "left", "shadow": False, "uppercase": True,
                 "band": True, "band_color": "#000000A0", "background_color": "#036",
                 "reference_scale": 0.5, "v_pos": "top", "h_pos": "right", "box_width": 50, "margin": 3, "max_height": 25,
                 "background_image": "backgrounds/0123456789abcdef.png", "background_fit": "fit",
                 "background_dim": 30, "title_scale": 1.3, "number_font": "Calibri, sans-serif",
                 "margin_top": 5, "margin_bottom": 6, "margin_left": 7, "margin_right": 8,
                 "reference_pos": "above", "balance_lines": True, "projector_hide": True}
        clean = validate_style(style)
        self.assertEqual(clean["font_family"], "Georgia, serif")
        self.assertEqual((clean["color"], clean["band_color"]), ("#ffffff", "#000000a0"))
        self.assertEqual(set(clean), set(STYLE_KEYS))
        self.assertEqual(validate_style({}), {})

    def test_every_kind_of_mistake_names_the_setting(self):
        bad = [({"colour": "#fff"}, "Unknown style setting"),   # the British spelling is not a setting
               ({"color": "red"}, "'color'"), ({"color": "#12345"}, "'color'"),
               ({"color": 5}, "'color'"), ({"font_size": 99}, "between 2 and 20"),
               ({"font_size": True}, "must be a number"), ({"font_size": "7"}, "must be a number"),
               ({"align": "justify"}, "one of"), ({"shadow": "yes"}, "true or false"),
               ({"font_family": "x; background: url(//evil)"}, "letters, digits"),
               ({"font_family": "a" * 200}, "letters, digits"), ({"font_family": ""}, "letters"),
               ({"line_height": 0.2}, "between"), ({"reference_scale": 3}, "between"),
               ("not a dict", "name: value")]
        for style, message in bad:
            with self.assertRaisesRegex(ValueError, message, msg=repr(style)):
                validate_style(style)

    def test_reading_drops_only_the_bad_parts(self):
        with self.assertLogs("churchlight_presenter.core.themes", level="WARNING"):
            clean = safe_style({"color": "#ffffff", "font_size": 500, "bogus": 1})
        self.assertEqual(clean, {"color": "#ffffff"})
        self.assertEqual(safe_style(None), {})
        self.assertEqual(safe_style([1, 2]), {})


class StyleLookupTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make_controller()
        self.addCleanup(self.db.close)

    def test_lookup_reads_from_memory_until_reloaded_and_stored_junk_is_survived(self):
        styles = ThemeStyles(self.db)
        self.assertIsNone(styles.get(None))
        with self.assertLogs("churchlight_presenter.core.themes", level="WARNING"):
            theme = self.db.add_theme("T", {"lines_per_slide": 3, "style": {"color": "#ff0000",
                                                                            "font_size": 900}})
            styles.reload()
        self.assertEqual(styles.get(theme), {"color": "#ff0000"})
        self.db.update_theme(theme, settings={"style": {"color": "#00ff00"}})
        self.assertEqual(styles.get(theme), {"color": "#ff0000"})          # not re-read yet
        styles.clear()
        self.assertEqual(styles.get(theme), {"color": "#00ff00"})
        no_style = self.db.add_theme("Plain", {"lines_per_slide": 2})
        styles.reload()
        self.assertEqual(styles.get(no_style), {})
        self.assertEqual(styles.get(9999), {})                              # a vanished theme

    def test_lookup_works_from_another_thread(self):
        import threading
        theme = self.db.add_theme("T", {"style": {"color": "#ff0000"}})
        styles = ThemeStyles(self.db)
        found = []
        t = threading.Thread(target=lambda: found.append(styles.get(theme)))
        t.start()
        t.join()
        self.assertEqual(found, [{"color": "#ff0000"}])

    def test_theme_style_does_not_disturb_slide_building(self):
        theme = self.db.add_theme("T", {"lines_per_slide": 2, "style": {"color": "#fff"}})
        self.db.update_theme(theme, settings={"lines_per_slide": 2, "style": {"color": "#ffffff"}})
        from churchlight_presenter.core.items import ItemRef
        slides = self.c.builder.build_item(ItemRef.song(entry(self.c, "Alpha").id), theme)
        self.assertEqual(slides[0].text, "a1\na2")


def verse_slide(theme_id=None):
    return Slide("scripture", "scripture", None, text="t", segments=((1, "t"),), label="D",
                 reference="John 1:1", verse_numbers=(1,), theme_id=theme_id)


def song_slide(theme_id=None):
    return Slide("lyrics", "song", 1, text="la", label="Chorus", theme_id=theme_id,
                 reference="A Song")


class PayloadStyleTests(unittest.TestCase):
    lookup = {1: {"color": "#111111"}, 2: {"color": "#222222"}, 3: {"color": "#333333"}}

    def state(self, base=None, overlay=None):
        session = LiveSession([base] if base else [])
        if base:
            session.go_to(0)
        if overlay:
            session.show_overlay([overlay])
        return session.state()

    def test_each_layer_carries_the_style_of_its_own_theme(self):
        payload = build_payload(self.state(song_slide(1), verse_slide(2)), Output("p", "projector"),
                                self.lookup.get)
        self.assertEqual((payload["base"]["style"], payload["overlay"]["style"]),
                         ({"color": "#111111"}, {"color": "#222222"}))

    def test_an_outputs_own_theme_wins_over_the_slides(self):
        payload = build_payload(self.state(song_slide(1), verse_slide(2)),
                                Output("p", "projector", theme_id=3), self.lookup.get)
        self.assertEqual(payload["base"]["style"], {"color": "#333333"})
        self.assertEqual(payload["overlay"]["style"], {"color": "#333333"})

    def test_no_theme_gives_none_and_no_lookup_gives_no_style_field(self):
        state = self.state(song_slide())
        self.assertIsNone(build_payload(state, Output("p", "projector"), self.lookup.get)["base"]["style"])
        self.assertNotIn("style", build_payload(state, Output("p", "projector"))["base"])

    def test_stage_layers_never_carry_a_style(self):
        payload = build_payload(self.state(song_slide(1)), Output("s", "stage"), self.lookup.get)
        self.assertNotIn("style", payload["base"])


class ControllerThemeTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make_controller()
        self.addCleanup(self.db.close)
        self.c.go_live_entry(entry(self.c, "Beta"))

    def test_saving_a_theme_restyles_the_live_output_at_once(self):
        theme = self.c.save_theme("Warm", {"color": "#ffeecc", "font_size": 8})
        self.c.set_output_theme("projector", theme)
        self.assertEqual(self.c.payloads()["projector"]["base"]["style"],
                         {"color": "#ffeecc", "font_size": 8.0})
        version = self.c.session.version
        self.c.save_theme("Warm", {"color": "#ffffff"}, theme_id=theme)
        self.assertGreater(self.c.session.version, version)          # pages will redraw
        self.assertEqual(self.c.payloads()["projector"]["base"]["style"], {"color": "#ffffff"})

    def test_updating_keeps_the_themes_other_settings(self):
        theme = self.db.add_theme("Mixed", {"lines_per_slide": 2})
        self.c.save_theme("Mixed", {"color": "#ffffff"}, theme_id=theme)
        self.assertEqual(self.db.get_theme_settings(theme),
                         {"lines_per_slide": 2, "kind": "projector", "style": {"color": "#ffffff"}})

    def test_mistakes_are_explained(self):
        from churchlight_presenter.ui.controller import ControllerError
        with self.assertRaisesRegex(ControllerError, "between 2 and 20"):
            self.c.save_theme("Bad", {"font_size": 50})
        self.c.save_theme("Once", {})
        with self.assertRaisesRegex(ControllerError, "already exists"):
            self.c.save_theme("Once", {})
        with self.assertRaisesRegex(ControllerError, "no theme number 99"):
            self.c.save_theme("X", {}, theme_id=99)
        with self.assertRaisesRegex(ControllerError, "no theme number 99"):
            self.c.set_output_theme("projector", 99)
        with self.assertRaisesRegex(ControllerError, "no output named"):
            self.c.set_output_theme("nope", None)

    def test_the_web_server_serves_styles_and_follows_changes(self):
        server = self.c.serve()
        self.addCleanup(self.c.close)
        theme = self.c.save_theme("Warm", {"color": "#ffeecc"})
        self.c.set_output_theme("projector", theme)

        def fetch():
            conn = http.client.HTTPConnection(*server.address, timeout=5)
            conn.request("GET", "/out/projector")
            body = json.loads(conn.getresponse().read())
            conn.close()
            return body

        self.assertEqual(fetch()["base"]["style"], {"color": "#ffeecc"})
        self.c.set_output_theme("projector", None)
        self.assertIsNone(fetch()["base"]["style"])


# ---------------------------------------------------------------------------
@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageStyleTests(unittest.TestCase):
    def css(self, style, placement):
        script = ("const {styleToCss}=require(process.argv[1]);"
                  "console.log(JSON.stringify(styleToCss(JSON.parse(process.argv[2]), process.argv[3])))")
        out = subprocess.run(["node", "-e", script, str(STATIC_DIR / "output.js"),
                              json.dumps(style), placement],
                             capture_output=True, text=True, timeout=30, check=True)
        return dict(json.loads(out.stdout))

    def test_text_settings_become_css(self):
        css = self.css({"font_family": "Georgia, serif", "font_size": 7, "color": "#fff",
                        "line_height": 1.3, "align": "left", "shadow": False,
                        "uppercase": True, "reference_scale": 0.5}, "full")
        self.assertEqual(css, {"font-family": "Georgia, serif", "font-size": "7vh",
                               "color": "#fff", "line-height": "1.3", "text-align": "left",
                               "align-items": "flex-start",
                               "text-shadow": "none", "text-transform": "uppercase",
                               "--ref-scale": "0.5"})

    def test_band_applies_to_lower_layers_and_background_to_full_ones(self):
        style = {"band_color": "#000000a0", "background_color": "#003366"}
        self.assertEqual(self.css(style, "lower"), {"background": "#000000a0"})
        self.assertEqual(self.css(style, "full"), {"background-color": "#003366"})
        self.assertEqual(self.css({"band": False, "band_color": "#000"}, "lower"),
                         {"background": "transparent"})

    def test_background_picture_and_text_band_on_full_layers(self):
        style = {"background_color": "#000000", "background_image": "backgrounds/0123456789abcdef.png",
                 "background_fit": "fit", "background_dim": 40}
        css = self.css(style, "full")
        self.assertIn("/media/backgrounds/0123456789abcdef.png", css["background-image"])
        self.assertIn("rgba(0,0,0,0.4)", css["background-image"])
        self.assertTrue(css["background-size"].endswith("contain"))
        self.assertEqual(self.css({"background_image": "backgrounds/0123456789abcdef.png"}, "lower"), {})
        self.assertEqual(self.css({"background_image": "backgrounds/0123456789abcdef.png"}, "full")["background-size"], "cover")

    def test_title_size_and_number_font(self):
        css = self.css({"title_scale": 1.3, "number_font": "Calibri, sans-serif"}, "full")
        self.assertEqual((css["--title-scale"], css["--num-font"]), ("1.3", "Calibri, sans-serif"))
        self.assertEqual(self.css({"number_font": "same"}, "full")["--num-font"], "inherit")
        self.assertEqual(validate_style({"number_font": "same"}), {"number_font": "same"})
        with self.assertRaises(ValueError):
            validate_style({"title_scale": 5})

    def test_bad_background_pictures_are_refused(self):
        for bad in ("../x.png", "backgrounds/x.png", "http://a/b.png", "backgrounds/0123456789abcdef.exe", 5):
            with self.assertRaises(ValueError):
                validate_style({"background_image": bad})

    def test_no_style_means_no_css(self):
        self.assertEqual(self.css({}, "full"), {})
        script = ("const {styleToCss}=require(process.argv[1]);"
                  "console.log(JSON.stringify(styleToCss(null,'full')))")
        out = subprocess.run(["node", "-e", script, str(STATIC_DIR / "output.js")],
                             capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(out.stdout), [])


if __name__ == "__main__":
    unittest.main()
