# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Showing a screen full screen on a chosen monitor (the browser and the monitor list are pretend here)."""
import unittest

from churchlight_presenter import launcher
from churchlight_presenter.core import monitors as monitor_list
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import default_outputs
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from churchlight_presenter.ui.screenwindows import ScreenWindows

MONITORS = monitor_list.label([
    {"x": 1920, "y": 0, "width": 1280, "height": 720, "primary": False},
    {"x": 0, "y": 0, "width": 1920, "height": 1080, "primary": True}])


class FakeProcess:
    def __init__(self, command):
        self.command = command
        self.ended = False
        self.pid = 4242

    def poll(self):
        return 0 if self.ended else None

    def terminate(self):
        self.ended = True

    def wait(self, timeout=None):
        return 0

    def kill(self):
        self.ended = True


class Recorder:
    def __init__(self):
        self.made = []

    def __call__(self, command, **kwargs):
        process = FakeProcess(command)
        self.made.append(process)
        return process


class MonitorListTests(unittest.TestCase):
    def test_primary_first_then_left_to_right_with_plain_names(self):
        self.assertEqual([m["name"] for m in MONITORS], ["Monitor 1 (main)", "Monitor 2"])
        self.assertEqual(MONITORS[1]["x"], 1920)

    def test_other_systems_have_no_list(self):
        self.assertEqual(monitor_list.list_monitors("linux"), [])


class CommandTests(unittest.TestCase):
    def test_the_window_is_placed_on_the_monitor_then_made_full_screen(self):
        command = launcher.kiosk_command("edge.exe", "http://127.0.0.1:1/view/projector", MONITORS[1], "C:/p/screen-projector")
        self.assertEqual(command[0], "edge.exe")
        self.assertIn("--kiosk", command)
        self.assertIn("--window-position=1920,0", command)
        self.assertIn("--window-size=1280,720", command)
        self.assertIn("--user-data-dir=C:/p/screen-projector", command)
        self.assertIn("http://127.0.0.1:1/view/projector", command)


class WindowsTests(unittest.TestCase):
    def make(self, monitors=MONITORS, browser=("Edge", "edge.exe")):
        self.run_ = Recorder()
        return ScreenWindows("/tmp/profiles", list_monitors=lambda: monitors, find_browser=lambda: browser,
                             popen=self.run_, platform="linux")

    def test_it_opens_closes_and_forgets_a_window_closed_by_hand(self):
        w = self.make()
        w.show("projector", "http://127.0.0.1:1/view/projector", 1)
        self.assertEqual(w.open_names(), ["projector"])
        self.assertIn("--window-position=1920,0", self.run_.made[0].command)
        self.run_.made[0].ended = True                                  # Alt+F4
        self.assertEqual(w.open_names(), [])
        w.show("projector", "http://127.0.0.1:1/view/projector", 0)
        self.assertTrue(w.hide("projector"))
        self.assertTrue(self.run_.made[1].ended)
        self.assertFalse(w.hide("projector"))

    def test_a_leftover_browser_of_that_screen_is_closed_before_a_new_one_opens(self):
        seen = []
        self.run_ = Recorder()
        w = ScreenWindows("/tmp/profiles", list_monitors=lambda: MONITORS, find_browser=lambda: ("Edge", "edge.exe"),
                          popen=self.run_, platform="linux",
                          close_leftovers=lambda profile, **kw: seen.append((profile, kw, len(self.run_.made))))
        w.show("projector", "http://127.0.0.1:1/view/projector", 1)
        self.assertEqual(len(seen), 1)
        self.assertTrue(seen[0][0].replace("\\", "/").endswith("profiles/screen-projector"))
        self.assertEqual(seen[0][1]["wait"], 0)                      # forced at once, nothing to save
        self.assertEqual(seen[0][2], 0)                              # and done before the new window was started

    def test_showing_again_replaces_the_old_window(self):
        w = self.make()
        w.show("stage", "u", 0)
        w.show("stage", "u", 1)
        self.assertTrue(self.run_.made[0].ended)
        self.assertEqual(len(w.open_names()), 1)

    def test_each_screen_has_its_own_profile_folder(self):
        w = self.make()
        w.show("stage", "u", 0)
        w.show("projector", "u", 1)
        self.assertIn("--user-data-dir=/tmp/profiles/screen-stage", self.run_.made[0].command)
        self.assertIn("--user-data-dir=/tmp/profiles/screen-projector", self.run_.made[1].command)

    def test_problems_are_explained(self):
        from churchlight_presenter.ui.screenwindows import ScreenWindowError
        with self.assertRaises(ScreenWindowError):
            self.make(browser=None).show("a", "u", 0)
        with self.assertRaises(ScreenWindowError) as caught:
            self.make().show("a", "u", 7)
        self.assertIn("not connected", str(caught.exception))
        self.assertFalse(self.make(monitors=[]).available())
        self.assertTrue(self.make().available())

    def test_a_screen_is_refused_on_the_monitor_the_operator_window_is_on(self):
        from churchlight_presenter.ui.screenwindows import ScreenWindowError
        w = self.make()
        with self.assertRaises(ScreenWindowError) as caught:
            w.show("projector", "u", 0, operator_at=(900, 500))             # the middle of Monitor 1
        self.assertIn("cover it", str(caught.exception))
        self.assertEqual(self.run_.made, [])
        w.show("projector", "u", 1, operator_at=(900, 500))                 # the other monitor is fine
        self.assertEqual(w.open_names(), ["projector"])

    def test_a_point_on_no_monitor_does_not_block(self):
        w = self.make()
        w.show("projector", "u", 0, operator_at=(99999, 99999))
        w.show("stage", "u", 0, operator_at=None)
        self.assertEqual(len(w.open_names()), 2)

    def test_close_all_closes_everything(self):
        w = self.make()
        w.show("a", "u", 0)
        w.show("b", "u", 1)
        w.close_all()
        self.assertTrue(all(p.ended for p in self.run_.made))
        self.assertEqual(w.open_names(), [])


class KeepOpenTests(unittest.TestCase):
    def make(self):
        self.rec = Recorder()
        self.hidden = []
        return ScreenWindows("/tmp/p", list_monitors=lambda: MONITORS, find_browser=lambda: ("Edge", "edge.exe"),
                             popen=self.rec, platform="linux", hide_button=lambda pid, platform=None: self.hidden.append(pid))

    def test_a_window_closed_by_accident_opens_again_on_the_same_monitor(self):
        w = self.make()
        w.show("projector", "http://127.0.0.1:1/view/projector?kiosk=1", 1)
        self.rec.made[0].ended = True
        self.rec.made[0].poll = lambda: 1                                       # Alt+F4
        self.assertEqual(w.reopen_missing(), ["projector"])
        self.assertEqual(len(self.rec.made), 2)
        self.assertIn("--window-position=1920,0", self.rec.made[1].command)
        self.assertEqual(w.open_names(), ["projector"])

    def test_a_screen_closed_on_purpose_stays_closed(self):
        w = self.make()
        w.show("projector", "u", 1)
        w.hide("projector")
        self.assertEqual(w.reopen_missing(), [])
        w.show("stage", "u", 0)
        w.close_all()
        self.assertEqual(w.reopen_missing(), [])

    def test_a_browser_that_keeps_dying_is_not_restarted_forever(self):
        w = self.make()
        w.show("projector", "u", 1)
        count = 0
        for second in range(20):
            self.rec.made[-1].poll = lambda: 1
            count += len(w.reopen_missing(now=1000 + second))
        self.assertEqual(count, ScreenWindows.MAX_REOPENS)
        self.assertEqual(len(w.reopen_missing(now=1100)), 1)                   # a minute later it tries again

    def test_each_new_window_gets_its_taskbar_button_taken_away(self):
        w = self.make()
        w.show("projector", "u", 1)
        self.assertEqual(self.hidden, [self.rec.made[0].pid])

    def test_the_watch_thread_reopens_by_itself(self):
        import time
        w = self.make()
        w.show("projector", "u", 1)
        self.rec.made[0].poll = lambda: 1
        w.start_watching(every=0.05)
        self.addCleanup(w.stop_watching)
        end = time.time() + 3
        while time.time() < end and len(self.rec.made) < 2:
            time.sleep(0.05)
        self.assertEqual(len(self.rec.made), 2)

    def test_taskbar_hiding_does_nothing_off_windows(self):
        from churchlight_presenter.ui import winhide
        self.assertIsNone(winhide.hide_from_taskbar_later(123, platform="linux"))


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, default_outputs())
        self.rec = Recorder()
        self.c.screen_windows = ScreenWindows("/tmp/p", list_monitors=lambda: MONITORS,
                                              find_browser=lambda: ("Edge", "edge.exe"), popen=self.rec, platform="linux")
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        self.api = OperatorApi(self.c)

    def test_the_page_can_list_show_and_hide(self):
        info = self.api.call("screen_monitors")
        self.assertTrue(info["available"])
        self.assertEqual(len(info["monitors"]), 2)
        self.api.call("screen_show", {"name": "projector", "monitor": 1})
        url = [a for a in self.rec.made[0].command if a.startswith("http://")][0]
        self.assertEqual(url, f"http://127.0.0.1:{self.server.address[1]}/view/projector?kiosk=1&test=1")      # the white TEST page
        self.assertEqual(self.api.call("screen_monitors")["open"], ["projector"])
        self.api.call("screen_hide", {"name": "projector"})
        self.assertEqual(self.api.call("screen_monitors")["open"], [])

    def test_the_test_is_kept_off_the_monitor_the_operator_window_is_on_and_says_where_it_is(self):
        with self.assertRaises(ApiError):
            self.api.call("screen_show", {"name": "projector", "monitor": 0, "operator_at": [900, 500]})
        self.api.call("screen_show", {"name": "projector", "monitor": 1, "operator_at": [900, 500]})
        self.assertEqual(len(self.rec.made), 1)
        with self.assertRaises(ApiError):
            self.api.call("screen_show", {"name": "stage", "monitor": 1, "operator_at": "x"})
        with self.assertRaises(ApiError):
            self.api.call("screen_show", {"name": "nope", "monitor": 1})

    def _kiosk_page(self):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        self.api.call("screen_show", {"name": "projector", "monitor": 1})
        self.assertEqual(self.c.screen_windows.open_names(), ["projector"])
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page()
        page.goto(f"http://127.0.0.1:{self.server.address[1]}/view/projector?kiosk=1")
        page.wait_for_selector("#root", state="attached")
        return page

    def _closed_soon(self):
        import time
        end = time.time() + 5
        while time.time() < end and self.c.screen_windows.open_names():
            time.sleep(0.05)
        return self.c.screen_windows.open_names() == []

    def test_a_test_page_is_a_big_black_TEST_on_white_whatever_the_screen_is(self):
        page = self._kiosk_page()
        page.goto(f"http://127.0.0.1:{self.server.address[1]}/view/projector?kiosk=1&test=1")
        page.wait_for_selector(".testscreen-word", state="attached")
        self.assertEqual(page.inner_text(".testscreen-word"), "TEST")
        self.assertEqual(page.evaluate("getComputedStyle(document.body).backgroundColor"), "rgb(255, 255, 255)")
        self.assertEqual(page.evaluate("getComputedStyle(document.querySelector('.testscreen-word')).color"), "rgb(0, 0, 0)")
        self.assertGreater(page.evaluate("document.querySelector('.testscreen-word').getBoundingClientRect().height"), 100)

    def test_a_named_screen_shows_its_word_big_and_a_long_one_fits(self):
        page = self._kiosk_page()
        width = page.evaluate("innerWidth")
        page.goto(f"http://127.0.0.1:{self.server.address[1]}/view/projector?kiosk=1&test=1&word=CONFIDENCE")
        page.wait_for_selector(".testscreen-word", state="attached")
        self.assertEqual(page.inner_text(".testscreen-word"), "CONFIDENCE")
        self.assertLessEqual(page.evaluate("document.querySelector('.testscreen-word').scrollWidth"), width)

    def test_the_screens_name_follows_what_it_shows(self):
        self.assertEqual([self.c.screen_word(n) for n in ("projector", "stage", "confidence", "lower-third")],
                         ["PROJECTOR", "STAGE", "CONFIDENCE", "LOWER-THIRD"])

    def test_escape_does_not_close_a_screen_window(self):
        page = self._kiosk_page()
        page.keyboard.press("Escape")
        page.wait_for_timeout(500)
        self.assertEqual(self.c.screen_windows.open_names(), ["projector"])
        self.assertFalse(self.rec.made[0].ended)

    def test_choosing_a_monitor_in_the_guide_opens_the_real_screen_keeps_it_and_saves_it(self):
        self.api.call("screen_assign", {"name": "projector", "monitor": 1, "operator_at": [900, 500]})
        url = [a for a in self.rec.made[0].command if a.startswith("http://")][0]
        self.assertTrue(url.endswith("/view/projector?kiosk=1"))
        self.assertEqual(self.api.call("screens_get")["assign"], {"projector": 1})
        self.assertTrue(self.api.call("screens_get")["auto"])                    # opens at every start unless turned off
        self.assertEqual(self.c.screen_positions(), {"projector": (1920, 0)})
        self.api.call("screen_assign", {"name": "projector", "monitor": None})
        self.assertEqual(self.api.call("screens_get")["assign"], {})
        self.assertEqual(self.c.screen_windows.open_names(), [])

    def test_the_operators_own_monitor_is_refused_and_nothing_is_saved(self):
        with self.assertRaises(ApiError):
            self.api.call("screen_assign", {"name": "projector", "monitor": 0, "operator_at": [900, 500]})
        self.assertEqual(self.api.call("screens_get")["assign"], {})

    def test_saved_screens_open_at_the_next_start_without_being_asked(self):
        self.api.call("screen_assign", {"name": "projector", "monitor": 1})
        self.c.close_screens()
        self.assertTrue(self.c.auto_open_screens(delay=0))
        import time
        end = time.time() + 5
        while time.time() < end and not self.c.screen_windows.open_names():
            time.sleep(0.05)
        self.assertEqual(self.c.screen_windows.open_names(), ["projector"])

    def test_a_normal_page_ignores_escape(self):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        self.api.call("screen_show", {"name": "projector", "monitor": 1})
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page()
        page.goto(f"http://127.0.0.1:{self.server.address[1]}/view/projector")           # an OBS browser source, say
        page.wait_for_selector("#root", state="attached")
        for _ in range(4):
            page.keyboard.press("Escape")
        page.wait_for_timeout(400)
        self.assertEqual(self.c.screen_windows.open_names(), ["projector"])

    def test_only_a_configured_screen_can_be_opened(self):
        with self.assertRaises(ApiError):
            self.api.call("screen_show", {"name": "../evil", "monitor": 0})
        with self.assertRaises(ApiError):
            self.api.call("screen_show", {"name": "nope", "monitor": 0})
        self.assertEqual(self.rec.made, [])

    def test_shutting_down_closes_the_screens(self):
        self.api.call("screen_show", {"name": "stage", "monitor": 0})
        self.c.close()
        self.assertTrue(self.rec.made[0].ended)

    def test_own_projector_windows_open_the_real_screen_on_the_saved_monitors(self):
        self.api.call("screens_set", {"assign": {"projector": 1}, "auto": False})
        view = self.api.call("screens_get")
        self.assertEqual(view["assign"], {"projector": 1})
        self.assertFalse(view["auto"])
        self.assertEqual(self.api.call("screens_open", {})["problems"], [])
        url = [a for a in self.rec.made[0].command if a.startswith("http://")][0]
        self.assertEqual(url, f"http://127.0.0.1:{self.server.address[1]}/view/projector?kiosk=1")      # no test=1
        self.assertEqual(self.api.call("screens_get")["open"], ["projector"])
        self.api.call("screens_close")
        self.assertEqual(self.api.call("screens_get")["open"], [])

    def test_a_screen_on_the_operators_monitor_is_reported_not_opened(self):
        self.api.call("screens_set", {"assign": {"projector": 0, "stage": 1}, "auto": False})
        problems = self.api.call("screens_open", {"operator_at": [900, 500]})["problems"]
        self.assertEqual(len(problems), 1)
        self.assertIn("projector", problems[0])
        self.assertEqual(self.c.screen_windows.open_names(), ["stage"])

    def test_bad_assignments_are_refused(self):
        for bad in ({"nope": 1}, {"projector": -1}, {"projector": "1"}, {"projector": True}):
            with self.assertRaises(ApiError):
                self.api.call("screens_set", {"assign": bad, "auto": False})
        with self.assertRaises(ApiError):
            self.api.call("screens_set", {"assign": [], "auto": False})

    def test_opening_at_start_only_when_ticked_and_assigned(self):
        self.assertFalse(self.c.auto_open_screens(delay=0))
        self.api.call("screens_set", {"assign": {"projector": 1}, "auto": False})
        self.assertFalse(self.c.auto_open_screens(delay=0))
        self.api.call("screens_set", {"assign": {"projector": 1}, "auto": True})
        self.assertTrue(self.c.auto_open_screens(delay=0))
        import time
        end = time.time() + 5
        while time.time() < end and not self.c.screen_windows.open_names():
            time.sleep(0.05)
        self.assertEqual(self.c.screen_windows.open_names(), ["projector"])

    def test_the_settings_fold_lists_screens_and_opens_them(self):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright is not installed")
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page()
        page.goto(f"http://127.0.0.1:{self.server.address[1]}/operator")
        page.wait_for_selector("#pw-list li", state="attached")
        self.assertGreaterEqual(page.locator("#pw-list li").count(), 1)
        page.evaluate("""() => { const s = document.querySelector('#pw-list li select'); s.value = '1';
            s.dispatchEvent(new Event('change')); }""")
        page.wait_for_timeout(500)
        self.assertEqual(len(self.c._read_screens()["assign"]), 1)
        page.evaluate("document.getElementById('pw-open').click()")
        page.wait_for_timeout(700)
        self.assertEqual(len(self.c.screen_windows.open_names()), 1)


class SharedMonitorTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, default_outputs())
        self.rec = Recorder()
        self.c.screen_windows = ScreenWindows("/tmp/p", list_monitors=lambda: MONITORS,
                                              find_browser=lambda: ("Edge", "edge.exe"), popen=self.rec, platform="linux")
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        self.api = OperatorApi(self.c)

    def test_two_screens_on_one_monitor_are_refused_in_plain_words_and_nothing_is_saved(self):
        self.api.call("screens_set", {"assign": {"projector": 1}, "auto": False})
        with self.assertRaises(ApiError) as caught:
            self.api.call("screens_set", {"assign": {"projector": 1, "stage": 1}, "auto": False})
        text = str(caught.exception)
        self.assertIn("already on Monitor 2", text)
        self.assertIn("cannot go there too", text)
        self.assertEqual(self.api.call("screens_get")["assign"], {"projector": 1})

    def test_choosing_a_monitor_another_screen_has_is_refused_before_anything_opens(self):
        self.api.call("screen_assign", {"name": "projector", "monitor": 1})
        opened = len(self.rec.made)
        with self.assertRaises(ApiError) as caught:
            self.api.call("screen_assign", {"name": "stage", "monitor": 1})
        self.assertIn("Projector", str(caught.exception))
        self.assertEqual(len(self.rec.made), opened)                        # no window was opened
        self.assertEqual(self.api.call("screens_get")["assign"], {"projector": 1})
        self.api.call("screen_assign", {"name": "projector", "monitor": 1})   # the same screen on its own monitor is fine
        self.api.call("screen_assign", {"name": "stage", "monitor": 0})       # a different monitor is fine

    def test_an_older_saved_setup_with_two_screens_on_one_monitor_opens_one_and_says_why(self):
        self.db.set_setting("screens", '{"assign": {"projector": 1, "stage": 1}, "auto": true}')
        problems = self.c.open_screens()
        self.assertEqual(len(problems), 1)
        self.assertIn("was not opened", problems[0])
        self.assertIn("Monitor 2", problems[0])
        self.assertEqual(len(self.c.screen_windows.open_names()), 1)


if __name__ == "__main__":
    unittest.main()