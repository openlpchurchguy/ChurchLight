# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A slideshow slide may have a title: it names the slide in the Live panel and the lists."""
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.export import slideshow_snapshot, write_bundle
from churchlight_presenter.importers.bundle import import_bundle
from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.operator_api import ApiError
from tests.test_deck_editor import DeckEditorBase, JS, HTML
from tests.test_export import PNG


class TitleTests(DeckEditorBase):
    def titles(self):
        return [p["title"] for p in self.pages()]

    def labels(self):
        return [s.label for s in self.c.preview(self.entry("presentation", "Welcome"))]

    def test_a_title_replaces_the_plain_slide_number_as_the_label(self):
        a, b, c, d = self.ids()
        self.c.set_deck_page_title(self.deck, b, "  Offering  ")
        self.assertEqual(self.titles(), ["", "Offering", "", ""])
        self.assertEqual(self.labels(), ["Slide 1", "Offering", "Slide 3", "Slide 4"])

    def test_clearing_goes_back_to_slide_n(self):
        a = self.ids()[0]
        self.c.set_deck_page_title(self.deck, a, "Welcome")
        self.c.set_deck_page_title(self.deck, a, "   ")
        self.assertEqual(self.titles()[0], "")
        self.assertEqual(self.labels()[0], "Slide 1")

    def test_spaces_collapse_and_length_is_limited(self):
        a = self.ids()[0]
        self.c.set_deck_page_title(self.deck, a, "Prayer   and \n praise")
        self.assertEqual(self.titles()[0], "Prayer and praise")
        for bad in ("x" * 61, 5, None):
            with self.assertRaises(ControllerError, msg=repr(bad)):
                self.c.set_deck_page_title(self.deck, a, bad)
        self.c.set_deck_page_title(self.deck, a, "x" * 60)

    def test_a_slide_that_is_not_in_the_deck_is_refused(self):
        with self.assertRaises(ControllerError):
            self.c.set_deck_page_title(self.deck, 999999, "Nope")

    def test_it_cannot_be_changed_while_live(self):
        self.c.go_live_entry(self.entry("presentation", "Welcome"))
        with self.assertRaises(ControllerError):
            self.c.set_deck_page_title(self.deck, self.ids()[0], "Late")

    def test_a_skipped_slide_keeps_its_title_and_numbers_do_not_shift_names(self):
        a, b, c, d = self.ids()
        self.c.set_deck_page_title(self.deck, c, "Announcements")
        self.c.skip_deck_pages(self.deck, [b], True)
        self.assertEqual(self.labels(), ["Slide 1", "Announcements", "Slide 4"])

    def test_duplicate_copies_the_title(self):
        a = self.ids()[0]
        self.c.set_deck_page_title(self.deck, a, "Welcome")
        self.c.duplicate_deck_pages(self.deck, [a])
        self.assertEqual(self.titles()[:2], ["Welcome", "Welcome"])

    def test_slides_copied_from_another_slideshow_and_a_split_keep_titles(self):
        a, b = self.ids()[:2]
        self.c.set_deck_page_title(self.deck, b, "Sermon")
        other, _paths = self.make_deck("Other", pages=1, folder="decks/other")
        self.c.add_deck_pages_from(other, self.deck, [b])
        self.assertEqual([p["title"] for p in self.c.deck_for_editing(other)["pages"]], ["", "Sermon"])
        part = self.c.split_deck(self.deck, [b], "Just the sermon")
        self.assertEqual([p["title"] for p in self.c.deck_for_editing(part)["pages"]], ["Sermon"])

    def test_the_operator_api(self):
        b = self.ids()[1]
        self.api.call("deck_page_title", {"id": self.deck, "page": b, "title": "Offering"})
        self.assertEqual(self.titles()[1], "Offering")
        with self.assertRaises(ApiError):
            self.api.call("deck_page_title", {"id": self.deck, "page": b, "title": "x" * 70})
        with self.assertRaises(ApiError):
            self.api.call("deck_page_title", {"id": self.deck, "title": "No page"})

    def test_the_editor_has_a_title_box_and_shows_titles_on_thumbnails(self):
        self.assertIn('id="de-slide-title"', HTML)
        self.assertIn('maxlength="60"', HTML[HTML.index('id="de-slide-title"'):][:200])
        self.assertIn("deck_page_title", JS)
        self.assertIn('"de-title"', JS)


class BundleTitleTests(unittest.TestCase):
    def test_titles_travel_in_an_exported_bundle_and_old_bundles_still_load(self):
        with tempfile.TemporaryDirectory() as tmp:
            media_a, media_b = Path(tmp) / "a", Path(tmp) / "b"
            (media_a / "decks").mkdir(parents=True)
            db = DatabaseManager(":memory:")
            self.addCleanup(db.close)
            pages = []
            for n in (1, 2):
                (media_a / "decks" / f"p{n}.png").write_bytes(PNG + bytes([n]))
                pages.append((f"decks/p{n}.png", None, "Offering" if n == 2 else None))
            show = db.add_presentation("Welcome", pages)
            path = Path(tmp) / "out.zip"
            with open(path, "wb") as f:
                write_bundle(slideshow_snapshot(db, [show]), media_a, f)
            other = DatabaseManager(":memory:")
            self.addCleanup(other.close)
            report = import_bundle(other, path, media_b)
            rows = other.get_presentation_pages(report.imported[0][0])
            self.assertEqual([r["title"] for r in rows], [None, "Offering"])


if __name__ == "__main__":
    unittest.main()
