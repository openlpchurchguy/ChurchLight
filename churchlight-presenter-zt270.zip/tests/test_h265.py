# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A video in H.265 (HEVC) cannot be shown by most browsers, OBS or XSplit: it is refused with a plain explanation."""
import io
import shutil
import struct
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.imports import mp4_uses_h265


def box(kind, body=b""):
    return struct.pack(">I4s", 8 + len(body), kind) + body


def mp4(entry, moov_first=True):
    """The smallest MP4 skeleton that names a video track `entry` (avc1, hvc1...)."""
    ftyp = box(b"ftyp", b"isom\x00\x00\x02\x00isomiso2")
    moov = box(b"moov", box(b"trak", box(b"mdia", box(b"hdlr", b"\x00" * 8 + b"vide" + b"\x00" * 12) + box(b"minf", box(b"stbl", box(b"stsd", b"\x00" * 8 + box(entry, b"\x00" * 78)))))))
    mdat = box(b"mdat", b"\x00" * 64)
    return ftyp + (moov + mdat if moov_first else mdat + moov)


class H265Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def write(self, name, data):
        path = self.tmp / name
        path.write_bytes(data)
        return path

    def test_it_is_found_wherever_the_movie_header_sits(self):
        for entry in (b"hvc1", b"hev1", b"dvh1"):
            for first in (True, False):
                self.assertTrue(mp4_uses_h265(self.write("a.mp4", mp4(entry, first))), (entry, first))

    def test_h264_and_unreadable_files_are_not_flagged(self):
        self.assertFalse(mp4_uses_h265(self.write("a.mp4", mp4(b"avc1"))))
        self.assertFalse(mp4_uses_h265(self.write("b.mp4", b"\x00\x00\x00\x18ftypisom" + b"\x00" * 16)))
        self.assertFalse(mp4_uses_h265(self.write("c.mp4", b"")))
        self.assertFalse(mp4_uses_h265(self.tmp / "missing.mp4"))

    def test_the_import_refuses_it_and_accepts_an_h264_video(self):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db, media_root=self.tmp / "media")
        c.serve(media_root=self.tmp / "media")
        self.addCleanup(c.close)
        data = mp4(b"hvc1")
        batch = c.imports.new_batch()
        c.imports.save_upload(batch, "Praise.mp4", io.BytesIO(data), len(data), "media")
        with self.assertRaises(ControllerError) as problem:
            c.add_media_file(batch, 30)
        self.assertIn("H.265", str(problem.exception))
        self.assertIn("HandBrake", str(problem.exception))
        self.assertEqual(c.media_list(), [])
        data = mp4(b"avc1")
        batch = c.imports.new_batch()
        c.imports.save_upload(batch, "Praise.mp4", io.BytesIO(data), len(data), "media")
        c.add_media_file(batch, 30)
        self.assertEqual([m["name"] for m in c.media_list()], ["Praise"])


if __name__ == "__main__":
    unittest.main()
