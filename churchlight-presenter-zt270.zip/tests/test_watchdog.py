# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""ChurchLight starts itself again when it stops answering, and when the Restart button is pressed."""
import threading
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui import watchdog
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi


class StepTests(unittest.TestCase):
    def make(self, answers):
        calls = []
        feed = iter(answers)
        dog = watchdog.Watchdog(lambda: next(feed), lambda: calls.append("stuck"), failures=3)
        return dog, calls

    def test_it_acts_only_after_several_silent_checks_in_a_row(self):
        dog, calls = self.make([True, False, False, False])
        self.assertEqual([dog.step() for _ in range(4)], [False, False, False, True])
        self.assertEqual(calls, ["stuck"])

    def test_the_log_gets_every_threads_position_when_it_is_stuck(self):
        dog, calls = self.make([True, False, False, False])
        with self.assertLogs("churchlight_presenter.watchdog", level="ERROR") as logged:
            for _ in range(4):
                dog.step()
        text = "\n".join(logged.output)
        self.assertIn("--- thread MainThread", text)
        self.assertIn("test_the_log_gets_every_threads_position", text)

    def test_one_answer_in_between_starts_the_count_again(self):
        dog, calls = self.make([True, False, False, True, False, False, True])
        for _ in range(7):
            dog.step()
        self.assertEqual(calls, [])

    def test_it_does_nothing_before_the_program_has_answered_once(self):
        dog, calls = self.make([False] * 10)
        for _ in range(10):
            dog.step()
        self.assertEqual(calls, [])

    def test_the_probe_is_false_when_nothing_listens_and_true_when_the_program_answers(self):
        self.assertFalse(watchdog.probe(1, timeout=0.5))
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db)
        server = c.serve()
        self.addCleanup(c.close)
        self.assertTrue(watchdog.probe(server.address[1]))

    def test_a_program_that_is_stuck_does_not_answer_in_time(self):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db)
        server = c.serve()
        self.addCleanup(c.close)
        c.lock.acquire()                                  # whatever holds the program's lock when it seizes up
        try:
            self.assertFalse(watchdog.probe(server.address[1], timeout=1.0))
        finally:
            c.lock.release()
        self.assertTrue(watchdog.probe(server.address[1]))


class RestartTests(unittest.TestCase):
    def test_the_new_copy_gets_the_same_arguments_without_open_after_a_freeze(self):
        made = []
        ok = watchdog.spawn_restart(["--db", "a.db", "--open", "--no-console"], popen=lambda cmd, **kw: made.append((cmd, kw)),
                                    environ={}, executable="python")
        self.assertTrue(ok)
        command, kwargs = made[0]
        self.assertEqual(command[0], "python")
        self.assertEqual(command[3:], ["--db", "a.db", "--no-console"])
        self.assertEqual(kwargs["env"][watchdog.RESTART_ENV], "1")

    def test_a_restart_asked_for_keeps_the_operator_window_option(self):
        made = []
        watchdog.spawn_restart(["--open", "--db", "a.db"], popen=lambda cmd, **kw: made.append(cmd), environ={}, executable="python", keep_open=True)
        self.assertEqual(made[0][3:], ["--open", "--db", "a.db"])

    def test_it_gives_up_after_too_many_restarts_in_a_row(self):
        made = []
        env = {watchdog.RESTART_ENV: str(watchdog.MAX_RESTARTS)}
        self.assertFalse(watchdog.spawn_restart(["--db", "a.db"], popen=lambda cmd, **kw: made.append(cmd), environ=env))
        self.assertEqual(made, [])

    def test_shutdown_works_even_when_the_program_has_seized_up(self):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db)
        api = OperatorApi(c)
        c.lock.acquire()                                  # the program is stuck holding its lock
        try:
            reply = {}
            worker = threading.Thread(target=lambda: reply.update(api.call("shutdown")), daemon=True)
            worker.start()
            worker.join(2)
            self.assertFalse(worker.is_alive())
            self.assertTrue(c.shutdown_requested.is_set())
        finally:
            c.lock.release()


if __name__ == "__main__":
    unittest.main()


class RestartHelpersTests(unittest.TestCase):
    def test_the_screens_are_closed_with_the_profile_of_the_database_in_the_arguments(self):
        from churchlight_presenter import __main__ as program
        self.assertTrue(program._browser_profile_of(["--db", "church.db", "--no-console"]).endswith("browser-profile"))
        self.assertTrue(program._browser_profile_of(["--db=x/church.db"]).replace("\\\\", "/").endswith("x/browser-profile"))
        self.assertIsNone(program._browser_profile_of(["--db", ":memory:"]))


class ForceExitTests(unittest.TestCase):
    def test_the_force_exit_never_arms_inside_the_tests(self):
        from unittest import mock
        from churchlight_presenter import __main__ as program
        with mock.patch.object(program.threading, "Thread") as thread:
            program._force_exit_later(0.01)
        thread.assert_not_called()
