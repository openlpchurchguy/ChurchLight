# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A browser that will not start sound without a click: only a page that wants sound asks for the click."""
import io
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import OperatorController
from tests.test_media_browser import wav_bytes

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:                                           # pragma: no cover
    HAVE_BROWSER = False


def until(check, seconds=6):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class SoundHintTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        self.c = OperatorController(db, [Output("projector", "projector")], media_root=self.tmp / "media")
        server = self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        self.base = server.url.rstrip("/")
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch(args=["--autoplay-policy=document-user-activation-required"])
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.browser = browser
        batch = self.c.imports.new_batch()
        data = wav_bytes(30)
        self.c.imports.save_upload(batch, "m.wav", io.BytesIO(data), len(data), "media")
        self.sound = self.c.add_media_file(batch, 30)

    def hint(self, page):
        page.wait_for_timeout(50)
        return page.locator("#cl-sound-hint").count() == 1

    def test_a_silent_page_never_asks_for_a_click(self):
        page = self.browser.new_page()
        page.goto(self.base + "/view/projector")
        self.c.play_music(self.sound)
        page.wait_for_timeout(2500)
        self.assertFalse(self.hint(page))

    BLOCK = """(() => {                       // what a strict browser does: sound needs a click, silence does not
      const real = HTMLMediaElement.prototype.play;
      window.__clicked = false;
      addEventListener("click", () => { window.__clicked = true; }, true);
      HTMLMediaElement.prototype.play = function () {
        if (!this.muted && !window.__clicked) return Promise.reject(new DOMException("blocked", "NotAllowedError"));
        return real.call(this);
      };
    })()"""

    def test_a_page_that_wants_sound_asks_once_and_plays_with_sound_after_the_click(self):
        page = self.browser.new_page()
        page.add_init_script(self.BLOCK)
        page.goto(self.base + "/view/projector?sound=on")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: self.hint(page)))
        self.assertEqual(page.locator("#cl-sound-hint").count(), 1)       # one notice, not one for every try
        page.mouse.click(50, 50)
        self.assertTrue(until(lambda: not self.hint(page)))
        self.assertTrue(until(lambda: page.evaluate("(() => { const a = document.querySelector('audio'); return !!a && !a.paused && !a.muted; })()")))

    def test_a_clip_that_is_turned_away_while_silent_is_tried_again(self):
        page = self.browser.new_page()
        page.add_init_script("""(() => {
          const real = HTMLMediaElement.prototype.play; let refused = 0;
          HTMLMediaElement.prototype.play = function () {
            if (refused < 2) { refused += 1; return Promise.reject(new DOMException("interrupted", "AbortError")); }
            return real.call(this);
          };
        })()""")
        page.goto(self.base + "/view/projector")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: page.evaluate("(() => { const a = document.querySelector('audio'); return !!a && !a.paused; })()"), 10))
        self.assertFalse(self.hint(page))


if __name__ == "__main__":
    unittest.main()
