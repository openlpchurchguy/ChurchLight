# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The ticks that leave song parts out are there in Plan mode only, not in Run mode."""
import unittest

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class SkipTicksTests(unittest.TestCase):
    def test_ticks_show_in_plan_and_hide_in_run(self):
        db, c, api = make()
        self.addCleanup(db.close)
        song = c.create_song("Hymn", "", "[Verse 1]\na\nb\n\n[Chorus]\nc\nd")
        c.new_service("S")
        c.add_entry(next(e for e in c.search_library("Hymn") if e.kind == "song"))
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#items button.more", state="attached")
        page.click("#items button.more")
        page.click("#mode-plan")
        self.assertGreater(page.locator("#items .outline-part input[type=checkbox]:visible").count(), 0)
        page.click("#mode-run")
        self.assertEqual(page.locator("#items .outline-part input[type=checkbox]:visible").count(), 0)
        self.assertGreater(page.locator("#items .outline-part").count(), 0)        # the parts themselves stay
        page.click("#mode-plan")
        self.assertGreater(page.locator("#items .outline-part input[type=checkbox]:visible").count(), 0)
        self.assertFalse(page.is_visible("#items .reset-parts"))           # nothing left out, nothing to reset
        self.assertNotIn("Parts and where we are", page.inner_text("#items"))   # and no line saying "whole song"
        # leave the chorus out: Plan shows the tick, Run shows a mark where the tick was and the reset button
        page.locator("#items .outline-part input[type=checkbox]").nth(1).uncheck()
        page.wait_for_selector("#items .outline-part.left-out", state="attached")
        self.assertIn("Parts and where we are", page.inner_text("#items"))      # now there is something to say
        self.assertFalse(page.is_visible("#items .skip-mark"))
        self.assertFalse(page.is_visible("#items .reset-parts"))           # Plan mode: no reset button
        before = page.locator("#items .outline-part.left-out label").bounding_box()
        page.click("#mode-run")
        self.assertTrue(page.is_visible("#items .skip-mark"))
        self.assertTrue(page.is_visible("#items .reset-parts"))
        after = page.locator("#items .outline-part.left-out label").bounding_box()
        self.assertAlmostEqual(before["x"], after["x"], delta=1)           # nothing moved
        self.assertEqual(page.locator("#items .outline-part:not(.left-out) .skip-mark:visible").count(), 0)
        page.locator("#items .outline-part.left-out label").click(force=True)         # clicking the name does nothing in Run mode
        page.wait_for_timeout(300)
        self.assertEqual(page.locator("#items .outline-part.left-out").count(), 1)
        self.assertEqual(page.evaluate("document.querySelector('#items .outline-part.left-out input').checked"), False)


    def test_a_redraw_keeps_the_part_list_where_it_was_scrolled(self):
        db, c, api = make()
        self.addCleanup(db.close)
        text = "\n\n".join(f"[Verse {n}]\n" + "\n".join(f"line {n}.{k} of the song words" for k in range(1, 5)) for n in range(1, 9))
        c.create_song("Long", "", text)
        c.new_service("S")
        c.add_entry(next(e for e in c.search_library("Long") if e.kind == "song"))
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1280, "height": 700})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#items button.more", state="attached")
        page.click("#items button.more")
        page.click("#mode-plan")
        page.evaluate("document.querySelector('.outline-list').scrollTop = 150")
        page.evaluate("document.querySelectorAll('#items .outline-part input[type=checkbox]')[5].click()")
        page.wait_for_selector("#items .outline-part.left-out", state="attached")
        page.wait_for_timeout(300)
        self.assertEqual(page.evaluate("document.querySelector('.outline-list').scrollTop"), 150)


    def test_the_whole_song_button_also_brings_back_only_the_title_slide(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.set_notice_settings("before", "", "", True)
        c.create_song("Hymn", "", "[Verse 1]\na\nb\n\n[Chorus]\nc\nd")
        c.new_service("S")
        c.add_entry(next(e for e in c.search_library("Hymn") if e.kind == "song"))
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector("#items button.more", state="attached")
        page.click("#items button.more")
        page.click("#mode-plan")
        first = page.locator("#items .outline-part").first
        self.assertIn("Title and CCLI", first.inner_text())
        first.locator("input[type=checkbox]").uncheck()
        page.wait_for_selector("#items .outline-part.left-out", state="attached")
        self.assertIn("Title and CCLI", page.locator("#items .outline-part").first.inner_text())      # still the first row
        self.assertIn("title and CCLI slide left out", page.inner_text("#items"))
        page.click("#mode-run")
        page.click("#items .reset-parts")                                    # only the title slide is missing
        page.wait_for_selector("#items .outline-part.left-out", state="detached")
        self.assertFalse(page.is_visible("#items .reset-parts"))


if __name__ == "__main__":
    unittest.main()
