# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A pretend OBS (obs-websocket 5) for the tests: keeps scenes, inputs and scene items in memory."""
import base64
import hashlib
import json
import socket
import threading

from churchlight_presenter.core.obsws import GUID, auth_string, encode_frame, read_message


class FakeObs:
    def __init__(self, password="", monitors=None, kinds=None, canvas=(1920, 1080)):
        self.password = password
        self.bad_password_close = 4009      # the close code sent for a wrong password; None hangs up without a word
        self.monitors = monitors if monitors is not None else [
            {"monitorName": "Main", "monitorIndex": 0, "monitorWidth": 1920, "monitorHeight": 1080},
            {"monitorName": "Projector", "monitorIndex": 1, "monitorWidth": 1280, "monitorHeight": 720}]
        self.kinds = kinds or ["browser_source", "color_source_v3", "dshow_input", "monitor_capture"]
        self.transforms = {}        # scene item id -> transform
        self.canvas = canvas
        self.scenes = ["Scene"]
        self.inputs = {}            # name -> {"kind", "settings"}
        self.items = {"Scene": []}  # scene -> [{"id", "source"}] bottom to top
        self.projected = []
        self.requests = []
        self.next_id = 1
        self.refuse = {}            # request type -> comment: answer with a failure
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        self.stop = False
        threading.Thread(target=self._accept, daemon=True).start()

    def close(self):
        self.stop = True
        try:
            self.sock.shutdown(socket.SHUT_RDWR)          # wakes the thread waiting in accept()
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass

    def _accept(self):
        while not self.stop:
            try:
                conn, _ = self.sock.accept()
            except OSError:
                return
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    def _send(self, conn, message):
        conn.sendall(encode_frame(json.dumps(message), mask=False))

    def _serve(self, conn):
        try:
            head = b""
            while b"\r\n\r\n" not in head:
                head += conn.recv(1)
            text = head.decode("latin-1")
            key = next(l.split(":", 1)[1].strip() for l in text.split("\r\n") if l.lower().startswith("sec-websocket-key"))
            accept = base64.b64encode(hashlib.sha1((key + GUID).encode()).digest()).decode()
            conn.sendall(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                          f"Sec-WebSocket-Accept: {accept}\r\nSec-WebSocket-Protocol: obswebsocket.json\r\n\r\n").encode())
            hello = {"obsWebSocketVersion": "5.5.0", "rpcVersion": 1}
            if self.password:
                hello["authentication"] = {"challenge": "chal", "salt": "salt"}
            self._send(conn, {"op": 0, "d": hello})
            ident = json.loads(read_message(conn))
            if self.password and ident["d"].get("authentication") != auth_string(self.password, "salt", "chal"):
                if self.bad_password_close is not None:                      # real OBS says why before it hangs up
                    reason = b"Authentication failed."
                    conn.sendall(bytes([0x88, 2 + len(reason)]) + self.bad_password_close.to_bytes(2, "big") + reason)
                conn.close()
                return
            self._send(conn, {"op": 2, "d": {"negotiatedRpcVersion": 1}})
            while True:
                message = json.loads(read_message(conn))
                d = message["d"]
                self.requests.append((d["requestType"], d.get("requestData") or {}))
                try:
                    if d["requestType"] in self.refuse:
                        raise KeyError(self.refuse[d["requestType"]])
                    data = self.handle(d["requestType"], d.get("requestData") or {})
                    status = {"result": True, "code": 100}
                except KeyError as err:
                    data, status = None, {"result": False, "code": 600, "comment": str(err.args[0])}
                self._send(conn, {"op": 7, "d": {"requestType": d["requestType"], "requestId": d["requestId"],
                                                 "requestStatus": status, "responseData": data}})
        except Exception:  # noqa: BLE001 - the client hung up
            try:
                conn.close()
            except OSError:
                pass

    def handle(self, kind, a):
        if kind == "GetVersion":
            return {"obsVersion": "31.0.0"}
        if kind == "GetVideoSettings":
            return {"baseWidth": self.canvas[0], "baseHeight": self.canvas[1]}
        if kind == "GetSceneList":
            return {"scenes": [{"sceneName": n, "sceneIndex": i} for i, n in enumerate(self.scenes)]}
        if kind == "GetInputList":
            return {"inputs": [{"inputName": n, "inputKind": v["kind"]} for n, v in self.inputs.items()]}
        if kind == "GetInputKindList":
            return {"inputKinds": self.kinds}
        if kind == "GetMonitorList":
            return {"monitors": self.monitors}
        if kind == "CreateScene":
            if a["sceneName"] in self.scenes:
                raise KeyError("A scene with that name already exists")
            self.scenes.append(a["sceneName"])
            self.items[a["sceneName"]] = []
            return {}
        if kind == "GetSceneItemList":
            return {"sceneItems": [{"sceneItemId": i["id"], "sourceName": i["source"], "sceneItemIndex": n}
                                   for n, i in enumerate(self.items[a["sceneName"]])]}
        if kind == "CreateInput":
            if a["inputName"] in self.inputs:
                raise KeyError("A source with that name already exists")
            if a["inputKind"] not in self.kinds:
                raise KeyError("Unknown input kind")
            self.inputs[a["inputName"]] = {"kind": a["inputKind"], "settings": dict(a.get("inputSettings") or {})}
            return self._add(a["sceneName"], a["inputName"])
        if kind == "SetInputSettings":
            self.inputs[a["inputName"]]["settings"].update(a["inputSettings"])
            return {}
        if kind == "CreateSceneItem":
            return self._add(a["sceneName"], a["sourceName"])
        if kind == "SetSceneItemIndex":
            items = self.items[a["sceneName"]]
            item = next(i for i in items if i["id"] == a["sceneItemId"])
            items.remove(item)
            items.insert(a["sceneItemIndex"], item)
            return {}
        if kind == "GetInputPropertiesListPropertyItems":
            return {"propertyItems": [{"itemName": "Display 1: 1920x1080 @ 0,0 (Primary Monitor)", "itemValue": "DISPLAY-A"},
                                      {"itemName": "Display 2: 1280x720 @ 1920,0", "itemValue": "DISPLAY-B"}]}
        if kind == "SetSceneItemTransform":
            self.transforms[a["sceneItemId"]] = a["sceneItemTransform"]
            return {}
        if kind == "OpenSourceProjector":
            self.projected.append((a["sourceName"], a["monitorIndex"]))
            return {}
        raise KeyError("Unknown request " + kind)

    def _add(self, scene, source):
        item = {"id": self.next_id, "source": source}
        self.next_id += 1
        self.items[scene].append(item)
        return {"sceneItemId": item["id"]}
