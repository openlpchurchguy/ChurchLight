# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The deck editor (Stage A): reorder, delete, duplicate, skip and notes, and the live lock."""
import json
import re
import shutil
import sqlite3
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.test_library_admin import AdminBase


STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
JS_PATH = STATIC / "operator.js"
HTML = (STATIC / "operator.html").read_text(encoding="utf-8")
JS = JS_PATH.read_text(encoding="utf-8")


class DeckEditorBase(AdminBase):
    def setUp(self):
        super().setUp()
        self.deck, self.paths = self.make_deck("Welcome", pages=4)
        self.api = OperatorApi(self.c)

    def pages(self):
        return self.c.deck_for_editing(self.deck)["pages"]

    def ids(self):
        return [p["id"] for p in self.pages()]

    def numbers(self):
        return [p["image"].rsplit("/", 1)[1] for p in self.pages()]


class DataTests(DeckEditorBase):
    def test_a_new_database_is_at_the_latest_version_and_pages_are_not_skipped(self):
        self.assertEqual(self.db.conn.execute("PRAGMA user_version").fetchone()[0], 20)
        self.assertTrue(all(p["skipped"] == 0 for p in self.db.get_presentation_pages(self.deck)))

    def test_migration_nine_keeps_existing_pages(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        from churchlight_presenter.core import migrations
        migrations.migrate(conn, migrations.MIGRATIONS[:8])
        conn.execute("INSERT INTO presentations (name) VALUES ('Old')")
        conn.execute("INSERT INTO presentation_pages (presentation_id, page_number, image_path) VALUES (1, 1, 'x.png')")
        migrations.migrate(conn)
        row = conn.execute("SELECT * FROM presentation_pages").fetchone()
        self.assertEqual((row["image_path"], row["skipped"]), ("x.png", 0))
        conn.close()

    def test_the_editor_view_lists_pages_in_order_with_their_services(self):
        info = self.c.deck_for_editing(self.deck)
        self.assertEqual((info["name"], info["live"], info["services"]), ("Welcome", False, []))
        self.assertEqual([p["number"] for p in info["pages"]], [1, 2, 3, 4])
        service = self.c.new_service("Sunday")
        self.c.add_entry(self.entry("presentation", "Welcome"))
        self.assertEqual([s["id"] for s in self.c.deck_for_editing(self.deck)["services"]], [service])


class ReorderTests(DeckEditorBase):
    def test_reorder_changes_the_order_and_keeps_every_page(self):
        a, b, c, d = self.ids()
        self.c.reorder_deck_pages(self.deck, [d, b, a, c])
        self.assertEqual(self.ids(), [d, b, a, c])
        self.assertEqual([p["number"] for p in self.pages()], [1, 2, 3, 4])

    def test_an_order_that_misses_or_adds_a_page_is_refused(self):
        a, b, c, d = self.ids()
        for bad in ([a, b, c], [a, b, c, d, 999], [a, a, b, c]):
            with self.assertRaises(ControllerError):
                self.c.reorder_deck_pages(self.deck, bad)
        self.assertEqual(self.ids(), [a, b, c, d])

    def test_the_slides_a_service_builds_follow_the_new_order(self):
        a, b, c, d = self.ids()
        self.c.new_service("Sunday")
        self.c.add_entry(self.entry("presentation", "Welcome"))
        self.c.reorder_deck_pages(self.deck, [d, c, b, a])
        built = [s.image_path for s in self.c.session.slides]
        self.assertEqual(built, list(reversed(self.paths)))


class DeleteTests(DeckEditorBase):
    def test_delete_closes_the_gap_and_removes_the_unused_picture(self):
        a, b, c, d = self.ids()
        self.c.delete_deck_pages(self.deck, [b, c])
        self.assertEqual(self.ids(), [a, d])
        self.assertEqual([p["number"] for p in self.pages()], [1, 2])
        self.assertFalse((self.tmp / "media" / self.paths[1]).exists())
        self.assertTrue((self.tmp / "media" / self.paths[0]).exists())

    def test_the_last_page_cannot_be_deleted(self):
        with self.assertRaises(ControllerError):
            self.c.delete_deck_pages(self.deck, self.ids())
        self.assertEqual(len(self.ids()), 4)

    def test_deleting_every_page_that_is_not_skipped_is_refused(self):
        a, b, c, d = self.ids()
        self.c.skip_deck_pages(self.deck, [b, c, d], True)
        with self.assertRaises(ControllerError):
            self.c.delete_deck_pages(self.deck, [a])

    def test_a_picture_another_page_still_uses_is_kept(self):
        a, b, c, d = self.ids()
        (new,) = self.c.duplicate_deck_pages(self.deck, [a])
        self.c.delete_deck_pages(self.deck, [a])
        self.assertTrue((self.tmp / "media" / self.paths[0]).exists())
        self.assertIn(new, self.ids())

    def test_a_page_from_another_deck_is_refused(self):
        other, _ = self.make_deck("Other", pages=2, folder="decks/other")
        foreign = self.db.get_presentation_pages(other)[0]["id"]
        with self.assertRaises(ControllerError):
            self.c.delete_deck_pages(self.deck, [foreign])
        self.assertEqual(len(self.db.get_presentation_pages(other)), 2)


class DuplicateTests(DeckEditorBase):
    def test_each_copy_goes_right_after_its_original(self):
        a, b, c, d = self.ids()
        self.c.set_deck_page_notes(self.deck, b, "say hello")
        new = self.c.duplicate_deck_pages(self.deck, [b, d])
        self.assertEqual(len(new), 2)
        self.assertEqual(self.ids(), [a, b, new[0], c, d, new[1]])
        copy = self.pages()[2]
        self.assertEqual((copy["image"], copy["notes"]), (self.paths[1], "say hello"))
        self.assertEqual([p["number"] for p in self.pages()], [1, 2, 3, 4, 5, 6])


class SkipTests(DeckEditorBase):
    def test_a_skipped_page_stays_in_the_deck_but_not_in_the_slides(self):
        a, b, c, d = self.ids()
        self.c.skip_deck_pages(self.deck, [b], True)
        self.assertTrue(self.pages()[1]["skipped"])
        self.assertEqual(len(self.pages()), 4)
        slides = self.c.preview(self.entry("presentation", "Welcome"))
        self.assertEqual([s.image_path for s in slides], [self.paths[0], self.paths[2], self.paths[3]])
        self.assertEqual([s.label for s in slides], ["Slide 1", "Slide 3", "Slide 4"])

    def test_skipping_can_be_undone(self):
        a, b, c, d = self.ids()
        self.c.skip_deck_pages(self.deck, [b, c], True)
        self.c.skip_deck_pages(self.deck, [b], False)
        self.assertEqual([p["skipped"] for p in self.pages()], [False, False, True, False])

    def test_every_page_cannot_be_skipped(self):
        with self.assertRaises(ControllerError):
            self.c.skip_deck_pages(self.deck, self.ids(), True)
        a, b, c, d = self.ids()
        self.c.skip_deck_pages(self.deck, [a, b, c], True)
        with self.assertRaises(ControllerError):
            self.c.skip_deck_pages(self.deck, [d], True)

    def test_a_service_stops_showing_a_skipped_slide_at_once(self):
        a, b, c, d = self.ids()
        self.c.new_service("Sunday")
        self.c.add_entry(self.entry("presentation", "Welcome"))
        self.assertEqual(len(self.c.session.slides), 4)
        self.c.skip_deck_pages(self.deck, [a], True)
        self.assertEqual(len(self.c.session.slides), 3)


class NotesTests(DeckEditorBase):
    def test_notes_are_saved_trimmed_and_can_be_cleared(self):
        a = self.ids()[0]
        self.c.set_deck_page_notes(self.deck, a, "  Welcome everyone  ")
        self.assertEqual(self.pages()[0]["notes"], "Welcome everyone")
        self.c.set_deck_page_notes(self.deck, a, "")
        self.assertEqual(self.pages()[0]["notes"], "")
        self.assertIsNone(self.db.get_presentation_pages(self.deck)[0]["notes"])

    def test_notes_must_be_text_and_not_huge(self):
        a = self.ids()[0]
        with self.assertRaises(ControllerError):
            self.c.set_deck_page_notes(self.deck, a, "x" * 6000)


class LiveLockTests(DeckEditorBase):
    def go_live(self):
        self.c.go_live_entry(self.entry("presentation", "Welcome"))

    def test_a_deck_on_the_outputs_cannot_be_changed(self):
        a, b, c, d = self.ids()
        self.go_live()
        self.assertTrue(self.c.deck_is_live(self.deck))
        self.assertTrue(self.c.deck_for_editing(self.deck)["live"])
        for call in (lambda: self.c.reorder_deck_pages(self.deck, [d, c, b, a]),
                     lambda: self.c.delete_deck_pages(self.deck, [a]),
                     lambda: self.c.duplicate_deck_pages(self.deck, [a]),
                     lambda: self.c.skip_deck_pages(self.deck, [a], True),
                     lambda: self.c.set_deck_page_notes(self.deck, a, "no")):
            with self.assertRaisesRegex(ControllerError, "live"):
                call()
        self.assertEqual(self.ids(), [a, b, c, d])

    def test_another_deck_is_still_editable_while_this_one_is_live(self):
        other, _ = self.make_deck("Other", pages=2, folder="decks/other")
        self.go_live()
        ids = [p["id"] for p in self.db.get_presentation_pages(other)]
        self.c.skip_deck_pages(other, [ids[0]], True)
        self.assertTrue(self.db.get_presentation_pages(other)[0]["skipped"])

    def test_the_lock_ends_when_the_output_is_cleared(self):
        self.go_live()
        self.c.clear()
        self.assertFalse(self.c.deck_is_live(self.deck))
        self.c.skip_deck_pages(self.deck, [self.ids()[0]], True)

    def test_a_deck_live_inside_a_service_is_locked_too(self):
        self.c.new_service("Sunday")
        self.c.add_entry(self.entry("presentation", "Welcome"))
        item = self.c.service_rows()[0].item_id
        self.c.go_live_service_item(item)
        self.assertTrue(self.c.deck_is_live(self.deck))
        with self.assertRaisesRegex(ControllerError, "live"):
            self.c.delete_deck_pages(self.deck, [self.ids()[0]])

    def test_a_song_live_does_not_lock_the_deck(self):
        self.c.create_song("Hymn", "", "[Verse 1]\nline one")
        self.c.go_live_entry(self.entry("song", "Hymn"))
        self.assertFalse(self.c.deck_is_live(self.deck))

    def test_the_library_list_says_which_deck_is_live(self):
        self.assertFalse(self.c.library_overview()["decks"][0]["live"])
        self.go_live()
        self.assertTrue(self.c.library_overview()["decks"][0]["live"])


class ApiTests(DeckEditorBase):
    def do(self, action, **args):
        return self.api.call(action, args)

    def test_get_reorder_skip_notes_duplicate_delete_through_the_api(self):
        a, b, c, d = self.ids()
        info = self.do("deck_get", id=self.deck)
        self.assertEqual([p["id"] for p in info["pages"]], [a, b, c, d])
        self.do("deck_pages_reorder", id=self.deck, order=[b, a, c, d])
        self.do("deck_pages_skip", id=self.deck, pages=[c], skipped=True)
        self.do("deck_page_notes", id=self.deck, page=a, notes="hi")
        new = self.do("deck_pages_duplicate", id=self.deck, pages=[d])["new"]
        self.do("deck_pages_delete", id=self.deck, pages=[b])
        self.assertEqual(self.ids(), [a, c, d, new[0]])
        self.assertEqual([p["skipped"] for p in self.pages()], [False, True, False, False])

    def test_bad_input_is_a_clear_error(self):
        with self.assertRaises(ApiError):
            self.do("deck_pages_reorder", id=self.deck, order="nope")
        with self.assertRaises(ApiError):
            self.do("deck_pages_skip", id=self.deck, pages=[1], skipped="yes")
        with self.assertRaises((ApiError, ControllerError)):
            self.do("deck_pages_delete", id=self.deck, pages=["x"])
        with self.assertRaises((ApiError, ControllerError)):
            self.do("deck_get", id=9999)


class EditorPageTests(unittest.TestCase):
    def test_the_editor_is_a_page_without_a_tab_reached_from_the_deck_library(self):
        self.assertIn('id="view-deckedit"', HTML)
        self.assertNotIn('id="tab-deckedit"', HTML)
        self.assertIn('"deckedit"', re.search(r"const VIEWS = \[[^\]]*\]", JS).group(0))
        self.assertNotIn("deckedit", re.search(r"const LIBRARY_VIEWS = \[[^\]]*\]", JS).group(0))
        self.assertIn("Edit slideshow", JS)

    def test_the_editor_has_a_back_button_a_grid_and_the_slide_buttons(self):
        start = HTML.index('id="view-deckedit"')
        page = HTML[start:HTML.index("</main>", start)]
        for ident in ("de-back", "de-grid", "de-left", "de-right", "de-duplicate", "de-skip",
                      "de-delete", "de-all", "de-notes", "de-notes-save", "de-live", "de-used", "de-preview"):
            self.assertIn(f'id="{ident}"', page)
        self.assertIn("← Back to Slideshow Library", page)

    def test_every_action_the_editor_sends_exists(self):
        sent = set(re.findall(r'"(deck_[a-z_]+)"', JS))
        api = OperatorApi.__new__(OperatorApi)
        OperatorApi.__init__(api, None)
        known = set(api._actions)
        self.assertEqual(sorted(a for a in sent if a not in known), [])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class EditorLogicTests(unittest.TestCase):
    def run_js(self, expression):
        script = ("const m=require(process.argv[1]);"
                  f"console.log(JSON.stringify({expression}))")
        out = subprocess.run(["node", "-e", script, str(JS_PATH)], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    ORDER = "[1,2,3,4,5,6]"

    def test_a_plain_click_selects_one(self):
        self.assertEqual(self.run_js(f"m.selectPages({{selected:[1,2],anchor:1}},{self.ORDER},4,{{}})"),
                         {"selected": [4], "anchor": 4})

    def test_ctrl_click_adds_and_removes_one(self):
        self.assertEqual(self.run_js(f"m.selectPages({{selected:[2],anchor:2}},{self.ORDER},5,{{ctrl:true}})"),
                         {"selected": [2, 5], "anchor": 5})
        self.assertEqual(self.run_js(f"m.selectPages({{selected:[2,5],anchor:5}},{self.ORDER},2,{{ctrl:true}})"),
                         {"selected": [5], "anchor": 2})

    def test_shift_click_selects_the_range_either_way(self):
        self.assertEqual(self.run_js(f"m.selectPages({{selected:[2],anchor:2}},{self.ORDER},5,{{shift:true}})"),
                         {"selected": [2, 3, 4, 5], "anchor": 2})
        self.assertEqual(self.run_js(f"m.selectPages({{selected:[5],anchor:5}},{self.ORDER},2,{{shift:true}})"),
                         {"selected": [2, 3, 4, 5], "anchor": 5})

    def test_shift_click_with_no_anchor_selects_one(self):
        self.assertEqual(self.run_js(f"m.selectPages({{selected:[],anchor:null}},{self.ORDER},3,{{shift:true}})"),
                         {"selected": [3], "anchor": 3})

    def test_moving_one_step_keeps_a_block_together_and_stops_at_the_edge(self):
        self.assertEqual(self.run_js(f"m.movePages({self.ORDER},[3,4],-1)"), [1, 3, 4, 2, 5, 6])
        self.assertEqual(self.run_js(f"m.movePages({self.ORDER},[3,4],1)"), [1, 2, 5, 3, 4, 6])
        self.assertEqual(self.run_js(f"m.movePages({self.ORDER},[1,2],-1)"), [1, 2, 3, 4, 5, 6])
        self.assertEqual(self.run_js(f"m.movePages({self.ORDER},[5,6],1)"), [1, 2, 3, 4, 5, 6])
        self.assertEqual(self.run_js(f"m.movePages({self.ORDER},[1,3],1)"), [2, 1, 4, 3, 5, 6])

    def test_dropping_slides_before_another_or_at_the_end(self):
        self.assertEqual(self.run_js(f"m.dropPages({self.ORDER},[1],5)"), [2, 3, 4, 1, 5, 6])
        self.assertEqual(self.run_js(f"m.dropPages({self.ORDER},[2,3],null)"), [1, 4, 5, 6, 2, 3])
        self.assertEqual(self.run_js(f"m.dropPages({self.ORDER},[5,6],1)"), [5, 6, 1, 2, 3, 4])
        self.assertEqual(self.run_js(f"m.dropPages({self.ORDER},[2,3],3)"), [1, 2, 3, 4, 5, 6])

    def pages(self, skipped=()):
        return json.dumps({"live": False, "pages": [{"id": i, "skipped": i in skipped} for i in range(1, 5)]})

    def test_button_rules(self):
        both = self.run_js(f"m.deckEditorState({self.pages()},[2])")
        self.assertTrue(both["canLeft"] and both["canRight"] and both["canDelete"] and both["canNotes"])
        edge = self.run_js(f"m.deckEditorState({self.pages()},[1])")
        self.assertFalse(edge["canLeft"])
        self.assertTrue(edge["canRight"])
        none = self.run_js(f"m.deckEditorState({self.pages()},[])")
        self.assertFalse(any(none[k] for k in ("canLeft", "canRight", "canDuplicate", "canSkip", "canDelete", "canNotes")))
        many = self.run_js(f"m.deckEditorState({self.pages()},[1,2])")
        self.assertFalse(many["canNotes"])

    def test_the_last_unskipped_slide_cannot_be_skipped_or_everything_deleted(self):
        every = self.run_js(f"m.deckEditorState({self.pages()},[1,2,3,4])")
        self.assertFalse(every["canDelete"] or every["canSkip"])
        last = self.run_js(f"m.deckEditorState({self.pages(skipped=[1,2,3])},[4])")
        self.assertFalse(last["canSkip"])
        undo = self.run_js(f"m.deckEditorState({self.pages(skipped=[1,2,3])},[1])")
        self.assertTrue(undo["canSkip"])
        self.assertEqual(undo["skipLabel"], "Put back")

    def test_a_live_deck_disables_every_change(self):
        data = json.dumps({"live": True, "pages": [{"id": 1, "skipped": False}, {"id": 2, "skipped": False}]})
        state = self.run_js(f"m.deckEditorState({data},[1])")
        self.assertTrue(state["locked"])
        self.assertFalse(any(state[k] for k in ("canLeft", "canRight", "canDuplicate", "canSkip", "canDelete", "canNotes")))

    def test_the_used_in_line(self):
        self.assertEqual(self.run_js("m.usedText([])"), "Not used in any service")
        text = self.run_js('m.usedText([{title:"Sunday",date:"2026-10-25"},{title:"Easter",date:null}])')
        self.assertIn("Used in 2 services: Sunday (2026-10-25), Easter", text)
        self.assertIn("Changes apply to all of them", text)
        self.assertIn("1 service:", self.run_js('m.usedText([{title:"A",date:null}])'))


class StageBPageTests(unittest.TestCase):
    def test_the_stage_b_controls_exist(self):
        start = HTML.index('id="view-deckedit"')
        page = HTML[start:HTML.index("</main>", start)]
        for ident in ("de-add", "de-add-file", "de-replace", "de-replace-file", "de-from-open", "de-from",
                      "de-from-deck", "de-from-grid", "de-from-add", "de-from-cancel", "de-split-open",
                      "de-split", "de-split-name", "de-split-create", "de-status"):
            self.assertIn(f'id="{ident}"', page)
        self.assertIn("multiple", re.search(r'<input type="file" id="de-add-file"[^>]*>', page).group(0))
        self.assertNotIn("multiple", re.search(r'<input type="file" id="de-replace-file"[^>]*>', page).group(0))

    def test_slide_pictures_have_their_own_upload_kind_with_a_size_limit(self):
        self.assertIn("slidepics:", JS)
        self.assertIn("slidepics", JS[JS.index("uploadSlidePictures"):])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class StageBLogicTests(unittest.TestCase):
    run_js = EditorLogicTests.run_js

    def test_new_pictures_go_after_the_last_selected_slide_or_at_the_end(self):
        self.assertEqual(self.run_js("m.afterPageFor([1,2,3,4],[2,3])"), 3)
        self.assertEqual(self.run_js("m.afterPageFor([1,2,3,4],[1])"), 1)
        self.assertIsNone(self.run_js("m.afterPageFor([1,2,3,4],[])"))

    def test_the_new_deck_name_starts_from_the_old_one(self):
        self.assertEqual(self.run_js('m.splitName("  Welcome  ")'), "Welcome (part)")
        self.assertLessEqual(len(self.run_js('m.splitName("x".repeat(300))')), 200)

    def test_which_buttons_work_with_what_is_selected(self):
        data = json.dumps({"live": False, "pages": [{"id": i, "skipped": False} for i in (1, 2, 3)]})
        one = self.run_js(f"m.deckEditorState({data},[2])")
        self.assertTrue(one["canAdd"] and one["canReplace"] and one["canFrom"] and one["canSplit"])
        two = self.run_js(f"m.deckEditorState({data},[1,2])")
        self.assertFalse(two["canReplace"])
        self.assertTrue(two["canSplit"])
        none = self.run_js(f"m.deckEditorState({data},[])")
        self.assertFalse(none["canReplace"] or none["canSplit"])
        self.assertTrue(none["canAdd"])

    def test_a_live_deck_can_still_be_split_but_nothing_can_be_added(self):
        data = json.dumps({"live": True, "pages": [{"id": 1, "skipped": False}, {"id": 2, "skipped": False}]})
        state = self.run_js(f"m.deckEditorState({data},[1])")
        self.assertFalse(state["canAdd"] or state["canReplace"] or state["canFrom"])
        self.assertTrue(state["canSplit"])


class StageCPageTests(unittest.TestCase):
    def test_the_timing_controls_exist(self):
        start = HTML.index('id="view-deckedit"')
        page = HTML[start:HTML.index("</main>", start)]
        for ident in ("de-delay", "de-delay-sec", "de-trans", "de-trans-sec", "de-timing-hint", "de-timing-for"):
            self.assertIn(f'id="{ident}"', page)
        self.assertIn("deck_pages_timing", JS)


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class StageCLogicTests(unittest.TestCase):
    run_js = EditorLogicTests.run_js

    def page(self, pid, seconds=None, kind=None, ms=None, **more):
        return dict(id=pid, auto_seconds=seconds, transition=kind, transition_ms=ms, skipped=False, notes="", **more)

    def common(self, pages, selected):
        return self.run_js(f"m.commonTiming({json.dumps(pages)},{json.dumps(selected)})")

    def test_slides_that_follow_the_deck_show_follow_the_deck(self):
        self.assertEqual(self.common([self.page(1), self.page(2)], [1, 2]),
                         {"delay": {"mode": "deck"}, "transition": {"mode": "deck"}})

    def test_a_shared_setting_is_shown(self):
        pages = [self.page(1, 0, "dissolve", 800), self.page(2, 0, "dissolve", 800), self.page(3, 9)]
        self.assertEqual(self.common(pages, [1, 2]),
                         {"delay": {"mode": "manual"}, "transition": {"mode": "dissolve", "ms": 800}})
        self.assertEqual(self.common(pages, [3])["delay"], {"mode": "seconds", "seconds": 9})

    def test_different_settings_show_mixed(self):
        pages = [self.page(1, 5, "dissolve", 800), self.page(2, 6, "dissolve", 900), self.page(3)]
        self.assertEqual(self.common(pages, [1, 2]), {"delay": {"mode": "mixed"}, "transition": {"mode": "mixed"}})
        self.assertEqual(self.common(pages, [1, 3])["delay"], {"mode": "mixed"})

    def test_nothing_selected_has_no_timing(self):
        self.assertIsNone(self.common([self.page(1)], []))

    def test_the_labels_under_a_thumbnail(self):
        flags = lambda page: self.run_js(f"m.pageFlags({json.dumps(page)})")
        self.assertEqual(flags(self.page(1)), [])
        self.assertEqual(flags(self.page(1, 0)), ["Waits"])
        self.assertEqual(flags(self.page(1, 8, "dissolve", 500)), ["8 s", "Dissolve"])
        self.assertEqual(flags(self.page(1, None, "none", 0)), ["Cut"])
        self.assertEqual(flags(dict(self.page(1, 3), skipped=True, notes="x")), ["Skipped", "Notes", "3 s"])

    def test_the_follow_the_deck_sentence(self):
        text = self.run_js('m.deckTimingText({auto_seconds:6,end_action:"loop",transition:"dissolve",transition_ms:500})')
        self.assertEqual(text, "Every 6 s, loop back to the first slide; Dissolve, 0.5 s")
        text = self.run_js('m.deckTimingText({auto_seconds:0,end_action:"stop",transition:"none",transition_ms:500})')
        self.assertEqual(text, "manual advance; no transition")

    def test_timing_is_off_for_a_live_deck_or_with_nothing_chosen(self):
        data = json.dumps({"live": True, "pages": [{"id": 1, "skipped": False}]})
        self.assertFalse(self.run_js(f"m.deckEditorState({data},[1])")["canTiming"])
        data = json.dumps({"live": False, "pages": [{"id": 1, "skipped": False}]})
        self.assertTrue(self.run_js(f"m.deckEditorState({data},[1])")["canTiming"])
        self.assertFalse(self.run_js(f"m.deckEditorState({data},[])")["canTiming"])


if __name__ == "__main__":
    unittest.main()
