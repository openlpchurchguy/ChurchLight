# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import http.client
import json
import threading
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.core.slides import BuildSettings
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi, slide_view

OUTPUTS = [Output("projector", "projector"), Output("stage", "ppt_notes")]


def make(shared=True):
    db = DatabaseManager(":memory:", shared=shared)
    db.create_song_with_sections(
        "Alpha Song", [("Verse 1", "verse", "a1\na2"), ("Chorus", "chorus", "c1\nc2")],
        order=["Verse 1", "Chorus"], author="Ann")
    db.create_song_with_sections("Beta Song", [("Verse 1", "verse", "b1\nb2")], order=["Verse 1"])
    db.add_presentation("Sermon", [("d/1.png", "note one"), ("d/2.png", "note two")])
    t = db.add_translation("DEMO", "Demo")
    db.add_verses(t, [("John", 3, 16, "[Demo 3:16] placeholder verse."),
                      ("John", 3, 17, "[Demo 3:17] short.")])
    c = OperatorController(db, OUTPUTS, BuildSettings(scripture_max_chars=60))
    return db, c, OperatorApi(c)


def find(api, title):
    return next(e for e in api.library(title))


class StateAndActionTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)

    def test_a_screen_shape_defaults_to_widescreen_and_is_remembered(self):
        name = self.api.state()["outputs"][0]["name"]
        self.assertEqual(self.api.state()["outputs"][0]["shape"], "16:9")
        before = self.c.version
        self.api.call("screen_shape_set", {"name": name, "shape": "4:3"})
        self.assertGreater(self.c.version, before)          # open pages are told to redraw
        shapes = {o["name"]: o["shape"] for o in self.api.state()["outputs"]}
        self.assertEqual(shapes[name], "4:3")
        self.assertEqual([v for k, v in shapes.items() if k != name], ["16:9"] * (len(shapes) - 1))
        self.assertEqual(self.c.screen_shape(name), "4:3")

    def test_a_screen_shape_must_be_a_known_shape_of_a_known_screen(self):
        name = self.api.state()["outputs"][0]["name"]
        for args in ({"name": name, "shape": "5:4"}, {"name": "nowhere", "shape": "4:3"}):
            with self.assertRaises(ApiError):
                self.api.call("screen_shape_set", args)
        self.assertEqual(self.c.screen_shape(name), "16:9")
        self.db.set_setting("screen_shapes", "{bad")        # damaged storage means the default
        self.assertEqual(self.c.screen_shape(name), "16:9")

    def test_the_state_says_whether_a_verse_may_go_over_the_live_slide(self):
        self.assertFalse(self.api.state()["verse_over_ok"])
        self.c.go_live_entry(next(e for e in self.c.search_library("Sermon") if e.kind == "presentation"))
        self.assertTrue(self.api.state()["verse_over_ok"])
        self.c.go_live_entry(next(e for e in self.c.search_library("Alpha") if e.kind == "song"))
        self.assertFalse(self.api.state()["verse_over_ok"])

    def test_the_empty_state_is_complete(self):
        s = self.api.state()
        self.assertIsNone(s["service"])
        self.assertEqual(s["items"], [])
        self.assertEqual(s["translations"], ["DEMO"])
        self.assertEqual(s["translation"], "DEMO")
        self.assertEqual([o["name"] for o in s["outputs"]], ["projector", "stage"])
        self.assertEqual(s["live"]["count"], 0)
        self.assertIsNone(s["live"]["base"])
        json.dumps(s)                                   # must be plain JSON

    def test_each_output_says_who_it_is_for_and_where_its_page_is(self):
        by_name = {o["name"]: o for o in self.api.state()["outputs"]}
        self.assertEqual(by_name["projector"]["audience"], "public")
        self.assertEqual(by_name["stage"]["audience"], "stage")
        self.assertEqual(by_name["stage"]["path"], "/view/stage")

    def test_library_search(self):
        titles = [e["title"] for e in self.api.library("")]
        self.assertEqual(titles, ["Sermon", "Alpha Song", "Beta Song"])
        self.assertEqual([e["title"] for e in self.api.library("Beta")], ["Beta Song"])
        self.assertEqual({e["kind"] for e in self.api.library("")}, {"song", "presentation"})

    def test_a_whole_service_through_the_api(self):
        new = self.api.call("new_service", {"title": "Sunday"})
        self.assertTrue(new["ok"] and new["id"] == 1)
        for title in ("Sermon", "Alpha Song"):
            e = find(self.api, title)
            self.api.call("add", {"kind": e["kind"], "id": e["id"]})
        self.api.call("add_verse", {"text": "jn 3:16"})
        self.api.call("add_announcement", {"title": "Picnic", "body": "Noon"})
        s = self.api.state()
        self.assertEqual([i["title"] for i in s["items"]][:2], ["Sermon", "Alpha Song"])
        self.assertEqual(len(s["items"]), 4)
        first = s["items"][0]["item_id"]
        self.api.call("go_item", {"item_id": first})
        live = self.api.state()["live"]
        self.assertEqual((live["index"], live["base"]["label"]), (0, "Slide 1"))
        self.assertEqual(live["base"]["notes"], "note one")        # the operator sees notes
        self.assertEqual(live["next"]["label"], "Slide 2")
        self.assertTrue(self.api.state()["items"][0]["live"])
        self.api.call("next")
        self.assertEqual(self.api.state()["live"]["index"], 1)
        self.assertGreaterEqual(len(self.api.c.show_verse("jn 3:16")), 1)       # (typed verses are the console's; the page uses the tray)
        live = self.api.state()["live"]
        self.assertEqual(live["overlay"]["reference"], "John 3:16")
        self.assertEqual(live["index"], 1)                          # the deck did not move
        self.api.call("hide_verse")
        self.assertIsNone(self.api.state()["live"]["overlay"])
        self.assertTrue(self.api.c.reshow_verse())
        self.assertIsNotNone(self.api.state()["live"]["overlay"])
        self.assertTrue(self.api.call("blank")["blank"])
        self.assertTrue(self.api.state()["live"]["blank"])
        self.api.call("clear")
        self.assertIsNone(self.api.state()["live"]["base"])

    def test_reorder_remove_and_go_to_a_slide(self):
        self.api.call("new_service", {"title": "S"})
        ids = []
        for title in ("Alpha Song", "Beta Song"):
            e = find(self.api, title)
            ids.append(self.api.call("add", {"kind": e["kind"], "id": e["id"]})["item_id"])
        self.api.call("move", {"item_id": ids[1], "position": 0})
        self.assertEqual([i["title"] for i in self.api.state()["items"]], ["Beta Song", "Alpha Song"])
        self.api.call("go_item", {"item_id": ids[0]})
        self.api.call("go_slide", {"index": 2})
        self.assertEqual(self.api.state()["live"]["index"], 2)
        self.api.call("remove", {"item_id": ids[1]})
        self.assertEqual(len(self.api.state()["items"]), 1)

    def test_single_item_goes_live_without_touching_the_service(self):
        self.api.call("new_service", {"title": "S"})
        e = find(self.api, "Beta Song")
        self.api.call("go_entry", {"kind": e["kind"], "id": e["id"]})
        s = self.api.state()
        self.assertEqual(s["mode"], "item")
        self.assertEqual(s["live"]["base"]["text"], "b1\nb2")
        self.assertEqual(s["items"], [])

    def test_previews_show_slides_without_going_live(self):
        e = find(self.api, "Alpha Song")
        slides = self.api.call("preview", {"kind": e["kind"], "id": e["id"]})["slides"]
        self.assertEqual([s["label"] for s in slides], ["Verse 1", "Chorus"])
        self.assertEqual(self.api.c.preview_verse("jn 3:16")[0].reference, "John 3:16")
        self.assertIsNone(self.api.state()["live"]["base"])

    def test_opening_and_listing_services(self):
        a = self.api.call("new_service", {"title": "One"})["id"]
        self.api.call("new_service", {"title": "Two"})
        self.api.call("open_service", {"id": a})
        s = self.api.state()
        self.assertEqual(s["service"]["title"], "One")
        self.assertEqual({x["title"] for x in s["services"]}, {"One", "Two"})

    def test_each_reply_carries_the_new_version(self):
        before = self.api.version
        reply = self.api.call("new_service", {"title": "S"})
        self.assertGreater(reply["version"], before)
        self.assertEqual(self.api.state()["version"], reply["version"])

    def test_translation_can_be_changed(self):
        self.db.add_translation("OTHER", "Other")
        self.api.call("set_translation", {"abbreviation": "OTHER"})
        self.assertEqual(self.api.state()["translation"], "OTHER")
        with self.assertRaises(ApiError):
            self.api.call("set_translation", {"abbreviation": "NOPE"})


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)

    def bad(self, action, args, status=400):
        with self.assertRaises(ApiError) as caught:
            self.api.call(action, args)
        self.assertEqual(caught.exception.status, status)
        return str(caught.exception)

    def test_unknown_action_and_bad_args(self):
        self.bad("explode", {}, 404)
        with self.assertRaises(ApiError):
            self.api.call("next", [])

    def test_missing_and_mistyped_values(self):
        self.api.call("new_service", {"title": "S"})
        self.assertIn("Missing", self.bad("remove", {}))
        self.assertIn("whole number", self.bad("remove", {"item_id": "1"}))
        self.assertIn("whole number", self.bad("remove", {"item_id": True}))
        self.assertIn("whole number", self.bad("remove", {"item_id": 1.5}))
        self.assertIn("whole number", self.bad("remove", {"item_id": 10 ** 12}))
        self.assertIn("kind", self.bad("add", {"kind": "video", "id": 1}))
        self.assertIn("must be text", self.bad("add_verse", {"text": 5}))
        self.assertIn("too long", self.bad("add_verse", {"text": "x" * 5000}))
        self.assertIn("name", self.bad("new_service", {"title": "   "}))
        self.assertIn("title", self.bad("add_announcement", {"title": ""}))
        self.assertIn("title", self.bad("add_announcement", {"title": "", "body": "  "}))

    def test_an_announcement_without_a_title_is_named_after_its_text(self):
        self.api.call("new_service", {"title": "Sunday"})
        self.api.call("add_announcement", {"title": "", "body": "Coffee after service\nAll welcome"})
        self.assertEqual(self.api.state()["items"][-1]["title"], "Coffee after service")

    def test_operator_mistakes_become_plain_messages_and_change_nothing(self):
        self.assertIn("service", self.bad("add", {"kind": "song", "id": 1}).lower())
        self.api.call("new_service", {"title": "S"})
        self.assertTrue(self.bad("tray_load", {"text": "jn 9:99"}))
        self.assertTrue(self.bad("go_slide", {"index": 5}))
        self.assertTrue(self.bad("go_item", {"item_id": 999}))
        self.assertTrue(self.bad("open_service", {"id": 999}))
        self.assertIsNone(self.api.state()["live"]["base"])

    def test_slide_views_cover_every_slide_field(self):
        from dataclasses import fields
        from churchlight_presenter.core.slides import Slide
        view = slide_view(Slide(kind="text", item_type="announcement", source_item_id=1, notes="n"))
        self.assertEqual(set(view), {f.name for f in fields(Slide)})
        self.assertIsNone(slide_view(None))


class ThreadSafetyTests(unittest.TestCase):
    def test_many_threads_can_use_the_controller_together(self):
        db, c, api = make()
        self.addCleanup(db.close)
        api.call("new_service", {"title": "S"})
        errors = []

        def worker(n):
            try:
                for i in range(25):
                    e = api.library("Song")[i % 2]
                    api.call("add", {"kind": e["kind"], "id": e["id"]})
                    api.state()
                    api.call("next")
                    api.call("hide_verse")
            except Exception as err:  # noqa: BLE001
                errors.append(repr(err))
        threads = [threading.Thread(target=worker, args=(n,)) for n in range(6)]
        [t.start() for t in threads]
        [t.join(30) for t in threads]
        self.assertEqual(errors, [])
        self.assertEqual(len(api.state()["items"]), 6 * 25)

    def test_the_terminal_and_the_page_take_turns(self):
        import io
        from churchlight_presenter.ui.console import Console
        db, c, api = make()
        self.addCleanup(db.close)
        console = Console(c, stdout=io.StringIO())
        console.onecmd("new Sunday")
        errors = []

        def web():
            try:
                for _ in range(40):
                    api.call("blank")
                    api.state()
            except Exception as err:  # noqa: BLE001
                errors.append(repr(err))
        t = threading.Thread(target=web)
        t.start()
        for _ in range(40):
            console.onecmd("find song")
            console.onecmd("status")
        t.join(30)
        self.assertEqual(errors, [])

    def test_a_database_not_opened_for_sharing_fails_loudly_not_silently(self):
        db, c, api = make(shared=False)
        self.addCleanup(db.close)
        failure = []

        def web():
            try:
                api.state()
            except Exception as err:  # noqa: BLE001
                failure.append(type(err).__name__)
        t = threading.Thread(target=web)
        t.start()
        t.join(10)
        self.assertEqual(failure, ["ProgrammingError"])


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        self.server = self.c.serve()
        self.addCleanup(self.c.close)

    def req(self, path, method="GET", body=None, headers=None, host=None):
        conn = http.client.HTTPConnection(*self.server.address, timeout=10)
        h = dict(headers or {})
        if host:
            h["Host"] = host
        data = None
        if body is not None:
            data = body if isinstance(body, bytes) else json.dumps(body).encode()
            h.setdefault("Content-Type", "application/json")
            h.setdefault("X-ChurchLight", "operator")
        conn.request(method, path, body=data, headers=h)
        res = conn.getresponse()
        raw = res.read()
        conn.close()
        try:
            return res.status, json.loads(raw)
        except ValueError:
            return res.status, raw

    def do(self, action, args=None, **kw):
        return self.req("/api/do", "POST", {"action": action, "args": args or {}}, **kw)

    def test_state_library_and_do_over_http(self):
        status, state = self.req("/api/state")
        self.assertEqual(status, 200)
        self.assertEqual(state["translation"], "DEMO")
        status, lib = self.req("/api/library?q=Alpha")
        self.assertEqual([e["title"] for e in lib["entries"]], ["Alpha Song"])
        status, reply = self.do("new_service", {"title": "S"})
        self.assertEqual((status, reply["ok"]), (200, True))
        status, state2 = self.req("/api/state")
        self.assertEqual(state2["service"]["title"], "S")
        self.assertGreater(state2["version"], state["version"])

    def test_long_poll_answers_304_then_wakes_on_a_change(self):
        _, state = self.req("/api/state")
        v = state["version"]
        self.assertEqual(self.req(f"/api/state?since={v}&wait=0.2")[0], 304)
        threading.Timer(0.2, self.c.toggle_blank).start()
        status, s = self.req(f"/api/state?since={v}&wait=5")
        self.assertEqual(status, 200)
        self.assertTrue(s["live"]["blank"])
        self.assertEqual(self.req("/api/state?since=x")[0], 400)

    def test_errors_become_json_with_the_right_status(self):
        self.assertEqual(self.do("explode")[0], 404)
        status, body = self.do("tray_load", {"text": "jn 9:99"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)
        self.assertEqual(self.req("/api/do", "POST", b"not json")[0], 400)
        self.assertEqual(self.req("/api/do", "POST", [1, 2])[0], 400)
        self.assertEqual(self.req("/api/do", "POST", {"args": {}})[0], 400)

    def test_cross_site_and_rebinding_requests_are_refused(self):
        self.assertEqual(self.req("/api/state", host="evil.example")[0], 403)
        self.assertEqual(self.do("next", host="evil.example:8765")[0], 403)
        self.assertEqual(self.req("/api/state", headers={"Origin": "http://evil.example"})[0], 403)
        self.assertEqual(self.req("/operator", host="evil.example")[0], 403)
        host = "%s:%s" % self.server.address
        self.assertEqual(self.req("/api/state", headers={"Origin": "http://" + host}, host=host)[0], 200)
        self.assertEqual(self.req("/api/state", host="localhost:%s" % self.server.address[1])[0], 200)

    def test_post_needs_the_header_json_and_a_sane_size(self):
        raw = json.dumps({"action": "next"}).encode()
        self.assertEqual(self.req("/api/do", "POST", raw, {"Content-Type": "text/plain",
                                                           "X-ChurchLight": "x"})[0], 415)
        conn = http.client.HTTPConnection(*self.server.address, timeout=10)
        conn.request("POST", "/api/do", body=raw, headers={"Content-Type": "application/json"})
        self.assertEqual(conn.getresponse().status, 403)
        conn.close()
        self.assertEqual(self.req("/api/do", "POST", b"x" * 70000)[0], 413)
        self.assertEqual(self.req("/api/do", "OPTIONS")[0], 501)       # no CORS preflight is ever approved

    def test_no_operator_means_no_api(self):
        self.c.close()
        server = self.c.serve(operator=False)
        conn = http.client.HTTPConnection(*server.address, timeout=10)
        for path in ("/api/state", "/operator"):
            conn.request("GET", path)
            res = conn.getresponse()
            res.read()
            self.assertEqual(res.status, 404)
        conn.close()

    def test_the_operator_page_files_are_served_with_the_strict_policy(self):
        for path, kind in (("/operator", "text/html"), ("/static/operator.js", "text/javascript"),
                           ("/static/operator.css", "text/css")):
            conn = http.client.HTTPConnection(*self.server.address, timeout=10)
            conn.request("GET", path)
            res = conn.getresponse()
            res.read()
            conn.close()
            self.assertEqual(res.status, 200, path)
            self.assertTrue(res.getheader("Content-Type").startswith(kind))
            if path == "/operator":
                policy = res.getheader("Content-Security-Policy")
                self.assertIn("script-src 'self'", policy)
                self.assertIn("frame-src 'self'", policy)          # preview frames of its own outputs only
            elif path.endswith(".js"):
                self.assertNotIn("frame-src", res.getheader("Content-Security-Policy"))


if __name__ == "__main__":
    unittest.main()
