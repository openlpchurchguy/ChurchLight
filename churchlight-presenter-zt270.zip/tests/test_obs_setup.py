# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Making the OBS scenes and projecting them, against a pretend OBS."""
import unittest

from churchlight_presenter.core import obssetup
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.obsws import ObsClient, ObsError, auth_string
from churchlight_presenter.core.outputs import default_outputs
from churchlight_presenter.ui import obsctl
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.fakeobs import FakeObs

BASE = "http://127.0.0.1:8765"


class ClientTests(unittest.TestCase):
    def test_it_connects_without_a_password_and_asks_questions(self):
        obs = FakeObs()
        self.addCleanup(obs.close)
        with ObsClient("127.0.0.1", obs.port) as client:
            self.assertEqual(client.version, "5.5.0")
            self.assertEqual(client.request("GetVersion")["obsVersion"], "31.0.0")

    def test_the_password_is_used_and_a_wrong_or_missing_one_is_explained(self):
        obs = FakeObs(password="secret")
        self.addCleanup(obs.close)
        with ObsClient("127.0.0.1", obs.port, "secret") as client:
            self.assertTrue(client.request("GetVersion"))
        with self.assertRaises(ObsError) as caught:
            ObsClient("127.0.0.1", obs.port, "").connect()
        self.assertIn("password", str(caught.exception))
        with self.assertRaises(ObsError) as caught:
            ObsClient("127.0.0.1", obs.port, "wrong").connect()
        self.assertIn("password", str(caught.exception).lower())

    def test_nothing_listening_says_how_to_turn_obs_on(self):
        import socket
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        with self.assertRaises(ObsError) as caught:
            ObsClient("127.0.0.1", port, timeout=1).connect()
        self.assertIn("WebSocket Server", str(caught.exception))

    def test_a_refused_request_carries_obs_reason(self):
        obs = FakeObs()
        self.addCleanup(obs.close)
        with ObsClient("127.0.0.1", obs.port) as client:
            with self.assertRaises(ObsError) as caught:
                client.request("CreateInput", {"sceneName": "Scene", "inputName": "x", "inputKind": "nope"})
        self.assertIn("Unknown input kind", str(caught.exception))

    def test_the_auth_answer_follows_the_published_recipe(self):
        # obs-websocket 5 docs: secret = base64(sha256(password + salt)); answer = base64(sha256(secret + challenge)).
        import base64, hashlib
        password = "supersecretpassword"
        salt = "lM1GncleQOaCu9lT1yeUZhFYnqhsLLP1G5lAGo3ixaI="
        challenge = "+IxH4CnCiqpX1rM9scsNynZzbOe4KhDeYcTNS3PDaeY="
        secret = base64.b64encode(hashlib.sha256((password + salt).encode()).digest()).decode()
        expected = base64.b64encode(hashlib.sha256((secret + challenge).encode()).digest()).decode()
        self.assertEqual(auth_string(password, salt, challenge), expected)
        self.assertEqual(len(expected), 44)


class ConnectionMessageTests(unittest.TestCase):
    def connect(self, obs, password):
        with ObsClient("127.0.0.1", obs.port, password):
            pass

    def test_a_wrong_password_is_reported_as_a_wrong_password(self):
        obs = FakeObs(password="right")
        self.addCleanup(obs.close)
        with self.assertRaises(ObsError) as caught:
            self.connect(obs, "wrong")
        self.assertIn("refused the password", str(caught.exception))
        self.assertEqual(caught.exception.code, 4009)

    def test_a_password_pasted_with_spaces_around_it_still_works(self):
        obs = FakeObs(password="right")
        self.addCleanup(obs.close)
        self.connect(obs, " right\r\n")

    def test_the_length_sent_is_mentioned_when_the_password_is_refused(self):
        obs = FakeObs(password="right")
        self.addCleanup(obs.close)
        with self.assertRaises(ObsError) as caught:
            self.connect(obs, "wrong")
        self.assertIn("5 characters", str(caught.exception))

    def test_another_reason_from_obs_is_shown_and_not_blamed_on_the_password(self):
        obs = FakeObs(password="right")
        obs.bad_password_close = 4005
        self.addCleanup(obs.close)
        with self.assertRaises(ObsError) as caught:
            self.connect(obs, "wrong")
        self.assertNotIn("refused the password", str(caught.exception))
        self.assertIn("4005", str(caught.exception))

    def test_a_silent_hang_up_does_not_claim_the_password_was_wrong(self):
        obs = FakeObs(password="right")
        obs.bad_password_close = None
        self.addCleanup(obs.close)
        with self.assertRaises(ObsError) as caught:
            self.connect(obs, "wrong")
        self.assertNotIn("refused the password", str(caught.exception))
        self.assertIn("did not answer", str(caught.exception))


class BuildTests(unittest.TestCase):
    def setUp(self):
        self.obs = FakeObs()
        self.addCleanup(self.obs.close)

    POSITIONS = {"projector": (1920, 0), "stage": (0, 0), "confidence": (0, 0)}

    def run_build(self, wanted=obssetup.SCENE_KEYS, outputs=None, positions=None):
        with ObsClient("127.0.0.1", self.obs.port) as client:
            return obssetup.build_scenes(client, outputs or default_outputs(), BASE, wanted,
                                         self.POSITIONS if positions is None else positions)

    def test_the_scenes_are_made_with_the_lower_third_as_the_only_browser_source(self):
        report = self.run_build()
        names = [s for s in self.obs.scenes if s.startswith("ChurchLight")]
        self.assertEqual(names, ["ChurchLight Projector", "ChurchLight Livestream", "ChurchLight Stage",
                                 "ChurchLight Confidence", "ChurchLight Home"])
        src = {n: v for n, v in self.obs.inputs.items() if v["kind"] == "browser_source"}
        self.assertEqual(sorted(src), ["ChurchLight lower-third"])
        self.assertEqual(src["ChurchLight lower-third"]["settings"]["width"], 1920)
        captures = sorted(n for n, v in self.obs.inputs.items() if v["kind"] == "monitor_capture")
        self.assertEqual(captures, ["ChurchLight confidence screen", "ChurchLight projector screen", "ChurchLight stage screen"])
        self.assertEqual([i["source"] for i in self.obs.items["ChurchLight Projector"]], ["ChurchLight projector screen"])
        self.assertTrue(report)

    def test_a_screen_capture_picks_the_monitor_by_where_it_is_and_fills_the_canvas(self):
        self.run_build(["projector"])
        capture = self.obs.inputs["ChurchLight projector screen"]
        self.assertEqual(capture["settings"]["monitor_id"], "DISPLAY-B")            # the one at 1920,0
        self.assertFalse(capture["settings"]["capture_cursor"])
        transform = list(self.obs.transforms.values())[0]
        self.assertEqual((transform["boundsWidth"], transform["boundsHeight"]), (1920, 1080))

    def test_stage_and_confidence_are_separate_scenes_you_can_pick_one_of(self):
        self.run_build(["stage"])
        self.assertEqual([s for s in self.obs.scenes if s != "Scene"], ["ChurchLight Stage"])
        self.run_build(["confidence"])
        self.assertIn("ChurchLight Confidence", self.obs.scenes)

    def test_a_screen_with_no_monitor_yet_says_so_instead_of_making_a_browser_source(self):
        report = self.run_build(["projector"], positions={})
        self.assertEqual(self.obs.items["ChurchLight Projector"], [])
        self.assertTrue(any("no monitor yet" in line for line in report))
        self.assertFalse(any(v["kind"] == "browser_source" for v in self.obs.inputs.values()))
    def test_no_browser_source_is_sent_to_the_obs_mixer_because_churchlight_plays_the_sound_itself(self):
        self.run_build()
        for name, source in self.obs.inputs.items():
            if source["kind"] == "browser_source":
                self.assertNotIn("reroute_audio", source["settings"])

    def test_the_lower_third_sits_above_the_camera(self):
        self.run_build()
        order = [i["source"] for i in self.obs.items["ChurchLight Livestream"]]
        self.assertEqual(order, ["ChurchLight Camera", "ChurchLight lower-third"])      # last is on top

    def test_a_lower_third_that_was_under_the_camera_is_moved_up(self):
        self.run_build(["livestream"])
        items = self.obs.items["ChurchLight Livestream"]
        items.reverse()                                                                # someone put the camera on top
        report = self.run_build(["livestream"])
        order = [i["source"] for i in self.obs.items["ChurchLight Livestream"]]
        self.assertEqual(order, ["ChurchLight Camera", "ChurchLight lower-third"])
        self.assertTrue(any("above the camera" in line for line in report))

    def test_the_home_scene_gets_a_black_background(self):
        self.run_build()
        self.assertEqual([i["source"] for i in self.obs.items["ChurchLight Home"]], ["ChurchLight Black"])
        self.assertEqual(self.obs.inputs["ChurchLight Black"]["kind"], "color_source_v3")

    def test_sizes_follow_the_obs_canvas(self):
        self.obs.canvas = (1280, 720)
        self.run_build()
        self.assertEqual(self.obs.inputs["ChurchLight lower-third"]["settings"]["height"], 720)

    def test_running_it_again_changes_nothing_but_the_address(self):
        self.run_build()
        before = {k: list(v) for k, v in self.obs.items.items()}
        scenes = list(self.obs.scenes)
        with ObsClient("127.0.0.1", self.obs.port) as client:
            report = obssetup.build_scenes(client, default_outputs(), "http://127.0.0.1:9999", obssetup.SCENE_KEYS, self.POSITIONS)
        self.assertEqual(self.obs.items, before)
        self.assertEqual(self.obs.scenes, scenes)
        self.assertTrue(any("already" in line for line in report))
        self.assertEqual(self.obs.inputs["ChurchLight lower-third"]["settings"]["url"], "http://127.0.0.1:9999/view/lower-third")

    def test_only_the_chosen_scenes_are_made_and_the_churchs_own_scene_is_untouched(self):
        self.run_build(["projector"])
        self.assertEqual([s for s in self.obs.scenes if s != "Scene"], ["ChurchLight Projector"])
        self.assertEqual(self.obs.items["Scene"], [])

    def test_a_source_of_another_kind_with_our_name_is_left_alone(self):
        self.obs.inputs["ChurchLight projector screen"] = {"kind": "color_source_v3", "settings": {}}
        report = self.run_build(["projector"])
        self.assertTrue(any("left alone" in line for line in report))
        self.assertEqual(self.obs.inputs["ChurchLight projector screen"]["kind"], "color_source_v3")

    def test_a_missing_camera_kind_is_not_fatal(self):
        self.obs.kinds = ["browser_source", "color_source_v3"]
        self.run_build(["livestream"])
        self.assertEqual([i["source"] for i in self.obs.items["ChurchLight Livestream"]], ["ChurchLight lower-third"])

    def test_nothing_to_make_is_explained(self):
        with ObsClient("127.0.0.1", self.obs.port) as client:
            with self.assertRaises(ObsError):
                obssetup.build_scenes(client, [], BASE, ["projector"])


class ProjectTests(unittest.TestCase):
    def test_projectors_open_on_the_chosen_monitors_and_missing_scenes_are_skipped(self):
        obs = FakeObs()
        self.addCleanup(obs.close)
        obs.scenes += ["ChurchLight Projector"]
        with ObsClient("127.0.0.1", obs.port) as client:
            report = obssetup.open_projectors(client, {"ChurchLight Projector": 1, "ChurchLight Stage": 0})
        self.assertEqual(obs.projected, [("ChurchLight Projector", 1)])
        self.assertTrue(any("not in OBS" in line for line in report))

    def test_the_monitor_list_is_plain(self):
        obs = FakeObs()
        self.addCleanup(obs.close)
        with ObsClient("127.0.0.1", obs.port) as client:
            found = obssetup.monitors(client)
        self.assertEqual([m["index"] for m in found], [0, 1])
        self.assertEqual(found[1]["width"], 1280)


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.obs = FakeObs(password="pw")
        self.addCleanup(self.obs.close)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, default_outputs())
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        self.api = OperatorApi(self.c)
        self.target = {"host": "127.0.0.1", "port": self.obs.port, "password": "pw"}

    def test_connect_setup_and_project_through_the_page_api(self):
        found = self.api.call("obs_connect", self.target)
        self.assertEqual(found["obs_version"], "5.5.0")
        self.assertEqual(len(found["monitors"]), 2)
        made = self.api.call("obs_setup", dict(self.target, scenes=["projector", "livestream", "stage", "home"], remember=True))
        self.assertIn("ChurchLight Projector", made["scenes"])
        url = self.obs.inputs["ChurchLight lower-third"]["settings"]["url"]
        self.assertTrue(url.startswith("http://127.0.0.1:") and url.endswith("/view/lower-third"))
        self.api.call("obs_project", {"monitors": {"ChurchLight Projector": 1, "ChurchLight Stage": 0}})
        self.assertIn(("ChurchLight Projector", 1), self.obs.projected)
        view = self.api.state()["obs"]
        self.assertEqual(view["monitors"], {"ChurchLight Projector": 1, "ChurchLight Stage": 0})
        self.assertTrue(view["has_password"])
        self.assertNotIn("password", view)
        self.assertNotIn("pw", str(view))

    def test_the_password_is_not_kept_when_the_church_says_not_to(self):
        self.api.call("obs_setup", dict(self.target, scenes=["home"], remember=False))
        self.assertFalse(self.api.state()["obs"]["has_password"])

    def test_the_saved_password_is_used_when_the_page_sends_none(self):
        self.api.call("obs_setup", dict(self.target, scenes=["home"], remember=True))
        again = {"host": "127.0.0.1", "port": self.obs.port}
        self.assertEqual(self.api.call("obs_connect", again)["obs_version"], "5.5.0")

    def test_only_this_computer_or_a_private_network_is_allowed(self):
        for host in ("8.8.8.8", "example.com", "", "http://127.0.0.1"):
            with self.assertRaises(ApiError):
                self.api.call("obs_connect", {"host": host, "port": 4455})
        for host in ("localhost", "192.168.1.5", "10.0.0.2"):
            self.assertEqual(obsctl.check_host(host), "127.0.0.1" if host == "localhost" else host)
        with self.assertRaises(ApiError):
            self.api.call("obs_connect", {"host": "127.0.0.1", "port": 70000})

    def test_a_wrong_password_comes_back_as_a_readable_error(self):
        with self.assertRaises(ApiError) as caught:
            self.api.call("obs_connect", dict(self.target, password="nope"))
        self.assertIn("password", str(caught.exception).lower())

    def test_a_changed_obs_password_typed_in_the_guide_is_used_to_open_the_projectors_and_kept(self):
        self.api.call("obs_setup", dict(self.target, scenes=["projector"], remember=True))      # the first password is saved
        self.obs.password = "newpw"                                                              # changed in OBS, then Apply
        with self.assertRaises(ApiError):                                                        # the saved one is stale now
            self.api.call("obs_project", {"monitors": {"ChurchLight Projector": 1}})
        target = dict(self.target, password="newpw")
        self.api.call("obs_project", dict(target, monitors={"ChurchLight Projector": 1}, remember=True))
        self.assertIn(("ChurchLight Projector", 1), self.obs.projected)
        self.api.call("obs_project", {"monitors": {"ChurchLight Projector": 0}})                 # the new one was saved
        self.assertIn(("ChurchLight Projector", 0), self.obs.projected)

    def test_projecting_with_a_typed_password_keeps_none_when_the_church_asked_not_to_remember_it(self):
        self.api.call("obs_setup", dict(self.target, scenes=["projector"], remember=False))
        self.api.call("obs_project", dict(self.target, monitors={"ChurchLight Projector": 1}, remember=False))
        self.assertIn(("ChurchLight Projector", 1), self.obs.projected)
        self.assertFalse(self.api.state()["obs"]["has_password"])

    def test_projecting_needs_a_monitor_and_only_churchlight_scenes(self):
        with self.assertRaises(ApiError):
            self.api.call("obs_project", dict({"monitors": {"My own scene": 1}}))
        self.api.call("obs_setup", dict(self.target, scenes=["projector"], remember=True))
        self.api.call("obs_project", {"monitors": {"My own scene": 1, "ChurchLight Projector": 1}})
        self.assertEqual(self.obs.projected, [("ChurchLight Projector", 1)])

    def test_auto_start_needs_saved_monitors_then_projects_quietly(self):
        with self.assertRaises(ApiError):
            self.api.call("obs_auto_set", {"on": True})
        self.api.call("obs_setup", dict(self.target, scenes=["projector"], remember=True))
        self.api.call("obs_project", {"monitors": {"ChurchLight Projector": 1}})
        self.obs.projected.clear()
        self.api.call("obs_auto_set", {"on": True})
        self.assertTrue(obsctl.auto_project(self.c))
        self.assertEqual(self.obs.projected, [("ChurchLight Projector", 1)])
        self.obs.close()
        self.assertFalse(obsctl.auto_project(self.c))          # OBS not open: no error, no crash

    def test_the_program_is_not_frozen_while_waiting_for_obs(self):
        import threading, time
        slow = FakeObs()
        self.addCleanup(slow.close)
        gate = threading.Event()
        original = slow.handle
        slow.handle = lambda kind, a: (gate.wait(3), original(kind, a))[1]
        worker = threading.Thread(target=lambda: self.api.call("obs_connect", {"host": "127.0.0.1", "port": slow.port}), daemon=True)
        worker.start()
        time.sleep(0.4)
        started = time.time()
        self.api.state()                                       # the page keeps refreshing meanwhile
        self.assertLess(time.time() - started, 1.0)
        gate.set()
        worker.join(5)


if __name__ == "__main__":
    unittest.main()
