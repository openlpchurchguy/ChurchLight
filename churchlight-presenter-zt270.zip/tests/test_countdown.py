# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Pre-service countdown and the speaker alert."""
import datetime
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import Output, build_payload
from churchlight_presenter.core.slides import Slide
from churchlight_presenter.ui.controller import ControllerError
from churchlight_presenter.ui.operator_api import ApiError
from tests.test_verse_tray import make

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
ALL = ("projector", "lower_third", "song_lower", "verse_lower", "verse_full", "ppt_verse", "confidence", "ppt_notes", "stage")


class PayloadTests(unittest.TestCase):
    def payload(self, layout, session, **kw):
        return build_payload(session.state(), Output("x", layout), **kw)

    def test_the_countdown_goes_to_the_projector_and_speaker_screens_only(self):
        session = LiveSession()
        session.start_countdown(1000.0, "Starts in")
        for layout in ALL:
            payload = self.payload(layout, session, now=940.0)
            if layout in ("projector", "confidence", "stage", "ppt_notes"):
                style = payload["countdown"].pop("style")
                self.assertEqual(payload["countdown"], {"end": 1000.0, "now": 940.0, "label": "Starts in", "linger": 5}, layout)
                if layout == "projector":
                    self.assertEqual((style["mode"], style["box"]["w"], style["bar"]["every"]), ("clock", 40, 1), layout)
                else:
                    self.assertEqual(style["position"], "top-right", layout)
            else:
                self.assertNotIn("countdown", payload, layout)              # lower thirds sit over the camera: never

    def test_the_alert_goes_to_speaker_screens_only(self):
        session = LiveSession()
        session.set_message("Wrap up")
        for layout in ALL:
            payload = self.payload(layout, session)
            if layout in ("confidence", "stage", "ppt_notes"):
                self.assertEqual(payload["message"], "Wrap up", layout)
            else:
                self.assertNotIn("message", payload, layout)                 # the audience never sees it

    def test_nothing_is_sent_when_none_is_set(self):
        session = LiveSession()
        for layout in ALL:
            payload = self.payload(layout, session)
            self.assertNotIn("countdown", payload)
            self.assertNotIn("message", payload)

    def test_blank_clear_and_load_do_not_touch_it(self):
        session = LiveSession([Slide("a", "song", 1, text="x")])
        session.start_countdown(5000.0)
        session.set_message("hi")
        session.set_blank(True)
        session.load([Slide("b", "song", 1, text="y")])
        session.clear()
        state = session.state()
        self.assertEqual(state.countdown, (5000.0, ""))
        self.assertEqual(state.message, "hi")
        self.assertIn("countdown", self.payload("projector", session))      # it still shows while the screens are blanked

    def test_changes_bump_the_version_once_and_no_change_does_not(self):
        session = LiveSession()
        before = session.version
        session.start_countdown(10.0)
        self.assertEqual(session.version, before + 1)
        session.start_countdown(10.0)
        self.assertEqual(session.version, before + 1)
        self.assertTrue(session.stop_countdown())
        self.assertFalse(session.stop_countdown())
        self.assertFalse(session.set_message(""))
        self.assertTrue(session.set_message("  Nursery 4 "))
        self.assertEqual(session.state().message, "Nursery 4")


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)

    def test_minutes_from_now(self):
        end = self.c.start_countdown(minutes=5, label="Soon", now=1_000_000.0)
        self.assertEqual(end, 1_000_300.0)
        self.assertEqual(self.c.session.state().countdown, (1_000_300.0, "Soon"))

    def test_a_clock_time_today(self):
        now = datetime.datetime(2026, 11, 8, 9, 30, 15).timestamp()
        end = self.c.start_countdown(at="10:00", now=now)
        self.assertEqual(datetime.datetime.fromtimestamp(end), datetime.datetime(2026, 11, 8, 10, 0, 0))

    def test_a_time_that_has_passed_is_refused(self):
        now = datetime.datetime(2026, 11, 8, 10, 30).timestamp()
        with self.assertRaises(ControllerError):
            self.c.start_countdown(at="10:00", now=now)
        self.assertIsNone(self.c.session.state().countdown)

    def test_bad_input_is_refused(self):
        for kwargs in ({}, {"at": "ten", "minutes": None}, {"at": "25:00"}, {"minutes": 0}, {"minutes": -3},
                       {"minutes": 99999}, {"minutes": "soon"}, {"at": "10:00", "minutes": 5}):
            with self.assertRaises(ControllerError, msg=str(kwargs)):
                self.c.start_countdown(**kwargs)

    def test_alert_text_is_tidied_and_limited(self):
        self.assertEqual(self.c.set_alert("  wrap \n  up  "), "wrap up")
        self.assertEqual(len(self.c.set_alert("x" * 500)), 140)
        self.assertEqual(self.c.set_alert(""), "")
        self.assertEqual(self.c.session.state().message, "")

    def test_the_operator_api_round_trip(self):
        reply = self.api.call("countdown_start", {"minutes": 2, "label": "Welcome"})
        self.assertTrue(reply["ok"])
        info = self.api.state()["countdown"]
        self.assertEqual(info["label"], "Welcome")
        self.assertGreater(info["end"], info["now"])
        self.api.call("alert_set", {"text": "Nursery 4"})
        self.assertEqual(self.c.countdown_view()["message"], "Nursery 4")
        self.api.call("countdown_stop")
        self.assertIsNone(self.c.countdown_view()["end"])
        self.api.call("alert_set", {"text": ""})
        self.assertEqual(self.c.countdown_view()["message"], "")

    def test_the_operator_api_rejects_junk(self):
        for args in ({}, {"minutes": "five"}, {"minutes": True}, {"at": 5}):
            with self.assertRaises(ApiError, msg=str(args)):
                self.api.call("countdown_start", args)
        with self.assertRaises(ApiError):
            self.api.call("countdown_start", {"at": "9:99"})


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "output.js")], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    def test_format(self):
        self.assertEqual(self.js("[m.formatCountdown(0), m.formatCountdown(-4000), m.formatCountdown(1), m.formatCountdown(59001),"
                                 "m.formatCountdown(600000), m.formatCountdown(3661000)]"),
                         ["0:00", "0:00", "0:01", "1:00", "10:00", "1:01:01"])

    def test_the_servers_clock_decides_not_the_pages(self):
        # the page's clock is 1000 s behind the server's: the offset fixes it
        self.assertEqual(self.js("m.countdownDisplay({end: 61000, offset: 1000000, linger: 5000}, -1000000)")["text"], "1:01")

    def test_it_ends_then_goes_away(self):
        d = lambda now: self.js(f"m.countdownDisplay({{end: 10000, offset: 0, linger: 5000}}, {now})")
        self.assertEqual(d(9000), {"text": "0:01", "ended": False, "gone": False})
        self.assertEqual(d(10000), {"text": "0:00", "ended": True, "gone": False})
        self.assertEqual(d(14000)["gone"], False)
        self.assertEqual(d(15000)["gone"], True)


if __name__ == "__main__":
    unittest.main()
