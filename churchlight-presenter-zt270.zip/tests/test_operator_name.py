# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The operator name: what only the operator sees for a song, kept apart from the song's real name."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.items import ItemRef
from churchlight_presenter.core.slides import SlideBuilder
from churchlight_presenter.ui.controller import ControllerError, OperatorController


class OperatorNameTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db)
        self.song = self.c.create_song("Amazing Grace", "John Newton", "[Verse 1]\nAmazing grace\nhow sweet",
                                       operator_name="  123   Amazing Grace ")

    def test_it_is_saved_tidied_and_returned_for_editing(self):
        info = self.c.song_for_editing(self.song)
        self.assertEqual(info["operator_name"], "123 Amazing Grace")
        self.assertEqual(info["title"], "Amazing Grace")

    def test_the_library_shows_it_and_either_name_finds_the_song(self):
        for text in ("", "123", "grace", "Newton"):
            titles = [e.title for e in self.c.search_library(text)]
            self.assertEqual(titles, ["123 Amazing Grace"], text)
        self.assertEqual([e.title for e in self.c.suggest_library("12")], ["123 Amazing Grace"])
        self.assertEqual([e.title for e in self.c.suggest_library("")], [])  # nothing used yet

    def test_a_song_without_one_shows_its_title(self):
        other = self.c.create_song("How Great", "", "[Verse 1]\nHow great")
        self.assertEqual(self.c.song_for_editing(other)["operator_name"], "")
        self.assertIn("How Great", [e.title for e in self.c.search_library("")])

    def test_changing_and_clearing_it_updates_the_search(self):
        self.c.update_song(self.song, "Amazing Grace", "John Newton", "[Verse 1]\nAmazing grace", operator_name="G9")
        self.assertEqual([e.title for e in self.c.search_library("G9")], ["G9"])
        self.assertEqual(self.c.search_library("123"), [])
        self.c.update_song(self.song, "Amazing Grace", "John Newton", "[Verse 1]\nAmazing grace", operator_name="")
        self.assertEqual([e.title for e in self.c.search_library("")], ["Amazing Grace"])

    def test_leaving_it_out_keeps_it(self):
        self.c.update_song(self.song, "Amazing Grace", "John Newton", "[Verse 1]\nAmazing grace")
        self.assertEqual(self.c.song_for_editing(self.song)["operator_name"], "123 Amazing Grace")

    def test_too_long_is_refused(self):
        with self.assertRaises(ControllerError):
            self.c.update_song(self.song, "Amazing Grace", "", "[Verse 1]\nx", operator_name="x" * 121)

    def test_the_screens_keep_the_real_title(self):
        slides = SlideBuilder(self.db).build_item(ItemRef.song(self.song))
        self.assertTrue(all("123" not in (s.reference or "") for s in slides))
        self.assertEqual(slides[0].reference, "Amazing Grace")

    def test_the_manage_list_carries_both_names(self):
        row = [s for s in self.c.library_overview()["songs"] if s["id"] == self.song][0]
        self.assertEqual((row["title"], row["operator_name"]), ("Amazing Grace", "123 Amazing Grace"))

    def test_the_service_list_shows_the_operator_name(self):
        service = self.db.create_service("Sunday", "2026-11-22")
        self.db.add_service_item(service, "song", song_id=self.song)
        titles = [r["display_title"] for r in self.db.get_service_outline(service)]
        self.assertEqual(titles, ["123 Amazing Grace"])

    def test_lists_sort_by_the_operator_name(self):
        self.c.create_song("Zion", "", "[Verse 1]\nz", operator_name="001 Zion")
        self.c.create_song("Blessed", "", "[Verse 1]\nb")
        self.c.create_song("Alpha", "", "[Verse 1]\na", operator_name="900 Alpha")
        names = [s["operator_name"] or s["title"] for s in self.c.library_overview()["songs"]]
        self.assertEqual(names, ["001 Zion", "123 Amazing Grace", "900 Alpha", "Blessed"])
        self.assertEqual([e.title for e in self.c.search_library("")], names)


if __name__ == "__main__":
    unittest.main()
