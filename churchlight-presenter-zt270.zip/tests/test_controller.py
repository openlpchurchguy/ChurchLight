# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import json
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.core.slides import BuildSettings
from churchlight_presenter.ui.controller import (
    ControllerError, LibraryEntry, OperatorController,
)

OUTPUTS = [Output("projector", "projector"), Output("verse-lower", "verse_lower"),
           Output("stage", "ppt_notes")]


def make_controller(translation=True):
    db = DatabaseManager(":memory:")
    db.create_song_with_sections(
        "Alpha Song", [("Verse 1", "verse", "a1\na2\na3\na4\na5"), ("Chorus", "chorus", "c1\nc2")],
        order=["Verse 1", "Chorus"], author="Ann")
    db.create_song_with_sections("Beta Song", [("Verse 1", "verse", "b1\nb2")], order=["Verse 1"])
    db.add_presentation("Sermon", [("d/1.png", "note one"), ("d/2.png", "note two"),
                                   ("d/3.png", None)])
    if translation:
        t = db.add_translation("DEMO", "Demo")
        db.add_verses(t, [("John", 3, 16, "[Demo 3:16] a long placeholder verse that needs "
                                          "splitting into more than one slide here."),
                          ("John", 3, 17, "[Demo 3:17] short.")])
    controller = OperatorController(db, OUTPUTS, BuildSettings(scripture_max_chars=60))
    return db, controller


def entry(controller, text, kind=None):
    found = [e for e in controller.search_library(text) if kind in (None, e.kind)]
    assert found, text
    return found[0]


class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make_controller()
        self.addCleanup(self.db.close)

    def test_empty_search_lists_everything_in_order(self):
        titles = [(e.kind, e.title) for e in self.c.search_library()]
        self.assertEqual(titles, [("presentation", "Sermon"), ("song", "Alpha Song"),
                                  ("song", "Beta Song")])

    def test_searching_finds_songs_by_lyrics_and_decks_by_name(self):
        self.assertEqual([e.title for e in self.c.search_library("c2")], ["Alpha Song"])
        self.assertEqual([e.title for e in self.c.search_library("serm")], ["Sermon"])
        self.assertEqual(self.c.search_library("nothing here"), [])

    def test_kinds_can_be_limited_and_details_are_filled_in(self):
        songs = self.c.search_library("", kinds=("song",))
        self.assertEqual([e.kind for e in songs], ["song", "song"])
        self.assertEqual(songs[0].detail, "Ann")
        self.assertEqual(self.c.search_library("", kinds=("presentation",))[0].detail, "3 pages")

    def test_preview_builds_slides_without_going_live(self):
        slides = self.c.preview(entry(self.c, "Alpha"))
        self.assertEqual([s.label for s in slides], ["Verse 1", "Verse 1", "Chorus"])
        self.assertEqual(self.c.session.state().base, None)
        self.assertEqual(self.c.session.version, 0)

    def test_preview_of_a_typed_verse_and_friendly_errors(self):
        self.assertEqual(self.c.preview_verse("jn 3:17")[0].reference, "John 3:17")
        for bad in ("gibberish", "jn 9:99", "jn"):
            with self.assertRaises(ControllerError, msg=bad):
                self.c.preview_verse(bad)
        with self.assertRaises(ControllerError):
            self.c.preview_verse("jn 3:16", translation="NOPE")


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make_controller()
        self.addCleanup(self.db.close)
        self.c.new_service("Sunday", "2026-10-25")

    def build(self):
        a = self.c.add_entry(entry(self.c, "Alpha"))
        d = self.c.add_entry(entry(self.c, "Sermon"))
        v = self.c.add_verse("jn 3:17")
        return a, d, v

    def test_rows_follow_the_items_in_order(self):
        a, d, v = self.build()
        rows = self.c.service_rows()
        self.assertEqual([(r.item_id, r.position, r.item_type) for r in rows],
                         [(a, 0, "song"), (d, 1, "presentation"), (v, 2, "scripture")])
        self.assertEqual(rows[2].title, "John 3:17 (DEMO)")
        self.assertFalse(any(r.is_live for r in rows))

    def test_the_slide_list_matches_the_service(self):
        self.build()
        self.assertEqual(len(self.c.session.slides), 3 + 3 + 1)

    def test_a_bible_row_numbers_its_slides_in_the_service(self):
        a, d, v = self.build()
        row = self.c.service_rows()[2]
        self.assertEqual(len(row.slide_numbers), 1)
        self.assertEqual(row.slide_numbers[0], 6)           # after 3 song slides and 3 deck slides
        self.c.go_live_service_item(v)
        self.assertEqual(self.c.session.state().base_index, row.slide_numbers[0])

    def test_the_live_items_last_slide_is_flagged(self):
        a, d, v = self.build()
        self.c.go_live_service_item(d)
        self.assertEqual([r.last_slide for r in self.c.service_rows()], [False, False, False])
        self.c.next()
        self.c.next()                                   # the deck's third and last slide
        self.assertEqual([r.last_slide for r in self.c.service_rows()], [False, True, False])
        self.c.next()                                   # into the Bible item (one slide: first and last)
        self.assertEqual([r.last_slide for r in self.c.service_rows()], [False, False, True])

    def test_edits_need_an_open_service(self):
        db, c = make_controller()
        self.addCleanup(db.close)
        with self.assertRaisesRegex(ControllerError, "service first"):
            c.add_entry(entry(c, "Alpha"))
        self.assertEqual(c.service_rows(), [])
        with self.assertRaises(ControllerError):
            c.open_service(999)

    def test_a_bad_verse_is_refused_before_it_reaches_the_service(self):
        with self.assertRaises(ControllerError):
            self.c.add_verse("jn 9:99")
        self.assertEqual(self.c.service_rows(), [])

    def test_going_live_on_a_service_item_marks_its_row(self):
        a, d, v = self.build()
        self.c.go_live_service_item(d)
        self.assertEqual(self.c.session.state().base_index, 3)
        self.assertEqual([r.is_live for r in self.c.service_rows()], [False, True, False])
        self.assertTrue(self.c.next())
        self.assertEqual(self.c.session.state().base.label, "Slide 2")

    def test_removing_and_moving_items_keeps_the_live_slide_up(self):
        a, d, v = self.build()
        self.c.go_live_service_item(d)
        self.c.next()                                   # deck slide 2
        self.c.move_item(d, 0)                          # deck to the front (positions start at 0)
        state = self.c.session.state()
        self.assertEqual((state.base.item_type, state.base.label), ("presentation", "Slide 2"))
        self.assertEqual(state.base_index, 1)
        self.c.remove_item(a)                           # an item before it disappears
        state = self.c.session.state()
        self.assertEqual((state.base.label, state.base_index), ("Slide 2", 1))
        self.c.remove_item(d)                           # the live item itself is removed
        self.assertIsNone(self.c.session.state().base)

    def test_a_verse_overlay_survives_service_edits(self):
        a, d, v = self.build()
        self.c.go_live_service_item(d)
        self.c.show_verse("jn 3:16")
        self.c.verse_next()
        self.c.add_announcement("Notice", "Potluck today")
        state = self.c.session.state()
        self.assertEqual((state.base.item_type, state.overlay.continued, state.overlay_index),
                         ("presentation", True, 1))

    def test_a_verse_over_a_slideshow_can_have_its_own_overlay_theme(self):
        a, d, v = self.build()
        look = {"font_size": 5, "color": "#ffffff", "v_pos": "top", "h_pos": "right", "box_width": 50}
        over = self.c.save_theme("Verse box", look, kind="overlay")
        self.c.go_live_service_item(d)
        self.c.show_verse("jn 3:16")
        before = self.c.payloads()["projector"]["overlay"].get("style")
        self.assertNotEqual((before or {}).get("v_pos"), "top")             # unchanged until a theme is chosen
        self.c.set_verse_over_theme(over)
        payloads = self.c.payloads()
        self.assertEqual(payloads["projector"]["overlay"]["style"]["v_pos"], "top")
        self.assertEqual(payloads["projector"]["overlay"]["style"]["box_width"], 50)
        self.assertNotEqual((payloads["projector"]["base"].get("style") or {}).get("v_pos"), "top")   # the slide keeps its own look
        self.assertEqual(self.c.verse_over_theme_id, over)
        usage = {t["id"]: t["usage"] for t in self.c.theme_details()}[over]
        self.assertTrue(usage["verse_over"])
        self.c.set_verse_over_theme(None)
        self.assertEqual(self.c.payloads()["projector"]["overlay"].get("style"), before)

    def test_the_verse_over_look_is_for_the_projector_and_the_lower_third_keeps_its_own_theme(self):
        a, d, v = self.build()
        box = {"font_size": 5, "color": "#ffffff", "v_pos": "top", "h_pos": "right", "box_width": 50}
        third = {"font_size": 5, "color": "#ffffff", "v_pos": "bottom", "h_pos": "left", "box_width": 80}
        over = self.c.save_theme("Verse box", box, kind="overlay")
        lower = self.c.save_theme("Lower third look", third, kind="overlay")
        self.c.set_service_theme(lower, kind="overlay")
        self.c.set_verse_over_theme(over)
        self.c.go_live_service_item(d)
        self.c.show_verse("jn 3:16")
        payloads = self.c.payloads()
        self.assertEqual(payloads["projector"]["overlay"]["style"]["v_pos"], "top")
        slide = self.c.session.state().overlay
        self.assertEqual(slide.overlay_theme_id, lower)                 # the slide itself stays on the lower-third theme
        lower_style = (payloads["verse-lower"].get("overlay") or payloads["verse-lower"].get("base") or {}).get("style") or {}
        self.assertEqual(lower_style.get("v_pos"), "bottom")

    def test_the_verse_over_theme_must_be_an_overlay_theme_and_goes_when_deleted(self):
        proj = self.c.save_theme("Plain", {"font_size": 5})
        with self.assertRaisesRegex(ControllerError, "theme"):
            self.c.set_verse_over_theme(proj)
        over = self.c.save_theme("Box", {"font_size": 5}, kind="overlay")
        self.c.set_verse_over_theme(over)
        self.c.delete_theme(over)
        self.assertIsNone(self.c.verse_over_theme_id)

    def test_a_hidden_verse_stays_hidden_after_an_edit_but_can_come_back(self):
        a, d, v = self.build()
        self.c.go_live_service_item(d)
        self.c.show_verse("jn 3:17")
        self.c.hide_verse()
        self.c.add_announcement("Notice", "x")
        self.assertIsNone(self.c.session.state().overlay)
        self.assertTrue(self.c.reshow_verse())
        self.assertEqual(self.c.session.state().overlay.reference, "John 3:17")

    def test_a_service_with_a_bad_item_still_loads(self):
        empty = self.db.insert_song("Empty Song")
        from churchlight_presenter.core.items import ItemRef, add_to_service
        add_to_service(self.db, self.c.service_id, ItemRef.song(empty))
        self.c.add_entry(entry(self.c, "Beta"))
        self.c.open_service(self.c.service_id)
        labels = [s.label for s in self.c.session.slides]
        self.assertTrue(labels[0].startswith("Problem:"))
        self.assertEqual(labels[1], "Verse 1")


class LiveTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c = make_controller()
        self.addCleanup(self.db.close)

    def test_a_library_item_can_go_straight_live_without_any_service(self):
        self.c.go_live_entry(entry(self.c, "Beta"))
        self.assertEqual(self.c.mode, "item")
        self.assertEqual(self.c.session.state().base.text, "b1\nb2")
        self.assertFalse(self.c.next())               # one slide only

    def test_going_live_from_the_library_leaves_the_service_alone(self):
        self.c.new_service("S", "2026-10-25")
        item = self.c.add_entry(entry(self.c, "Sermon"))
        self.c.go_live_service_item(item)
        self.c.next()
        self.c.go_live_entry(entry(self.c, "Beta"))
        self.c.add_announcement("n", "b")               # editing now must not disturb the song
        self.assertEqual(self.c.session.state().base.text, "b1\nb2")
        self.c.go_live_service_item(item)               # back to the service
        self.assertEqual((self.c.mode, self.c.session.state().base.label), ("service", "Slide 1"))

    def test_next_and_previous_item_walk_the_service(self):
        self.c.new_service("S", "2026-10-25")
        ids = [self.c.add_entry(entry(self.c, n)) for n in ("Sermon", "Alpha", "Beta")]   # the deck has several slides
        live = lambda: [r.item_id for r in self.c.service_rows() if r.is_live]
        self.assertFalse(self.c.previous_item())        # nothing live: back does nothing
        self.assertTrue(self.c.next_item())             # nothing live: forward starts at the first item
        self.assertEqual(live(), [ids[0]])
        self.c.next()                                   # move inside the deck...
        self.assertEqual(self.c.session.state().base.label, "Slide 2")
        self.assertTrue(self.c.next_item())             # ...and still jump to the next item
        self.assertEqual(live(), [ids[1]])
        self.assertTrue(self.c.next_item())
        self.assertEqual(live(), [ids[2]])
        self.assertFalse(self.c.next_item())            # end of the service: stays put
        self.assertEqual(live(), [ids[2]])
        self.assertTrue(self.c.previous_item())
        self.assertEqual(live(), [ids[1]])
        self.assertTrue(self.c.previous_item())
        self.assertEqual(self.c.session.state().base.label, "Slide 1")   # lands on the item's first slide
        self.assertFalse(self.c.previous_item())        # start of the service: stays put
        self.assertEqual(live(), [ids[0]])

    def test_item_stepping_without_a_service_does_nothing(self):
        self.assertFalse(self.c.next_item())
        self.assertFalse(self.c.previous_item())

    def test_a_verse_over_a_live_deck_does_not_move_the_deck(self):
        self.c.go_live_entry(entry(self.c, "Sermon"))
        self.c.next()
        self.c.show_verse("jn 3:16")
        payloads = self.c.payloads()
        self.assertEqual(payloads["projector"]["base"]["label"], "Slide 2")
        self.assertEqual(payloads["projector"]["overlay"]["reference"], "John 3:16")
        self.assertEqual(payloads["stage"]["base"]["notes"], "note two")
        self.assertNotIn("note two", json.dumps(payloads["projector"]))
        self.c.hide_verse()
        self.assertIsNone(self.c.payloads()["projector"]["overlay"])
        self.assertEqual(self.c.payloads()["projector"]["base"]["label"], "Slide 2")

    def test_a_verse_goes_over_a_deck_and_reaches_the_verse_output(self):
        self.c.go_live_entry(entry(self.c, "Sermon"))
        self.c.show_verse("jn 3:17")
        out = self.c.payloads()["verse-lower"]
        self.assertEqual(out["overlay"]["text"], "[Demo 3:17] short.")
        self.assertEqual(out["overlay"]["verse_numbers"], [17])

    def test_a_verse_is_refused_unless_a_deck_is_live(self):
        for setup in (lambda: None, lambda: self.c.go_live_entry(entry(self.c, "Alpha"))):
            setup()
            self.assertFalse(self.c.verse_over_ok())
            with self.assertRaisesRegex(ControllerError, "slideshow only"):
                self.c.show_verse("jn 3:17")
            with self.assertRaisesRegex(ControllerError, "slideshow only"):
                self.c.reshow_verse()
            self.assertIsNone(self.c.session.state().overlay)
        self.c.go_live_entry(entry(self.c, "Sermon"))
        self.assertTrue(self.c.verse_over_ok())

    def test_a_showing_verse_comes_down_when_the_live_slide_stops_being_a_deck(self):
        self.c.new_service("S")
        deck = self.c.add_entry(entry(self.c, "Sermon"))
        song = self.c.add_entry(entry(self.c, "Alpha"))
        self.c.go_live_service_item(deck)
        self.c.show_verse("jn 3:17")
        self.assertIsNotNone(self.c.session.state().overlay)
        self.c.go_live_service_item(song)
        self.assertIsNone(self.c.session.state().overlay)           # taken down...
        with self.assertRaises(ControllerError):
            self.c.reshow_verse()                                   # ...and not brought back over a song

    def test_bad_verse_leaves_the_screen_alone(self):
        self.c.go_live_entry(entry(self.c, "Beta"))
        version = self.c.session.version
        with self.assertRaises(ControllerError):
            self.c.show_verse("nonsense")
        self.assertEqual(self.c.session.version, version)

    def test_no_translation_installed_says_so(self):
        db, c = make_controller(translation=False)
        self.addCleanup(db.close)
        c.go_live_entry(entry(c, "Sermon"))
        with self.assertRaisesRegex(ControllerError, "No Bible translation"):
            c.show_verse("jn 3:16")
        with self.assertRaisesRegex(ControllerError, "No verse has been shown"):
            c.reshow_verse()

    def test_the_translation_can_be_chosen(self):
        t = self.db.add_translation("ALT", "Alternate")
        self.db.add_verses(t, [("John", 3, 16, "[Alt 3:16] Different words.")])
        self.assertEqual(self.c.translation, "ALT")        # first in alphabetical order
        self.c.translation = "DEMO"
        self.c.go_live_entry(entry(self.c, "Sermon"))
        self.assertEqual(self.c.show_verse("jn 3:16")[0].label, "DEMO")
        self.assertEqual(self.c.show_verse("jn 3:16", translation="ALT")[0].label, "ALT")
        with self.assertRaises(ControllerError):
            self.c.translation = "NOPE"

    def test_the_default_bible_is_remembered(self):
        t = self.db.add_translation("ALT", "Alternate")
        self.db.add_verses(t, [("John", 3, 16, "x")])
        self.c.translation = "DEMO"
        again = OperatorController(self.db, OUTPUTS, BuildSettings(scripture_max_chars=60))
        self.assertEqual(again.translation, "DEMO")                  # a new run still uses it

    def test_clear_blank_and_go_to_slide(self):
        self.c.go_live_entry(entry(self.c, "Alpha"))
        self.assertTrue(self.c.go_to_slide(2))
        with self.assertRaisesRegex(ControllerError, "no slide 9"):
            self.c.go_to_slide(8)
        self.assertTrue(self.c.toggle_blank())
        self.assertIsNone(self.c.payloads()["projector"]["base"])
        self.c.clear()
        self.assertIsNone(self.c.session.state().base)

    def test_listeners_hear_about_edits_and_going_live(self):
        calls = []
        unsubscribe = self.c.subscribe(lambda: calls.append(1))
        self.c.new_service("S", "2026-10-25")
        self.c.add_entry(entry(self.c, "Beta"))
        self.assertGreaterEqual(len(calls), 2)
        count = len(calls)
        unsubscribe()
        self.c.next()
        self.assertEqual(len(calls), count)

    def test_the_server_can_be_started_from_the_controller(self):
        import http.client
        server = self.c.serve()
        self.addCleanup(self.c.close)
        self.c.go_live_entry(entry(self.c, "Beta"))
        conn = http.client.HTTPConnection(*server.address, timeout=5)
        conn.request("GET", "/out/projector")
        body = json.loads(conn.getresponse().read())
        conn.close()
        self.assertEqual(body["base"]["text"], "b1\nb2")
        self.assertIs(self.c.serve(), server)               # asking again reuses it


if __name__ == "__main__":
    unittest.main()
