# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.items import ItemRef, add_to_service, load_service
from churchlight_presenter.core.scripture_ref import ReferenceParseError

JOHN, PSALMS = 43, 19


class ItemCase(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.kjv = self.db.add_translation("KJV", "King James Version")
        self.db.add_verses(self.kjv, [
            ("John", 3, 16, "For God so loved the world"),
            ("John", 3, 17, "For God sent not his Son"),
            ("Psalms", 23, 1, "The LORD is my shepherd"),
            ("Psalms", 23, 2, "He maketh me to lie down"),
            ("Psalms", 23, 3, "He restoreth my soul"),
        ])
        self.service = self.db.create_service("Sunday", "2026-10-18")


class DatabaseLookupTests(ItemCase):
    def test_get_book(self):
        self.assertEqual(self.db.get_book(43)["name"], "John")
        self.assertEqual(self.db.get_book("john")["id"], 43)
        self.assertIsNone(self.db.get_book("Hezekiah"))
        self.assertIsNone(self.db.get_book(999))

    def test_get_translation(self):
        self.assertEqual(self.db.get_translation(self.kjv)["abbreviation"], "KJV")
        self.assertEqual(self.db.get_translation("kjv")["id"], self.kjv)
        self.assertIsNone(self.db.get_translation("NIV"))
        self.assertIsNone(self.db.get_translation(999))

    def test_get_verses_and_last_verse(self):
        rows = self.db.get_verses(self.kjv, PSALMS, 23, 2, 3)
        self.assertEqual([r["verse"] for r in rows], [2, 3])
        self.assertEqual([r["verse"] for r in self.db.get_verses(self.kjv, JOHN, 3, 16)], [16])
        self.assertEqual(self.db.last_verse(self.kjv, PSALMS, 23), 3)
        self.assertIsNone(self.db.last_verse(self.kjv, PSALMS, 24))


class ItemRefTests(ItemCase):
    def test_unknown_type_is_rejected(self):
        with self.assertRaises(ValueError):
            ItemRef("karaoke")

    def test_is_immutable_and_hashable_despite_overrides(self):
        ref = ItemRef.song(1, overrides={"lines_per_slide": 2})
        with self.assertRaises(Exception):
            ref.song_id = 2
        hash(ref)

    def test_save_and_load_round_trip(self):
        song = self.db.create_song_with_sections("S", [("V1", "verse", "a")])
        ref = ItemRef.song(song, overrides={"lines_per_slide": 2}, title="Opener")
        item_id = add_to_service(self.db, self.service, ref)
        add_to_service(self.db, self.service, ItemRef.blank())
        add_to_service(self.db, self.service,
                       ItemRef.passage(self.kjv, JOHN, 3, 16, 17), position=0)

        loaded = load_service(self.db, self.service)
        self.assertEqual([r.item_type for r in loaded], ["scripture", "song", "blank"])
        song_ref = loaded[1]
        self.assertEqual(song_ref.item_id, item_id)
        self.assertEqual(song_ref.song_id, song)
        self.assertEqual(song_ref.title, "Opener")
        self.assertEqual(song_ref.overrides, {"lines_per_slide": 2})
        self.assertEqual(loaded[0].verse_end, 17)
        self.assertEqual(loaded[2].overrides, {})

    def test_other_factories(self):
        pres = self.db.add_presentation("Deck", ["a.png"])
        media = self.db.insert_media_asset("Cross", "bg/cross.png")
        for ref in (ItemRef.presentation(pres), ItemRef.media(media),
                    ItemRef.announcement("Welcome", "Hello everyone")):
            add_to_service(self.db, self.service, ref)
        self.assertEqual([r.item_type for r in load_service(self.db, self.service)],
                         ["presentation", "media", "announcement"])


class FromReferenceTests(ItemCase):
    def test_verse_and_range(self):
        ref = ItemRef.from_reference(self.db, "kjv", "jn 3:16-17")
        self.assertEqual((ref.item_type, ref.translation_id, ref.book_id, ref.chapter,
                          ref.verse_start, ref.verse_end), ("scripture", self.kjv, JOHN, 3, 16, 17))
        single = ItemRef.from_reference(self.db, self.kjv, "john 3:16")
        self.assertEqual((single.verse_start, single.verse_end), (16, None))

    def test_whole_chapter_runs_to_the_last_verse(self):
        ref = ItemRef.from_reference(self.db, "KJV", "ps 23")
        self.assertEqual((ref.chapter, ref.verse_start, ref.verse_end), (23, 1, 3))

    def test_extra_fields_pass_through(self):
        ref = ItemRef.from_reference(self.db, "KJV", "john 3:16", overrides={"a": 1})
        self.assertEqual(ref.overrides, {"a": 1})

    def test_problems_are_reported_as_value_errors(self):
        with self.assertRaises(ValueError):
            ItemRef.from_reference(self.db, "NIV", "john 3:16")      # unknown translation
        with self.assertRaises(ValueError) as ctx:
            ItemRef.from_reference(self.db, "KJV", "john 3:99")       # no such verse
        self.assertIn("not found", str(ctx.exception))
        with self.assertRaises(ValueError):
            ItemRef.from_reference(self.db, "KJV", "psalm 24")        # chapter not loaded
        with self.assertRaises(ReferenceParseError):
            ItemRef.from_reference(self.db, "KJV", "gibberish")


if __name__ == "__main__":
    unittest.main()
