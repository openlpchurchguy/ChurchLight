# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Settings -> Screens lists the address of every output, and other computers' addresses when the server is open."""
import unittest

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


class ServerAddressTests(unittest.TestCase):
    def test_loopback_has_no_lan_addresses(self):
        db, c, api = make()
        self.addCleanup(db.close)
        self.assertEqual(c.server_addresses()["lan"], [])
        server = c.serve()
        self.addCleanup(server.close)
        info = c.server_addresses()
        self.assertEqual(info["lan"], [])
        self.assertEqual(info["port"], server.address[1])
        self.assertEqual(api.state()["server"], info)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class ScreenAddressPageTests(unittest.TestCase):
    def test_addresses_listed_with_copy(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        base = server.url.rstrip("/")
        page.goto(base + "/operator")
        page.wait_for_selector("#address-list li", state="attached")
        names = [o.name for o in c.outputs]
        self.assertEqual(page.locator("#address-list li").count(), len(names))
        values = page.eval_on_selector_all("#address-list input", "els => els.map(e => e.value)")
        for name, value in zip(names, values):
            self.assertEqual(value, base + "/view/" + name)
        self.assertTrue(page.is_hidden("#address-lan"))


if __name__ == "__main__":
    unittest.main()
