# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The verse over the slide has a toggle trigger and on and off triggers, like the blank ones."""
import unittest

from churchlight_presenter.ui.operator_api import ApiError, TRIGGER_NAMES
from tests.test_verse_tray import deck_live, make


class VerseTriggerTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        deck_live(self.c)
        self.c.load_tray("John 3")

    def showing(self):
        return self.c.session.state().overlay is not None

    def test_on_shows_the_first_tray_verse_and_again_changes_nothing(self):
        self.api.trigger("verse_on")
        self.assertTrue(self.showing())
        before = self.c.session.state().overlay
        self.api.trigger("verse_on")
        self.assertEqual(self.c.session.state().overlay, before)

    def test_off_hides_and_hiding_twice_is_fine(self):
        self.api.trigger("verse_on")
        self.api.trigger("verse_off")
        self.assertFalse(self.showing())
        self.api.trigger("verse_off")
        self.assertFalse(self.showing())

    def test_on_brings_back_the_verse_that_was_hidden(self):
        self.c.show_tray_verses([3])
        shown = self.c.session.state().overlay
        self.api.trigger("verse_off")
        self.api.trigger("verse_on")
        self.assertEqual(self.c.session.state().overlay, shown)

    def test_the_toggle_goes_both_ways(self):
        self.api.trigger("verse")
        self.assertTrue(self.showing())
        self.api.trigger("verse")
        self.assertFalse(self.showing())
        self.api.trigger("verse")
        self.assertTrue(self.showing())

    def test_the_old_hide_name_still_works(self):
        self.api.trigger("verse_on")
        self.assertNotIn("hide_verse", TRIGGER_NAMES)
        self.api.trigger("hide_verse")
        self.assertFalse(self.showing())

    def test_with_no_slideshow_live_it_says_why(self):
        self.c.clear()
        with self.assertRaises(ApiError) as caught:
            self.api.trigger("verse_on")
        self.assertEqual(caught.exception.status, 409)

    def test_with_no_tray_and_nothing_hidden_it_says_why(self):
        db, c, api = make()
        self.addCleanup(db.close)
        deck_live(c)
        with self.assertRaises(ApiError) as caught:
            api.trigger("verse_on")
        self.assertEqual(caught.exception.status, 409)


if __name__ == "__main__":
    unittest.main()
