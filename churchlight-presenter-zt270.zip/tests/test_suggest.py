# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Search suggestions (names only, numbers read from titles, recently used) and readable deck names."""
import http.client
import json
import re
import shutil
import subprocess
import tempfile
import unittest
from datetime import date
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import OperatorController, title_number
from churchlight_presenter.ui.operator_api import OperatorApi
from tests.test_imports import Base as ImportBase

WORDS = "[Verse 1]\nsome words here"


class SuggestBase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")

    def song(self, title, author="", draft=False, text=WORDS):
        return self.c.create_song(title, author, text, draft=draft)

    def deck(self, name):
        return self.db.add_presentation(name, [(f"d/{name}.png", None)])

    def titles(self, text):
        return [e.title for e in self.c.suggest_library(text)]


class TitleNumberTests(unittest.TestCase):
    def test_numbers_at_the_start_of_a_title(self):
        for title, number in (("055 Amazing Grace", "55"), ("#55 - Amazing", "55"), ("55. Amazing", "55"),
                              ("  550) Amazing", "550"), ("0 Hymn", "0"), ("000", "0"), ("7", "7"),
                              ("55 – Amazing", "55")):
            self.assertEqual(title_number(title), number, title)

    def test_titles_that_only_look_numbered_are_not(self):
        for title in ("10,000 Reasons", "55th Anniversary", "Amazing 55", "", "1234567 Too Long", "A55"):
            self.assertIsNone(title_number(title), title)


class NumberSuggestionTests(SuggestBase):
    def setUp(self):
        super().setUp()
        for title in ("055 Amazing Grace", "550 How Great", "559 Blessed Be", "5500 Far Out", "560 Other",
                      "155 Midway", "55th Anniversary", "10,000 Reasons", "Hymn Without Number"):
            self.song(title)

    def test_55_finds_055_then_550_to_559_in_number_order(self):
        names = self.titles("55")
        self.assertEqual(names[:4], ["055 Amazing Grace", "550 How Great", "559 Blessed Be", "5500 Far Out"])
        self.assertNotIn("155 Midway", names[:4])
        self.assertNotIn("560 Other", names)

    def test_leading_zeros_in_what_is_typed_do_not_matter(self):
        self.assertEqual(self.titles("055")[:4], self.titles("55")[:4])      # the numbered ones; names after them may differ

    def test_the_exact_number_comes_first_even_when_it_was_added_last(self):
        self.song("5 Small")
        self.assertEqual(self.titles("5")[0], "5 Small")

    def test_a_number_that_is_not_there_finds_nothing(self):
        self.assertEqual(self.titles("999"), [])

    def test_drafts_are_never_suggested(self):
        self.song("551 Draft Song", draft=True)
        self.assertNotIn("551 Draft Song", self.titles("55"))

    def test_decks_with_numbers_are_matched_too(self):
        self.deck("057 Welcome Slides")
        self.assertIn("057 Welcome Slides", self.titles("57"))


class NameSuggestionTests(SuggestBase):
    def test_names_that_start_with_the_text_come_before_other_matches(self):
        self.song("Blessed Grace", author="Ann")
        self.song("Amazing Grace")
        self.song("Grace Alone")
        self.song("Other", text="[Verse 1]\ngrace in the words only")
        names = self.titles("grace")
        self.assertEqual(names[0], "Grace Alone")
        self.assertEqual(set(names[1:3]), {"Blessed Grace", "Amazing Grace"})
        self.assertEqual(names[3], "Other")

    def test_songs_and_decks_both_appear_and_carry_only_a_name(self):
        self.song("Welcome Song")
        self.deck("Welcome Slideshow")
        entries = self.c.suggest_library("welcome")
        self.assertEqual({(e.kind, e.title) for e in entries},
                         {("song", "Welcome Song"), ("presentation", "Welcome Slideshow")})
        self.assertTrue(all(e.detail == "" for e in entries))

    def test_there_are_at_most_eight(self):
        for n in range(20):
            self.song(f"Praise {n}")
        self.assertEqual(len(self.c.suggest_library("praise")), 8)

    def test_a_song_is_not_suggested_twice(self):
        self.song("55 Fifty-five")
        names = self.titles("55")
        self.assertEqual(names.count("55 Fifty-five"), 1)

    def test_nothing_typed_that_matches_gives_nothing(self):
        self.song("Hymn")
        self.assertEqual(self.titles("zzzz"), [])


class RecentTests(SuggestBase):
    def test_an_empty_box_offers_what_services_used_lately_newest_first(self):
        a, b, c = self.song("Alpha"), self.song("Beta"), self.song("Gamma")
        deck = self.deck("Slides")
        old = self.db.create_service("Old", "2026-01-04")
        new = self.db.create_service("New", "2026-10-25")
        self.db.add_service_item(old, "song", song_id=a)
        self.db.add_service_item(old, "song", song_id=b)
        self.db.add_service_item(new, "song", song_id=b)
        self.db.add_service_item(new, "presentation", presentation_id=deck)
        names = self.titles("")
        self.assertEqual(names[:2], ["Slides", "Beta"])
        self.assertEqual(names[2], "Alpha")
        self.assertNotIn("Gamma", names)
        self.assertEqual(len(names), len(set(names)))

    def test_no_services_means_no_suggestions(self):
        self.song("Alpha")
        self.assertEqual(self.titles(""), [])
        self.assertEqual(self.titles("   "), [])


class EndpointTests(SuggestBase):
    def test_the_api_returns_kind_id_and_title_only(self):
        self.song("055 Amazing Grace", author="Ann")
        found = OperatorApi(self.c).suggest("55")
        self.assertEqual(found, [{"kind": "song", "id": found[0]["id"], "title": "055 Amazing Grace"}])

    def test_the_web_route_answers(self):
        self.song("055 Amazing Grace")
        server = self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        host, port = server.url.split("//")[1].split(":")
        conn = http.client.HTTPConnection(host, int(port), timeout=10)
        conn.request("GET", "/api/suggest?q=55")
        reply = conn.getresponse()
        data = json.loads(reply.read())
        conn.close()
        self.assertEqual(reply.status, 200)
        self.assertEqual([e["title"] for e in data["entries"]], ["055 Amazing Grace"])


class DeckNameTests(ImportBase):
    def pictures(self):
        return sorted((self.tmp / "sample" / "slides").glob("*.png"))

    def test_uploaded_pictures_are_not_named_after_the_upload_folder(self):
        pictures = self.pictures()
        self.assertGreater(len(pictures), 1)
        self.m.start("deck", self.batch_with("deck", *pictures))
        self.assertEqual(self.wait()["status"], "done")
        name = self.c.library_overview()["decks"][0]["name"]
        self.assertEqual(name, f"Slide pictures {date.today().isoformat()}")

    def test_one_picture_is_named_after_its_file(self):
        self.m.start("deck", self.batch_with("deck", self.pictures()[0]))
        self.assertEqual(self.wait()["status"], "done")
        self.assertEqual(self.c.library_overview()["decks"][0]["name"], self.pictures()[0].stem)

    def test_a_typed_name_wins(self):
        self.m.start("deck", self.batch_with("deck", *self.pictures()), name="Easter")
        self.wait()
        self.assertEqual(self.c.library_overview()["decks"][0]["name"], "Easter")


STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
JS_PATH = STATIC / "operator.js"
JS = JS_PATH.read_text(encoding="utf-8")
HTML = (STATIC / "operator.html").read_text(encoding="utf-8")
CSS = (STATIC / "operator.css").read_text(encoding="utf-8")


def dropdown_code():
    return JS[JS.index("function attachSuggest"):JS.index("async function addSuggested")]


class DropdownPageTests(unittest.TestCase):
    def test_the_service_search_box_gets_the_dropdown_when_results_under_it_are_off(self):
        self.assertIn('attachSuggest($("search")', JS)
        self.assertIn('() => !resultsUnder', JS)
        self.assertIn('id="search"', HTML)
        self.assertNotIn('finder-text', HTML)

    def test_the_dropdown_asks_the_suggest_route_and_shows_only_names(self):
        body = dropdown_code()
        self.assertIn('"/api/suggest?q="', body)
        self.assertIn("entry.title", body)
        for forbidden in ("entry.detail", "entry.author", "badge"):
            self.assertNotIn(forbidden, body)

    def test_it_is_a_proper_combobox_for_screen_readers(self):
        body = dropdown_code()
        for text in ('"combobox"', '"listbox"', '"option"', "aria-activedescendant", "aria-expanded"):
            self.assertIn(text, body)

    def test_stale_answers_are_dropped_and_the_list_closes_on_blur(self):
        body = dropdown_code()
        self.assertIn("mine !== counter", body)
        self.assertIn('addEventListener("blur"', body)
        self.assertIn("mousedown", body)           # a click on a row must not blur the box first

    def test_the_list_cannot_be_clipped_by_a_panel(self):
        self.assertRegex(CSS, r"\.suggest \{[^}]*position: fixed")

    def test_the_deck_editor_can_rename_its_deck(self):
        for ident in ("de-rename", "de-rename-box", "de-rename-input", "de-rename-save", "de-rename-cancel"):
            self.assertIn(f'id="{ident}"', HTML)
        self.assertIn('"deck_rename"', JS[JS.index("function wireDeckEditor"):])


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class DropdownLogicTests(unittest.TestCase):
    def step(self, current, count, key):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify(m.stepSuggestion({current},{count},'{key}')))"
        out = subprocess.run(["node", "-e", script, str(JS_PATH)], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_arrows_move_and_wrap(self):
        self.assertEqual(self.step(-1, 4, "ArrowDown"), 0)
        self.assertEqual(self.step(0, 4, "ArrowDown"), 1)
        self.assertEqual(self.step(3, 4, "ArrowDown"), 0)
        self.assertEqual(self.step(-1, 4, "ArrowUp"), 3)
        self.assertEqual(self.step(0, 4, "ArrowUp"), 3)
        self.assertEqual(self.step(2, 4, "ArrowUp"), 1)

    def test_no_rows_means_nothing_is_highlighted(self):
        self.assertEqual(self.step(0, 0, "ArrowDown"), -1)
        self.assertEqual(self.step(2, 4, "Home"), 2)


if __name__ == "__main__":
    unittest.main()
