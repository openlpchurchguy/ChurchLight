# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import http.client
import importlib.util
import io
import json
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.importers import pdfrender
from churchlight_presenter.ui import imports as imports_module
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.imports import ImportManager, safe_filename
from churchlight_presenter.ui.operator_api import OperatorApi
from tests.test_decks import make_pdf

ROOT = Path(__file__).resolve().parent.parent
_spec = importlib.util.spec_from_file_location("make_sample_data", ROOT / "tools" / "make_sample_data.py")
sample = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sample)


class Base(unittest.TestCase):
    memory = False

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.files = sample.make_files(self.tmp / "sample")
        self.db = DatabaseManager(":memory:" if self.memory else self.tmp / "t.db", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        self.c.imports = ImportManager(self.c)
        self.addCleanup(self.c.imports.close)
        self.m = self.c.imports
        self.versions = []
        self.c.subscribe(lambda: self.versions.append(self.c.version))

    def batch_with(self, kind, *paths):
        batch = self.m.new_batch()
        for path in paths:
            data = Path(path).read_bytes()
            self.m.save_upload(batch, Path(path).name, io.BytesIO(data), len(data), kind)
        return batch

    def wait(self):
        deadline = time.monotonic() + 30
        while self.m.busy():
            self.assertLess(time.monotonic(), deadline, "the import never finished")
            time.sleep(0.02)
        return self.m.jobs()[0]


class UploadTests(Base):
    def test_filenames_are_made_safe(self):
        self.assertEqual(safe_filename("../../etc/passwd"), "passwd")
        self.assertEqual(safe_filename("C:\\Users\\me\\song one.xml"), "song one.xml")
        self.assertEqual(safe_filename("..."), "file")
        self.assertEqual(safe_filename(".hidden.xml"), "hidden.xml")
        self.assertEqual(safe_filename("a<b>|c?.xml"), "a_b__c_.xml")
        self.assertEqual(safe_filename("Ünïcode Sóng.xml"), "Ünïcode Sóng.xml")
        self.assertLessEqual(len(safe_filename("x" * 500 + ".xml")), 120)

    def test_files_land_in_the_batch_and_names_stay_unique(self):
        batch = self.m.new_batch()
        for _ in range(3):
            self.m.save_upload(batch, "../a.xml", io.BytesIO(b"<x/>"), 4, "songs")
        names = sorted(p.name for p in (self.tmp / "media" / ".uploads" / batch).iterdir())
        self.assertEqual(names, ["a (2).xml", "a (3).xml", "a.xml"])

    def test_wrong_type_empty_oversize_and_short_streams_are_refused(self):
        batch = self.m.new_batch()
        with self.assertRaisesRegex(ControllerError, "not a kind of file"):
            self.m.save_upload(batch, "x.exe", io.BytesIO(b"x"), 1, "songs")
        with self.assertRaisesRegex(ControllerError, "empty"):
            self.m.save_upload(batch, "x.xml", io.BytesIO(b""), 0, "songs")
        with self.assertRaisesRegex(ControllerError, "too large"):
            self.m.save_upload(batch, "x.xml", io.BytesIO(b"x"), 10 ** 9, "songs")
        with self.assertRaisesRegex(ControllerError, "stopped early"):
            self.m.save_upload(batch, "x.xml", io.BytesIO(b"abc"), 10, "songs")
        with self.assertRaisesRegex(ControllerError, "Unknown kind"):
            self.m.save_upload(batch, "x.xml", io.BytesIO(b"x"), 1, "movies")
        self.assertEqual(list((self.tmp / "media" / ".uploads" / batch).iterdir()), [])   # nothing half-written

    def test_batch_ids_cannot_point_elsewhere(self):
        for bad in ("../x", "..", "", "A" * 16, "0" * 15, None, "0123456789abcdeg"):
            with self.assertRaises(ControllerError, msg=repr(bad)):
                self.m.save_upload(bad, "x.xml", io.BytesIO(b"x"), 1, "songs")
        with self.assertRaisesRegex(ControllerError, "expired"):
            self.m.save_upload("0123456789abcdef", "x.xml", io.BytesIO(b"x"), 1, "songs")

    def test_too_many_files_and_too_much_data(self):
        batch = self.m.new_batch()
        with mock.patch.object(imports_module, "MAX_FILES", 2):
            for n in range(2):
                self.m.save_upload(batch, f"{n}.xml", io.BytesIO(b"x"), 1, "songs")
            with self.assertRaisesRegex(ControllerError, "too many"):
                self.m.save_upload(batch, "3.xml", io.BytesIO(b"x"), 1, "songs")
        with mock.patch.object(imports_module, "MAX_BATCH_BYTES", 5):
            with self.assertRaisesRegex(ControllerError, "too much data"):
                self.m.save_upload(batch, "big.xml", io.BytesIO(b"x" * 10), 10, "songs")

    def test_old_unfinished_batches_are_cleaned_up_at_start(self):
        old = self.m.new_batch()
        folder = self.tmp / "media" / ".uploads" / old
        long_ago = time.time() - 3 * 24 * 3600
        os.utime(folder, (long_ago, long_ago))
        fresh = self.m.new_batch()
        ImportManager(self.c)
        self.assertFalse(folder.exists())
        self.assertTrue((self.tmp / "media" / ".uploads" / fresh).exists())

    def test_without_a_media_folder_importing_is_unavailable(self):
        c = OperatorController(self.db)
        with self.assertRaisesRegex(ControllerError, "media folder"):
            ImportManager(c).new_batch()


class SongImportTests(Base):
    def test_songs_import_in_the_background_and_listeners_hear_about_it(self):
        batch = self.batch_with("songs", *sorted(self.files["songs"].glob("*.xml")))
        before = len(self.versions)
        self.m.start("songs", batch)
        job = self.wait()
        self.assertEqual((job["status"], job["message"]), ("done", "Added 3 songs"))
        self.assertEqual(len(self.c.library_overview()["songs"]), 3)
        self.assertGreaterEqual(len(self.versions) - before, 2)     # started, then finished
        self.assertFalse((self.tmp / "media" / ".uploads" / batch).exists())   # temporary files removed

    def test_the_same_songs_again_are_reported_as_already_there(self):
        for _ in range(2):
            self.m.start("songs", self.batch_with("songs", *sorted(self.files["songs"].glob("*.xml"))))
            job = self.wait()
        self.assertEqual(job["message"], "Added 0 songs, 3 already there")
        self.assertEqual(len(self.c.library_overview()["songs"]), 3)

    def test_one_bad_file_does_not_stop_the_good_ones(self):
        bad = self.tmp / "bad.xml"
        bad.write_text("<not-a-song")
        good = sorted(self.files["songs"].glob("*.xml"))[0]
        self.m.start("songs", self.batch_with("songs", bad, good))
        job = self.wait()
        self.assertEqual(job["status"], "done")
        self.assertIn("Added 1 song", job["message"])
        self.assertIn("1 could not be read", job["message"])
        self.assertTrue(any(n.startswith("bad.xml") for n in job["notes"]))

    def test_only_bad_files_is_a_failure_with_the_reason(self):
        bad = self.tmp / "bad.xml"
        bad.write_text("<not-a-song")
        self.m.start("songs", self.batch_with("songs", bad))
        job = self.wait()
        self.assertEqual(job["status"], "failed")
        self.assertTrue(job["notes"])


class BibleImportTests(Base):
    def test_a_bible_installs_with_the_chosen_abbreviation(self):
        self.m.start("bible", self.batch_with("bible", self.files["bible"]), abbreviation="kjv", name="King James")
        job = self.wait()
        self.assertEqual(job["status"], "done")
        self.assertIn("Installed KJV", job["message"])
        self.assertEqual(self.c.translations(), ["KJV"])
        self.assertEqual(self.c.library_overview()["translations"][0]["name"], "King James")

    def test_installing_the_same_abbreviation_twice_explains_itself(self):
        self.m.start("bible", self.batch_with("bible", self.files["bible"]))
        self.wait()
        self.m.start("bible", self.batch_with("bible", self.files["bible"]))
        job = self.wait()
        self.assertEqual(job["status"], "failed")
        self.assertIn("already installed", job["message"])

    def test_one_bible_file_at_a_time(self):
        batch = self.batch_with("bible", self.files["bible"], self.files["bible"])
        with self.assertRaisesRegex(ControllerError, "one Bible file"):
            self.m.start("bible", batch)


class DeckImportTests(Base):
    def test_slide_pictures_become_a_deck(self):
        pictures = sorted((self.tmp / "sample" / "slides").glob("*.png"))
        self.assertTrue(pictures)
        self.m.start("deck", self.batch_with("deck", *pictures), name="Picture deck")
        job = self.wait()
        self.assertEqual(job["status"], "done")
        self.assertEqual(job["message"], f"Added a slideshow of {len(pictures)} pages")
        deck = self.c.library_overview()["decks"][0]
        self.assertEqual((deck["name"], deck["pages"]), ("Picture deck", len(pictures)))
        row = self.db.get_presentation_pages(deck["id"])[0]
        self.assertTrue((self.tmp / "media" / row["image_path"]).is_file())

    def test_the_same_pictures_again_say_already_there(self):
        pictures = sorted((self.tmp / "sample" / "slides").glob("*.png"))
        for _ in range(2):
            self.m.start("deck", self.batch_with("deck", *pictures))
            job = self.wait()
        self.assertIn("already in the library", job["message"])
        self.assertEqual(len(self.c.library_overview()["decks"]), 1)

    def test_a_presentation_file_is_not_accepted_only_pdfs_and_pictures(self):
        batch = self.m.new_batch()
        with self.assertRaisesRegex(ControllerError, "not a kind of file"):
            self.m.save_upload(batch, "deck.pptx", io.BytesIO(b"x"), 1, "deck")
        self.m.save_upload(batch, "deck.pdf", io.BytesIO(b"%PDF"), 4, "deck")

    def test_mixed_or_confusing_selections_are_refused_with_advice(self):
        pdf = self.tmp / "a.pdf"
        make_pdf(pdf, 1)
        picture = next((self.tmp / "sample" / "slides").glob("*.png"))
        with self.assertRaisesRegex(ControllerError, "not both"):
            self.m.start("deck", self.batch_with("deck", pdf, picture))
        two = self.tmp / "b.pdf"
        make_pdf(two, 1)
        with self.assertRaisesRegex(ControllerError, "one PDF"):
            self.m.start("deck", self.batch_with("deck", pdf, two))
        with self.assertRaisesRegex(ControllerError, "No files"):
            self.m.start("deck", self.m.new_batch())

    @unittest.skipUnless(pdfrender.renderer_name(), "no PDF renderer is installed")
    def test_a_pdf_imports(self):
        pdf = self.tmp / "talk.pdf"
        make_pdf(pdf, 3)
        self.m.start("deck", self.batch_with("deck", pdf))
        job = self.wait()
        self.assertEqual((job["status"], job["message"]), ("done", "Added a slideshow of 3 pages"))
        self.assertEqual(self.c.library_overview()["decks"][0]["name"], "talk")

    def test_a_broken_pdf_fails_with_a_reason_and_leaves_no_files(self):
        pdf = self.tmp / "broken.pdf"
        pdf.write_bytes(b"not a pdf")
        with mock.patch.object(pdfrender, "default_renderer", side_effect=pdfrender.ImporterError("The PDF could not be read: x")):
            self.m.start("deck", self.batch_with("deck", pdf))
            job = self.wait()
        self.assertEqual(job["status"], "failed")
        self.assertIn("could not be read", job["message"])
        self.assertEqual(self.c.library_overview()["decks"], [])
        self.assertEqual(list((self.tmp / "media" / ".uploads").iterdir()), [])


class InMemoryDatabaseTests(Base):
    memory = True

    def test_without_a_file_database_the_import_uses_the_controllers_lock(self):
        self.m.start("bible", self.batch_with("bible", self.files["bible"]))
        job = self.wait()
        self.assertEqual(job["status"], "done")
        self.assertEqual(self.c.translations(), ["DEMO"])


class WorkerSurvivesTests(Base):
    def test_an_unexpected_crash_is_a_failed_job_and_the_next_job_still_runs(self):
        with mock.patch.object(imports_module, "import_bible", side_effect=RuntimeError("boom")):
            with self.assertLogs("churchlight_presenter.ui.imports", "ERROR"):
                self.m.start("bible", self.batch_with("bible", self.files["bible"]))
                job = self.wait()
        self.assertEqual(job["status"], "failed")
        self.assertNotIn("boom", job["message"])
        self.m.start("bible", self.batch_with("bible", self.files["bible"]))
        self.assertEqual(self.wait()["status"], "done")

    def test_only_recent_jobs_are_kept(self):
        for _ in range(imports_module.KEEP_JOBS + 3):
            self.m.start("bible", self.batch_with("bible", self.files["bible"]))
        self.wait()
        self.assertEqual(len(self.m.jobs()), imports_module.KEEP_JOBS)


class OverHttpTests(Base):
    def setUp(self):
        super().setUp()
        self.c.imports.close()
        self.c.imports = None
        self.server = self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        self.api = OperatorApi(self.c)

    def request(self, method, path, body=None, headers=None):
        conn = http.client.HTTPConnection(*self.server.address, timeout=30)
        conn.request(method, path, body=body, headers=headers or {})
        res = conn.getresponse()
        raw = res.read()
        conn.close()
        try:
            return res.status, json.loads(raw)
        except ValueError:
            return res.status, raw

    def upload(self, batch, kind, path, **extra_headers):
        data = Path(path).read_bytes()
        headers = {"Content-Type": "application/octet-stream", "X-ChurchLight": "t", **extra_headers}
        return self.request("POST", f"/api/upload?batch={batch}&kind={kind}&name={path.name}", data, headers)

    def do(self, action, args):
        return self.request("POST", "/api/do", json.dumps({"action": action, "args": args}),
                            {"Content-Type": "application/json", "X-ChurchLight": "t"})

    def test_the_whole_flow_over_http(self):
        status, reply = self.do("import_batch", {})
        self.assertEqual(status, 200)
        batch = reply["batch"]
        for song in sorted(self.files["songs"].glob("*.xml")):
            self.assertEqual(self.upload(batch, "songs", song)[0], 200)
        status, reply = self.do("import_start", {"kind": "songs", "batch": batch})
        self.assertEqual(status, 200)
        deadline = time.monotonic() + 30
        while True:
            _, state = self.request("GET", "/api/state")
            if state["imports"] and state["imports"][0]["status"] in ("done", "failed"):
                break
            self.assertLess(time.monotonic(), deadline)
            time.sleep(0.05)
        self.assertEqual(state["imports"][0]["message"], "Added 3 songs")
        self.assertTrue(state["can_import"])
        _, manage = self.request("GET", "/api/manage")
        self.assertEqual(len(manage["songs"]), 3)

    def test_upload_guards(self):
        _, reply = self.do("import_batch", {})
        batch = reply["batch"]
        song = sorted(self.files["songs"].glob("*.xml"))[0]
        data = song.read_bytes()
        url = f"/api/upload?batch={batch}&kind=songs&name=a.xml"
        self.assertEqual(self.request("POST", url, data, {"Content-Type": "application/octet-stream"})[0], 403)
        self.assertEqual(self.request("POST", url, data, {"Content-Type": "text/plain", "X-ChurchLight": "t"})[0], 415)
        self.assertEqual(self.request("POST", url, data, {"Content-Type": "application/octet-stream",
                                                          "X-ChurchLight": "t", "Origin": "http://evil.example"})[0], 403)
        status, body = self.request("POST", f"/api/upload?batch={batch}&kind=songs&name=a.exe", data,
                                    {"Content-Type": "application/octet-stream", "X-ChurchLight": "t"})
        self.assertEqual(status, 400)
        self.assertIn("not a kind of file", body["error"])
        self.assertEqual(self.request("POST", f"/api/upload?kind=songs&name=a.xml", data,
                                      {"Content-Type": "application/octet-stream", "X-ChurchLight": "t"})[0], 400)
        self.assertEqual(self.upload(batch, "songs", song, Host="evil.example")[0], 403)

    def test_the_upload_folder_is_never_served_as_media(self):
        _, reply = self.do("import_batch", {})
        picture = next((self.tmp / "sample" / "slides").glob("*.png"))
        self.assertEqual(self.upload(reply["batch"], "deck", picture)[0], 200)
        self.assertEqual(self.request("GET", f"/media/.uploads/{reply['batch']}/{picture.name}")[0], 404)


class ApiActionTests(Base):
    def setUp(self):
        super().setUp()
        self.api = OperatorApi(self.c)

    def test_song_actions_through_the_api(self):
        reply = self.api.call("song_save", {"title": "S", "author": "A", "text": "[Verse 1]\nhello"})
        sid = reply["id"]
        got = self.api.call("song_get", {"id": sid})
        self.assertEqual((got["title"], got["author"], got["text"]), ("S", "A", "[Verse 1]\nhello"))
        check = self.api.call("song_check", {"text": "[A]\nx\n\n[B]\ny"})
        self.assertTrue(check["valid"])
        self.assertEqual([s["label"] for s in check["sections"]], ["A", "B"])
        wrong = self.api.call("song_check", {"text": "[A]\nx\nOrder: Q"})
        self.assertFalse(wrong["valid"])
        self.assertIn("[Q]", wrong["error"])
        self.api.call("song_save", {"id": sid, "title": "S2", "text": "[A]\nnew"})
        self.assertEqual(self.api.manage()["songs"][0]["title"], "S2")
        self.api.call("song_delete", {"id": sid})
        self.assertEqual(self.api.manage()["songs"], [])

    def test_bad_input_becomes_an_api_error(self):
        from churchlight_presenter.ui.operator_api import ApiError
        with self.assertRaisesRegex(ApiError, "no words"):
            self.api.call("song_save", {"title": "S", "text": ""})
        with self.assertRaisesRegex(ApiError, "abbreviation"):
            self.api.call("import_start", {"kind": "bible", "batch": "0" * 16, "abbreviation": "A B!"})
        with self.assertRaisesRegex(ApiError, "must be text"):
            self.api.call("song_check", {"text": 5})
        with self.assertRaisesRegex(ApiError, "too long"):
            self.api.call("song_check", {"text": "x" * 70000})

    def test_deck_and_bible_actions(self):
        self.m.start("bible", self.batch_with("bible", self.files["bible"]))
        self.wait()
        pictures = sorted((self.tmp / "sample" / "slides").glob("*.png"))
        self.m.start("deck", self.batch_with("deck", *pictures), name="D")
        self.wait()
        deck = self.api.manage()["decks"][0]
        self.api.call("deck_rename", {"id": deck["id"], "name": "Renamed"})
        self.assertEqual(self.api.manage()["decks"][0]["name"], "Renamed")
        self.api.call("deck_delete", {"id": deck["id"]})
        self.assertEqual(self.api.manage()["decks"], [])
        self.api.call("bible_delete", {"abbreviation": "DEMO"})
        self.assertEqual(self.api.manage()["translations"], [])


if __name__ == "__main__":
    unittest.main()
