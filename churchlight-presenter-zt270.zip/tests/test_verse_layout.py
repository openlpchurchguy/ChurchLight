# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Verse layout: one verse per slide by default, optional fit-as-many-as-will-fit, service override."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.themes import projector_char_capacity

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


class CapacityParityTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("node"), "node not installed")
    def test_the_page_and_python_agree_on_room(self):
        styles = [{}, {"font_size": 7, "band": True}, {"font_size": 10, "band": True},
                  {"font_size": 5.5, "line_height": 1.5, "title_scale": 1.0, "uppercase": True}]
        script = ("const t=require(%s);const s=%s;"
                  "console.log(JSON.stringify(s.map(x=>t.projectorLayout(x).chars)));"
                  % (json.dumps(str(STATIC / "themes.js")), json.dumps(styles)))
        out = subprocess.run(["node", "-e", script], capture_output=True, text=True, check=True).stdout
        self.assertEqual(json.loads(out), [projector_char_capacity(s) for s in styles])

    @unittest.skipUnless(shutil.which("node"), "node not installed")
    def test_packing_takes_one_verse_unless_asked_for_more(self):
        script = ("const t=require(%s);const g=[[1,'aaaa'],[2,'bbbb'],[3,'c'.repeat(500)]];"
                  "console.log(JSON.stringify([t.packSegments(g,100,'verse').length,t.packSegments(g,100,'chars').length]));"
                  % json.dumps(str(STATIC / "themes.js")))
        out = subprocess.run(["node", "-e", script], capture_output=True, text=True, check=True).stdout
        self.assertEqual(json.loads(out), [1, 2])


class ServiceLayoutTests(unittest.TestCase):
    def setUp(self):
        from churchlight_presenter.core.database import DatabaseManager
        from churchlight_presenter.core.outputs import Output
        from churchlight_presenter.ui.controller import OperatorController
        from churchlight_presenter.ui.operator_api import OperatorApi
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        t = self.db.add_translation("DEMO", "Demo")
        self.db.add_verses(t, [("John", 3, 16, "For God so loved the world."),
                               ("John", 3, 17, "He sent his Son."),
                               ("John", 3, 18, "Believe and live.")])
        self.c = OperatorController(self.db, [Output("projector", "projector")], translation="DEMO")
        self.api = OperatorApi(self.c)
        self.c.new_service("Sunday")
        self.c.add_verse("John 3:16-18")

    def counts(self):
        return [i["slides"] for i in self.api.state()["items"] if i["type"] == "scripture"]

    def test_one_verse_per_slide_is_the_default(self):
        self.assertEqual(self.counts(), [3])
        self.assertIsNone(self.api.state()["service"]["verse_split"])

    def test_a_service_can_ask_for_as_many_whole_verses_as_fit(self):
        self.api.call("service_verse_split", {"value": "chars"})
        self.assertEqual(self.api.state()["service"]["verse_split"], "chars")
        self.assertEqual(self.counts(), [1])
        self.api.call("service_verse_split", {"value": ""})
        self.assertEqual(self.counts(), [3])
        self.assertIsNone(self.api.state()["service"]["verse_split"])

    def test_an_unknown_choice_is_refused(self):
        from churchlight_presenter.ui.operator_api import ApiError
        with self.assertRaises(ApiError):
            self.api.call("service_verse_split", {"value": "sideways"})


if __name__ == "__main__":
    unittest.main()
