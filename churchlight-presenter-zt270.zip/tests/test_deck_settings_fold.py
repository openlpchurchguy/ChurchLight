# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Each slideshow in the library can fold away its picture size, transition and autoplay controls."""
import json
import subprocess
import unittest
from pathlib import Path

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

JS = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "operator.js"


def js(expression):
    script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
    out = subprocess.run(["node", "-e", script, str(JS)], capture_output=True, text=True, timeout=30, check=True)
    return json.loads(out.stdout)


class PureTests(unittest.TestCase):
    def test_stored_choices_are_read_defensively(self):
        for raw in ("null", "'{'", "'{\"a\":1}'", "undefined", "'[\"x\"]'"):
            self.assertEqual(js(f"m.parseDeckOpen({raw})"), [], raw)
        self.assertEqual(js("m.parseDeckOpen('[3,5]')"), [3, 5])

    def test_toggling_adds_and_removes(self):
        self.assertEqual(js("m.toggleDeckOpen([1],2)"), [1, 2])
        self.assertEqual(js("m.toggleDeckOpen([1,2],1)"), [2])


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def test_settings_start_folded_open_per_slideshow_and_are_remembered(self):
        db, c, api = make()                                   # holds one slideshow, "Deck"
        self.addCleanup(db.close)
        db.add_presentation("Second", [("s/1.png", "one")])
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.click("#tab-decks")
        page.wait_for_selector("#deck-list .deck-settings", state="attached")
        rows = page.locator("#deck-list .row")
        self.assertEqual(rows.count(), 2)
        self.assertEqual(page.locator("#deck-list .deck-settings:visible").count(), 0)      # folded by default
        self.assertTrue(page.is_visible("#deck-list .row >> nth=0 >> text=Edit slideshow"))  # the rest of the row stays
        first = rows.nth(0).locator("button", has_text="Show settings")
        first.click()
        self.assertEqual(page.locator("#deck-list .deck-settings:visible").count(), 1)
        self.assertEqual(rows.nth(0).locator("button", has_text="Hide settings").get_attribute("aria-expanded"), "true")
        page.reload()
        page.click("#tab-decks")
        page.wait_for_selector("#deck-list .deck-settings", state="attached")
        self.assertEqual(page.locator("#deck-list .deck-settings:visible").count(), 1)       # remembered
        page.locator("#deck-list button", has_text="Hide settings").click()
        self.assertEqual(page.locator("#deck-list .deck-settings:visible").count(), 0)


if __name__ == "__main__":
    unittest.main()
