# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Video and sound files are streamed in pieces, with Range requests, and only from the media folder."""
import http.client
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.server import app as server_app
from churchlight_presenter.server.app import OutputServer

DATA = bytes(range(256)) * 400          # 102,400 bytes: more than one chunk


class MediaStreamTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        root = Path(self.folder.name)
        (root / "media").mkdir()
        (root / "media" / "clip.mp4").write_bytes(DATA)
        (root / "media" / "song.mp3").write_bytes(DATA[:5000])
        (root / "media" / "empty.wav").write_bytes(b"")
        (root / "media" / "notes.txt").write_bytes(b"hello")
        (root / "pic.png").write_bytes(b"\x89PNG" + b"\0" * 16)
        self.server = OutputServer(LiveSession(), [Output("projector", "projector")], media_root=root).start()
        self.addCleanup(self.server.close)
        self.port = self.server.address[1]

    def get(self, path, headers=None, method="GET"):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            conn.request(method, path, headers=headers or {})
            response = conn.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            conn.close()

    def test_a_whole_file_is_sent_with_its_type_and_says_ranges_are_welcome(self):
        status, headers, body = self.get("/media/media/clip.mp4")
        self.assertEqual((status, headers["Content-Type"], headers["Accept-Ranges"]), (200, "video/mp4", "bytes"))
        self.assertEqual(body, DATA)
        self.assertEqual(self.get("/media/media/song.mp3")[1]["Content-Type"], "audio/mpeg")

    def test_a_range_gets_just_that_piece(self):
        status, headers, body = self.get("/media/media/clip.mp4", {"Range": "bytes=100-199"})
        self.assertEqual((status, body), (206, DATA[100:200]))
        self.assertEqual(headers["Content-Range"], f"bytes 100-199/{len(DATA)}")
        self.assertEqual(int(headers["Content-Length"]), 100)

    def test_open_ended_and_last_n_ranges_and_a_range_past_the_end_is_cut_short(self):
        _, headers, body = self.get("/media/media/clip.mp4", {"Range": f"bytes={len(DATA) - 10}-"})
        self.assertEqual(body, DATA[-10:])
        _, _, tail = self.get("/media/media/clip.mp4", {"Range": "bytes=-50"})
        self.assertEqual(tail, DATA[-50:])
        status, headers, body = self.get("/media/media/clip.mp4", {"Range": f"bytes=100000-{len(DATA) * 5}"})
        self.assertEqual((status, body), (206, DATA[100000:]))

    def test_a_piece_bigger_than_one_chunk_arrives_whole(self):
        self.assertGreater(len(DATA), server_app.STREAM_CHUNK)
        status, _, body = self.get("/media/media/clip.mp4", {"Range": f"bytes=10-{len(DATA) - 11}"})
        self.assertEqual((status, body), (206, DATA[10:len(DATA) - 10]))

    def test_bad_ranges_are_refused(self):
        for value in (f"bytes={len(DATA)}-", "bytes=500-100", "bytes=-", "bytes=abc", "items=1-2", "bytes=1-2,5-6"):
            status, headers, _ = self.get("/media/media/clip.mp4", {"Range": value})
            self.assertEqual(status, 416, value)
            self.assertEqual(headers["Content-Range"], f"bytes */{len(DATA)}")

    def test_head_sends_the_headers_and_no_body(self):
        status, headers, body = self.get("/media/media/clip.mp4", method="HEAD")
        self.assertEqual((status, body, int(headers["Content-Length"])), (200, b"", len(DATA)))

    def test_an_empty_file_is_sent_as_empty(self):
        status, headers, body = self.get("/media/media/empty.wav")
        self.assertEqual((status, body, headers["Content-Length"]), (200, b"", "0"))

    def test_only_listed_types_inside_the_media_folder_are_served(self):
        self.assertEqual(self.get("/media/media/notes.txt")[0], 404)
        self.assertEqual(self.get("/media/media/missing.mp4")[0], 404)
        self.assertEqual(self.get("/media/../clip.mp4")[0], 404)
        self.assertEqual(self.get("/media/media/%2e%2e/pic.png")[0], 404)
        self.assertEqual(self.get("/media/pic.png")[0], 200)           # pictures still work

    def test_a_client_that_hangs_up_mid_file_does_no_harm(self):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request("GET", "/media/media/clip.mp4")
        conn.getresponse().read(10)
        conn.close()                                                   # the rest of the file is never read
        self.assertEqual(self.get("/media/media/song.mp3")[0], 200)    # and the server carries on

    def test_pages_may_load_media_from_this_server_only(self):
        self.assertIn("media-src 'self'", server_app.PAGE_CSP)


if __name__ == "__main__":
    unittest.main()
