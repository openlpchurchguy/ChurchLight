# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Projector background pictures: upload, storage, cleanup and the band behind full-screen text."""
import base64
import io
import json
import os
import subprocess
import tempfile
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import ControllerError, OperatorController

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")


class BackgroundTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.media = Path(self.tmp.name) / "m"
        self.db = DatabaseManager(":memory:")
        self.c = OperatorController(self.db, media_root=self.media)
        self.c.serve(media_root=self.media)          # starts the import manager
        self.addCleanup(self.tmp.cleanup)

    def upload(self, name="pic.png", data=PNG):
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, name, io.BytesIO(data), len(data), "background")
        return batch

    def test_a_picture_is_stored_under_a_random_name(self):
        path = self.c.import_background(self.upload())
        self.assertRegex(path, r"^backgrounds/[0-9a-f]{16}\.png$")
        self.assertEqual((self.media / path).read_bytes(), PNG)

    def test_something_that_is_not_a_picture_is_refused(self):
        with self.assertRaises(ControllerError):
            self.c.import_background(self.upload("fake.png", b"not a picture at all"))

    def test_the_picture_is_kept_by_the_theme_and_pruned_when_unused(self):
        path = self.c.import_background(self.upload())
        theme = self.c.save_theme("Pic", {"background_image": path, "background_fit": "fit"})
        self.c._prune_backgrounds(grace_seconds=0)
        self.assertTrue((self.media / path).exists())
        self.c.delete_theme(theme)
        self.c._prune_backgrounds(grace_seconds=0)
        self.assertFalse((self.media / path).exists())

    def test_a_fresh_unsaved_upload_survives_a_save_of_another_theme(self):
        path = self.c.import_background(self.upload())
        self.c.save_theme("Other", {"color": "#ffffff"})
        self.assertTrue((self.media / path).exists())

    def test_only_projector_themes_keep_a_picture(self):
        path = self.c.import_background(self.upload())
        theme = self.c.save_theme("Over", {"background_image": path}, kind="overlay")
        self.assertNotIn("background_image", self.db.get_theme_settings(theme)["style"])

    def test_the_picture_is_served_from_the_media_folder(self):
        path = self.c.import_background(self.upload())
        self.assertTrue((self.media / path).is_file())


class BandScriptTests(unittest.TestCase):
    def band(self, layer):
        script = ("const m=require(process.argv[1]);console.log(JSON.stringify(m.hasTextBand(%s)))" % json.dumps(layer))
        out = subprocess.run(["node", "-e", script, str(STATIC / "output.js")], capture_output=True, text=True, check=True)
        return json.loads(out.stdout)

    def test_only_full_text_layers_with_the_band_on_get_one(self):
        full = {"placement": "full", "view": {"image": None, "style": {"band": True}}}
        self.assertTrue(self.band(full))
        self.assertFalse(self.band({"placement": "full", "view": {"image": None, "style": {"band": False}}}))
        self.assertFalse(self.band({"placement": "full", "view": {"image": None, "style": {}}}))
        self.assertFalse(self.band({"placement": "full", "view": {"image": "a.png", "style": {"band": True}}}))
        self.assertFalse(self.band({"placement": "confidence", "view": {"image": None, "style": {"band": True}}}))


if __name__ == "__main__":
    unittest.main()


class TransparentBackgroundTests(unittest.TestCase):
    def test_a_fully_transparent_background_is_a_valid_style(self):
        from churchlight_presenter.core.themes import validate_style
        self.assertEqual(validate_style({"background_color": "#00000000"})["background_color"], "#00000000")

    def test_the_editor_offers_a_transparent_box_for_the_full_screen_color(self):
        text = (STATIC / "themes.js").read_text(encoding="utf-8")
        self.assertIn("backgroundColorControl", text)
        self.assertIn("Transparent (a video behind the page shows through)", text)
