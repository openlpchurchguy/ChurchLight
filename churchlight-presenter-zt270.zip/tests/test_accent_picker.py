# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""An accent colour of your own in the Appearance panel."""
import time
import unittest

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


def until(check, seconds=10):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class AccentPickerTests(unittest.TestCase):
    def open(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1400, "height": 900})
        self.url = server.url.rstrip("/") + "/operator"
        self.page.goto(self.url)
        self.page.wait_for_selector("#connection")
        self.page.evaluate("wizardHide()")

    def accent(self):
        return self.page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()")

    def test_a_chosen_colour_is_used_explained_kept_and_replaced_by_a_preset(self):
        self.open()
        self.page.click("#btn-look")
        self.assertTrue(self.page.is_hidden("#look-accent-note"))
        self.page.evaluate("""() => { const p = document.getElementById('look-accent-custom'); p.value = '#cc3377';
            p.dispatchEvent(new Event('input', {bubbles: true})); }""")
        self.assertEqual(self.page.evaluate("document.documentElement.dataset.accent"), "custom")
        self.assertNotEqual(self.accent(), "")
        self.assertFalse(self.page.is_hidden("#look-accent-note"))
        self.assertTrue(self.page.inner_text("#look-accent-note"))
        first = self.accent()
        self.page.reload()
        self.page.wait_for_selector("#connection")
        self.assertEqual(self.accent(), first)                                   # kept in this browser
        self.page.evaluate("wizardHide()")
        self.page.click("#btn-look")
        self.page.click(".swatch.green")                                         # a preset takes over again
        self.assertEqual(self.page.evaluate("document.documentElement.dataset.accent"), "green")
        self.assertEqual(self.page.evaluate("document.documentElement.style.getPropertyValue('--accent')"), "")

    def test_the_colour_is_refitted_when_the_look_changes_between_dark_and_light(self):
        self.open()
        self.page.evaluate("ChurchLook.set({theme: 'dark', accent: '#cc3377'})")
        dark = self.accent()
        self.page.evaluate("ChurchLook.set({theme: 'light'})")
        light = self.accent()
        self.assertNotEqual(dark, light)
