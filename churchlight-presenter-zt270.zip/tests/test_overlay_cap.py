# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
# ChurchLight Presenter — free worship software
# Copyright (C) 2026 ChurchLight contributors. AGPL-3.0-or-later.
"""The overlay height cap: the lower third decides where verses break when it holds less than the projector."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.items import ItemRef
from churchlight_presenter.core.slides import SlideBuilder
from churchlight_presenter.core.themes import overlay_char_capacity, validate_style

LONG = " ".join(["word"] * 40)      # 199 characters


class CapacityTests(unittest.TestCase):
    def test_no_cap_means_no_limit(self):
        self.assertIsNone(overlay_char_capacity({"font_size": 5}))
        self.assertIsNone(overlay_char_capacity({"max_height": 0}))

    def test_taller_box_holds_more(self):
        small = overlay_char_capacity({"font_size": 5, "max_height": 20})
        big = overlay_char_capacity({"font_size": 5, "max_height": 40})
        self.assertGreater(big, small)

    def test_bigger_text_or_narrower_box_holds_less(self):
        base = overlay_char_capacity({"font_size": 5, "max_height": 30, "box_width": 80})
        self.assertLess(overlay_char_capacity({"font_size": 8, "max_height": 30, "box_width": 80}), base)
        self.assertLess(overlay_char_capacity({"font_size": 5, "max_height": 30, "box_width": 40}), base)

    def test_style_accepts_range(self):
        self.assertEqual(validate_style({"max_height": 25})["max_height"], 25.0)
        with self.assertRaises(ValueError):
            validate_style({"max_height": 80})


class SplitTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.kjv = self.db.add_translation("KJV", "King James Version")
        self.db.add_verses(self.kjv, [("John", 3, n, LONG) for n in (16, 17, 18)])
        self.book = self.db.get_book_by_name("John")["id"] if hasattr(self.db, "get_book_by_name") else None
        self.builder = SlideBuilder(self.db)

    def build(self, overlay_style=None):
        overlay = None
        if overlay_style is not None:
            overlay = self.db.add_theme("Lower", {"kind": "overlay", "style": overlay_style})
        from tests.test_slides import JOHN
        ref = ItemRef.passage(self.kjv, JOHN, 3, 16, 18)
        return self.builder.build_item(ref, None, overlay)

    def test_without_a_cap_nothing_changes(self):
        base = self.build()
        self.assertEqual(len(self.build({"font_size": 5, "box_width": 80})), len(base))

    def test_a_small_cap_forces_more_breaks(self):
        base = self.build()
        capped = self.build({"font_size": 5, "box_width": 60, "max_height": 14})
        self.assertGreater(len(capped), len(base))
        self.assertEqual(" ".join(s.text for s in capped), " ".join(s.text for s in base))

    def test_a_roomy_cap_leaves_the_projector_in_charge(self):
        base = self.build()
        self.assertEqual(len(self.build({"font_size": 5, "box_width": 90, "max_height": 60})), len(base))


if __name__ == "__main__":
    unittest.main()
