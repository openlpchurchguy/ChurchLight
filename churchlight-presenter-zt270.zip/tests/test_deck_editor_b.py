# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The deck editor (Stage B): add pictures, replace a picture, copy slides from another deck, split a deck."""
import base64
import io
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.importers.decks import import_image_folder
from churchlight_presenter.ui.controller import ControllerError, OperatorController
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi

PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
JPG = b"\xff\xd8\xff\xe0" + b"0" * 20


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.media = self.tmp / "media"
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.media)
        self.c.serve(media_root=self.media)               # starts the import manager
        self.addCleanup(self.c.close)
        self.api = OperatorApi(self.c)
        self.deck, self.paths = self.make_deck("Welcome", 4, "decks/aaa")

    def make_deck(self, name, pages, folder):
        paths = []
        for n in range(1, pages + 1):
            rel = f"{folder}/page-{n:03d}.png"
            (self.media / rel).parent.mkdir(parents=True, exist_ok=True)
            (self.media / rel).write_bytes(PNG)
            paths.append(rel)
        return self.db.add_presentation(name, [(p, None) for p in paths]), paths

    def upload(self, *files, kind="slidepics"):
        batch = self.c.imports.new_batch()
        for name, data in files:
            self.c.imports.save_upload(batch, name, io.BytesIO(data), len(data), kind)
        return batch

    def pages(self, deck=None):
        return list(self.db.get_presentation_pages(deck or self.deck))

    def images(self, deck=None):
        return [p["image_path"] for p in self.pages(deck)]

    def ids(self, deck=None):
        return [p["id"] for p in self.pages(deck)]

    def go_live(self, deck=None):
        entry = next(e for e in self.c.search_library("") if e.kind == "presentation" and e.id == (deck or self.deck))
        self.c.go_live_entry(entry)


class AddPicturesTests(Base):
    def test_pictures_go_after_the_chosen_slide_in_natural_file_order(self):
        a, b, c, d = self.ids()
        new = self.c.add_deck_pictures(self.deck, self.upload(("pic10.png", PNG), ("pic2.jpg", JPG), ("pic1.png", PNG)), b)
        self.assertEqual(self.ids()[:2], [a, b])
        self.assertEqual(self.ids()[2:5], new)
        self.assertEqual(self.ids()[5:], [c, d])
        added = self.images()[2:5]
        self.assertTrue(all(p.startswith("decks/added/") for p in added))
        self.assertEqual([Path(p).suffix for p in added], [".png", ".jpg", ".png"])       # pic1, pic2, pic10
        self.assertTrue(all((self.media / p).is_file() for p in added))
        self.assertEqual([p["page_number"] for p in self.pages()], list(range(1, 8)))

    def test_with_no_slide_chosen_they_go_at_the_end(self):
        new = self.c.add_deck_pictures(self.deck, self.upload(("x.png", PNG)))
        self.assertEqual(self.ids()[-1], new[0])

    def test_something_that_is_not_a_picture_adds_nothing(self):
        batch = self.upload(("ok.png", PNG), ("fake.png", b"not a picture at all"))
        with self.assertRaises(ControllerError):
            self.c.add_deck_pictures(self.deck, batch)
        self.assertEqual(len(self.ids()), 4)
        self.assertFalse((self.media / "decks" / "added").exists())

    def test_other_kinds_of_file_are_not_accepted_as_slide_pictures(self):
        with self.assertRaises(ControllerError):
            self.upload(("deck.pdf", b"%PDF-1.4"))
        batch = self.c.imports.new_batch()
        with self.assertRaises(ControllerError):
            self.c.imports.start("slidepics", batch)

    def test_a_live_deck_cannot_get_pictures(self):
        self.go_live()
        with self.assertRaisesRegex(ControllerError, "live"):
            self.c.add_deck_pictures(self.deck, self.upload(("x.png", PNG)))
        self.assertEqual(len(self.ids()), 4)

    def test_a_page_that_is_not_in_the_deck_adds_nothing_and_leaves_no_file(self):
        other, _ = self.make_deck("Other", 2, "decks/bbb")
        foreign = self.ids(other)[0]
        with self.assertRaises(ControllerError):
            self.c.add_deck_pictures(self.deck, self.upload(("x.png", PNG)), foreign)
        self.assertEqual(len(self.ids()), 4)
        self.assertEqual(list((self.media / "decks").glob("added/*")), [])


class ReplaceTests(Base):
    def test_the_slide_keeps_its_place_notes_and_skip_setting(self):
        a, b, c, d = self.ids()
        self.c.set_deck_page_notes(self.deck, b, "say hi")
        self.c.skip_deck_pages(self.deck, [b], True)
        self.c.replace_deck_picture(self.deck, b, self.upload(("new.jpg", JPG)))
        page = self.pages()[1]
        self.assertEqual((page["id"], page["page_number"], page["notes"], page["skipped"]), (b, 2, "say hi", 1))
        self.assertTrue(page["image_path"].startswith("decks/added/") and page["image_path"].endswith(".jpg"))
        self.assertFalse((self.media / self.paths[1]).exists())          # the old picture is no longer used
        self.assertTrue((self.media / self.paths[0]).exists())

    def test_a_picture_another_slide_still_uses_is_kept(self):
        (copy,) = self.c.duplicate_deck_pages(self.deck, [self.ids()[0]])
        self.c.replace_deck_picture(self.deck, self.ids()[0], self.upload(("new.png", PNG)))
        self.assertTrue((self.media / self.paths[0]).exists())
        self.assertEqual(self.pages()[1]["image_path"], self.paths[0])

    def test_exactly_one_picture_is_needed(self):
        with self.assertRaises(ControllerError):
            self.c.replace_deck_picture(self.deck, self.ids()[0], self.upload(("a.png", PNG), ("b.png", PNG)))
        self.assertEqual(self.images(), self.paths)

    def test_a_live_deck_or_a_foreign_page_is_refused(self):
        other, _ = self.make_deck("Other", 2, "decks/bbb")
        with self.assertRaises(ControllerError):
            self.c.replace_deck_picture(self.deck, self.ids(other)[0], self.upload(("a.png", PNG)))
        self.go_live()
        with self.assertRaisesRegex(ControllerError, "live"):
            self.c.replace_deck_picture(self.deck, self.ids()[0], self.upload(("a.png", PNG)))
        self.assertEqual(self.images(), self.paths)


class CopyFromTests(Base):
    def setUp(self):
        super().setUp()
        self.other, self.other_paths = self.make_deck("Announcements", 3, "decks/bbb")

    def test_chosen_slides_are_copied_in_the_other_decks_order_with_notes(self):
        o1, o2, o3 = self.ids(self.other)
        self.c.set_deck_page_notes(self.other, o3, "last")
        a, b, c, d = self.ids()
        new = self.c.add_deck_pages_from(self.deck, self.other, [o3, o1], a)
        self.assertEqual(self.ids()[:1] + self.ids()[3:], [a, b, c, d][:1] + [b, c, d])
        self.assertEqual(self.ids()[1:3], new)
        self.assertEqual(self.images()[1:3], [self.other_paths[0], self.other_paths[2]])
        self.assertEqual([p["notes"] for p in self.pages()[1:3]], [None, "last"])
        self.assertEqual(len(self.ids(self.other)), 3)                    # the other deck is unchanged

    def test_the_other_deck_may_be_live_but_this_one_may_not(self):
        o1 = self.ids(self.other)[0]
        self.go_live(self.other)
        self.c.add_deck_pages_from(self.deck, self.other, [o1])
        self.assertEqual(len(self.ids()), 5)
        self.c.clear()
        self.go_live()
        with self.assertRaisesRegex(ControllerError, "live"):
            self.c.add_deck_pages_from(self.deck, self.other, [o1])

    def test_the_same_deck_or_a_wrong_slide_is_refused(self):
        with self.assertRaises(ControllerError):
            self.c.add_deck_pages_from(self.deck, self.deck, [self.ids()[0]])
        with self.assertRaises(ControllerError):
            self.c.add_deck_pages_from(self.deck, self.other, [self.ids()[0]])
        with self.assertRaises(ControllerError):
            self.c.add_deck_pages_from(self.deck, 9999, [1])
        self.assertEqual(len(self.ids()), 4)

    def test_deleting_the_other_deck_keeps_the_pictures_the_copy_uses(self):
        o1 = self.ids(self.other)[0]
        self.c.add_deck_pages_from(self.deck, self.other, [o1])
        self.c.delete_deck(self.other)
        self.assertTrue((self.media / self.other_paths[0]).exists())
        self.assertFalse((self.media / self.other_paths[1]).exists())


class SplitTests(Base):
    def test_a_new_deck_gets_the_chosen_slides_in_order_and_the_original_is_unchanged(self):
        a, b, c, d = self.ids()
        self.c.set_deck_page_notes(self.deck, c, "note")
        new = self.c.split_deck(self.deck, [d, c], " Part two ")
        self.assertEqual(self.db.get_presentation(new)["name"], "Part two")
        self.assertEqual(self.images(new), [self.paths[2], self.paths[3]])
        self.assertEqual([p["notes"] for p in self.pages(new)], ["note", None])
        self.assertEqual([p["page_number"] for p in self.pages(new)], [1, 2])
        self.assertEqual(self.images(), self.paths)

    def test_splitting_works_while_the_deck_is_live(self):
        self.go_live()
        self.c.split_deck(self.deck, [self.ids()[0]], "One slide")
        self.assertEqual(len(self.ids()), 4)

    def test_a_name_and_real_slides_are_needed(self):
        for args in (([self.ids()[0]], " "), ([], "x"), ([999], "x")):
            with self.assertRaises(ControllerError):
                self.c.split_deck(self.deck, *args)
        self.assertEqual(len(self.db.presentation_summaries()), 1)

    def test_deleting_the_original_keeps_what_the_new_deck_uses(self):
        new = self.c.split_deck(self.deck, [self.ids()[1]], "Mine")
        self.c.delete_deck(self.deck)
        self.assertTrue((self.media / self.paths[1]).exists())
        self.assertFalse((self.media / self.paths[0]).exists())
        self.assertEqual(self.images(new), [self.paths[1]])

    def test_importing_the_same_pictures_again_does_not_wipe_a_split_decks_files(self):
        folder = self.tmp / "slides"
        folder.mkdir()
        for n in (1, 2, 3):
            (folder / f"s{n}.png").write_bytes(PNG + bytes([n]))
        result = import_image_folder(self.db, folder, self.media, name="Imported")
        original = result.presentation_id
        new = self.c.split_deck(original, [self.ids(original)[0]], "Piece")
        kept = self.images(new)[0]
        self.c.delete_deck(original)
        self.assertTrue((self.media / kept).exists())
        again = import_image_folder(self.db, folder, self.media, name="Imported again")
        self.assertFalse(again.duplicate)
        self.assertTrue((self.media / kept).exists())
        self.assertTrue(all((self.media / p).exists() for p in self.images(again.presentation_id)))
        self.assertNotEqual(Path(self.images(again.presentation_id)[0]).parent, Path(kept).parent)


class ApiTests(Base):
    def test_the_actions_work_through_the_api(self):
        other, _ = self.make_deck("Other", 2, "decks/bbb")
        batch = self.api.call("import_batch")["batch"]
        data = PNG
        self.c.imports.save_upload(batch, "p.png", io.BytesIO(data), len(data), "slidepics")
        first = self.ids()[0]
        new = self.api.call("deck_pages_add", {"id": self.deck, "batch": batch, "after": first})["new"]
        self.assertEqual(self.ids()[1], new[0])
        batch = self.api.call("import_batch")["batch"]
        self.c.imports.save_upload(batch, "q.png", io.BytesIO(data), len(data), "slidepics")
        self.api.call("deck_page_replace", {"id": self.deck, "page": first, "batch": batch})
        self.assertTrue(self.images()[0].startswith("decks/added/"))
        got = self.api.call("deck_pages_from", {"id": self.deck, "source": other, "pages": self.ids(other)})["new"]
        self.assertEqual(len(got), 2)
        made = self.api.call("deck_split", {"id": self.deck, "pages": [first], "name": "Split"})["id"]
        self.assertEqual(len(self.ids(made)), 1)

    def test_bad_input_is_a_clear_error(self):
        with self.assertRaises(ApiError):
            self.api.call("deck_pages_add", {"id": self.deck})
        with self.assertRaises(ApiError):
            self.api.call("deck_split", {"id": self.deck, "pages": "x", "name": "n"})
        with self.assertRaises(ApiError):
            self.api.call("deck_pages_add", {"id": self.deck, "batch": "0" * 16})


if __name__ == "__main__":
    unittest.main()
