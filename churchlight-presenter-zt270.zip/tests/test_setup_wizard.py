# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The first-time setup guide: its facts (checks, done flag, practice service) and the page that walks through it."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui import setup
from churchlight_presenter.ui.controller import OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

OUTPUTS = [Output("projector", "projector"), Output("lower", "lower_third"), Output("stage", "stage")]


def empty():
    db = DatabaseManager(":memory:", shared=True)
    t = db.add_translation("KJV", "King James")
    db.add_verses(t, [("John", 3, 16, "For God so loved the world.")])
    c = OperatorController(db, OUTPUTS, translation="KJV")
    return db, c, OperatorApi(c)


class SetupFactsTests(unittest.TestCase):
    def test_an_empty_program_opens_the_guide_and_a_used_one_does_not(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        self.assertTrue(api.state()["setup"]["first_run"])
        c.create_song("S", "", "[Verse 1]\nline")
        self.assertFalse(api.state()["setup"]["first_run"])

    def test_finishing_or_skipping_it_is_remembered_and_can_be_undone(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        api.call("setup_done", {"value": True})
        self.assertFalse(api.state()["setup"]["first_run"])
        self.assertTrue(api.state()["setup"]["done"])
        api.call("setup_done", {"value": False})
        self.assertTrue(api.state()["setup"]["first_run"])

    def test_python_is_checked_by_version(self):
        from unittest import mock
        self.assertTrue(setup.python_check()["ok"])
        self.assertIn("is installed", setup.python_check()["detail"])
        with mock.patch.object(setup.sys, "version_info", (3, 8, 0, "final", 0)):
            check = setup.python_check()
        self.assertFalse(check["ok"])
        self.assertIn("python.org", check["detail"])

    def test_the_checks_are_plain_and_complete(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        checks = api.call("setup_checks")["checks"]
        self.assertEqual([x["id"] for x in checks], ["python", "browser", "pdf", "clicker", "bible", "folders"])
        for check in checks:
            self.assertIsInstance(check["ok"], bool)
            self.assertTrue(check["label"] and check["detail"])
        self.assertTrue(next(x for x in checks if x["id"] == "bible")["ok"])

    def test_no_bible_is_reported(self):
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        c = OperatorController(db, OUTPUTS)
        bible = next(x for x in setup.checks(c) if x["id"] == "bible")
        self.assertFalse(bible["ok"])

    def test_the_practice_service_has_a_song_and_a_verse_and_can_be_made_again(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        first = api.call("setup_practice")["id"]
        self.assertEqual(c.service_id, first)
        self.assertEqual(len(api.state()["items"]), 2)                       # the practice song and John 3:16
        second = api.call("setup_practice")["id"]
        self.assertNotEqual(first, second)
        titles = [s["title"] for s in c.services()]
        self.assertEqual(len(set(titles)), len(titles))
        self.assertEqual(db.conn.execute("SELECT COUNT(*) FROM songs").fetchone()[0], 1)     # one practice song only


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class SetupPageTests(unittest.TestCase):
    def open(self, c):
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 900})
        page.goto(server.url.rstrip("/") + "/operator")
        return page

    def test_the_guide_opens_on_a_new_program_walks_through_and_finishes(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        page = self.open(c)
        page.wait_for_selector("#wizard:not([hidden])")
        self.assertEqual(page.text_content("#wizard-title"), "Welcome to ChurchLight")
        self.assertIn("What you will need", page.text_content("#wizard-body"))
        self.assertEqual(page.locator("#wizard-body .wizard-need li").count(), 4)
        self.assertIn("OBS (or another broadcast software)", page.inner_text("#wizard-body"))
        self.assertTrue(page.is_hidden("#wizard-why"))
        self.assertTrue(page.is_hidden("#wizard-back"))
        self.assertIn("place this program window where it will be used to run the program during the church service", page.inner_text("#wizard-body"))
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Check this computer")
        self.assertTrue(page.is_visible("#wizard-why"))
        self.assertIn("ready for a service", page.inner_text("#wizard-why"))
        page.wait_for_selector(".wizard-check")
        self.assertGreaterEqual(page.locator(".wizard-check").count(), 6)
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Your church and screens")
        self.assertEqual(page.locator("#wizard-body select[aria-label='Screen shape of projector']").count(), 0)   # the shape comes from the monitor
        self.assertEqual(page.locator("text=Show it there").count(), 0)                   # no window of our own
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Set up OBS")
        values = page.eval_on_selector_all("#wizard-body .address-list input", "els => els.map(e => e.value)")
        self.assertEqual(len(values), 3)
        self.assertTrue(all("/view/" in v for v in values))
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Add your content")
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Look, clicker and Stream Deck")
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "You are ready")
        self.assertEqual(page.inner_text("#wizard-next"), "Finish")
        self.assertTrue(page.is_hidden("#wizard-skip"))
        page.click("#wizard-next")
        page.wait_for_selector("#wizard", state="hidden")
        self.assertTrue(api.state()["setup"]["done"])

    def test_a_church_with_only_a_livestream_gets_only_that_scene(self):
        from tests.fakeobs import FakeObs
        obs = FakeObs()
        self.addCleanup(obs.close)
        db, c, api = empty()
        self.addCleanup(db.close)
        page = self.open(c)
        page.wait_for_selector("#wizard:not([hidden])")
        for _ in range(2):
            page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Your church and screens")
        self.assertEqual(page.locator(".wizard-kinds").count(), 0)                 # the "what does your church use" choices are gone
        self.assertEqual(page.locator(".wizard-scenes > p").first.inner_text(), "What does your church use?")
        for label in ("Projector", "Stage", "Confidence monitor", "Home"):
            page.uncheck(f".wizard-scenes label:has-text('{label}:') input")
        ticks = page.eval_on_selector_all(".wizard-scenes input", "els => els.map(e => e.checked)")
        self.assertEqual(ticks, [False, True, False, False, False])
        self.assertEqual(page.locator("text=Which monitor shows each room screen").count(), 0)   # no room screens, no monitors
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Set up OBS")
        self.assertIn("Scenes it will make: Livestream", page.inner_text("#wizard-body"))
        page.fill("input[aria-label='OBS WebSocket port']", str(obs.port))
        page.click("text=Connect and make the scenes")
        page.wait_for_selector(".wizard-report li")
        self.assertEqual([s for s in obs.scenes if s.startswith("ChurchLight")], ["ChurchLight Livestream"])
        self.assertEqual(page.locator("text=Put the room screens on your monitors").count(), 0)   # nothing to project

    def _guide_with_monitors(self, monitors=None, confidence=False):
        from churchlight_presenter.ui.screenwindows import ScreenWindows
        from tests.test_screen_windows import MONITORS, Recorder
        db, c, api = empty()
        if confidence:
            c.outputs.append(Output("confidence", "confidence"))
        self.addCleanup(db.close)
        rec = Recorder()
        found = monitors or MONITORS
        c.screen_windows = ScreenWindows("/tmp/p", list_monitors=lambda: found, find_browser=lambda: ("Edge", "edge.exe"),
                                         popen=rec, platform="linux")
        page = self.open(c)
        page.wait_for_selector("#wizard:not([hidden])")
        for _ in range(2):
            page.click("#wizard-next")
        page.wait_for_selector("select[aria-label='Monitor for Projector (the room)']")
        return c, page, rec

    def test_the_monitor_chosen_in_the_guide_shows_its_name_and_the_real_screen_returns_when_the_step_ends(self):
        c, page, rec = self._guide_with_monitors()
        row = "#wizard-body .row:has(select[aria-label='Monitor for Projector (the room)'])"
        self.assertEqual(page.locator(row + " button").count(), 0)                  # no Test / Stop test any more
        page.select_option("select[aria-label='Monitor for Projector (the room)']", "1")
        page.wait_for_selector(row + " :text('Open on that monitor')")
        self.assertEqual(len(rec.made), 1)
        self.assertIn("--window-position=1920,0", rec.made[0].command)
        self.assertIn("/view/projector?kiosk=1&test=1&word=PROJECTOR", " ".join(rec.made[0].command))   # its name, big
        self.assertEqual(c._read_screens()["assign"], {"projector": 1})              # saved: it opens at every start
        page.click("#wizard-next")                                                  # moving on puts the real screen there
        page.wait_for_selector("text=Connect and make the scenes")
        end = __import__("time").time() + 5
        while __import__("time").time() < end and len(rec.made) < 2:
            page.wait_for_timeout(100)
        self.assertEqual(len(rec.made), 2)
        command = " ".join(rec.made[1].command)
        self.assertTrue("/view/projector?kiosk=1" in command and "test=1" not in command)
        self.assertIn("--window-position=1920,0", rec.made[1].command)
        self.assertFalse(rec.made[1].ended)

    def test_the_monitor_the_window_is_on_is_named_and_cannot_be_chosen(self):
        c, page, rec = self._guide_with_monitors()
        page.wait_for_selector(".wizard-here")
        self.assertIn("This program window is on Monitor 1 (main)", page.inner_text(".wizard-here"))
        select = "select[aria-label='Monitor for Projector (the room)']"
        self.assertTrue(page.eval_on_selector(select + " option[value='0']", "o => o.disabled"))
        self.assertFalse(page.eval_on_selector(select + " option[value='1']", "o => o.disabled"))
        self.assertEqual(rec.made, [])
        self.assertEqual(c._read_screens()["assign"], {})

    def test_stage_and_confidence_have_their_own_ticks_and_monitor_rows(self):
        c, page, rec = self._guide_with_monitors(confidence=True)
        ticks = page.eval_on_selector_all(".wizard-scenes label", "els => els.map(e => e.textContent.trim().split(':')[0])")
        self.assertIn("Stage", ticks)
        self.assertIn("Confidence monitor", ticks)
        self.assertEqual(page.locator("select[aria-label='Monitor for Confidence monitor']").count(), 1)
        page.uncheck(".wizard-scenes label:has-text('Confidence monitor') input")
        self.assertEqual(page.locator("select[aria-label='Monitor for Confidence monitor']").count(), 0)
        self.assertEqual(page.locator("select[aria-label='Monitor for Stage (singers and speaker)']").count(), 1)

    def test_a_monitor_chosen_earlier_is_still_chosen_when_the_guide_is_opened_again(self):
        c, page, rec = self._guide_with_monitors()
        page.select_option("select[aria-label='Monitor for Projector (the room)']", "1")
        page.wait_for_selector(":text('Open on that monitor')")
        page.reload()
        page.wait_for_selector("#wizard:not([hidden])")
        for _ in range(2):
            page.click("#wizard-next")
        page.wait_for_selector("select[aria-label='Monitor for Projector (the room)']")
        page.wait_for_timeout(800)                                              # the saved choice is loaded a moment after the list
        self.assertEqual(page.input_value("select[aria-label='Monitor for Projector (the room)']"), "1")

    def test_the_projector_shape_comes_from_the_monitor_chosen(self):
        from churchlight_presenter.core import monitors as monitor_list
        found = monitor_list.label([
            {"x": 0, "y": 0, "width": 1920, "height": 1080, "primary": True},
            {"x": 1920, "y": 0, "width": 1024, "height": 768, "primary": False}])
        c, page, rec = self._guide_with_monitors(found)
        self.assertEqual(c.screen_shape("projector"), "16:9")
        page.select_option("select[aria-label='Monitor for Projector (the room)']", "1")          # 1024 x 768
        page.wait_for_selector("text=set to 4:3")
        self.assertEqual(c.screen_shape("projector"), "4:3")

    def test_the_obs_step_makes_the_scenes_and_captures_the_screens_it_does_not_project(self):
        from tests.fakeobs import FakeObs
        obs = FakeObs(password="pw")
        self.addCleanup(obs.close)
        c, page, rec = self._guide_with_monitors()
        page.select_option("select[aria-label='Monitor for Projector (the room)']", "1")
        page.wait_for_selector(":text('Open on that monitor')")
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Set up OBS")
        page.fill("input[aria-label='OBS WebSocket port']", str(obs.port))
        page.fill("input[aria-label='OBS WebSocket password']", "wrong")
        page.click("text=Connect and make the scenes")
        import time
        end = time.time() + 5
        while time.time() < end and "password" not in (page.text_content("#wizard-body .wizard-obs .wizard-note") or "").lower():
            time.sleep(0.05)                                                  # "Talking to OBS..." comes first
        self.assertIn("password", page.text_content("#wizard-body .wizard-obs .wizard-note").lower())
        self.assertEqual([s for s in obs.scenes if s.startswith("ChurchLight")], [])
        page.fill("input[aria-label='OBS WebSocket password']", "pw")
        page.click("text=Connect and make the scenes")
        page.wait_for_selector(".wizard-report li")
        self.assertIn("ChurchLight Projector", obs.scenes)
        self.assertGreater(page.locator(".wizard-report li").count(), 3)
        self.assertEqual(obs.inputs["ChurchLight projector screen"]["kind"], "monitor_capture")
        browser = [n for n, v in obs.inputs.items() if v["kind"] == "browser_source"]
        self.assertEqual(len(browser), 1)
        self.assertTrue(browser[0].startswith("ChurchLight lower"))                      # the lower third; no other browser source
        self.assertEqual(page.locator("text=Put the room screens on your monitors").count(), 0)   # OBS no longer projects
        self.assertEqual(obs.projected, [])
        self.assertFalse(rec.made[-1].ended)

    def test_skip_is_remembered_so_it_does_not_come_back(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        page = self.open(c)
        page.wait_for_selector("#wizard:not([hidden])")
        page.click("#wizard-skip")
        page.wait_for_selector("#wizard", state="hidden")
        page.reload()
        page.wait_for_selector("#connection")
        page.wait_for_timeout(500)
        self.assertTrue(page.is_hidden("#wizard"))

    def test_escape_closes_it_without_marking_it_done_and_keys_do_nothing_meanwhile(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        page = self.open(c)
        page.wait_for_selector("#wizard:not([hidden])")
        page.keyboard.press("b")                                                  # the Blank key must not reach the screens
        self.assertFalse(c.session.state()["blank"] if isinstance(c.session.state(), dict) else c.session.state().blank)
        page.keyboard.press("Escape")
        page.wait_for_selector("#wizard", state="hidden")
        self.assertFalse(api.state()["setup"]["done"])

    def test_a_church_that_already_uses_it_is_not_greeted_and_can_open_it_from_settings(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        c.create_song("S", "", "[Verse 1]\nline")
        page = self.open(c)
        page.wait_for_selector("#connection")
        page.wait_for_timeout(500)
        self.assertTrue(page.is_hidden("#wizard"))
        page.click("#tab-shortcuts")
        page.click("#btn-run-setup")
        page.wait_for_selector("#wizard:not([hidden])")
        self.assertEqual(page.text_content("#wizard-title"), "Welcome to ChurchLight")

    def test_the_practice_button_makes_a_service_and_keeps_the_guide_open(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        page = self.open(c)
        page.wait_for_selector("#wizard:not([hidden])")
        for _ in range(4):
            page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Add your content")
        self.assertEqual(page.locator("#wizard-body >> text=Make a practice service").count(), 0)         # offered on the last step instead
        for _ in range(2):
            page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "You are ready")
        page.click("#wizard-body button:has-text(\"Make a practice service\")")
        page.wait_for_selector("text=A practice service is ready")
        self.assertFalse(page.is_hidden("#wizard"))
        self.assertEqual(len(api.state()["items"]), 2)


class SkipObsTests(unittest.TestCase):
    def test_i_dont_livestream_skips_the_obs_step_going_forward(self):
        db, c, api = empty()
        self.addCleanup(db.close)
        page = SetupPageTests.open(self, c)
        page.wait_for_selector("#wizard:not([hidden])")
        for _ in range(3):
            page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Set up OBS")
        page.check(".wizard-skip-obs input")
        self.assertEqual(page.locator("#wizard-body .wizard-obs").count(), 0)          # the OBS form is gone
        self.assertIn("OBS connection is skipped", page.inner_text("#wizard-body"))
        page.click("#wizard-back")
        page.click("#wizard-next")                                                     # forward from screens: past OBS
        self.assertEqual(page.text_content("#wizard-title"), "Add your content")
        page.click("#wizard-back")                                                     # back still lands on OBS so it can be undone
        self.assertEqual(page.text_content("#wizard-title"), "Set up OBS")
        page.uncheck(".wizard-skip-obs input")
        self.assertGreater(page.locator("#wizard-body .wizard-obs").count(), 0)


class WhyLineTests(unittest.TestCase):
    def test_every_step_after_welcome_has_a_why_line_in_the_source(self):
        import pathlib, re
        js = (pathlib.Path(__file__).parent.parent / "churchlight_presenter/server/static/wizard.js").read_text(encoding="utf-8")
        block = js[js.index("const WIZARD_WHY"):js.index("function drawWizard() {")]
        for step in ("computer", "screens", "obs", "content", "extras"):
            self.assertRegex(block, step + r': "[^"]{20,}"')


class RevisedStepsTests(unittest.TestCase):
    def _walk(self, steps):
        db, c, api = empty()
        self.addCleanup(db.close)
        page = SetupPageTests.open(self, c)
        page.wait_for_selector("#wizard:not([hidden])")
        for _ in range(steps):
            page.click("#wizard-next")
        return page

    def test_step_4_explains_what_the_addresses_are_for(self):
        page = self._walk(3)
        self.assertEqual(page.text_content("#wizard-title"), "Set up OBS")
        body = page.inner_text("#wizard-body")
        self.assertIn("What your broadcast software needs", body)
        self.assertIn("Tested issue in XSplit", body)
        self.assertIn("did not match the Windows numbers", body)
        self.assertIn("Look at the picture in the scene preview", body)
        values = page.eval_on_selector_all("#wizard-body > .address-list input", "els => els.map(e => e.value)")
        self.assertEqual(len(values), 1)                                                # only the lower third is shown up front
        self.assertIn("lower", values[0])
        fold = page.locator("details.wizard-manual")
        self.assertIsNone(fold.get_attribute("open"))                                   # the other addresses are folded
        others = page.eval_on_selector_all("details.wizard-manual .address-list input", "els => els.map(e => e.value)")
        self.assertEqual(len(others), 2)
        self.assertTrue(all("lower" not in v for v in others))
        self.assertFalse(page.is_checked("text=Remember the OBS password on this computer"))

    def test_step_3_has_recommendations_and_no_obs_wording(self):
        page = self._walk(2)
        self.assertEqual(page.text_content("#wizard-title"), "Your church and screens")
        body = page.inner_text("#wizard-body")
        self.assertNotIn("OBS", body.replace("Livestream", ""))                           # nothing about OBS here any more
        self.assertIn("Recommended", body)
        self.assertIn("Optional: only if you have a screen for them", body)

    def test_home_picture_is_at_the_top_of_the_content_step(self):
        page = self._walk(4)
        self.assertEqual(page.text_content("#wizard-title"), "Add your content")
        first = page.eval_on_selector("#wizard-body .wizard-add strong", "e => e.textContent")
        self.assertEqual(first, "Home screen picture")
        page.click("#wizard-next")
        self.assertEqual(page.text_content("#wizard-title"), "Look, clicker and Stream Deck")
        self.assertNotIn("Home screen picture", page.inner_text("#wizard-body"))

    def test_the_window_keeps_its_size_and_the_buttons_their_places(self):
        page = self._walk(0)
        seen = []
        for _ in range(6):
            box = page.eval_on_selector("#wizard", "e => { const r = e.getBoundingClientRect(); return [r.width, r.height]; }")
            nxt = page.eval_on_selector("#wizard-next", "e => { const r = e.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top)]; }")
            seen.append((box, nxt))
            page.click("#wizard-next")
            page.wait_for_timeout(100)
        self.assertEqual(len({tuple(map(round, b)) for b, _ in seen}), 1)               # same window size on every step
        self.assertEqual(len({tuple(n) for _, n in seen}), 1)                           # Next never moves (Start/Next labels included)
