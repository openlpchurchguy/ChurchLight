# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Slides in the service drop-downs are whole-line buttons: no little Go buttons, one row each, the mouse and keyboard both work."""
import time
import unittest
from pathlib import Path

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


def until(check, seconds=8):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


class SourceTests(unittest.TestCase):
    def test_no_per_line_go_buttons_are_left(self):
        js = (STATIC / "operator.js").read_text(encoding="utf-8")
        self.assertNotIn('"go-slide"', js)
        self.assertEqual(js.count("slideBar("), 5)                  # the helper and its users: songs, a song's title slide, passages, slideshows
        css = (STATIC / "operator.css").read_text(encoding="utf-8")
        self.assertNotIn(".go-slide", css)

    def test_the_item_level_go_button_stays(self):
        js = (STATIC / "operator.js").read_text(encoding="utf-8")
        self.assertIn('el("button", "primary item-go", "Go")', js)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def test_a_slideshow_line_is_a_full_width_button_that_shows_the_slide(self):
        db, c, api = make()
        self.addCleanup(db.close)
        deck = next(e for e in c.search_library("Deck") if e.kind == "presentation")
        c.new_service("Sunday")
        c.add_entry(deck)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector(".item-options", state="attached")
        page.click("button.more")
        page.wait_for_selector(".deck-slide-list .slide-bar")
        self.assertEqual(page.locator(".go-slide").count(), 0)
        bar = page.locator(".deck-slide-list .slide-bar").nth(1)
        box = bar.bounding_box()
        row = page.locator(".deck-slide-list li").nth(1).bounding_box()
        self.assertGreaterEqual(box["width"], row["width"] - 2)          # the bar fills the whole line
        self.assertGreaterEqual(box["height"], 30)
        bar.focus()
        page.keyboard.press("Enter")                                      # the keyboard works too
        self.assertTrue(until(lambda: c.session.state().base_index == 1))
        self.assertTrue(until(lambda: page.locator(".deck-slide-list li.slide-live").count() == 1))
        self.assertEqual(page.locator(".deck-slide-list li.slide-live .slide-mark").inner_text(), "▶")


if __name__ == "__main__":
    unittest.main()
