# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Replace from a PDF, on the slideshow editor page."""
import time
import unittest

from tests.test_deck_replace import ReplaceBase, png
from tests.test_decks import make_pdf

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


def until(check, seconds=30):
    end = time.time() + seconds
    while time.time() < end:
        try:
            if check():
                return True
        except Exception:
            pass
        time.sleep(0.1)
    return False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class EditorTests(ReplaceBase):
    def open_editor(self):
        server = self.c.serve(media_root=self.media)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.evaluate("showView('decks')")
        page.wait_for_selector("text=Edit slideshow")
        page.click("text=Edit slideshow >> nth=0")
        page.wait_for_selector("#de-pdf", state="attached")
        return page

    def test_choose_a_pdf_read_the_summary_and_apply(self):
        pdf = self.tmp / "new.pdf"
        make_pdf(pdf, 6)
        page = self.open_editor()
        self.assertTrue(until(lambda: page.is_enabled("#de-pdf")))          # enabled once the slideshow has loaded
        page.set_input_files("#de-pdf-file", str(pdf))
        self.assertTrue(until(lambda: page.is_visible("#de-pdfpanel")))
        summary = page.inner_text("#de-pdf-summary")
        self.assertIn("2 new pages will be added at the end.", summary)
        self.assertIn("Slides 1–4 are checked", summary)
        self.assertFalse(page.is_visible("#de-pdf-extra-line"))           # nothing to remove: the PDF is longer
        page.click("#de-pdf-apply")
        self.assertTrue(until(lambda: len(self.pages()) == 6))
        self.assertEqual(self.pages()[1]["title"], "Offering")
        self.assertTrue(until(lambda: not page.is_visible("#de-pdfpanel")))
        self.assertEqual(len(self.db.search_presentation()), 1)           # the temporary slideshow is gone

    def test_each_different_slide_can_be_kept_and_the_identical_ones_have_their_own_choice(self):
        pdf = self.tmp / "new.pdf"
        make_pdf(pdf, 4)
        page = self.open_editor()
        page.set_input_files("#de-pdf-file", str(pdf))
        self.assertTrue(until(lambda: page.is_visible("#de-pdfpanel")))
        self.assertEqual(page.locator("#de-pdf-list li").count(), 4)          # the fixture pictures all differ from the rendered pages
        self.assertFalse(page.is_visible("#de-pdf-same-line"))                # nothing looks identical here
        before = self.images()
        page.check("input[name=de-pdf-slide-2][value=keep]")
        page.check("input[name=de-pdf-slide-3][value=keep]")
        page.click("#de-pdf-apply")
        self.assertTrue(until(lambda: not page.is_visible("#de-pdfpanel")))
        after = self.images()
        self.assertEqual((after[1], after[2]), (before[1], before[2]))        # kept
        self.assertNotEqual((after[0], after[3]), (before[0], before[3]))     # changed
        page.wait_for_selector("text=Replaced 1, 4")

    def test_keep_all_and_change_all(self):
        pdf = self.tmp / "new.pdf"
        make_pdf(pdf, 4)
        page = self.open_editor()
        page.set_input_files("#de-pdf-file", str(pdf))
        self.assertTrue(until(lambda: page.is_visible("#de-pdfpanel")))
        page.click("#de-pdf-keep-all")
        self.assertEqual(page.locator("#de-pdf-list input[value=keep]:checked").count(), 4)
        page.click("#de-pdf-change-all")
        self.assertEqual(page.locator("#de-pdf-list input[value=change]:checked").count(), 4)

    def test_cancel_changes_nothing_and_a_shorter_pdf_offers_to_remove_the_rest(self):
        pdf = self.tmp / "short.pdf"
        make_pdf(pdf, 2)
        before = self.images()
        page = self.open_editor()
        page.set_input_files("#de-pdf-file", str(pdf))
        self.assertTrue(until(lambda: page.is_visible("#de-pdfpanel")))
        self.assertTrue(page.is_visible("#de-pdf-extra-line"))
        self.assertIn("3–4", page.inner_text("#de-pdf-extra-text"))
        page.click("#de-pdf-cancel")
        self.assertTrue(until(lambda: not page.is_visible("#de-pdfpanel")))
        self.assertTrue(until(lambda: len(self.db.search_presentation()) == 1))
        self.assertEqual(self.images(), before)


if __name__ == "__main__":
    unittest.main()
