# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Add to the Media Library (copy chosen slide pictures), the tidied slideshow editor toolbar, and video pages in a slideshow."""
import time
import unittest

from churchlight_presenter.core import export
from churchlight_presenter.core.outputs import build_payload
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry
from tests.test_media_playback import MP4, Base
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100


def until(check, seconds=8):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.1)
    return False


class CopyTests(Base):
    def setUp(self):
        super().setUp()
        folder = self.tmp / "media" / "decks"
        folder.mkdir(parents=True)
        for name in ("a.png", "b.png", "c.png"):
            (folder / name).write_bytes(PNG)
        self.deck = self.db.add_presentation("Easter", [("decks/a.png", None), ("decks/b.png", None, "Welcome"), ("decks/c.png", None)])
        self.pages = [p["id"] for p in self.db.get_presentation_pages(self.deck)]

    def names(self):
        return sorted(r["name"] for r in self.c.media_list())

    def test_each_chosen_slide_becomes_a_picture_in_the_library_and_the_slideshow_is_unchanged(self):
        result = self.c.copy_slides_to_media(self.deck, [self.pages[0], self.pages[1]])
        self.assertEqual((len(result["added"]), result["skipped"]), (2, 0))
        self.assertEqual(self.names(), ["Easter - slide 1", "Welcome"])
        for media_id in result["added"]:
            asset = self.db.get_media_asset(media_id)
            self.assertEqual(asset["media_type"], "image")
            self.assertTrue((self.tmp / "media" / asset["path"]).is_file())
        self.assertEqual([p["image_path"] for p in self.db.get_presentation_pages(self.deck)], ["decks/a.png", "decks/b.png", "decks/c.png"])

    def test_the_same_slide_copied_twice_gets_a_numbered_name(self):
        self.c.copy_slides_to_media(self.deck, [self.pages[0]])
        self.c.copy_slides_to_media(self.deck, [self.pages[0]])
        self.assertEqual(self.names(), ["Easter - slide 1", "Easter - slide 1 (2)"])

    def test_deleting_the_copy_leaves_the_slideshow_picture(self):
        (media_id,) = self.c.copy_slides_to_media(self.deck, [self.pages[0]])["added"]
        self.c.delete_media(media_id)
        self.assertTrue((self.tmp / "media" / "decks" / "a.png").is_file())

    def test_it_works_while_the_slideshow_is_live(self):
        self.c.new_service("Sunday")
        item = self.c.add_entry(LibraryEntry("presentation", self.deck, ""))
        self.c.go_live_service_item(item)
        self.assertEqual(len(self.c.copy_slides_to_media(self.deck, [self.pages[2]])["added"]), 1)

    def test_a_video_slide_is_skipped_because_it_is_already_a_library_file(self):
        video = self.add("Welcome.mp4", MP4, 20)
        (clip,) = self.c.add_deck_library(self.deck, [video])
        result = self.c.copy_slides_to_media(self.deck, [clip, self.pages[0]])
        self.assertEqual((len(result["added"]), result["skipped"]), (1, 1))
        with self.assertRaises(ControllerError) as caught:
            self.c.copy_slides_to_media(self.deck, [clip])
        self.assertIn("already", str(caught.exception))

    def test_wrong_slides_and_missing_pictures_are_refused_plainly(self):
        with self.assertRaises(ControllerError):
            self.c.copy_slides_to_media(self.deck, [99999])
        (self.tmp / "media" / "decks" / "a.png").unlink()
        with self.assertRaises(ControllerError) as caught:
            self.c.copy_slides_to_media(self.deck, [self.pages[0]])
        self.assertIn("slide 1", str(caught.exception))
        self.assertEqual(self.names(), [])


class VideoPageTests(Base):
    def setUp(self):
        super().setUp()
        self.video = self.add("Welcome.mp4", MP4, 20)
        self.deck = self.db.add_presentation("Notices", [("decks/a.png", None)])
        self.c.add_deck_library(self.deck, [self.video])
        self.c.new_service("Sunday")
        self.item = self.c.add_entry(LibraryEntry("presentation", self.deck, ""))
        self.c.go_live_service_item(self.item)
        self.c.go_to_slide(1)

    def test_only_the_projector_gets_the_video_and_the_other_screens_get_no_clip(self):
        state = self.c.session.state()
        for out in self.c.outputs:
            payload = build_payload(state, out)
            self.assertEqual("media" in payload, out.layout == "projector", out.name)

    def test_back_and_next_move_off_the_video_and_stop_it(self):
        self.c.go_to_slide(0)
        self.assertIsNone(self.c.session.state().media)

    def test_a_slideshow_with_a_video_cannot_be_exported_yet_and_says_so(self):
        with self.assertRaises(export.ExportError) as caught:
            export.slideshow_snapshot(self.db, [self.deck])
        self.assertIn("video", str(caught.exception))

    def test_a_video_used_in_a_slideshow_cannot_be_deleted(self):
        with self.assertRaises(ControllerError) as caught:
            self.c.delete_media(self.video)
        self.assertIn("slideshow", str(caught.exception))


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class ToolbarTests(unittest.TestCase):
    def setUp(self):
        db, c, api = make()
        self.addCleanup(db.close)
        self.c = c
        self.deck = db.add_presentation("Easter", [("decks/a.png", None), ("decks/b.png", None)])
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1400, "height": 1000})
        self.page.goto(server.url.rstrip("/") + "/operator")
        try:
            self.page.wait_for_selector("#wizard:not([hidden])", timeout=3000)
            self.page.evaluate("wizardHide()")
        except Exception:
            pass
        self.page.evaluate(f"openDeckEditor({self.deck})")
        self.page.wait_for_selector("#de-grid .de-card")

    def test_the_selection_bar_says_what_is_selected_and_shows_the_buttons(self):
        page = self.page
        for ident in ("de-left", "de-right", "de-duplicate", "de-skip", "de-tomedia", "de-split-open", "de-delete"):
            self.assertTrue(page.is_visible("#" + ident), ident)
        page.evaluate("deckEdit.selected = []; drawDeckEditor()")
        self.assertIn("none yet", page.inner_text("#de-sel-label"))
        self.assertFalse(page.evaluate("$('de-selbar').classList.contains('active')"))
        self.assertTrue(page.is_disabled("#de-tomedia"))
        page.click("#de-all")
        self.assertTrue(until(lambda: "2 slides selected" in page.inner_text("#de-sel-label")))
        self.assertTrue(page.evaluate("$('de-selbar').classList.contains('active')"))
        self.assertEqual(page.get_attribute("#de-left", "aria-label"), "Move earlier")

    def test_the_menus_open_choose_and_close(self):
        page = self.page
        self.assertFalse(page.is_visible("#de-library-open"))
        page.click("#de-menu-from > summary")
        self.assertTrue(page.is_visible("#de-library-open") and page.is_visible("#de-from-open"))
        page.click("#de-menu-replace > summary")                    # outside click closes the first menu
        self.assertTrue(until(lambda: not page.is_visible("#de-library-open")))
        self.assertTrue(page.is_visible("#de-pdf"))
        page.keyboard.press("Escape")
        self.assertTrue(until(lambda: not page.is_visible("#de-pdf")))
        page.click("#de-menu-from > summary")
        page.click("#de-library-open")
        self.assertFalse(page.is_visible("#de-from-open"))          # choosing closes the menu

    def test_the_toolbar_wraps_at_a_narrow_width(self):
        page = self.page
        page.set_viewport_size({"width": 700, "height": 900})
        self.assertFalse(page.evaluate("document.documentElement.scrollWidth > window.innerWidth"))
        for ident in ("de-delete", "de-tomedia", "de-add"):
            box = page.locator("#" + ident).bounding_box()
            self.assertLessEqual(box["x"] + box["width"], 702, ident)

    def test_add_to_the_media_library_shows_a_notice(self):
        page = self.page
        import tempfile
        from pathlib import Path
        self.c.media_root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, self.c.media_root, True)
        folder = self.c.media_root / "decks"
        folder.mkdir(parents=True, exist_ok=True)
        for name in ("a.png", "b.png"):
            (folder / name).write_bytes(PNG)
        page.click("#de-all")
        page.click("#de-tomedia")
        self.assertTrue(until(lambda: "Added 2 pictures to the Media Library" in page.inner_text("#message-text")))
        self.assertEqual(len(self.c.media_list()), 2)


if __name__ == "__main__":
    unittest.main()
