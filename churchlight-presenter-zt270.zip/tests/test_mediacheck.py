# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Videos are looked at before they are accepted; a video already in the library that a screen cannot play is told to the operator."""
import io
import shutil
import struct
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.mediacheck import check_video, inspect_mp4
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry, OperatorController
from churchlight_presenter.ui.operator_api import OperatorApi


def box(kind, body=b""):
    return struct.pack(">I4s", 8 + len(body), kind) + body


def video_track(entry=b"avc1", profile=100, width=1280, height=720, fps=30, seconds=10):
    avcc = box(b"avcC", bytes([1, profile, 0, 31]) + b"\x00" * 4) if entry in (b"avc1", b"avc3") else b""
    sample = b"\x00" * 6 + b"\x00\x01" + b"\x00" * 16 + struct.pack(">HH", width, height) + b"\x00" * 50 + avcc
    sample = box(entry, sample)
    stsd = box(b"stsd", b"\x00" * 4 + struct.pack(">I", 1) + sample)
    count = int(fps * seconds)
    stsz = box(b"stsz", struct.pack(">IIII", 0, 0, count, 0))
    mdhd = box(b"mdhd", struct.pack(">IIIII", 0, 0, 0, 1000, seconds * 1000) + b"\x00" * 4)
    hdlr = box(b"hdlr", b"\x00" * 8 + b"vide" + b"\x00" * 12)
    return box(b"trak", box(b"mdia", mdhd + hdlr + box(b"minf", box(b"stbl", stsd + stsz))))


def sound_track(entry=b"mp4a"):
    stsd = box(b"stsd", b"\x00" * 4 + struct.pack(">I", 1) + box(entry, b"\x00" * 28))
    hdlr = box(b"hdlr", b"\x00" * 8 + b"soun" + b"\x00" * 12)
    return box(b"trak", box(b"mdia", hdlr + box(b"minf", box(b"stbl", stsd))))


def mp4(*tracks, moov_first=True):
    ftyp = box(b"ftyp", b"isom\x00\x00\x02\x00isomiso2")
    moov = box(b"moov", b"".join(tracks))
    mdat = box(b"mdat", b"\x00" * 64)
    return ftyp + (moov + mdat if moov_first else mdat + moov)


class CheckTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def check(self, data):
        path = self.tmp / "v.mp4"
        path.write_bytes(data)
        return check_video(path)

    def test_a_normal_h264_video_with_aac_sound_passes_clean(self):
        for first in (True, False):
            self.assertEqual(self.check(mp4(video_track(), sound_track(), moov_first=first)), (None, []))

    def test_other_playable_and_unreadable_files_pass(self):
        self.assertEqual(self.check(mp4(video_track(b"vp09"), sound_track(b"Opus")))[0], None)
        self.assertEqual(self.check(b"")[0], None)
        self.assertEqual(self.check(b"\x00\x00\x00\x18ftypisom" + b"\x00" * 16)[0], None)
        self.assertIsNone(inspect_mp4(self.tmp / "missing.mp4"))

    def test_formats_that_cannot_be_shown_are_refused_with_the_fix(self):
        for entry, word in ((b"hvc1", "H.265"), (b"av01", "AV1"), (b"apch", "ProRes"), (b"mp4v", "MPEG-4")):
            problem, _ = self.check(mp4(video_track(entry), sound_track()))
            self.assertIn(word, problem)
            self.assertIn("HandBrake", problem)
            self.assertIn("Fast 1080p30", problem)

    def test_ten_bit_h264_is_refused(self):
        problem, _ = self.check(mp4(video_track(profile=110)))
        self.assertIn("10-bit", problem)
        self.assertIn("HandBrake", problem)

    def test_sound_browsers_cannot_play_is_refused(self):
        problem, _ = self.check(mp4(video_track(), sound_track(b"ac-3")))
        self.assertIn("Dolby AC-3", problem)

    def test_no_picture_is_refused(self):
        self.assertIn("no picture", self.check(mp4(sound_track()))[0])

    def test_big_or_fast_videos_are_accepted_with_a_warning(self):
        problem, warnings = self.check(mp4(video_track(width=3840, height=2160, fps=60), sound_track()))
        self.assertIsNone(problem)
        self.assertEqual(len(warnings), 2)
        self.assertIn("3840×2160", warnings[0])
        self.assertIn("60 frames", warnings[1])

    def test_a_very_heavy_video_is_warned_about_and_described(self):
        from churchlight_presenter.core.mediacheck import describe_video
        path = self.tmp / "heavy.mp4"
        path.write_bytes(mp4(video_track(width=1920, height=1080, fps=30), sound_track()) + b"\x00" * 5_000_000)
        problem, warnings = check_video(path, 1.0)                  # about 40 Mbit/s
        self.assertIsNone(problem)
        self.assertTrue(any("Mbit/s" in w for w in warnings))
        self.assertEqual(check_video(path, 60)[1], [])               # the same file spread over a minute is light
        self.assertEqual(check_video(path)[1], [])                    # length unknown: nothing to judge
        self.assertEqual(describe_video(path, 1.0), "1920×1080 · 30 fps · H.264 · 40 Mbit/s")
        self.assertEqual(describe_video(self.tmp / "missing.mp4"), "")


class ProgramTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, media_root=self.tmp / "media")
        self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        self.api = OperatorApi(self.c)

    def upload(self, name, data):
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, name, io.BytesIO(data), len(data), "media")
        return batch

    def test_a_refused_video_says_its_name_and_the_fix(self):
        with self.assertRaises(ControllerError) as error:
            self.c.add_media_file(self.upload("Phone.mp4", mp4(video_track(b"hvc1"))), 5)
        self.assertIn("Phone.mp4", str(error.exception))
        self.assertIn("HandBrake", str(error.exception))
        self.assertEqual(self.c.media_list(), [])

    def test_a_warning_comes_back_with_the_added_video(self):
        batch = self.upload("Big.mp4", mp4(video_track(width=3840, height=2160), sound_track()))
        reply = self.api.call("media_add", {"batch": batch, "duration": 10})
        self.assertIn("id", reply)
        self.assertIn("Big.mp4", reply["warning"])
        batch = self.upload("Fine.mp4", mp4(video_track(), sound_track()))
        self.assertNotIn("warning", self.api.call("media_add", {"batch": batch, "duration": 10}))

    def test_a_screen_that_cannot_play_the_live_video_is_shown_to_the_operator_until_it_is_cleared(self):
        media_id = self.c.add_media_file(self.upload("Odd.mp4", mp4(video_track(), sound_track())), 10)
        self.assertIsNone(self.c.media_view()["problem"])
        self.c.go_live_entry(LibraryEntry("media", media_id, ""))
        live = self.c.media_view()["live"]
        self.assertIsNotNone(live)
        self.api.call("clip_problem", {"src": "media/somethingelse.mp4", "output": "projector"})      # not the live file: ignored
        self.assertIsNone(self.c.media_view()["problem"])
        self.api.call("clip_problem", {"src": live["src"], "output": "projector"})
        problem = self.c.media_view()["problem"]
        self.assertIn("projector", problem)
        self.assertIn("Odd", problem)
        self.assertIn("HandBrake", problem)
        self.assertIn("looks like the right kind", problem)                   # the file itself is fine: not blamed for being the wrong format
        self.api.call("clip_problem", {"src": live["src"], "output": "stage"})                     # a second report changes nothing
        self.assertEqual(self.c.media_view()["problem"], problem)
        self.c.clear()
        self.assertIsNone(self.c.media_view()["problem"])


if __name__ == "__main__":
    unittest.main()

    def test_a_file_that_really_is_the_wrong_format_is_told_so(self):
        media_id = self.c.add_media_file(self.upload("Phone.mp4", mp4(video_track(), sound_track())), 10)
        path = Path(self.c.media_root) / self.c.media_list()[0]["path"]
        path.write_bytes(mp4(video_track(b"hvc1"), sound_track()))                 # turned out to be H.265 after all
        self.c.go_live_entry(LibraryEntry("media", media_id, ""))
        self.api.call("clip_problem", {"src": self.c.media_view()["live"]["src"], "output": "projector"})
        self.assertIn("format browsers, OBS and XSplit cannot show", self.c.media_view()["problem"])

    def test_the_screen_page_reports_only_a_failed_decode_or_a_video_that_never_started(self):
        js = (Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "output.js").read_text(encoding="utf-8")
        self.assertIn("if (code === 3 || code === 4) reportClipProblem", js)            # not a stop or a dropped network read
        self.assertIn("if (held.hasPlayed || !held.view.playing)", js)                   # a video that has played then waits (after a jump) is not a problem


class LibraryFlagTests(ProgramTests):
    def test_a_video_that_may_stutter_or_cannot_play_stays_flagged_in_the_library(self):
        self.c.add_media_file(self.upload("Big.mp4", mp4(video_track(width=3840, height=2160), sound_track())), 10)
        self.c.add_media_file(self.upload("Fine.mp4", mp4(video_track(), sound_track())), 10)
        flags = {m["name"]: m.get("flag") for m in self.c.media_list()}
        self.assertEqual(flags["Big"]["level"], "warning")
        self.assertIn("3840", flags["Big"]["text"])
        self.assertIsNone(flags["Fine"])
        self.assertEqual({m["name"]: m.get("flag") for m in self.c.media_list()}["Big"], flags["Big"])      # remembered, same answer
        self.assertEqual({m["name"]: m.get("spec") for m in self.c.media_list()}["Fine"][:9], "1280×720 ")
        # a file that was fine at import and later turns out to be a problem (an old library, a copied file)
        path = Path(self.c.media_root) / [m for m in self.c.media_list() if m["name"] == "Fine"][0]["path"]
        path.write_bytes(mp4(video_track(b"hvc1"), sound_track()))
        flag = {m["name"]: m.get("flag") for m in self.c.media_list()}["Fine"]
        self.assertEqual(flag["level"], "problem")
        self.assertIn("HandBrake", flag["text"])
