# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The text-area margins: validation, the output page's padding, the line-room formula and the guide box maths."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.themes import projector_char_capacity, safe_style, validate_style

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
NODE = shutil.which("node")


def node(script):
    out = subprocess.run([NODE, "-e", script], capture_output=True, text=True, check=True).stdout
    return json.loads(out)


class MarginValidationTests(unittest.TestCase):
    def test_margins_are_numbers_within_range(self):
        self.assertEqual(validate_style({"margin_left": 10, "margin_top": 2.5})["margin_left"], 10.0)
        for bad in ({"margin_left": 50}, {"margin_top": -1}, {"margin_right": "a"}, {"margin_bottom": True}):
            with self.assertRaises(ValueError):
                validate_style(bad)

    def test_margins_that_leave_no_room_for_text_are_refused_when_saving(self):
        with self.assertRaises(ValueError):
            validate_style({"margin_left": 45, "margin_right": 45})
        with self.assertRaises(ValueError):
            validate_style({"margin_top": 40, "margin_bottom": 41})

    def test_a_damaged_stored_style_loses_only_its_margins(self):
        style = safe_style({"margin_left": 45, "margin_right": 45, "margin_top": 5, "font_size": 6})
        self.assertEqual(style, {"font_size": 6.0})
        self.assertEqual(safe_style({"margin_left": 20, "margin_right": 20})["margin_left"], 20.0)

    def test_wider_margins_hold_less_text_per_slide(self):
        self.assertLess(projector_char_capacity({"margin_left": 20, "margin_right": 20}), projector_char_capacity({}))
        self.assertLess(projector_char_capacity({"margin_top": 20, "margin_bottom": 20}), projector_char_capacity({}))
        self.assertEqual(projector_char_capacity({"margin_top": 4, "margin_bottom": 4, "margin_left": 6, "margin_right": 6}),
                         projector_char_capacity({}))


@unittest.skipUnless(NODE, "node not installed")
class PageTests(unittest.TestCase):
    def test_the_output_page_pads_the_text_by_the_themes_margins(self):
        got = node("const o=require(%s);console.log(JSON.stringify([o.textMargins({}),"
                   "o.textMargins({margin_left:10}),o.styleToCss({margin_top:1,margin_bottom:2,margin_left:3,margin_right:4},'full')"
                   ".filter(x=>x[0]==='padding'),o.styleToCss({margin_left:10},'lower').filter(x=>x[0]==='padding')]))"
                   % json.dumps(str(STATIC / "output.js")))
        self.assertEqual(got, [None, "4vh 6vw 4vh 10vw", [["padding", "1vh 4vw 2vh 3vw"]], []])

    def test_a_slide_picture_is_never_padded_by_the_themes_margins(self):
        got = node("const o=require(%s);console.log(JSON.stringify([o.styleToCss({margin_top:4,margin_left:6},'full',true)"
                   ".filter(x=>x[0]==='padding'),o.styleToCss({margin_top:4,margin_left:6},'full',false)"
                   ".filter(x=>x[0]==='padding')]))" % json.dumps(str(STATIC / "output.js")))
        self.assertEqual(got, [[], [["padding", "4vh 6vw 4vh 6vw"]]])

    def test_the_theme_builder_and_python_agree_on_room_with_margins(self):
        styles = [{"margin_left": 15, "margin_right": 10}, {"margin_top": 10, "margin_bottom": 12, "font_size": 6},
                  {"margin_left": 0, "margin_right": 0, "margin_top": 0, "margin_bottom": 0, "band": True}]
        got = node("const t=require(%s);console.log(JSON.stringify(%s.map(s=>t.projectorLayout(s).chars)))"
                   % (json.dumps(str(STATIC / "themes.js")), json.dumps(styles)))
        self.assertEqual(got, [projector_char_capacity(s) for s in styles])

    def test_the_projector_guide_is_the_four_margins_and_dragging_sets_them(self):
        got = node("""const t=require(%s);
          const s={margin_left:10,margin_right:6,margin_top:4,margin_bottom:8};
          console.log(JSON.stringify([t.guideRect('projector',s),
            t.dragGuide('projector',s,'left',0.2), t.dragGuide('projector',s,'right',0.9),
            t.dragGuide('projector',s,'top',0.123), t.dragGuide('projector',s,'bottom',0.5),
            t.dragGuide('projector',{margin_left:20,margin_right:50},'left',0.9)]))""" % json.dumps(str(STATIC / "themes.js")))
        rect, left, right, top, bottom, clamped = got
        self.assertEqual(rect, {"left": 0.1, "top": 0.04, "right": 0.94, "bottom": 0.92})
        self.assertEqual((left, right, top, bottom), ({"margin_left": 20}, {"margin_right": 10}, {"margin_top": 12.5}, {"margin_bottom": 40}))
        self.assertEqual(clamped, {"margin_left": 30})        # left + right may not leave less than 20% for the text

    def test_the_overlay_guide_follows_its_position_and_dragging_resizes_or_moves_it(self):
        got = node("""const t=require(%s);
          const s={h_pos:'left',v_pos:'bottom',box_width:60,margin:4,max_height:0};
          const r=t.guideRect('overlay',s,0.2);
          console.log(JSON.stringify([r,
            t.dragGuide('overlay',s,'right',0.8,0.2),     // far edge: width
            t.dragGuide('overlay',s,'left',0.1,0.2),      // anchored edge: the gap
            t.dragGuide('overlay',s,'top',0.5,0.2),       // far edge: height cap
            t.dragGuide('overlay',s,'bottom',0.9,0.2),    // anchored edge: the gap
            t.dragGuide('overlay',{h_pos:'center',v_pos:'bottom',box_width:60,margin:4,max_height:0},'left',0.2,0.2),
            t.guideRect('overlay',{h_pos:'right',v_pos:'top',box_width:50,margin:5,max_height:30},0.1),
            t.guideRect('confidence',{},0)]))""" % json.dumps(str(STATIC / "themes.js")))
        rect, width, gap_x, cap, gap_y, centered, other, none = got
        self.assertAlmostEqual(rect["left"], 0.04 / (16 / 9), places=4)
        self.assertAlmostEqual(rect["right"] - rect["left"], 0.6, places=6)
        self.assertAlmostEqual(rect["bottom"], 0.96, places=6)
        self.assertAlmostEqual(rect["bottom"] - rect["top"], 0.2, places=6)
        self.assertEqual(width, {"box_width": 78})            # 0.8 minus the left gap (about 0.0225), as a share of the width
        self.assertEqual(gap_x, {"margin": 15})               # dragged far enough to hit the 15 limit
        self.assertEqual(cap, {"max_height": 46})
        self.assertEqual(gap_y, {"margin": 10})
        self.assertEqual(centered, {"box_width": 60})
        self.assertAlmostEqual(other["right"], 1 - 0.05 / (16 / 9), places=6)
        self.assertAlmostEqual(other["bottom"] - other["top"], 0.3, places=6)
        self.assertIsNone(none)


if __name__ == "__main__":
    unittest.main()
