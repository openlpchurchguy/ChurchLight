# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The King James Bible that ships with the program, and the rule for installing it."""
import csv
import shutil
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.content import (
    BIBLE_FLAG, BIBLE_VERSION, KJV_DIGEST, KJV_FILE, ensure_bundled_bible, kjv_is_intact)
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import OperatorController


class BundledFileTests(unittest.TestCase):
    def test_the_file_matches_its_checksum(self):
        self.assertTrue(kjv_is_intact())

    def test_a_changed_or_missing_file_is_not_intact(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        copy = tmp / "kjv.csv"
        shutil.copy(KJV_FILE, copy)
        self.assertTrue(kjv_is_intact(copy, KJV_DIGEST))
        copy.write_text(copy.read_text(encoding="utf-8").replace("heaven", "heavan", 1), encoding="utf-8")
        self.assertFalse(kjv_is_intact(copy, KJV_DIGEST))
        self.assertFalse(kjv_is_intact(tmp / "nope.csv", KJV_DIGEST))

    def test_the_text_is_the_whole_king_james_and_clean(self):
        with open(KJV_FILE, encoding="utf-8", newline="") as handle:
            rows = list(csv.reader(handle))
        self.assertEqual(len(rows), 31102)
        self.assertEqual({int(r[0]) for r in rows}, set(range(1, 67)))
        self.assertEqual(len({tuple(r[:3]) for r in rows}), 31102)
        bad = [r for r in rows if not r[3].strip() or any(ch in r[3] for ch in "¶[]<>{}") or any(ch.isdigit() for ch in r[3])
               or "  " in r[3] or r[3] != r[3].strip()]
        self.assertEqual(bad, [])
        by_ref = {tuple(map(int, r[:3])): r[3] for r in rows}
        self.assertTrue(by_ref[(43, 3, 16)].startswith("For God so loved the world"))
        self.assertEqual(by_ref[(66, 22, 21)], "The grace of our Lord Jesus Christ be with you all. Amen.")

    def test_the_notice_names_the_source_and_the_uk_printing_right(self):
        text = (KJV_FILE.parent.parent / "NOTICES.txt").read_text(encoding="utf-8")
        for needle in ("eBible.org", "eng-kjv2006", "Public domain", "United Kingdom", "31,102"):
            self.assertIn(needle, text)


class InstallRuleTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)

    def test_a_database_with_no_bible_gets_the_kjv_as_the_default(self):
        report = ensure_bundled_bible(self.db)
        self.assertEqual((report.abbreviation, report.verse_count, report.book_count), ("KJV", 31102, 66))
        self.assertEqual(self.db.get_setting("default_translation"), "KJV")
        self.assertEqual(self.db.get_setting(BIBLE_FLAG), BIBLE_VERSION)
        c = OperatorController(self.db)
        self.assertEqual(c.translation, "KJV")
        tray = c.load_tray("John 3:16")
        self.assertIn("only begotten Son", tray.verses[0][1])
        self.assertIn("public domain", self.db.get_translation("KJV")["license_notes"].lower())

    def test_it_is_installed_once_and_never_put_back(self):
        ensure_bundled_bible(self.db)
        self.assertIsNone(ensure_bundled_bible(self.db))                  # already decided
        self.db.delete_translation(self.db.get_translation("KJV")["id"])
        self.assertIsNone(ensure_bundled_bible(self.db))                  # deleted on purpose: stays deleted
        self.assertIsNone(self.db.get_translation("KJV"))

    def test_a_church_that_already_has_a_bible_is_left_alone(self):
        t = self.db.add_translation("WEB", "World English Bible")
        self.db.add_verses(t, [(43, 3, 16, "x")])
        self.assertIsNone(ensure_bundled_bible(self.db))
        self.assertEqual(self.db.conn.execute("SELECT COUNT(*) FROM translations").fetchone()[0], 1)
        self.assertEqual(self.db.get_setting(BIBLE_FLAG), BIBLE_VERSION)   # decided: later deletion will not bring it back
        self.assertIsNone(self.db.get_setting("default_translation"))

    def test_a_damaged_file_installs_nothing_and_leaves_the_choice_open(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        bad = tmp / "kjv.csv"
        bad.write_text("1,1,1,not the Bible\n", encoding="utf-8")
        with self.assertLogs("churchlight.content", "ERROR"):
            self.assertIsNone(ensure_bundled_bible(self.db, bad, KJV_DIGEST))
        self.assertIsNone(self.db.get_translation("KJV"))
        self.assertIsNone(self.db.get_setting(BIBLE_FLAG))                  # a repaired package will install it
        with self.assertLogs("churchlight.content", "ERROR"):
            self.assertIsNone(ensure_bundled_bible(self.db, tmp / "missing.csv", KJV_DIGEST))
        self.assertIsNotNone(ensure_bundled_bible(self.db))                  # the real file still works


if __name__ == "__main__":
    unittest.main()
