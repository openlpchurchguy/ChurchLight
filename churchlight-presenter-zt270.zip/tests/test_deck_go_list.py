# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A slideshow in the service lists its slides, by title or "Slide N", each with a Go button (no pictures involved)."""
import json
import subprocess
import time
import unittest
from pathlib import Path

from churchlight_presenter.ui.controller import LibraryEntry
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

JS = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "operator.js"


def js(expression):
    script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
    out = subprocess.run(["node", "-e", script, str(JS)], capture_output=True, text=True, timeout=30, check=True)
    return json.loads(out.stdout)


def until(check, seconds=5):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


class DataTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()                       # a slideshow "Deck" with three pages
        self.addCleanup(self.db.close)
        self.deck = next(e for e in self.c.search_library("Deck") if e.kind == "presentation")
        self.c.new_service("Sunday")
        self.c.add_entry(self.deck)

    def row(self):
        return self.c.service_rows()[0]

    def test_every_slide_is_listed_with_its_number_in_the_service(self):
        self.assertEqual(self.row().deck_slides,
                         ({"index": 0, "label": "Slide 1"}, {"index": 1, "label": "Slide 2"}, {"index": 2, "label": "Slide 3"}))

    def test_a_title_replaces_the_slide_number_and_skipped_slides_do_not_appear(self):
        pages = self.db.get_presentation_pages(self.deck.id)
        self.c.set_deck_page_title(self.deck.id, pages[1]["id"], "Offering")
        self.assertEqual([s["label"] for s in self.row().deck_slides], ["Slide 1", "Offering", "Slide 3"])

    def test_the_api_carries_the_list(self):
        state = self.api.state()
        self.assertEqual([s["index"] for s in state["items"][0]["deck_slides"]], [0, 1, 2])

    def test_go_slide_jumps_straight_to_the_chosen_slide(self):
        self.api.call("go_slide", {"index": 2})
        self.assertEqual(self.c.session.state().base_index, 2)
        self.assertTrue(self.row().is_live)


class ViewTests(unittest.TestCase):
    SLIDES = [{"index": 3, "label": "Welcome"}, {"index": 4, "label": "Slide 2"}, {"index": 5, "label": "Offering"}]

    def test_states_follow_the_live_slide_once_the_item_is_live(self):
        view = js("m.deckSlideView(%s, 4, true)" % json.dumps(self.SLIDES))
        self.assertEqual([s["state"] for s in view], ["done", "live", "next"])

    def test_no_states_when_the_item_is_not_live(self):
        view = js("m.deckSlideView(%s, 4, false)" % json.dumps(self.SLIDES))
        self.assertEqual([s["state"] for s in view], ["", "", ""])
        self.assertEqual(js("m.deckSlideView(null, null, false)"), [])


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def test_the_options_list_shows_titles_and_go_jumps(self):
        db, c, api = make()
        self.addCleanup(db.close)
        deck = next(e for e in c.search_library("Deck") if e.kind == "presentation")
        c.set_deck_page_title(deck.id, db.get_presentation_pages(deck.id)[1]["id"], "Offering")
        c.new_service("Sunday")
        c.add_entry(deck)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        page.wait_for_selector(".item-options", state="attached")
        page.click("button.more")
        page.wait_for_selector(".deck-slide-list li")
        lines = page.locator(".deck-slide-list li .slide-text").all_inner_texts()
        self.assertEqual(lines, ["Slide 1", "Offering", "Slide 3"])
        page.locator(".deck-slide-list li").nth(2).locator("button.slide-bar").click()
        self.assertTrue(until(lambda: c.session.state().base_index == 2))
        page.wait_for_selector(".deck-slide-list li.slide-live")
        self.assertIn("Slide 3", page.inner_text(".deck-slide-list li.slide-live"))


if __name__ == "__main__":
    unittest.main()
