# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Finding the PDF renderer in a vendor folder, and saying plainly whether PDF import is ready."""
import importlib.util
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from churchlight_presenter.importers import pdfrender
from churchlight_presenter.ui.operator_api import OperatorApi

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "churchlight_presenter" / "server" / "static"
NODE = shutil.which("node")


def load_tool():
    spec = importlib.util.spec_from_file_location("add_vendor_wheel", ROOT / "tools" / "add_vendor_wheel.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class VendorFolderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self._path = list(sys.path)
        self.addCleanup(lambda: sys.path.__setitem__(slice(None), self._path))

    def test_a_vendor_folder_is_added_once_and_only_when_it_exists(self):
        vendor = self.dir / "vendor"
        self.assertFalse(pdfrender.use_vendor_folder(vendor))          # nothing there yet
        vendor.mkdir()
        self.assertTrue(pdfrender.use_vendor_folder(vendor))
        self.assertFalse(pdfrender.use_vendor_folder(vendor))          # already on the path
        self.assertEqual(sys.path[-1], str(vendor))                    # after everything installed

    def test_the_default_vendor_folder_sits_next_to_the_program_folder(self):
        self.assertEqual(pdfrender.VENDOR_DIR, ROOT / "vendor")

    def test_a_package_in_the_vendor_folder_can_be_imported_without_pip(self):
        vendor = self.dir / "vendor"
        (vendor / "vendored_demo_pkg").mkdir(parents=True)
        (vendor / "vendored_demo_pkg" / "__init__.py").write_text("MARK = 'bundled'\n")
        self.assertIsNone(importlib.util.find_spec("vendored_demo_pkg"))
        pdfrender.use_vendor_folder(vendor)
        self.assertIsNotNone(importlib.util.find_spec("vendored_demo_pkg"))

    def test_a_renderer_from_the_vendor_folder_is_reported_as_included(self):
        vendor = self.dir / "vendor"
        fake = mock.MagicMock(__file__=str(vendor / "pypdfium2" / "__init__.py"))
        (vendor / "pypdfium2").mkdir(parents=True)
        with mock.patch.object(pdfrender, "VENDOR_DIR", vendor), \
                mock.patch.object(pdfrender, "pdfium_available", return_value=True), \
                mock.patch.dict(sys.modules, {"pypdfium2": fake}):
            status = pdfrender.pdf_status()
        self.assertEqual((status["ready"], status["engine"], status["bundled"]), (True, "pypdfium2", True))
        self.assertIn("included with the program", status["message"])


class BundledCopyTests(unittest.TestCase):
    """If a renderer was placed in the vendor folder for the download, its licence files must travel with it."""
    VENDOR = ROOT / "vendor"

    @unittest.skipUnless((ROOT / "vendor" / "pypdfium2").is_dir(), "no renderer bundled in this tree")
    def test_the_bundled_renderer_has_its_library_and_licences(self):
        self.assertTrue(list(self.VENDOR.glob("pypdfium2_raw/pdfium.*")), "the PDFium library file is missing")
        dist = list(self.VENDOR.glob("pypdfium2-*.dist-info"))
        self.assertEqual(len(dist), 1)
        self.assertTrue(any(p.is_file() for p in (dist[0] / "licenses").rglob("*")), "the licence files are missing")


class StatusTests(unittest.TestCase):
    def test_ready_through_an_installed_renderer(self):
        with mock.patch.object(pdfrender, "pdfium_available", return_value=True), \
                mock.patch.dict(sys.modules, {"pypdfium2": mock.MagicMock(__file__="/usr/lib/python3/pypdfium2/__init__.py")}):
            status = pdfrender.pdf_status()
        self.assertEqual((status["ready"], status["engine"], status["bundled"]), (True, "pypdfium2", False))
        self.assertNotIn("included", status["message"])

    def test_ready_through_poppler(self):
        with mock.patch.object(pdfrender, "pdfium_available", return_value=False), \
                mock.patch.object(shutil, "which", return_value="/usr/bin/pdftoppm"):
            status = pdfrender.pdf_status()
        self.assertEqual((status["ready"], status["engine"]), (True, "poppler"))

    def test_not_ready_says_what_to_do_in_plain_words(self):
        with mock.patch.object(pdfrender, "pdfium_available", return_value=False), \
                mock.patch.object(shutil, "which", return_value=None):
            status = pdfrender.pdf_status()
        self.assertFalse(status["ready"])
        self.assertIsNone(status["engine"])
        self.assertIn("not set up", status["message"])

    def test_the_operator_state_carries_it_and_looks_it_up_once(self):
        api = OperatorApi(None)
        with mock.patch.object(pdfrender, "pdf_status", return_value={"ready": True, "message": "x"}) as look:
            self.assertEqual(api._pdf_status()["ready"], True)
            api._pdf_status()
        look.assert_called_once()


class WheelToolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.tool = load_tool()

    def wheel(self, files, name="demo-1.0-py3-none-win_amd64.whl"):
        path = self.dir / name
        with zipfile.ZipFile(path, "w") as zf:
            for filename, data in files.items():
                zf.writestr(filename, data)
        return path

    def test_a_wheel_is_unpacked_with_its_license_files(self):
        wheel = self.wheel({"demo/__init__.py": "x = 1\n", "demo/lib.dll": "bin", "demo-1.0.dist-info/LICENSE": "Apache"})
        vendor = self.dir / "vendor"
        self.assertEqual(self.tool.add_wheel(wheel, vendor), 3)
        self.assertEqual((vendor / "demo" / "__init__.py").read_text(), "x = 1\n")
        self.assertTrue((vendor / "demo-1.0.dist-info" / "LICENSE").is_file())

    def test_files_that_would_escape_the_folder_are_refused(self):
        wheel = self.wheel({"../evil.py": "boom"})
        with self.assertRaises(SystemExit):
            self.tool.add_wheel(wheel, self.dir / "vendor")
        self.assertFalse((self.dir / "evil.py").exists())

    def test_only_wheels_are_accepted(self):
        other = self.dir / "x.zip"
        other.write_bytes(b"nope")
        with self.assertRaises(SystemExit):
            self.tool.add_wheel(other, self.dir / "vendor")


@unittest.skipUnless(NODE, "node not installed")
class PageTests(unittest.TestCase):
    def run_js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run([NODE, "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True,
                             timeout=30, check=True)
        import json
        return json.loads(out.stdout)

    def test_the_settings_line_says_ready_or_not(self):
        self.assertEqual(self.run_js("m.pdfLine({ready:true,message:'PDF import is ready.'})"), "✓ PDF import is ready.")
        self.assertTrue(self.run_js("m.pdfLine({ready:false,message:'Not set up.'})").startswith("⚠ Not set up."))
        self.assertEqual(self.run_js("m.pdfLine(null)"), "Checking…")

    def test_the_page_has_the_section(self):
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        self.assertIn('data-settings-fold="pdf"', html)
        self.assertIn('id="pdf-status"', html)


if __name__ == "__main__":
    unittest.main()
