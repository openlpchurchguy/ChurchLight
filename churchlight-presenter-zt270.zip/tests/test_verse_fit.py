# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
# ChurchLight Presenter — free worship software
# Copyright (C) 2026 ChurchLight contributors. AGPL-3.0-or-later.
"""Bible verses split by what the projector and the lower third really hold (measured with the theme's font)."""
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.fontmetrics import Ruler
from churchlight_presenter.core.items import ItemRef
from churchlight_presenter.core.slides import SlideBuilder, _fit_split, _VerseFit
from churchlight_presenter.core.themes import overlay_fit_shape, projector_line_room_em, projector_max_lines

VERSE = ("For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him "
         "should not perish, but have everlasting life. For God sent not his Son into the world to condemn the "
         "world; but that the world through him might be saved.")


def fitter(room, most):
    ruler = Ruler(None)
    return _VerseFit([(ruler, room, most, False)]).fits, ruler


class FitSplitTests(unittest.TestCase):
    def test_a_verse_that_fits_stays_whole(self):
        fits, _ = fitter(40, 10)
        self.assertEqual(_fit_split(VERSE, fits), [" ".join(VERSE.split())])

    def test_every_part_fits_and_nothing_is_lost(self):
        fits, _ = fitter(20, 3)
        parts = _fit_split(VERSE, fits)
        self.assertGreater(len(parts), 1)
        self.assertTrue(all(fits(p) for p in parts))
        self.assertEqual(" ".join(parts), " ".join(VERSE.split()))

    def test_the_fewest_parts_are_used(self):
        fits, ruler = fitter(20, 3)
        parts = _fit_split(VERSE, fits)
        total_lines = ruler.lines(VERSE, 20)
        self.assertLessEqual(len(parts), -(-total_lines // 3) + 1)

    def test_parts_are_even_so_no_slide_is_left_with_a_scrap(self):
        fits, ruler = fitter(18, 4)
        parts = _fit_split(VERSE, fits)
        sizes = [len(p) for p in parts]
        self.assertLessEqual(max(sizes) - min(sizes), max(sizes) * 0.4)

    def test_a_pause_is_preferred_to_a_cut_mid_phrase(self):
        fits, _ = fitter(24, 3)
        parts = _fit_split(VERSE, fits)
        for part in parts[:-1]:
            self.assertIn(part[-1], ",;:.?!", parts)

    def test_a_word_too_big_for_any_slide_stays_whole(self):
        fits, _ = fitter(5, 1)
        parts = _fit_split("a supercalifragilistic word", fits)
        self.assertIn("supercalifragilistic", parts)


class BuilderTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.addCleanup(self.db.close)
        self.kjv = self.db.add_translation("KJV", "King James Version")
        self.db.add_verses(self.kjv, [("John", 3, 16, VERSE), ("John", 3, 17, "Short verse here.")])
        self.builder = SlideBuilder(self.db)
        self.builder.use_capacity = True

    def build(self, overlay_style, last=16):
        from tests.test_slides import JOHN
        overlay = self.db.add_theme(f"Lower{len(self.db.list_themes()) if hasattr(self.db, 'list_themes') else id(overlay_style)}", {"kind": "overlay", "style": overlay_style}) if overlay_style else None
        return self.builder.build_item(ItemRef.passage(self.kjv, JOHN, 3, 16, last), None, overlay)

    def test_slides_fit_the_lower_third_when_measured(self):
        style = {"font_size": 5, "box_width": 80, "max_height": 16}
        slides = self.build(style)
        room, most = overlay_fit_shape(style)
        ruler = Ruler(None)
        for slide in slides:
            self.assertLessEqual(ruler.lines(slide.text, room), most)
        self.assertEqual(" ".join(s.text for s in slides), " ".join(VERSE.split()))
        self.assertTrue(all(s.continued for s in slides[1:]))

    def test_a_roomy_lower_third_does_not_cut_earlier_than_the_projector_needs(self):
        from churchlight_presenter.core.themes import ASPECTS
        roomy = self.build({"font_size": 5, "box_width": 90, "max_height": 60})
        none = self.build(None)
        self.assertEqual(len(roomy), len(none))
        ruler = Ruler(None)
        room, most = projector_line_room_em({}, ASPECTS["16:9"]), projector_max_lines({}, ASPECTS["16:9"])
        for slide in none:
            self.assertLessEqual(ruler.lines(slide.text, room), most)

    def test_the_same_verse_gives_the_same_breaks_every_time(self):
        style = {"font_size": 5, "box_width": 80, "max_height": 16}
        self.assertEqual([s.text for s in self.build(style)], [s.text for s in self.build(style)])

    def test_packing_keeps_whole_verses_together_while_they_fit(self):
        self.builder.defaults = type(self.builder.defaults)(scripture_split="chars")
        slides = self.build(None, last=17)
        self.assertEqual(slides[-1].verse_numbers[-1], 17)
        self.assertEqual(" ".join(s.text for s in slides).count("Short verse here."), 1)


if __name__ == "__main__":
    unittest.main()
