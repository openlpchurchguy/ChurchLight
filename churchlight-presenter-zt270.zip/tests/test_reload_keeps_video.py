# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Changing the service while a video plays must not start the video again."""
from churchlight_presenter.ui.controller import LibraryEntry
from tests.test_media_playback import MP4, WAV, Base


class ReloadKeepsPlaybackTests(Base):
    def add(self, name, data, seconds):
        return self.c.add_media_file(self.upload(name, data), seconds)

    def live_clip(self):
        return self.c.session.state().media

    def test_adding_or_moving_items_leaves_the_playing_video_where_it_is(self):
        video = self.add("a.mp4", MP4, 600)
        other = self.add("b.mp4", MP4, 60)
        self.c.new_service("Sunday")
        item = self.c.add_entry(LibraryEntry("media", video, ""))
        self.c.go_live_item = getattr(self.c, "go_live_service_item")
        self.c.go_live_service_item(item)
        self.c.media_control("seek", 123.0)
        before = dict(self.live_clip())
        self.assertEqual(round(before["pos"]), 123)
        version = self.c.session.version
        for change in (lambda: self.c.add_entry(LibraryEntry("media", other, "")),
                       lambda: self.c.add_announcement("Welcome", "Hello", 0),             # in front of it: its place in the list moves
                       lambda: self.c.add_entry(LibraryEntry("media", other, ""), 1)):
            change()
            clip = self.live_clip()
            self.assertEqual((clip["pos"], clip["at"], clip["playing"]), (before["pos"], before["at"], before["playing"]))
        self.assertGreater(self.c.session.version, version)

    def test_a_paused_video_stays_paused_and_a_removed_one_is_forgotten(self):
        video = self.add("a.mp4", MP4, 600)
        self.c.new_service("Sunday")
        item = self.c.add_entry(LibraryEntry("media", video, ""))
        self.c.go_live_service_item(item)
        self.c.media_control("seek", 40.0)
        self.c.media_control("pause")
        self.c.add_announcement("Welcome", "Hello", 1)
        clip = self.live_clip()
        self.assertFalse(clip["playing"])
        self.assertEqual(round(clip["pos"]), 40)
        self.c.remove_item(item)
        self.assertIsNone(self.live_clip())



class SongImportIsGentleTests(Base):
    def test_a_song_import_rests_a_moment_after_each_song(self):
        from unittest import mock
        from churchlight_presenter.importers import songs
        folder = self.tmp / "songs"
        folder.mkdir()
        for n in range(5):
            (folder / f"Song {n}.txt").write_text(f"[Verse 1]\nline {n} one\nline {n} two\n\nOrder: Verse 1")
        with mock.patch.object(songs.time, "sleep") as sleep:
            report = songs.import_openlyrics(self.db, folder, pause=0.004)
        self.assertEqual(len(report.imported), 5)
        self.assertEqual(sleep.call_count, 5)
        with mock.patch.object(songs.time, "sleep") as sleep:
            songs.import_openlyrics(self.db, folder, force=True)           # callers that do not ask for a rest get none
        self.assertEqual(sleep.call_count, 0)

    def test_the_programs_import_asks_for_the_rest(self):
        from churchlight_presenter.ui import imports
        self.assertGreater(imports.SONG_PAUSE, 0)
