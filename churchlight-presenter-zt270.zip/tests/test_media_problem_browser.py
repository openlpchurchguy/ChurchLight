# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""A video the screen cannot play shows the operator what is wrong and what to do; the help for preparing videos is in the Media Library."""
import unittest

from churchlight_presenter.ui.controller import LibraryEntry
from tests import test_media_browser
from tests.test_media_browser import HAVE_BROWSER, until

_Fixture = test_media_browser.MediaBrowserTests if HAVE_BROWSER else object      # its own tests are not repeated here


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class ProblemTests(_Fixture):
    def test_an_unplayable_live_video_is_reported_to_the_operator_and_goes_away_when_cleared(self):
        self.c.new_service("Sunday")
        operator = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        operator.goto(self.base + "/operator")
        operator.evaluate("document.getElementById('wizard').hidden = true; showView('run')")
        self.page("main")
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))             # the fixture file is not a real video
        self.assertTrue(until(lambda: self.c.media_view()["problem"], 10))
        operator.wait_for_selector("#clip-problem:not([hidden])", timeout=10000)
        text = operator.text_content("#clip-problem")
        self.assertIn("main", text)
        self.assertIn("HandBrake", text)
        self.c.clear()
        operator.wait_for_selector("#clip-problem", state="hidden", timeout=10000)

    def test_the_help_for_preparing_a_video_is_in_the_media_library_tab(self):
        operator = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        operator.goto(self.base + "/operator")
        self.assertEqual(operator.locator("#media-help").count(), 1)
        self.assertIn("Fast 1080p30", operator.text_content("#media-help"))
        self.assertIn("handbrake.fr", operator.text_content("#media-help"))

    def test_a_flagged_video_shows_its_warning_in_the_media_library_list(self):
        from tests.test_mediacheck import mp4, sound_track, video_track
        import io
        batch = self.c.imports.new_batch()
        data = mp4(video_track(width=3840, height=2160, fps=60), sound_track())
        self.c.imports.save_upload(batch, "Phone.mp4", io.BytesIO(data), len(data), "media")
        self.c.add_media_file(batch, 10)
        operator = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        operator.goto(self.base + "/operator")
        operator.evaluate("loadManage()")
        self.assertTrue(until(lambda: "May stutter" in (operator.text_content("#media-list") or "")))
        operator.wait_for_selector("#wizard:not([hidden])")                           # the first-run guide opens by itself; wait, then close it
        operator.evaluate("wizardHide(); showView('media')")
        operator.click("#media-list .media-pick:has-text('Phone')")                 # the details are in the preview
        operator.wait_for_selector("#media-preview .media-facts")
        self.assertIn("3840", operator.text_content("#media-preview"))
        self.assertIn("May stutter", operator.text_content("#media-preview"))


for _name in [n for n in dir(_Fixture) if n.startswith("test_") and n not in ProblemTests.__dict__]:
    setattr(ProblemTests, _name, None)


if __name__ == "__main__":
    unittest.main()
