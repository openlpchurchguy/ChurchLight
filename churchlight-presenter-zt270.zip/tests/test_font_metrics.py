# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Lines on the screen: the width of lyric lines comes from the theme's real font, and slides are cut evenly."""
import unittest
from pathlib import Path

from churchlight_presenter.core.fontmetrics import FONT_DIR, Ruler, _bundled
from churchlight_presenter.core.slides import BuildSettings, _even_cuts, _song_chunks

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

LINES = ["Amazing grace how sweet the sound that saved a wretch like me", "I once was lost but now am found",
         "Open the eyes of my heart Lord I want to see you", "Be thou my vision O Lord of my heart",
         "Jesus paid it all all to him I owe sin had left a crimson stain he washed it white as snow"]


class RulerTests(unittest.TestCase):
    def test_bundled_fonts_are_read_and_a_missing_one_falls_back(self):
        self.assertIn(("open sans", False), _bundled())
        sans = Ruler("Open Sans, sans-serif")
        self.assertTrue(sans.exact)
        self.assertFalse(Ruler("Georgia, serif").exact)
        self.assertGreater(sans.width("WWWW"), sans.width("iiii"))                 # real letter widths, not an average
        self.assertAlmostEqual(sans.width("a"), 0.556, delta=0.05)

    def test_wrapping_follows_the_room(self):
        ruler = Ruler("Open Sans")
        line = LINES[0]
        wide = ruler.width(line) + 0.1
        self.assertEqual(ruler.lines(line, wide), 1)
        self.assertEqual(ruler.lines(line, wide / 1.5), 2)
        self.assertEqual(ruler.lines(line, wide / 3), 4)
        counts = [ruler.lines(line, wide / d) for d in (1, 1.5, 2, 3, 4)]
        self.assertEqual(counts, sorted(counts))                              # a narrower line never takes fewer rows
        self.assertEqual(ruler.lines("", 10), 1)
        self.assertEqual(ruler.lines("Supercalifragilistic", 3), 3)            # one word wider than the line breaks across lines

    @unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
    def test_it_agrees_with_the_browser(self):
        import tempfile
        face = "".join('@font-face{font-family:"%s";font-weight:%d;src:url("file://%s/%s")}' % (fam, 700 if bold else 400, FONT_DIR, name)
                       for (fam, bold), name in _bundled().items())
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1920, "height": 1080})
        for family, size in (("Open Sans", 7), ("Lato", 8), ("Roboto", 10), ("Lora", 8)):
            room = 177.78 * 0.88 / size
            html = ("<html><meta charset=utf-8><style>%s body{margin:0}div{font-family:'%s';font-size:%svh;line-height:1.3;"
                    "width:%svh}</style>%s</html>" % (face, family, size, room * size, "".join("<div>%s</div>" % t for t in LINES)))
            with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False) as handle:
                handle.write(html)
            self.addCleanup(Path(handle.name).unlink)
            page.goto("file://" + handle.name)
            page.evaluate("(f) => document.fonts.load('20px \"' + f + '\"')", family)
            page.wait_for_timeout(300)
            heights = page.evaluate("[...document.querySelectorAll('div')].map(d => d.getBoundingClientRect().height)")
            real = [round(h / (size * 1.3 * 10.8)) for h in heights]
            ruler = Ruler(family)
            self.assertEqual([ruler.lines(t, room) for t in LINES], real, (family, size))


class EvenCutTests(unittest.TestCase):
    def test_the_fewest_slides_cut_evenly(self):
        self.assertEqual(_even_cuts([2, 1, 2], 4), [2, 1])           # not two + one + two
        self.assertEqual(_even_cuts([1, 1, 1, 1, 1], 4), [3, 2])
        sizes = _even_cuts([2, 2, 1, 1, 2, 2], 4)
        self.assertEqual((len(sizes), sum(sizes)), (3, 6))
        self.assertEqual(_even_cuts([1, 1, 1, 1], 4), [4])
        self.assertIsNone(_even_cuts([5], 4))

    def test_a_song_part_of_long_lines_uses_the_rows_the_screen_draws(self):
        ruler = Ruler("Open Sans")
        room = max(ruler.width(t) for t in LINES) + 0.2             # every line fits on one row
        settings = BuildSettings(lines_per_slide=4, song_count="screen", line_ruler=(ruler, room, False))
        self.assertEqual([len(c) for c in _song_chunks(LINES, settings)], [3, 2])      # five lines: 3 + 2, not 4 + 1
        narrow = BuildSettings(lines_per_slide=4, song_count="screen", line_ruler=(ruler, room * 0.55, False))
        slides = _song_chunks(LINES, narrow)
        rows = lambda chunk: sum(ruler.lines(t, room * 0.55) for t in chunk)
        self.assertTrue(all(rows(chunk) <= 4 for chunk in slides))
        self.assertGreater(len(slides), 2)


if __name__ == "__main__":
    unittest.main()
