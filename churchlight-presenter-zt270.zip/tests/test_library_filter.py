# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The search box can be narrowed to songs or slideshows."""
import unittest

from tests.test_verse_tray import make


class FilterTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)
        sid = self.db.insert_song("Deck the Halls")
        self.db.add_section(sid, "Verse 1", "fa la la")

    def kinds(self, entries):
        return {e["kind"] for e in entries}

    def test_library_can_be_narrowed(self):
        both = self.api.library("deck")
        self.assertEqual(self.kinds(both), {"song", "presentation"})
        self.assertEqual(self.kinds(self.api.library("deck", "song")), {"song"})
        self.assertEqual(self.kinds(self.api.library("deck", "presentation")), {"presentation"})

    def test_unknown_kind_means_all(self):
        self.assertEqual(self.kinds(self.api.library("deck", "nope")), {"song", "presentation"})
        self.assertEqual(self.kinds(self.api.library("deck", "")), {"song", "presentation"})

    def test_names_can_be_narrowed_too(self):
        self.assertEqual(self.kinds(self.api.suggest("deck")), {"song", "presentation"})
        self.assertEqual(self.kinds(self.api.suggest("deck", "song")), {"song"})
        self.assertEqual(self.kinds(self.api.suggest("deck", "presentation")), {"presentation"})
        self.assertEqual(self.kinds(self.api.suggest("deck", "nope")), {"song", "presentation"})


if __name__ == "__main__":
    unittest.main()
