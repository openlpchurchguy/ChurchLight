# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The page's tabs, the three library pages, the Broadcast Integration page and the Service tab's screen text."""
import re
import unittest
from pathlib import Path


STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
HTML = (STATIC / "operator.html").read_text(encoding="utf-8")
JS = (STATIC / "operator.js").read_text(encoding="utf-8")


def slide(kind, label, reference):
    return {"item_type": kind, "label": label, "reference": reference}


class TabTests(unittest.TestCase):
    def test_the_tabs_are_in_order(self):
        ids = re.findall(r'<button type="button" id="(tab-[a-z]+)" class="tab', HTML)
        self.assertEqual(ids, ["tab-run", "tab-themes", "tab-songs", "tab-decks", "tab-media", "tab-bibles", "tab-broadcast", "tab-shortcuts"])
        for name in ("Service", "Theme Library", "Song Library", "Slideshow Library", "Media Library", "Bible Library", "Alerts Settings", "Settings"):
            self.assertIn(f">{name}</button>", HTML)

    def test_every_tab_has_a_page_and_the_old_library_page_is_gone(self):
        for view in ("run", "themes", "songs", "decks", "media", "bibles", "broadcast"):
            self.assertIn(f'id="view-{view}"', HTML)
        self.assertNotIn('id="view-library"', HTML)
        self.assertNotIn('id="tab-library"', HTML)

    def test_each_import_lives_with_its_own_library(self):
        def page(view):
            start = HTML.index(f'id="view-{view}"')
            end = HTML.find("<main", start + 10)
            return HTML[start:end if end > 0 else len(HTML)]
        self.assertIn('id="pick-songs"', page("songs"))
        self.assertIn('id="church-ccli-form"', page("songs"))
        self.assertIn('id="draft-list"', page("songs"))
        self.assertIn('id="pick-deck"', page("decks"))
        self.assertIn('id="deck-list"', page("decks"))
        self.assertIn('id="pick-media"', page("media"))
        self.assertIn('id="media-list"', page("media"))
        self.assertIn('id="pick-bible"', page("bibles"))
        self.assertIn('id="bible-list"', page("bibles"))
        for other, button in (("songs", "pick-deck"), ("decks", "pick-songs"), ("bibles", "pick-songs"), ("decks", "pick-media")):
            self.assertNotIn(f'id="{button}"', page(other))

    def test_the_alerts_settings_page_has_the_style_editor_only(self):
        start = HTML.index('id="view-broadcast"')
        broadcast = HTML[start:HTML.index('id="view-shortcuts"')]
        self.assertIn(">Alerts Settings</h2>", broadcast)
        self.assertNotIn("Broadcast Integration", HTML)
        for ident in ("h-ts", "ts-proj", "ts-speak", "ts-reset"):
            self.assertIn(f'id="{ident}"', broadcast)
        for gone in ("screens", "preview-frames"):
            self.assertNotIn(f'id="{gone}"', broadcast)
        for gone in ("to-service", "bc-blank", "bc-now", "bc-next", "bc-previous", "bc-clear-verse", "verse-form", "verse-text"):
            self.assertNotIn(f'id="{gone}"', broadcast)
        self.assertLess(broadcast.index('id="h-broadcast"'), broadcast.index('id="h-ts"'))
        self.assertEqual(broadcast.count("<h2"), 1)                             # nothing sits between the title and the style editor
        self.assertNotIn("<h3>Show a verse", broadcast)
        run = HTML[HTML.index('id="view-run"'):HTML.index('id="view-themes"')]
        for gone in ("to-broadcast", "output-text", "screens-fold"):         # the two Live previews replaced the Screens fold
            self.assertNotIn(f'id="{gone}"', run)
        self.assertNotIn('id="preview-frames"', run)

    def test_the_service_picker_is_on_the_service_tab_not_in_the_header(self):
        header = HTML[HTML.index("<header"):HTML.index("</header>")]
        self.assertNotIn('id="service-select"', header)
        run = HTML[HTML.index('id="view-run"'):HTML.index('id="view-themes"')]
        for ident in ("service-select", "new-service-form", "new-service-name"):
            self.assertIn(f'id="{ident}"', run)

    def test_the_service_tab_has_the_search_built_into_the_service_and_no_library_page(self):
        run = HTML[HTML.index('id="view-run"'):HTML.index('id="view-themes"')]
        self.assertEqual(sorted(re.findall(r'data-panel="([a-z]+)"', run)), ["live", "service", "tray"])
        service = run[run.index('data-panel="service"'):run.index('data-panel="live"')]
        for ident in ("search", "results", "preview", "new-song-run", "add-verse-form",
                      "results-switch", "items"):
            self.assertIn(f'id="{ident}"', service)
        self.assertLess(service.index('id="search"'), service.index('id="items"'))
        for gone in ("view-add", "finder-text", "add-items", "to-service-from-add", "tab-add"):
            self.assertNotIn(gone, HTML)

    def test_the_settings_tab_holds_the_screen_options_and_the_shortcuts(self):
        settings = HTML[HTML.index('id="view-shortcuts"'):]
        for ident in ("h-shortcuts", "home-file", "home-choose", "home-remove", "home-on", "home-fit", "shape-list", "keys-body", "gk-toggle"):
            self.assertIn(f'id="{ident}"', settings)
        self.assertIn(">Settings<", HTML)
        broadcast = HTML[HTML.index('id="view-broadcast"'):HTML.index('id="view-shortcuts"')]
        for gone in ("home-file", "home-fit", "shape-list"):
            self.assertNotIn(f'id="{gone}"', broadcast)

    def test_the_service_tab_is_a_40_60_split_with_a_fixed_tools_panel_like_the_theme_library(self):
        css = (STATIC / "operator.css").read_text(encoding="utf-8")
        self.assertIn("grid-template-columns: minmax(0, 2fr) minmax(0, 3fr)", css[css.index(".board {"):][:200])
        self.assertIn("position: fixed", css[css.index(".run-bottom {"):][:120])
        run = HTML[HTML.index('id="view-run"'):HTML.index('id="view-themes"')]
        self.assertLess(run.index('data-panel="service"'), run.index('data-panel="live"'))
        self.assertLess(run.index('data-panel="live"'), run.index('data-panel="tray"'))
        for gone in ("btn-arrange", "btn-reset-layout", "layout-tools", "arrange-tools"):
            self.assertNotIn(gone, HTML)

    def test_the_tools_panel_switches_between_bible_and_announcements_with_timer(self):
        run = HTML[HTML.index('id="view-run"'):HTML.index('id="view-themes"')]
        bottom = run[run.index('id="run-bottom"'):]
        self.assertEqual(re.findall(r'class="rb-tab" data-pane="([a-z]+)"', bottom), ["bible", "announce"])
        panes = {name: bottom[bottom.index(f'id="rb-{name}"'):] for name in ("bible", "announce")}
        bible = panes["bible"][:panes["bible"].index('id="rb-announce"')]
        announce = panes["announce"]
        for ident in ("tray-form", "tray-body", "tray-list", "tray-jump"):
            self.assertIn(f'id="{ident}"', bible)
        for ident in ("add-announcement-form", "ann-title", "ann-body"):
            self.assertIn(f'id="{ident}"', announce)
        for ident in ("cd-start-at", "cd-start-min", "cd-stop", "cd-mode", "cd-look", "alert-text", "alert-send", "alert-clear"):
            self.assertIn(f'id="{ident}"', announce)             # the timer shares the Announcements tab
        self.assertTrue(panes["announce"].split(">", 1)[0].count("hidden") or "hidden" in panes["announce"][:200])

    def test_there_is_no_screens_fold_or_keys_paragraph_under_the_live_controls(self):
        live = HTML[HTML.index('data-panel="live"'):HTML.index('data-panel="tray"')]
        self.assertNotIn("screens-fold", live)
        self.assertNotIn('class="muted keys"', live)

    def test_there_is_no_ready_box_but_the_ready_line_and_slideshow_only_verse_controls_are_on_the_page(self):
        live = HTML[HTML.index('data-panel="live"'):HTML.index('data-panel="tray"')]
        for ident in ("ready", "ready-title", "ready-take", "ready-clear"):
            self.assertNotIn(f'id="{ident}"', live)
        self.assertIn('id="tray-ready"', HTML)
        self.assertNotIn('id="verse-over-block"', HTML)              # the typed "verse over a slideshow" block is gone; the tray does it
        self.assertNotIn("verse-deck-note", HTML)
        self.assertIn("Show over slideshow", HTML)

    def test_the_live_panel_previews_one_output_chosen_from_a_dropdown(self):
        live = HTML[HTML.index('data-panel="live"'):HTML.index('data-panel="tray"')]
        for ident in ("live-output", "live-frame", "timer-line"):
            self.assertIn(f'id="{ident}"', live)
        toolbar = HTML[HTML.index('id="run-toolbar"'):HTML.index('data-panel="service"')]
        for ident in ("btn-next", "btn-previous"):                 # the buttons moved up into the toolbar
            self.assertIn(f'id="{ident}"', toolbar)
        for gone in ('id="now"', 'id="over"', 'id="notes"'):
            self.assertNotIn(gone, live)

    def test_there_is_no_bible_dropdown_in_the_service_tab_and_no_typed_verse_form_anywhere(self):
        tray = HTML[HTML.index('data-panel="tray"'):HTML.index('id="view-themes"')]
        self.assertIn('id="tray-form"', tray)
        self.assertNotIn('id="translation"', HTML)             # the default Bible is chosen in the Library tab
        for gone in ("verse-form", "verse-text", "verse-hint", "btn-verse-hide", "btn-verse-again",
                     "btn-verse-next", "btn-verse-previous", "verse-position", "verse-bible"):
            self.assertNotIn(f'id="{gone}"', HTML)

    def test_the_verse_can_be_cleared_from_the_live_toolbar(self):
        js = (Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "operator.js").read_text(encoding="utf-8")
        self.assertIn('id="btn-clear-verse"', HTML)
        self.assertIn('$("btn-clear-verse").addEventListener("click", () => act("hide_verse"))', js)
        self.assertNotIn("bc-clear-verse", HTML)

    def test_loading_a_passage_moves_the_cursor_to_the_verse_line_whichever_reply_comes_first(self):
        # The update can arrive before the answer to Enter, so the focus must not depend on the order.
        self.assertIn("function focusVerseLine()", JS)
        submit = JS[JS.index('$("tray-form").addEventListener("submit"'):JS.index('$("tray-clear").addEventListener')]
        self.assertIn("focusVerseLine()", submit)
        self.assertNotIn("pendingJumpFocus = true", submit)
        body = JS[JS.index("function focusVerseLine()"):JS.index("let trayChecked")]
        self.assertIn('$("tray-jump").focus()', body)        # straight away when the tray is already drawn
        self.assertIn("setTimeout", body)                    # and never left waiting for ever

    def test_ids_are_unique(self):
        ids = re.findall(r'\sid="([^"]+)"', HTML)
        self.assertEqual(sorted(i for i in set(ids) if ids.count(i) > 1), [])

    def test_the_script_uses_the_new_views(self):
        self.assertIn('const VIEWS = ["run", "themes", "songs", "decks", "media", "bibles", "broadcast", "shortcuts", "deckedit"]', JS)
        self.assertNotIn('"view-library"', JS)


class ServiceTabScriptTests(unittest.TestCase):
    def js(self, expression):
        import json
        import subprocess
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    def test_the_settings_line_names_the_service_and_its_themes(self):
        state = ("{service:{title:'Sunday',date:'2026-10-25',theme_id:2,overlay_theme_id:null},"
                 "themes:[{id:2,name:'Deep blue'}]}")
        self.assertEqual(self.js(f"m.serviceSummary({state})"),
                         "Sunday — 2026-10-25 · Projector: Deep blue · Overlay: plain")
        self.assertIn("No service open", self.js("m.serviceSummary({service:null})"))

    def test_the_item_after_the_live_one_is_marked_next(self):
        self.assertEqual(self.js("m.nextItemIndex([{live:false},{live:true},{live:false}])"), 2)
        self.assertEqual(self.js("m.nextItemIndex([{live:false},{live:false}])"), -1)       # nothing live
        self.assertEqual(self.js("m.nextItemIndex([{live:false},{live:true}])"), -1)        # live is the last item


if __name__ == "__main__":
    unittest.main()
