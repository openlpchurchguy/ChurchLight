# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The "Ready to start?" check, the saved "I don't livestream" choice, plain-word confirmations, and Undo."""
import unittest

from churchlight_presenter.ui import setup
from tests.test_fold_all import until
from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


class ReadyChecksTests(unittest.TestCase):
    def setUp(self):
        self.db, self.c, self.api = make()
        self.addCleanup(self.db.close)

    def test_rows_say_what_to_fix(self):
        rows = {r["id"]: r for r in setup.ready_checks(self.c)}
        self.assertFalse(rows["screens"]["ok"])
        self.assertEqual(rows["screens"]["fix"], "windows")
        self.assertTrue(rows["bible"]["ok"])
        self.assertFalse(rows["backup"]["ok"])          # an in-memory church has no backup copy

    def test_no_livestream_choice_is_kept(self):
        self.assertFalse(setup.status(self.c)["no_livestream"])
        setup.set_no_livestream(self.c, True)
        self.assertTrue(setup.status(self.c)["no_livestream"])
        setup.set_no_livestream(self.c, False)
        self.assertFalse(setup.status(self.c)["no_livestream"])

    def test_remote_links_and_clicker_only_when_turned_on(self):
        ids = [r["id"] for r in setup.ready_checks(self.c)]
        self.assertNotIn("clicker", ids)


class UndoTests(unittest.TestCase):
    def test_removed_item_comes_back_in_place(self):
        db, c, api = make()
        self.addCleanup(db.close)
        c.new_service("Sunday")
        from churchlight_presenter.ui.controller import LibraryEntry
        a = c.create_song("Alpha", "", "[Verse 1]\nOne")
        b = c.create_song("Beta", "", "[Verse 1]\nTwo")
        d = c.create_song("Gamma", "", "[Verse 1]\nThree")
        for sid, title in ((a, "Alpha"), (b, "Beta"), (d, "Gamma")):
            c.add_entry(LibraryEntry("song", sid, title))
        items = [r["id"] for r in db.get_service_items(c.service_id)]
        c.remove_item(items[1])
        self.assertEqual(len(db.get_service_items(c.service_id)), 2)
        c.undo_remove_item()
        rows = db.get_service_items(c.service_id)
        self.assertEqual([r["song_id"] for r in rows], [a, b, d])
        self.assertEqual([r["position"] for r in rows], [0, 1, 2])


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class ReadyBrowserTests(unittest.TestCase):
    def open(self):
        db, c, api = make()
        self.addCleanup(db.close)
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(server.url.rstrip("/") + "/operator")
        try:
            page.wait_for_selector("#wizard:not([hidden])", timeout=3000)
        except Exception:
            pass
        page.evaluate("wizardHide()")
        return page, c

    def test_empty_service_tab_shows_a_folded_check_and_practice_button(self):
        page, c = self.open()
        self.assertTrue(until(lambda: page.is_visible("#landing") and page.locator("#ready-list li").count() >= 3, 10))
        self.assertFalse(page.evaluate("document.getElementById('ready').open"))              # starts folded
        self.assertTrue(page.is_visible("#ready-headline"))
        self.assertTrue(page.is_visible("#landing-practice"))
        page.click("#ready > summary")                                                       # opening shows the rows
        self.assertIn("Screens", page.inner_text("#ready-list"))
        page.click("#ready-list li[data-check=screens] button")                              # the fix button opens Settings, Projector windows
        self.assertTrue(page.is_visible("#view-shortcuts"))
        self.assertTrue(page.evaluate("document.querySelector('details[data-settings-fold=windows]').open"))
        self.assertFalse(page.evaluate("document.querySelector('details[data-settings-fold=screens]').open"))

    def test_ticking_no_obs_in_the_guide_changes_the_bar_without_pressing_finish(self):
        page, c = self.open()
        self.assertTrue(until(lambda: page.locator("#ready-list li[data-check=obs]").count() == 1, 20))
        page.evaluate("wizardShow(WIZARD_STEPS.indexOf('obs'))")
        page.check(".wizard-skip-obs input")
        self.assertTrue(until(lambda: page.locator("#ready-list li[data-check=obs]").count() == 0, 20))      # gone while the guide is still open
        page.uncheck(".wizard-skip-obs input")
        self.assertTrue(until(lambda: page.locator("#ready-list li[data-check=obs]").count() == 1, 20))
        page.evaluate("wizardHide()")

    def test_the_bar_names_what_needs_checking_without_opening(self):
        page, c = self.open()
        self.assertTrue(until(lambda: "to check" in page.inner_text("#ready-headline"), 15))
        self.assertIn("Screens", page.inner_text("#ready-headline"))
        self.assertTrue(page.evaluate("document.getElementById('ready').classList.contains('ready-todo')"))
        self.assertFalse(page.evaluate("document.getElementById('ready').open"))

    def test_the_bar_says_all_good_when_nothing_is_wrong(self):
        page, c = self.open()
        self.assertTrue(until(lambda: page.locator("#ready-list li").count() >= 3, 10))
        page.evaluate("""() => { const list = document.getElementById('ready-list');
            list.replaceChildren(); list.appendChild(drawReadyRow({id: 'a', label: 'Screens', ok: true, detail: 'fine'}));
            readyHeadline(false); }""")
        self.assertIn("Everything is good to go", page.inner_text("#ready-headline"))
        self.assertTrue(page.evaluate("document.getElementById('ready').classList.contains('ready-good')"))

    def test_confirm_says_what_will_go(self):
        page, c = self.open()
        page.evaluate("""() => { const b = document.createElement('button'); b.id = 'probe'; b.textContent = 'Delete';
            document.body.appendChild(b); confirmClick(b, () => { window.gone = true; }, 'Delete the song “Amazing”? Its words are gone for good.'); }""")
        page.click("#probe")
        self.assertEqual(page.inner_text("#probe"), "Yes, delete")
        self.assertIn("Amazing", page.inner_text("#message-text"))
        page.click("#probe")
        self.assertTrue(page.evaluate("window.gone === true"))

    def test_notice_with_undo_runs_the_undo(self):
        page, c = self.open()
        page.evaluate("window.back = false; showNotice('Removed “Alpha” from the service.', () => { window.back = true; })")
        self.assertTrue(page.is_visible("#message-undo"))
        page.click("#message-undo")
        self.assertTrue(page.evaluate("window.back === true"))
        self.assertFalse(page.is_visible("#message"))
