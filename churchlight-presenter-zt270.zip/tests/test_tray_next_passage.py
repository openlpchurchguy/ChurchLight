# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The verse tray is ready for the next passage: letters typed in "Go to verse" move to the passage box, the first Enter
shows the top of the pane without moving the cursor, and a finished verse returns the cursor to the passage box."""
import json
import shutil
import subprocess
import time
import unittest
from pathlib import Path

from tests.test_tray_enter import BrowserTests as _EnterBase
from tests.test_tray_enter import until

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class HandoverTests(unittest.TestCase):
    def handover(self, text):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify(m.jumpHandover({json.dumps(text)})))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True, timeout=30, check=True)
        return json.loads(out.stdout)

    def test_only_letters_move_the_text(self):
        for text in ("", "16", "16-18", "16, 18", " 3 ", "1 "):
            self.assertFalse(self.handover(text), text)
        for text in ("R", "1 J", "Romans 8", "John 3:16", "é"):
            self.assertTrue(self.handover(text), text)


class NextPassageTests(_EnterBase):
    pass_through = None
    def focused(self, page):
        return page.evaluate("document.activeElement && document.activeElement.id")

    def ready(self, page):
        self.c.load_tray("John 3")
        until(lambda: page.get_attribute("#tray-jump", "placeholder").startswith("Enter adds"))

    def test_a_letter_typed_in_go_to_verse_moves_everything_to_the_passage_box(self):
        self.c.load_tray("John 3")
        page = self.open()
        self.ready(page)
        page.fill("#tray-text", "old text")
        page.focus("#tray-jump")
        page.keyboard.type("Romans 8")
        self.assertEqual(page.input_value("#tray-text"), "Romans 8")        # the first letter was not lost, the old text is gone
        self.assertEqual(page.input_value("#tray-jump"), "")
        self.assertEqual(self.focused(page), "tray-text")
        self.assertEqual(self.items(), [])                                  # nothing was added to the service

    def test_a_book_that_starts_with_a_number_moves_at_its_first_letter(self):
        page = self.open()
        self.ready(page)
        page.focus("#tray-jump")
        page.keyboard.type("1 John 3")
        self.assertEqual(page.input_value("#tray-text"), "1 John 3")
        self.assertEqual(page.input_value("#tray-jump"), "")

    def test_numbers_stay_in_go_to_verse(self):
        page = self.open()
        self.ready(page)
        page.focus("#tray-jump")
        page.keyboard.type("2-3")
        self.assertEqual(page.input_value("#tray-jump"), "2-3")
        self.assertEqual(page.input_value("#tray-text"), "")
        self.assertEqual(self.focused(page), "tray-jump")

    def test_the_first_enter_keeps_the_cursor_and_shows_the_top_of_the_pane(self):
        page = self.open()
        self.ready(page)
        page.evaluate("document.getElementById('run-bottom').scrollTop = 400")
        page.focus("#tray-jump")
        page.keyboard.type("2")
        page.keyboard.press("Enter")
        self.assertTrue(until(lambda: self.c.cue is not None))
        self.assertTrue(until(lambda: page.evaluate("document.getElementById('run-bottom').scrollTop") == 0))
        self.assertEqual(self.focused(page), "tray-jump")
        self.assertTrue(until(lambda: "Ready" in page.inner_text("#tray-ready")))
        page.keyboard.press("Enter")                                         # the second Enter still takes it
        self.assertTrue(until(lambda: self.c.cue is None))

    def test_after_the_verse_is_live_the_cursor_is_back_in_the_passage_box(self):
        page = self.open()
        self.ready(page)
        page.fill("#tray-text", "")
        page.focus("#tray-jump")
        page.keyboard.type("2")
        page.keyboard.press("Enter")
        self.assertTrue(until(lambda: self.c.cue is not None))
        self.assertTrue(until(lambda: "Ready" in page.inner_text("#tray-ready")))
        page.keyboard.press("Enter")
        self.assertTrue(until(lambda: self.c.cue is None))
        self.assertTrue(until(lambda: self.focused(page) == "tray-text"))
        self.assertEqual(page.input_value("#tray-jump"), "")

    def test_the_passage_box_text_is_selected_so_typing_replaces_it(self):
        page = self.open()
        self.ready(page)
        page.fill("#tray-text", "Genesis 1")
        page.focus("#tray-jump")
        page.keyboard.type("2")
        page.keyboard.press("Enter")
        self.assertTrue(until(lambda: self.c.cue is not None))
        self.assertTrue(until(lambda: "Ready" in page.inner_text("#tray-ready")))
        page.keyboard.press("Enter")
        self.assertTrue(until(lambda: self.focused(page) == "tray-text"))
        page.keyboard.type("Acts 2")
        self.assertEqual(page.input_value("#tray-text"), "Acts 2")

    def test_add_whole_passage_returns_the_cursor_to_the_passage_box(self):
        page = self.open()
        self.ready(page)
        page.focus("#tray-jump")
        page.click("#tray-add-all")
        self.assertTrue(until(lambda: self.items() == [(1, 6)]))
        self.assertTrue(until(lambda: self.focused(page) == "tray-text"))


for _name in [n for n in dir(_EnterBase) if n.startswith("test_") and n not in NextPassageTests.__dict__]:
    setattr(NextPassageTests, _name, None)           # only this file's tests run here; the base ones belong to their own module
del _EnterBase, _name

if __name__ == "__main__":
    unittest.main()
