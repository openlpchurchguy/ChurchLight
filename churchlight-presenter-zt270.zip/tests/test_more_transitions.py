# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Slide, split, wipe and fade transitions: the stored choices, the upgrade of an older database, and the page."""
import json
import shutil
import sqlite3
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core import migrations
from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.transitions import TRANSITIONS, check_transition

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
NEW = [k for k in TRANSITIONS if k not in ("none", "dissolve", "circle_out", "circle_in")]

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


class StorageTests(unittest.TestCase):
    def test_every_new_kind_is_a_valid_choice(self):
        self.assertEqual(len(NEW), 14)
        for kind in NEW:
            self.assertEqual(check_transition(kind, 700), (kind, 700))

    def test_the_requested_set_is_all_there(self):
        wanted = {"slide_left", "slide_right", "slide_up", "slide_down",
                  "split_horizontal", "split_vertical", "split_diagonal_left", "split_diagonal_right",
                  "wipe_left", "wipe_right", "wipe_up", "wipe_down", "fade_black", "fade_white"}
        self.assertEqual(set(NEW), wanted)

    def test_a_new_database_stores_every_kind_on_decks_and_pages(self):
        db = DatabaseManager(":memory:")
        self.addCleanup(db.close)
        deck = db.add_presentation("D", [("a.png", None), ("b.png", None)])
        page = db.get_presentation_pages(deck)[0]["id"]
        for kind in NEW:
            db.set_presentation_transition(deck, kind, 500)
            db.set_presentation_pages_timing(deck, [page], transition=kind, transition_ms=500)
            self.assertEqual(db.get_presentation(deck)["transition"], kind)
            self.assertEqual(db.get_presentation_pages(deck)[0]["transition"], kind)

    def test_an_older_database_keeps_its_rows_and_gains_the_new_kinds(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        migrations.migrate(conn, migrations.MIGRATIONS[:14])
        conn.execute("INSERT INTO presentations (name, transition, transition_ms) VALUES ('Old', 'circle_in', 800)")
        conn.execute("INSERT INTO presentation_pages (presentation_id, page_number, image_path, transition, transition_ms) "
                     "VALUES (1, 1, 'x.png', 'dissolve', 300)")
        conn.commit()
        with self.assertRaises(sqlite3.IntegrityError):         # the old database does not know them yet
            conn.execute("UPDATE presentations SET transition = 'wipe_left'")
        conn.rollback()
        self.assertEqual(migrations.migrate(conn), 20)
        deck = conn.execute("SELECT * FROM presentations").fetchone()
        page = conn.execute("SELECT * FROM presentation_pages").fetchone()
        self.assertEqual((deck["transition"], deck["transition_ms"], page["transition"], page["transition_ms"]),
                         ("circle_in", 800, "dissolve", 300))
        conn.execute("UPDATE presentations SET transition = 'fade_white'")
        conn.execute("UPDATE presentation_pages SET transition = 'split_diagonal_left'")
        for bad in ("UPDATE presentations SET transition = 'spin'", "UPDATE presentation_pages SET transition = 'spin'"):
            with self.assertRaises(sqlite3.IntegrityError):
                conn.execute(bad)
        self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")
        self.assertEqual(conn.execute("PRAGMA foreign_key_check").fetchall(), [])
        conn.close()

    def test_migrating_a_second_time_changes_nothing(self):
        conn = sqlite3.connect(":memory:")
        self.assertEqual(migrations.migrate(conn), 20)
        before = conn.execute("SELECT group_concat(sql) FROM sqlite_master").fetchone()[0]
        self.assertEqual(migrations.migrate(conn), 20)
        self.assertEqual(conn.execute("SELECT group_concat(sql) FROM sqlite_master").fetchone()[0], before)
        conn.close()

    def test_a_database_file_reopens_after_the_upgrade(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "c.db")
            conn = sqlite3.connect(path)
            conn.execute("PRAGMA foreign_keys = ON")
            migrations.migrate(conn, migrations.MIGRATIONS[:14])
            conn.execute("INSERT INTO presentations (name) VALUES ('Old')")
            conn.commit()
            conn.close()
            db = DatabaseManager(path)
            db.set_presentation_transition(1, "wipe_up", 400)
            db.close()
            again = DatabaseManager(path)
            self.addCleanup(again.close)
            self.assertEqual(again.get_presentation(1)["transition"], "wipe_up")


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class PageScriptTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "output.js")], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    def test_every_kind_has_steps_and_the_page_list_matches(self):
        self.assertEqual(sorted(self.js("m.TRANSITION_TYPES")), sorted(k for k in TRANSITIONS if k != "none"))
        for kind in NEW:
            self.assertIsNotNone(self.js(f"m.transitionSteps('{kind}')"), kind)

    def test_slides_come_in_from_the_named_edge(self):
        start = lambda kind: self.js(f"m.transitionSteps('{kind}').keyframes[0].transform")
        self.assertEqual(start("slide_left"), "translate(100%, 0)")
        self.assertEqual(start("slide_right"), "translate(-100%, 0)")
        self.assertEqual(start("slide_up"), "translate(0, 100%)")
        self.assertEqual(start("slide_down"), "translate(0, -100%)")
        self.assertEqual(self.js("m.transitionSteps('slide_left').moves"), "new")

    def test_wipes_and_splits_grow_to_the_whole_frame(self):
        for kind in ("wipe_left", "wipe_right", "wipe_up", "wipe_down", "split_horizontal", "split_vertical"):
            frames = self.js(f"m.transitionSteps('{kind}').keyframes")
            self.assertEqual(frames[1]["clipPath"], "inset(0 0 0 0)", kind)
            self.assertNotEqual(frames[0]["clipPath"], frames[1]["clipPath"], kind)
        self.assertEqual(self.js("m.transitionSteps('wipe_left').keyframes[0].clipPath"), "inset(0 0 0 100%)")

    def test_diagonal_splits_start_as_a_line(self):
        for kind in ("split_diagonal_left", "split_diagonal_right"):
            frames = self.js(f"m.transitionSteps('{kind}').keyframes")
            self.assertEqual(frames[1]["clipPath"], "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)")
            self.assertEqual(len(frames[0]["clipPath"].split(",")), 4)          # same corner count, so it can animate

    def test_fades_go_through_a_cover(self):
        self.assertEqual(self.js("m.transitionSteps('fade_black')"), {"moves": "cover", "color": "#000000"})
        self.assertEqual(self.js("m.transitionSteps('fade_white')"), {"moves": "cover", "color": "#ffffff"})

    def test_the_editor_lists_them_with_short_names_for_the_thumbnails(self):
        script = "const m=require(process.argv[1]);console.log(JSON.stringify(m.transitionText('wipe_left',700)+'|'+m.transitionText('fade_white',500)))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True, timeout=30)
        self.assertEqual(json.loads(out.stdout), "Wipe left, 0.7 s|Fade to white, 0.5 s")


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class PageAnimationTests(unittest.TestCase):
    """Run each transition on the real output page: it must end with exactly one frame and no cover left behind."""

    def test_every_transition_finishes_cleanly(self):
        from churchlight_presenter.core.outputs import Output
        from churchlight_presenter.server.app import OutputServer
        from churchlight_presenter.ui.controller import OperatorController
        from tests.test_picture_swap_browser import picture_payload, tiny_png
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        outputs = [Output("projector", "projector")]
        controller = OperatorController(db, outputs)
        server = OutputServer(controller.session, outputs).start()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        page = browser.new_page(viewport={"width": 640, "height": 360})
        pictures = {"a": tiny_png(40), "b": tiny_png(200)}
        page.route("**/media/**", lambda route: route.fulfill(
            body=pictures[route.request.url.rsplit("/", 1)[1].split(".")[0]], content_type="image/png"))
        page.add_init_script("window.fetch = () => new Promise(() => {});")
        page.goto(f"http://127.0.0.1:{server.address[1]}/view/projector")
        results = page.evaluate("""async ([a, b, kinds]) => {
            const root = document.getElementById('root');
            await render(a, root);
            const out = {};
            let version = 2;
            for (const kind of kinds) {
                const next = JSON.parse(JSON.stringify(version % 2 ? a : b));
                next.version = ++version;
                next.base.transition = kind; next.base.transition_ms = 200;
                next.base.image_path = next.base.image_path.replace(/[ab]\\.png/, (version % 2 ? 'a' : 'b') + '.png');
                next.base.label = 'x' + version;
                const done = render(next, root);
                await new Promise((r) => setTimeout(r, 60));
                const during = root.children.length;
                await done;
                await new Promise((r) => setTimeout(r, 900));
                out[kind] = { during: during, after: root.children.length, cover: document.querySelectorAll('.frame').length };
            }
            return out;
        }""", [picture_payload("a", 1), picture_payload("b", 2), sorted(k for k in TRANSITIONS if k != "none")])
        for kind, seen in results.items():
            self.assertEqual(seen["after"], 1, kind)
            self.assertEqual(seen["cover"], 1, kind)
            self.assertGreaterEqual(seen["during"], 2, kind)


if __name__ == "__main__":
    unittest.main()
