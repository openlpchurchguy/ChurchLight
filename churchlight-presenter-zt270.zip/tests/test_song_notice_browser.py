# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The title and CCLI slide on screen and on the operator page."""
import time
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False


def until(check, seconds=10):
    end = time.time() + seconds
    while time.time() < end:
        try:
            if check():
                return True
        except Exception:
            pass
        time.sleep(0.05)
    return False


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class NoticeBrowserTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, [Output("projector", "projector"), Output("lower", "lower_third")])
        self.c.new_service("Sunday")
        song = self.c.create_song("Grace", "John Newton", "[Verse 1]\nline one\nline two", ccli="7068424", copyright_text="2010 Owner")
        self.c.add_entry(next(e for e in self.c.search_library("Grace") if e.kind == "song"))
        self.c.set_church_ccli("12345")
        self.c.set_notice_settings("before", "Words and music by", "Used by Permission.", True)
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            self.browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(self.browser.close)
        self.base = self.server.url.rstrip("/")

    def test_the_projector_shows_a_large_title_and_small_details(self):
        self.c.go_to_slide(0)
        page = self.browser.new_page(viewport={"width": 1280, "height": 720})
        page.goto(self.base + "/view/projector")
        self.assertTrue(until(lambda: page.locator(".line.notice-title").count() == 1))
        self.assertEqual(page.locator(".line.notice-title").inner_text(), "Grace")
        details = page.locator(".line.notice-detail").all_inner_texts()
        self.assertEqual(details, ["Words and music by John Newton", "© 2010 Owner. Used by Permission.",
                                   "CCLI Song #7068424 · CCLI License #12345"])
        title_size = page.evaluate("parseFloat(getComputedStyle(document.querySelector('.notice-title')).fontSize)")
        detail_size = page.evaluate("parseFloat(getComputedStyle(document.querySelector('.notice-detail')).fontSize)")
        self.assertGreater(title_size, detail_size * 2)

    def test_the_lower_third_does_not_say_the_title_twice(self):
        self.c.go_to_slide(0)
        page = self.browser.new_page(viewport={"width": 1280, "height": 720})
        page.goto(self.base + "/view/lower")
        self.assertTrue(until(lambda: "Words and music by" in page.inner_text("body")))
        self.assertEqual(page.inner_text("body").count("Grace"), 1)

    def test_the_operator_page_lists_it_and_the_tick_leaves_it_out(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector(".item-options", state="attached")
        page.click("button.more")
        page.wait_for_selector(".notice-part")
        self.assertIn("Title and CCLI", page.inner_text(".notice-part"))
        page.locator(".notice-part .slide-bar").click()                    # a click shows it
        self.assertTrue(until(lambda: self.c.session.state().base_index == 0))
        page.locator(".notice-part input[type=checkbox]").uncheck()
        self.assertTrue(until(lambda: [s.kind for s in self.c.session.slides] == ["lyrics"]))
        self.assertTrue(until(lambda: "left out of this service" in page.inner_text(".notice-part")))
        page.locator(".notice-part input[type=checkbox]").check()
        self.assertTrue(until(lambda: [s.kind for s in self.c.session.slides] == ["notice", "lyrics"]))

    def test_settings_save_and_the_missing_number_note(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.click("#tab-shortcuts")
        page.evaluate("document.querySelectorAll('details[data-settings-fold]').forEach((d) => { d.open = true; })")     # Settings starts folded
        page.wait_for_selector("#notice-position", state="visible")
        self.assertEqual(page.input_value("#notice-position"), "before")
        self.assertEqual(page.inner_text("#notice-note").strip(), "")
        page.select_option("#notice-position", "after")
        page.fill("#notice-writers", "Written by")
        page.click("#notice-save")
        self.assertTrue(until(lambda: [s.kind for s in self.c.session.slides] == ["lyrics", "notice"]))
        self.assertIn("Written by John Newton", self.c.session.slides[1].text)
        self.c.set_church_ccli("")
        self.assertTrue(until(lambda: "license number is not set" in page.inner_text("#notice-note")))

    def test_the_song_editor_saves_the_copyright_and_the_choice(self):
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.click("#new-song-run")
        page.wait_for_selector("#song-title", state="visible")
        page.fill("#song-title", "Fresh Song")
        page.fill("#song-author", "A Writer")
        page.fill("#song-copyright", "2020 Some Publisher")
        page.select_option("#song-notice", "after")
        page.fill("#song-text", "[Verse 1]\nonly line")
        page.click("#song-save")
        self.assertTrue(until(lambda: any(r["title"] == "Fresh Song" for r in self.db.song_summaries())))
        song = next(e for e in self.c.search_library("Fresh") if e.kind == "song")
        info = self.c.song_for_editing(song.id)
        self.assertEqual((info["copyright"], info["notice"]), ("2020 Some Publisher", "after"))
        page.goto(self.base + "/operator")
        self.c.update_song(song.id, "Fresh Song", "A Writer", "[Verse 1]\nonly line", notice="")
        self.assertEqual(self.c.song_for_editing(song.id)["notice"], "")


if __name__ == "__main__":
    unittest.main()
