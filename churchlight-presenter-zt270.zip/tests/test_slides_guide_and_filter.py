# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The Slideshow Library filter box and the "Bringing your slides into ChurchLight" guide."""
import json
import subprocess
import time
import unittest
from pathlib import Path

from tests.test_verse_tray import make

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

JS = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static" / "operator.js"


def until(check, seconds=8):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.1)
    return False


def js(expression):
    script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
    out = subprocess.run(["node", "-e", script, str(JS)], capture_output=True, text=True, timeout=30, check=True)
    return json.loads(out.stdout)


class FilterPureTests(unittest.TestCase):
    def test_filter_ignores_case_and_matches_part_of_the_name(self):
        decks = [{"name": "Easter Sunday"}, {"name": "Christmas Eve"}, {"name": "Welcome slides"}]
        self.assertEqual([d["name"] for d in js(f"m.filterDecks({json.dumps(decks)}, ' EAS ')")], ["Easter Sunday"])
        self.assertEqual([d["name"] for d in js(f"m.filterDecks({json.dumps(decks)}, 'EAS')")], ["Easter Sunday"])
        self.assertEqual(len(js(f"m.filterDecks({json.dumps(decks)}, '')")), 3)


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BrowserTests(unittest.TestCase):
    def setUp(self):
        db, c, api = make()
        self.addCleanup(db.close)
        db.add_presentation("Easter Sunday", [("s/1.png", "one")])
        server = c.serve()
        self.addCleanup(server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1400, "height": 1000})
        self.page.goto(server.url.rstrip("/") + "/operator")
        try:
            self.page.wait_for_selector("#wizard:not([hidden])", timeout=3000)
            self.page.evaluate("wizardHide()")
        except Exception:
            pass
        self.page.click("#tab-decks")
        self.page.wait_for_selector("#deck-list .row")

    def test_the_filter_narrows_the_list_and_keeps_its_text(self):
        page = self.page
        self.assertEqual(page.locator("#deck-list .row").count(), 2)
        page.fill("#deck-filter", "easter")
        self.assertTrue(until(lambda: page.locator("#deck-list .row").count() == 1))
        page.fill("#deck-filter", "zzz")
        self.assertTrue(until(lambda: page.locator("#deck-list .row").count() == 0))
        self.assertIn("No slideshows match", page.inner_text("#deck-list"))
        page.evaluate("drawDeckList()")                                       # a redraw keeps what was typed
        self.assertEqual(page.input_value("#deck-filter"), "zzz")
        page.fill("#deck-filter", "")
        self.assertTrue(until(lambda: page.locator("#deck-list .row").count() == 2))

    def test_the_guide_opens_shows_each_program_and_closes(self):
        page = self.page
        self.assertTrue(page.is_hidden("#slides-guide"))
        page.evaluate("document.querySelector('.import-controls[data-view=decks]').hidden = false")   # shown once importing is on
        page.click("#sg-open")
        self.assertTrue(page.is_visible("#slides-guide"))
        self.assertIn("Create PDF/XPS", page.inner_text("#sg-powerpoint"))
        for tab, panel, text in (("google", "sg-google", "Download"), ("keynote", "sg-keynote", "Export To"), ("impress", "sg-impress", "Export as PDF")):
            page.click(f"#sg-tab-{tab}")
            self.assertTrue(page.is_visible("#" + panel))
            self.assertIn(text, page.inner_text("#" + panel))
            self.assertEqual(page.locator("[data-sg-panel]:visible").count(), 1)
        self.assertIn("speaker notes", page.inner_text("#slides-guide").lower())
        page.keyboard.press("Escape")
        self.assertTrue(page.is_hidden("#slides-guide"))

    def test_the_guide_opens_from_the_empty_list_and_the_setup_guide(self):
        page = self.page
        page.evaluate("manage.decks = []; drawDeckList()")
        page.click("#deck-list button")
        self.assertTrue(page.is_visible("#slides-guide"))
        page.click("#sg-close")
        self.assertTrue(page.is_hidden("#slides-guide"))
        page.evaluate("wizardShow(WIZARD_STEPS.indexOf('content'))")
        page.click("#wizard-body >> text=How do I get my slides in?")
        self.assertTrue(page.is_visible("#slides-guide"))


if __name__ == "__main__":
    unittest.main()
