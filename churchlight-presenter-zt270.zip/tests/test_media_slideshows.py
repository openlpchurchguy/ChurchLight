# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Library files inside slideshows: video pages, muting, a sound file per page, and keeping library files safe."""
import io
import time
import unittest

from churchlight_presenter.core import export
from churchlight_presenter.ui.controller import ControllerError, LibraryEntry
from churchlight_presenter.ui.operator_api import ApiError, OperatorApi
from tests.test_media_playback import MP3, MP4, Base

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100


class DeckBase(Base):
    def setUp(self):
        super().setUp()
        self.picture = self.add("Cross.png", PNG, 0)
        self.video = self.add("Welcome.mp4", MP4, 20)
        self.music = self.add("Hymn.mp3", MP3, 30)
        self.deck = self.db.add_presentation("Notices", [("decks/a.png", None)])
        self.c.new_service("Sunday")
        self.new = self.c.add_deck_library(self.deck, [self.picture, self.video])
        self.item = self.c.add_entry(LibraryEntry("presentation", self.deck, ""))

    def live(self, slide):
        self.c.go_live_service_item(self.item)
        self.c.go_to_slide(slide)
        return self.c.session.state()


class LibraryPagesTests(DeckBase):
    def test_library_files_become_pages_in_order_and_show_as_pictures_and_videos(self):
        pages = self.c.deck_for_editing(self.deck)["pages"]
        self.assertEqual([p["kind"] for p in pages], ["image", "image", "video"])
        self.assertEqual(self.c.deck_for_editing(self.deck)["pages"][2]["image"], self.db.get_media_asset(self.video)["path"])

    def test_only_pictures_and_videos_can_be_added_not_sound(self):
        with self.assertRaises(ControllerError):
            self.c.add_deck_library(self.deck, [self.music])
        with self.assertRaises(ControllerError):
            self.c.add_deck_library(self.deck, [999])

    def test_a_video_page_plays_a_picture_page_does_not(self):
        state = self.live(2)
        self.assertEqual((state.base.kind, state.media["kind"], state.media["silent"], state.media["duration"]), ("video", "video", False, 20.0))
        state = self.live(1)
        self.assertEqual((state.base.kind, state.media), ("image", None))

    def test_a_muted_video_page_is_marked_silent(self):
        self.c.set_deck_pages_sound(self.deck, [self.new[1]], muted=True)
        self.assertTrue(self.live(2).media["silent"])
        self.assertEqual(self.c.deck_for_editing(self.deck)["pages"][2]["muted"], True)

    def test_the_video_page_moves_on_when_the_video_ends_and_ignores_the_slide_delay(self):
        c = self.c
        c._timer_scale = 0.02
        c.CLIP_GRACE = 0.0
        self.addCleanup(c.set_timer_paused, True)
        c.remove_item(self.item)                                    # this test's slideshow is the whole service
        deck = self.db.add_presentation("Timed", [("decks/a.png", None)])
        (clip,) = c.add_deck_library(deck, [self.video])
        self.db.add_presentation_pages(deck, [("decks/z.png", None)])
        self.db.set_presentation_pages_timing(deck, [clip], auto_seconds=600)       # a long delay that must not hold the video
        item = c.add_entry(LibraryEntry("presentation", deck, ""))
        c.go_live_service_item(item)
        c.go_to_slide(1)
        self.assertEqual(c.session.state().base.kind, "video")
        end = time.monotonic() + 3
        while time.monotonic() < end and c.session.state().base_index == 1:
            time.sleep(0.01)
        self.assertEqual(c.session.state().base_index, 2)

    def test_deleting_a_page_or_slideshow_never_deletes_the_library_file(self):
        path = self.tmp / "media" / self.db.get_media_asset(self.picture)["path"]
        self.assertTrue(path.exists())
        self.c.delete_deck_pages(self.deck, [self.new[0]]) if hasattr(self.c, "delete_deck_pages") else None
        self.assertTrue(path.exists())
        self.c.remove_item(self.item)
        self.c.delete_deck(self.deck)
        self.assertTrue(path.exists())
        self.assertEqual(len(self.c.media_list()), 3)

    def test_a_library_file_in_a_slideshow_cannot_be_deleted_and_says_so(self):
        with self.assertRaises(ControllerError) as caught:
            self.c.delete_media(self.picture)
        self.assertIn("slideshow", str(caught.exception))
        row = next(r for r in self.c.media_list() if r["id"] == self.picture)
        self.assertEqual(row["decks"], 1)

    def test_duplicating_a_page_keeps_its_media_mute_and_sound(self):
        self.c.set_deck_pages_sound(self.deck, [self.new[1]], muted=True, sound_id=self.music, sound_loop=True)
        (copy,) = self.db.duplicate_presentation_pages(self.deck, [self.new[1]])
        page = self.db.conn.execute("SELECT * FROM presentation_pages WHERE id = ?", (copy,)).fetchone()
        self.assertEqual((page["media_id"], page["muted"], page["sound_id"], page["sound_loop"]), (self.video, 1, self.music, 1))

    def test_replacing_a_picture_makes_it_an_ordinary_picture_again(self):
        self.db.replace_presentation_page_image(self.deck, self.new[1], "decks/new.png")
        page = self.db.get_presentation_pages(self.deck)[2]
        self.assertEqual((page["media_id"], page["muted"]), (None, 0))

    def test_exporting_a_slideshow_with_a_video_page_is_refused_plainly(self):
        with self.assertRaises(export.ExportError) as caught:
            export.slideshow_snapshot(self.db, [self.deck])
        self.assertIn("video", str(caught.exception))


class PageSoundTests(DeckBase):
    def setUp(self):
        super().setUp()
        self.c.set_deck_pages_sound(self.deck, [self.new[0], self.new[1]], sound_id=self.music)

    def test_the_sound_starts_with_the_page_and_ends_when_you_move_on(self):
        sound = self.live(1).page_sound
        self.assertEqual((sound["src"], sound["playing"], sound["duration"]), (self.db.get_media_asset(self.music)["path"], True, 30.0))
        self.c.go_to_slide(0)
        self.assertIsNone(self.c.session.state().page_sound)

    def test_moving_to_another_page_with_the_same_sound_starts_it_again_from_the_top(self):
        self.live(1)
        self.c.page_sound_control("seek") if False else None
        first = self.c.session.state().page_sound["at"]
        time.sleep(0.02)
        self.c.go_to_slide(2)
        self.assertGreater(self.c.session.state().page_sound["at"], first)
        self.assertEqual(self.c.session.state().page_sound["pos"], 0.0)

    def test_pause_resume_restart_and_loop_control_the_pages_sound(self):
        self.live(1)
        self.c.page_sound_control("pause")
        self.assertFalse(self.c.session.state().page_sound["playing"])
        self.c.page_sound_control("resume")
        self.assertTrue(self.c.session.state().page_sound["playing"])
        self.c.page_sound_control("loop", True)
        self.assertTrue(self.c.session.state().page_sound["loop"])
        self.c.page_sound_control("restart")
        self.assertEqual(self.c.session.state().page_sound["pos"], 0.0)
        with self.assertRaises(ControllerError):
            self.c.page_sound_control("explode")

    def test_a_page_with_no_sound_has_nothing_to_control(self):
        self.live(0)
        with self.assertRaises(ControllerError):
            self.c.page_sound_control("pause")

    def test_the_sound_may_loop_from_the_start_and_removing_it_clears_the_loop(self):
        self.c.set_deck_pages_sound(self.deck, [self.new[0]], sound_loop=True)
        self.assertTrue(self.live(1).page_sound["loop"])
        self.c.clear()                                           # a live slideshow cannot be edited
        self.c.set_deck_pages_sound(self.deck, [self.new[0]], sound_id=None)
        page = self.c.deck_for_editing(self.deck)["pages"][1]
        self.assertEqual((page["sound_id"], page["sound_loop"]), (None, False))

    def test_only_sound_files_can_be_chosen_and_a_sound_in_use_cannot_be_deleted(self):
        with self.assertRaises(ControllerError):
            self.c.set_deck_pages_sound(self.deck, [self.new[0]], sound_id=self.video)
        with self.assertRaises(ControllerError):
            self.c.delete_media(self.music)

    def test_the_projector_payload_carries_the_pages_sound_to_one_screen_only(self):
        self.live(1)
        payloads = self.c.payloads()
        names = [o.name for o in self.c.outputs if o.layout == "projector"]
        self.assertTrue(payloads[names[0]]["page_sound"]["plays_sound"])
        for name, payload in payloads.items():
            if name not in names:
                self.assertNotIn("page_sound", payload)

    def test_blank_hides_the_pages_sound_from_the_screens(self):
        self.live(1)
        self.c.set_blank(True)
        names = [o.name for o in self.c.outputs if o.layout == "projector"]
        self.assertNotIn("page_sound", self.c.payloads()[names[0]])

    def test_the_api(self):
        api = OperatorApi(self.c)
        for action, args in (("deck_pages_sound", {"id": self.deck, "page_ids": [self.new[0]], "muted": False}),
                             ("deck_add_library", {"id": self.deck, "media_ids": [self.picture]})):
            with self.subTest(action):
                self.assertTrue(api.call(action, args)["ok"])
        self.live(1)
        for action, args in (("page_sound_pause", {}), ("page_sound_resume", {}), ("page_sound_restart", {}),
                             ("page_sound_loop", {"on": True})):
            with self.subTest(action):
                self.assertTrue(api.call(action, args)["ok"])
        for action, args in (("deck_pages_sound", {"id": self.deck, "page_ids": [self.new[0]]}),
                             ("deck_pages_sound", {"id": self.deck, "page_ids": "x", "muted": True}),
                             ("page_sound_loop", {"on": "yes"})):
            with self.subTest(bad=action):
                with self.assertRaises((ApiError, ControllerError)):
                    api.call(action, args)
