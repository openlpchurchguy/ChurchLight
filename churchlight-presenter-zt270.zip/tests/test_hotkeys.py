# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Customizable keyboard shortcuts: the pure logic in operator.js (run with node)."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"


@unittest.skipUnless(shutil.which("node"), "node is not installed")
class HotkeyLogicTests(unittest.TestCase):
    def js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run(["node", "-e", script, str(STATIC / "operator.js")], capture_output=True, text=True, check=True)
        return json.loads(out.stdout)

    def test_every_action_has_default_keys_and_no_key_is_shared(self):
        keys = self.js("m.defaultKeys()")
        everything = [k for ks in keys.values() for k in ks]
        self.assertEqual(len(everything), len(set(everything)))
        self.assertTrue(all(keys.values()))

    def test_buttons_name_the_key_in_use_not_the_default(self):
        self.assertEqual(self.js("m.keyHint(m.defaultKeys(),'blank')"), "B")
        self.assertEqual(self.js("(()=>{const k=m.defaultKeys();k.blank=['F9','b'];return m.keyHint(k,'blank')})()"), "F9")
        self.assertEqual(self.js("(()=>{const k=m.defaultKeys();k.hide_text=[];return m.keyHint(k,'hide_text')})()"), "")
        self.assertEqual(self.js("m.keyHint(m.defaultKeys(),'next')"), "Space")
        self.assertEqual(self.js("m.withHint('Hide words','W')"), "Hide words (W)")
        self.assertEqual(self.js("m.withHint('Hide words','')"), "Hide words")           # no key, no brackets
        self.assertEqual(self.js("m.blankText(false,null,'F9')"), "Blank screens (F9)")
        self.assertEqual(self.js("m.blankText(false,null,'')"), "Blank screens")

    def test_the_key_list_follows_the_keys_in_use(self):
        line = self.js("(()=>{const k=m.defaultKeys();k.hide_text=['F2'];k.hide_lower=[];return m.keysLine(k)})()")
        self.assertIn("F2 hide the words", line)
        self.assertNotIn("W hide the words", line)
        self.assertNotIn("lower thirds", line)                                       # a key-less action is left out
        self.assertTrue(line.startswith("Keys: "))

    def test_the_pages_do_not_hard_code_a_key_on_a_button(self):
        import re
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        buttons = re.findall(r"<button[^>]*>[^<]*</button>", html)
        self.assertEqual([b for b in buttons if re.search(r"\(\s*[A-Za-z]\s*\)", b)], [])

    def test_custom_keys_replace_the_defaults(self):
        keys = self.js("(()=>{const k=m.defaultKeys();k.next=['F5'];return m.keyAction('F5',{typing:false},k)})()")
        self.assertEqual(keys, {"action": "next"})
        old = self.js("(()=>{const k=m.defaultKeys();k.next=['F5'];return m.keyAction('PageDown',{typing:false},k)})()")
        self.assertIsNone(old)

    def test_letters_match_whatever_the_case(self):
        self.assertEqual(self.js("m.keyAction('B',{typing:false})"), {"action": "blank"})
        self.assertEqual(self.js("m.keyAction('b',{typing:false})"), {"action": "blank"})

    def test_keys_that_need_the_service_tab_do_nothing_on_the_broadcast_tab(self):
        for key in ("t", "g", "/"):
            self.assertIsNone(self.js("m.keyAction(%s,{typing:false,view:'broadcast'})" % json.dumps(key)))
            self.assertIsNotNone(self.js("m.keyAction(%s,{typing:false,view:'run'})" % json.dumps(key)))
        self.assertIsNone(self.js("m.keyAction('v',{typing:false,view:'run'})"))               # the verse box is gone, so V does nothing
        self.assertEqual(self.js("m.keyAction('PageDown',{typing:false,view:'broadcast'})"), {"action": "next"})

    def test_escape_and_typing_rules_still_hold_with_custom_keys(self):
        self.assertEqual(self.js("m.keyAction('Escape',{typing:false,verseShown:true})"), {"action": "hide_verse"})
        self.assertIsNone(self.js("m.keyAction('Escape',{typing:false,verseShown:false})"))
        self.assertIsNone(self.js("m.keyAction('b',{typing:true})"))
        self.assertIsNone(self.js("m.keyAction(' ',{typing:false,onButton:true})"))

    def test_assigning_a_key_moves_it_from_its_old_action(self):
        out = self.js("(()=>{const k=m.defaultKeys();k.hide_verse=['h','q'];return m.assignKey(k,'next','q')})()")
        self.assertEqual(out["keys"]["next"], ["q"])
        self.assertEqual(out["keys"]["hide_verse"], ["h"])
        self.assertEqual(out["moved"], "Hide the verse")

    def test_enter_and_escape_take_or_clear_the_ready_verse_only_when_one_is_ready(self):
        self.assertEqual(self.js("m.keyAction('Enter',{typing:false,cueReady:true})"), {"action": "cue_take"})
        self.assertIsNone(self.js("m.keyAction('Enter',{typing:false,cueReady:false})"))
        self.assertIsNone(self.js("m.keyAction('Enter',{typing:false,cueReady:true,onButton:true})"))   # Enter on a button presses it
        self.assertIsNone(self.js("m.keyAction('Enter',{typing:true,cueReady:true})"))
        self.assertEqual(self.js("m.keyAction('Escape',{typing:false,cueReady:true})"), {"action": "cue_clear"})
        self.assertEqual(self.js("m.keyAction('Escape',{typing:false,cueReady:true,verseShown:true})"), {"action": "hide_verse"})

    def test_the_take_key_works_only_while_something_is_ready(self):
        self.assertEqual(self.js("m.defaultKeys().take_cue"), ["x"])
        self.assertEqual(self.js("m.keyAction('x',{typing:false,cueReady:true,view:'run'})"), {"action": "cue_take"})
        self.assertEqual(self.js("m.keyAction('x',{typing:false,cueReady:true,view:'broadcast'})"), {"action": "cue_take"})
        self.assertIsNone(self.js("m.keyAction('x',{typing:false,cueReady:false,view:'run'})"))

    def test_a_key_cannot_be_taken_from_an_action_that_has_only_that_key(self):
        out = self.js("m.assignKey(m.defaultKeys(),'next','b')")           # b is Blank's only key
        self.assertIn("only key", out["error"])
        self.assertNotIn("keys", out)

    def test_reserved_and_unknown_keys_are_refused(self):
        for key in ("Escape", "Tab", "Enter", "Shift", "Control"):
            self.assertIn("error", self.js("m.assignKey(m.defaultKeys(),'next',%s)" % json.dumps(key)), key)
        self.assertIn("error", self.js("m.assignKey(m.defaultKeys(),'nope','q')"))

    def test_f_keys_and_unused_letters_can_be_assigned(self):
        out = self.js("m.assignKey(m.defaultKeys(),'next','F8')")
        self.assertEqual((out["keys"]["next"], out["moved"]), (["F8"], None))
        self.assertEqual(self.js("m.assignKey(m.defaultKeys(),'next','Q')")["keys"]["next"], ["q"])

    def test_saved_choices_load_and_bad_ones_are_ignored(self):
        saved = json.dumps({"v": 1, "keys": {"next": ["F8"], "previous": ["F7"]}})
        out = self.js("m.parseKeyChoices(%s)" % json.dumps(saved))
        self.assertEqual((out["next"], out["previous"], out["blank"]), (["F8"], ["F7"], ["b"]))
        for bad in ("", "not json", "null", json.dumps({"v": 2, "keys": {}}),
                    json.dumps({"v": 1, "keys": {"next": "F8"}}),
                    json.dumps({"v": 1, "keys": {"next": ["Escape"]}}),
                    json.dumps({"v": 1, "keys": {"next": []}})):
            self.assertEqual(self.js("m.parseKeyChoices(%s)" % json.dumps(bad)), self.js("m.defaultKeys()"), bad)

    def test_a_saved_key_taken_from_a_default_leaves_no_duplicates(self):
        saved = json.dumps({"v": 1, "keys": {"next": ["b"]}})             # b was Blank's default
        out = self.js("m.parseKeyChoices(%s)" % json.dumps(saved))
        everything = [k for ks in out.values() for k in ks]
        self.assertEqual(len(everything), len(set(everything)))
        self.assertEqual(out["next"], ["b"])
        self.assertEqual(out["blank"], [])                               # it lost its only key: shown as "no key"

    def test_labels_are_readable(self):
        self.assertEqual(self.js("[m.keyLabel(' '),m.keyLabel('ArrowDown'),m.keyLabel('PageDown'),m.keyLabel('b'),m.keyLabel('F5')]"),
                         ["Space", "↓", "Page Down", "B", "F5"])


class HotkeyPageTests(unittest.TestCase):
    def test_the_step_buttons_are_on_the_broadcast_page_and_the_shortcut_tables_on_the_shortcuts_tab(self):
        html = (STATIC / "operator.html").read_text(encoding="utf-8")
        start = html.index('id="view-broadcast"')
        split = html.index('id="view-shortcuts"')
        broadcast, shortcuts = html[start:split], html[split:html.index("<script", split)]
        for ident in ("bc-next", "bc-previous", "bc-next-item", "bc-previous-item", "bc-blank", "bc-now", "to-service"):
            self.assertNotIn(f'id="{ident}"', broadcast)                   # the Alerts Settings tab has no step buttons
        for ident in ("keys-body", "keys-reset", "keys-note", "gk-toggle", "gk-body", "gk-note", "shortcuts-back"):
            self.assertIn(f'id="{ident}"', shortcuts)
            self.assertNotIn(f'id="{ident}"', broadcast)
        self.assertIn(">Settings</button>", html)
        self.assertNotIn("on the Broadcast tab", html)         # the help text points at the new tab
        script = (STATIC / "operator.js").read_text(encoding="utf-8")
        self.assertIn('for (const view of ["songs", "decks", "media", "bibles", "broadcast", "shortcuts"]) $("tab-" + view)', script)
        self.assertIn('$("shortcuts-back").addEventListener("click"', script)


if __name__ == "__main__":
    unittest.main()
