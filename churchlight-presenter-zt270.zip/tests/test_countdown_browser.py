# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The countdown ticks on the real output pages, stays off the lower thirds, and the operator panel starts it."""
import time
import unittest

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

def until(check, seconds=5):
    """Poll `check()` (the pages' strict CSP refuses string scripts, so waits are done from here)."""
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


OUTPUTS = [Output("projector", "projector"), Output("lower", "lower_third"), Output("stage", "stage"),
           Output("confidence", "confidence")]


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class CountdownBrowserTests(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, OUTPUTS)
        self.server = self.c.serve()
        self.addCleanup(self.server.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            self.browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(self.browser.close)
        self.base = self.server.url.rstrip("/")

    def page(self, name):
        page = self.browser.new_page(viewport={"width": 960, "height": 540})
        page.goto(f"{self.base}/view/{name}")
        return page

    def test_it_ticks_on_the_projector_and_the_speaker_screens_but_not_the_lower_third(self):
        pages = {name: self.page(name) for name in ("projector", "lower", "stage", "confidence")}
        self.c.start_countdown(minutes=2, label="Service begins in")
        for name in ("projector", "stage", "confidence"):
            pages[name].wait_for_selector("#cl-countdown .cd-time", state="visible")
            text = pages[name].inner_text("#cl-countdown .cd-time")
            self.assertRegex(text, r"^(2:00|1:5\d)$", name)
            self.assertIn("Service begins in", pages[name].inner_text("#cl-countdown"))
        first = pages["projector"].inner_text("#cl-countdown .cd-time")
        self.assertTrue(until(lambda: pages["projector"].inner_text("#cl-countdown .cd-time") != first, 4))
        pages["lower"].wait_for_timeout(600)
        self.assertEqual(pages["lower"].query_selector("#cl-countdown"), None)
        self.c.stop_countdown()
        pages["projector"].wait_for_selector("#cl-countdown", state="detached")

    def test_the_alert_shows_on_speaker_screens_only(self):
        pages = {name: self.page(name) for name in ("projector", "stage", "confidence")}
        self.c.set_alert("Wrap up")
        for name in ("stage", "confidence"):
            pages[name].wait_for_selector("#cl-message", state="visible")
            self.assertEqual(pages[name].inner_text("#cl-message"), "Wrap up")
        pages["projector"].wait_for_timeout(600)
        self.assertEqual(pages["projector"].query_selector("#cl-message"), None)
        self.c.set_alert("")
        pages["stage"].wait_for_selector("#cl-message", state="detached")

    def test_the_timer_is_not_redrawn_when_a_slide_changes(self):
        page = self.page("projector")
        self.c.start_countdown(minutes=5)
        page.wait_for_selector("#cl-countdown", state="visible")
        page.evaluate("() => { document.getElementById('cl-countdown').dataset.mark = 'same'; }")
        self.c.session.set_blank(True)
        self.c.session.set_blank(False)
        page.wait_for_timeout(500)
        self.assertEqual(page.get_attribute("#cl-countdown", "data-mark"), "same")

    def test_the_words_input_follows_the_clock_or_bar_choice(self):
        self.c.new_service("Sunday")
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector("#rb-tab-announce", state="visible")
        page.click("#rb-tab-announce")
        # a big clock: words go above it
        self.assertTrue(page.is_visible("#cd-label"))
        self.assertFalse(page.is_visible("#cd-bar-text"))
        # a scrolling bar: the bar's own message, with {minutes}, starting from what is saved
        page.select_option("#cd-mode", "bar")
        page.wait_for_selector("#cd-bar-text", state="visible")
        self.assertFalse(page.is_visible("#cd-label"))
        self.assertEqual(page.input_value("#cd-bar-text"), "{minutes} until service begins")
        page.fill("#cd-bar-text", "{minutes} until we worship together")
        page.press("#cd-bar-text", "Enter")
        self.assertTrue(until(lambda: self.c.timer_style()["bar_text"] == "{minutes} until we worship together"))
        # the zero wording sits beside it and saves the same way; empty means the bar says nothing
        self.assertEqual(page.input_value("#cd-zero-text"), "Service is beginning")
        page.fill("#cd-zero-text", "Let us worship")
        page.press("#cd-zero-text", "Enter")
        self.assertTrue(until(lambda: self.c.timer_style()["bar_zero_text"] == "Let us worship"))
        page.fill("#cd-bar-text", "")
        page.press("#cd-bar-text", "Enter")
        self.assertTrue(until(lambda: self.c.timer_style()["bar_text"] == ""))
        page.fill("#cd-zero-text", "")
        page.press("#cd-zero-text", "Enter")
        self.assertTrue(until(lambda: self.c.timer_style()["bar_zero_text"] == ""))
        # back to the big clock
        page.select_option("#cd-mode", "clock")
        page.wait_for_selector("#cd-label", state="visible")
        page.wait_for_selector("#cd-bar-text", state="hidden")
        page.wait_for_selector("#cd-zero-text", state="hidden")
        page.close()

    def test_an_ended_countdown_goes_away_after_a_moment(self):
        page = self.page("projector")
        self.c.session.start_countdown(__import__("time").time() + 1, "")
        page.wait_for_selector("#cl-countdown", state="visible")
        self.assertTrue(until(lambda: page.inner_text("#cl-countdown .cd-time") == "0:00", 4))
        self.assertTrue(until(lambda: "ended" in (page.get_attribute("#cl-countdown", "class") or ""), 2))

    def test_the_operator_panel_starts_and_stops_it_and_sends_an_alert(self):
        self.c.new_service("Sunday")                      # without a service the page shows the start screen
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector("#rb-tab-announce", state="visible")
        page.click("#rb-tab-announce")
        page.fill("#cd-minutes", "3")
        page.fill("#cd-label", "Welcome")
        page.click("#cd-start-min")
        self.assertTrue(until(lambda: page.inner_text("#cd-status").startswith("Counting down")))
        self.assertEqual(self.c.session.state().countdown[1], "Welcome")
        page.fill("#alert-text", "Nursery 4")
        page.click("#alert-send")
        self.assertTrue(until(lambda: "Nursery 4" in page.inner_text("#alert-status")))
        self.assertEqual(self.c.session.state().message, "Nursery 4")
        page.click("#alert-clear")
        self.assertTrue(until(lambda: page.inner_text("#alert-status").startswith("No alert")))
        page.click("#cd-stop")
        self.assertTrue(until(lambda: page.inner_text("#cd-status").startswith("No countdown")))
        self.assertIsNone(self.c.session.state().countdown)

    def test_a_time_that_has_passed_shows_a_plain_message(self):
        self.c.new_service("Sunday")                      # without a service the page shows the start screen
        page = self.browser.new_page(viewport={"width": 1400, "height": 1000})
        page.goto(self.base + "/operator")
        page.wait_for_selector("#rb-tab-announce", state="visible")
        page.click("#rb-tab-announce")
        page.fill("#cd-at", "00:00")
        page.click("#cd-start-at")
        self.assertTrue(until(lambda: "already passed" in page.inner_text("#message")))
        self.assertIsNone(self.c.session.state().countdown)


if __name__ == "__main__":
    unittest.main()
