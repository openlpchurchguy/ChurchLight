# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The output pages really play sound and video: one screen makes the sound, the others and the previews do not."""
import io
import shutil
import tempfile
import time
import unittest
import wave
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.ui.controller import LibraryEntry, OperatorController

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:
    HAVE_BROWSER = False

OUTPUTS = [Output("main", "projector"), Output("second", "projector"), Output("lower", "lower_third")]
MP4 = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 64         # not a real video: enough for the library, the page shows the error


def until(check, seconds=5):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


def wav_bytes(seconds=30):
    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(1)
        w.setframerate(8000)
        w.writeframes(b"\x80" * 8000 * seconds)
    return out.getvalue()


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class MediaBrowserTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(self.db.close)
        self.c = OperatorController(self.db, OUTPUTS, media_root=self.tmp / "media")
        self.server = self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            self.browser = pw.chromium.launch(args=["--autoplay-policy=no-user-gesture-required"])
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(self.browser.close)
        self.base = self.server.url.rstrip("/")
        self.sound = self.add("Prelude.wav", wav_bytes(), 30)
        self.video = self.add("Welcome.mp4", MP4, 20)

    def add(self, name, data, seconds):
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, name, io.BytesIO(data), len(data), "media")
        return self.c.add_media_file(batch, seconds)

    def page(self, name, query=""):
        page = self.browser.new_page(viewport={"width": 640, "height": 360})
        page.goto(f"{self.base}/view/{name}{query}")
        return page

    def audio(self, page):
        return page.evaluate("""() => { const a = document.querySelector('audio');
            return a ? { paused: a.paused, muted: a.muted, time: a.currentTime, volume: a.volume, loop: a.loop } : null; }""")

    def test_the_music_plays_aloud_on_one_screen_only_and_follows_the_controls(self):
        main, second, lower = self.page("main", "?sound=on"), self.page("second", "?sound=on"), self.page("lower", "?sound=on")
        self.c.play_music(self.sound, loop=True)
        self.assertTrue(until(lambda: self.audio(main) and not self.audio(main)["paused"]))
        self.assertFalse(self.audio(main)["muted"])
        self.assertTrue(self.audio(main)["loop"])
        self.assertTrue(until(lambda: self.audio(second) is not None))
        self.assertTrue(self.audio(second)["muted"])                       # the other projector page is silent
        lower.wait_for_timeout(500)
        self.assertIsNone(self.audio(lower))                               # a lower third never plays anything
        self.c.sound_control("volume", 0.3)
        self.assertTrue(until(lambda: abs(self.audio(main)["volume"] - 0.3) < 0.01))
        self.c.sound_control("mute", True)
        self.assertTrue(until(lambda: self.audio(main)["muted"]))
        self.c.sound_control("mute", False)
        self.c.sound_control("pause")
        self.assertTrue(until(lambda: self.audio(main)["paused"]))
        self.c.sound_control("seek", 12)
        self.assertTrue(until(lambda: abs(self.audio(main)["time"] - 12) < 1))
        self.c.sound_control("resume")
        self.assertTrue(until(lambda: not self.audio(main)["paused"]))
        self.c.sound_control("stop")
        self.assertTrue(until(lambda: self.audio(main) is None))

    def test_scrubbing_quickly_always_ends_where_the_bar_was_left(self):
        main = self.page("main", "?sound=on")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: self.audio(main) and not self.audio(main)["paused"]))
        for seconds in (5, 22, 9, 25, 3, 14):                        # faster than the page's two-second guard against needless jumps
            self.c.sound_control("seek", seconds)
            main.wait_for_timeout(120)
        self.assertTrue(until(lambda: abs(self.audio(main)["time"] - 14) < 1.5, 6))

    def test_the_music_keeps_playing_when_the_slides_change_or_the_screens_are_blanked(self):
        main = self.page("main", "?sound=on")
        self.c.play_music(self.sound)
        self.assertTrue(until(lambda: self.audio(main) and not self.audio(main)["paused"]))
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))
        self.c.set_blank(True)
        self.c.set_blank(False)
        self.c.clear()
        main.wait_for_timeout(300)
        self.assertFalse(self.audio(main)["paused"])

    def test_a_sound_slide_plays_and_a_blank_screen_silences_it(self):
        main = self.page("main", "?sound=on")
        self.c.go_live_entry(LibraryEntry("media", self.sound, ""))
        self.assertTrue(until(lambda: self.audio(main) and not self.audio(main)["paused"]))
        self.assertFalse(self.audio(main)["muted"])
        self.c.set_blank(True)
        self.assertTrue(until(lambda: self.audio(main) is None))

    def test_a_video_slide_gets_a_video_element_that_is_silent_off_the_sound_screen(self):
        main, second = self.page("main", "?sound=on"), self.page("second", "?sound=on")
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))
        for page, silent in ((main, False), (second, True)):
            page.wait_for_selector("#cl-media video", state="attached")
            self.assertEqual(page.evaluate("document.querySelector('#cl-media video').muted"), silent)
        self.assertEqual(main.query_selector_all(".layer"), [])           # nothing is drawn over it
        self.c.clear()
        main.wait_for_selector("#cl-media video", state="hidden")           # kept for the next clip, not shown
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))         # the same player is used again, never a second one
        main.wait_for_selector("#cl-media video", state="visible")
        self.assertEqual(main.locator("#cl-media video").count(), 1)

    def test_a_preview_names_what_is_playing_and_never_plays_it(self):
        self.c.go_live_entry(LibraryEntry("media", self.video, ""))
        self.c.play_music(self.sound)
        peek = self.page("main", "?peek=1")
        peek.wait_for_selector("#cl-media-label")
        self.assertIn("Welcome", peek.inner_text("#cl-media-label"))
        self.assertIsNone(peek.query_selector("video"))
        self.assertIsNone(peek.query_selector("audio"))

    def test_a_slideshow_pages_sound_plays_with_the_page_and_stops_when_you_leave_it(self):
        deck = self.db.add_presentation("Notices", [("decks/a.png", None), ("decks/b.png", None)])
        first, second = [p["id"] for p in self.db.get_presentation_pages(deck)]
        self.c.new_service("Sunday")
        self.c.set_deck_pages_sound(deck, [second], sound_id=self.sound, sound_loop=True)
        item = self.c.add_entry(LibraryEntry("presentation", deck, ""))
        main, other = self.page("main", "?sound=on"), self.page("second", "?sound=on")
        self.c.go_live_service_item(item)
        self.assertTrue(self.c.session.state().base_index == 0)
        main.wait_for_timeout(300)
        self.assertIsNone(self.audio(main))                                  # the first page has no sound
        self.c.go_to_slide(1)
        self.assertTrue(until(lambda: self.audio(main) and not self.audio(main)["paused"]))
        self.assertFalse(self.audio(main)["muted"])
        self.assertTrue(self.audio(main)["loop"])
        self.assertTrue(until(lambda: self.audio(other) is not None))
        self.assertTrue(self.audio(other)["muted"])
        self.c.go_to_slide(0)
        self.assertTrue(until(lambda: self.audio(main) is None))
