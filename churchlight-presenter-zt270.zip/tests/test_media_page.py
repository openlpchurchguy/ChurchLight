# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""The operator page: add a sound file, play it as music, and use the controls on the Service page."""
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.ui.controller import OperatorController
from tests.test_media_browser import wav_bytes

try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:                                           # pragma: no cover
    HAVE_BROWSER = False


def until(check, seconds=5):
    end = time.time() + seconds
    while time.time() < end:
        if check():
            return True
        time.sleep(0.05)
    return False


class PageBase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        db = DatabaseManager(":memory:", shared=True)
        self.addCleanup(db.close)
        db.set_setting("setup_done", "1")
        self.c = OperatorController(db, media_root=self.tmp / "media")
        self.c.new_service("Sunday")                                  # without a service the page shows its start screen
        server = self.c.serve(media_root=self.tmp / "media")
        self.addCleanup(self.c.close)
        pw = sync_playwright().start()
        self.addCleanup(pw.stop)
        try:
            browser = pw.chromium.launch()
        except Exception:
            self.skipTest("no browser available")
        self.addCleanup(browser.close)
        self.page = browser.new_page(viewport={"width": 1400, "height": 1000})
        self.page.goto(server.url.rstrip("/") + "/operator")
        self.wav = self.tmp / "Prelude.wav"
        self.wav.write_bytes(wav_bytes(40))

    def music(self):
        return self.c.session.state().sound


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class MediaPageTests(PageBase):
    def test_adding_a_sound_file_reads_its_length_and_the_controls_drive_the_music(self):
        page = self.page
        page.evaluate("showView('media')")
        page.set_input_files("#file-media", str(self.wav))
        page.wait_for_selector("#media-list .row .title")
        self.assertIn("Prelude", page.inner_text("#media-list"))
        self.assertIn("0:40", page.inner_text("#media-list"))
        page.click("#media-list .media-pick")                          # choose it: the preview shows its buttons
        page.wait_for_selector("#media-preview audio")
        page.click("#media-preview >> text=Play as music")
        self.assertTrue(until(lambda: self.music() is not None))
        page.evaluate("showView('run')")
        page.wait_for_selector("#clip-music", state="visible")
        self.assertIn("prelude", page.inner_text("#clip-music-title").lower())
        page.click("#music-play")                                     # now says Pause
        self.assertTrue(until(lambda: not self.music()["playing"]))
        self.assertTrue(until(lambda: page.inner_text("#music-play") == "Play"))
        page.click("#music-play")
        self.assertTrue(until(lambda: self.music()["playing"]))
        page.check("#music-loop")
        self.assertTrue(until(lambda: self.music()["loop"]))
        page.click("#music-mute")
        self.assertTrue(until(lambda: self.c.session.state().sound["muted"]))
        page.click("#music-stop")
        self.assertTrue(until(lambda: self.music() is None))
        page.wait_for_selector("#clip-panel", state="hidden")

    def test_a_file_that_is_not_a_sound_or_video_is_refused_with_a_message(self):
        bad = self.tmp / "notes.txt"
        bad.write_text("hello")
        self.page.evaluate("showView('media')")
        self.page.set_input_files("#file-media", str(bad))
        self.page.wait_for_selector("text=is not one of")
        self.assertEqual(self.c.media_list(), [])


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class MediaLibraryTabTests(PageBase):
    PNG = (b"\x89PNG\r\n\x1a\n" + b"\x00" * 200)

    def test_the_tab_lists_pictures_and_sound_and_the_filter_narrows_them(self):
        page = self.page
        pic = self.tmp / "Cross.png"
        pic.write_bytes(self.PNG)
        page.click("#tab-media")
        page.set_input_files("#file-media", [str(pic), str(self.wav)])
        page.wait_for_selector("#media-list .row:nth-child(2)")
        text = page.inner_text("#media-list")
        self.assertIn("Cross", text)
        self.assertIn("Prelude", text)
        page.select_option("#media-filter", "image")
        self.assertIn("Cross", page.inner_text("#media-list"))
        self.assertNotIn("Prelude", page.inner_text("#media-list"))
        self.assertEqual({r["kind"] for r in self.c.media_list()}, {"image", "audio"})

    def test_pictures_from_slideshows_are_listed_separately_and_read_only(self):
        self.c.db.add_presentation("Welcome deck", [("decks/a.png", None), ("decks/b.png", None)])
        self.page.click("#tab-media")
        self.assertFalse(self.page.eval_on_selector("#media-sources-fold", "d => d.open"))      # folded until asked for
        self.page.click("#media-sources-fold > summary")
        self.page.wait_for_selector("#media-sources .row")
        self.assertIn("Welcome deck", self.page.inner_text("#media-sources"))
        self.page.click("#media-sources .media-pick")
        self.page.wait_for_selector("#media-preview >> text=Open slideshow")
        self.assertEqual(self.page.locator("#media-preview button", has_text="Delete").count(), 0)
        self.assertEqual(self.page.locator("#media-list .row").count(), 0)         # not mixed into the library list

    def test_the_page_is_a_list_on_the_left_and_a_preview_with_the_options_on_the_right(self):
        page = self.page
        pic = self.tmp / "Cross.png"
        pic.write_bytes(self.PNG)
        page.click("#tab-media")
        page.wait_for_selector("#media-preview")
        left = page.eval_on_selector("#media-list", "e => e.getBoundingClientRect().left")
        right = page.eval_on_selector("#media-preview", "e => e.getBoundingClientRect().left")
        self.assertLess(left, right)
        self.assertIn("Choose a file", page.inner_text("#media-preview"))
        page.set_input_files("#file-media", str(pic))
        page.wait_for_selector("#media-list .media-pick")
        self.assertEqual(page.locator("#media-list button", has_text="Delete").count(), 0)      # the buttons live in the preview
        page.click("#media-list .media-pick")
        page.wait_for_selector("#media-preview img.media-preview-image")
        for label in ("Add to service", "Show now", "Rename", "Delete"):
            self.assertEqual(page.locator("#media-preview button", has_text=label).count(), 1, label)
        self.assertEqual(page.get_attribute("#media-list .media-pick", "aria-pressed"), "true")
        page.click("#media-preview >> text=Rename")
        page.fill("#media-preview input", "Big cross")
        page.press("#media-preview input", "Enter")
        page.wait_for_selector("#media-preview h3:has-text('Big cross')")
        self.assertEqual(self.c.media_list()[0]["name"], "Big cross")
        self.assertTrue(until(lambda: self.page.locator("#media-preview button", has_text="Delete").count() == 1))

    def test_a_slideshow_takes_library_pictures_and_a_sound_without_leaving_the_editor(self):
        pic = self.tmp / "Cross.png"
        pic.write_bytes(self.PNG)
        batch = self.c.imports.new_batch()
        self.c.imports.save_upload(batch, "Cross.png", __import__("io").BytesIO(self.PNG), len(self.PNG), "media")
        image = self.c.add_media_file(batch, 0)
        batch = self.c.imports.new_batch()
        data = self.wav.read_bytes()
        self.c.imports.save_upload(batch, "Prelude.wav", __import__("io").BytesIO(data), len(data), "media")
        sound = self.c.add_media_file(batch, 40)
        deck = self.c.db.add_presentation("Notices", [("decks/a.png", None)])
        page = self.page
        page.evaluate(f"openDeckEditor({deck})")
        page.wait_for_selector("#de-grid .de-card")
        page.click("#de-menu-from > summary")
        page.click("#de-library-open")
        page.wait_for_selector("#de-library-grid .de-card")
        page.click("#de-library-grid .de-card")
        page.click("#de-library-add")
        page.wait_for_selector("#de-grid .de-card:nth-child(2)")
        self.assertEqual(len(self.c.db.get_presentation_pages(deck)), 2)
        self.assertEqual(self.c.db.get_presentation_pages(deck)[1]["media_id"], image)
        page.select_option("#de-sound-select", str(sound))                    # the new slide is selected
        page.check("#de-sound-loop")
        self.assertTrue(until(lambda: self.c.db.get_presentation_pages(deck)[1]["sound_id"] == sound))
        self.assertTrue(until(lambda: self.c.db.get_presentation_pages(deck)[1]["sound_loop"] == 1))
        self.assertIn("Sound", page.inner_text("#de-grid .de-card:nth-child(2) .de-flags"))
