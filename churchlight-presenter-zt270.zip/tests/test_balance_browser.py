# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
"""Balanced lyric lines are made by the page itself, so every browser (XSplit's included) breaks them alike."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from churchlight_presenter.core.database import DatabaseManager
from churchlight_presenter.core.outputs import Output
from churchlight_presenter.server.app import OutputServer
from churchlight_presenter.ui.controller import OperatorController

STATIC = Path(__file__).resolve().parent.parent / "churchlight_presenter" / "server" / "static"
NODE = shutil.which("node")
try:
    from playwright.sync_api import sync_playwright
    HAVE_BROWSER = True
except ImportError:           # no browser driver on this computer: the in-browser test is skipped
    HAVE_BROWSER = False

LONG = "'Cause I know there is peace within Your presence"


@unittest.skipUnless(NODE, "node not installed")
class BreakTextTests(unittest.TestCase):
    def run_js(self, expression):
        script = f"const m=require(process.argv[1]);console.log(JSON.stringify({expression}))"
        out = subprocess.run([NODE, "-e", script, str(STATIC / "output.js")], capture_output=True, text=True,
                             timeout=30, check=True)
        return json.loads(out.stdout)

    def test_breaks_go_in_front_of_the_chosen_words_and_drop_the_space(self):
        self.assertEqual(self.run_js(f"m.breakText({json.dumps(LONG)}, [{LONG.index('peace')}])"),
                         "'Cause I know there is\npeace within Your presence")
        self.assertEqual(self.run_js("m.breakText('a b c d', [4, 2])"), "a b\nc d")   # out-of-order offsets are ignored
        self.assertEqual(self.run_js("m.breakText('a b c', [])"), "a b c")
        self.assertEqual(self.run_js("m.breakText('a b', [0, 99])"), "a b")


@unittest.skipUnless(HAVE_BROWSER, "playwright is not installed")
class BalanceInABrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db = DatabaseManager(":memory:", shared=True)
        outputs = [Output("projector", "projector")]
        cls.c = OperatorController(cls.db, outputs)
        cls.server = OutputServer(cls.c.session, outputs).start()
        cls.port = cls.server.address[1]
        cls.pw = sync_playwright().start()
        try:
            cls.browser = cls.pw.chromium.launch()
        except Exception:             # the driver is there but no browser was downloaded
            cls.pw.stop()
            cls.server.close()
            cls.db.close()
            raise unittest.SkipTest("no browser available for the page tests")

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
        cls.server.close()
        cls.db.close()

    def lines(self, text, balance, native_balance, monitor=False):
        slide = {"kind": "lyrics", "item_type": "song", "text": text, "segments": [], "label": "V1", "reference": "",
                 "verse_numbers": [], "continued": False, "image_path": None, "theme_id": None, "title_first": False,
                 "source_item_id": None, "style": {"font_size": 9.5, "band": True, "balance_lines": balance}}
        if balance is None:
            del slide["style"]["balance_lines"]
        payload = {"schema": 1, "version": 1, "output": "projector", "layout": "confidence" if monitor else "projector",
                   "audience": "confidence" if monitor else "public",
                   "theme_id": None, "blank": False, "base": slide, "overlay": None}
        page = self.browser.new_page(viewport={"width": 1280, "height": 720})
        try:
            page.add_init_script("window.fetch = () => new Promise(() => {});")      # no live polling: draw only what we send
            page.goto(f"http://127.0.0.1:{self.port}/view/projector")
            return page.evaluate("""async ([payload, native]) => {
                if (!native) {      // behave like a browser without text-wrap: balance (XSplit's older one)
                    const style = document.createElement('style');
                    style.textContent = '.line.balance { text-wrap: wrap !important; }';
                    document.head.appendChild(style);
                }
                await render(payload, document.getElementById('root'));
                await new Promise((resolve) => setTimeout(resolve, 200));
                return Array.from(document.querySelectorAll('.line')).map((p) => {
                  const rows = new Set();
                  const range = document.createRange();
                  range.selectNodeContents(p);
                  for (const rect of range.getClientRects()) rows.add(Math.round(rect.top / 4));
                  return { text: p.textContent, rows: rows.size };
                });
            }""", [payload, native_balance])
        finally:
            page.close()

    def test_a_long_line_splits_near_the_middle_even_without_native_support(self):
        for native in (False, True):
            first = self.lines(LONG + "\nI speak Jesus", True, native)
            self.assertEqual(first[0]["text"], "'Cause I know there is\npeace within Your presence", f"native={native}")
            self.assertEqual(first[0]["rows"], 2)
            self.assertEqual(first[1], {"text": "I speak Jesus", "rows": 1})      # a short line is left alone

    def test_the_confidence_monitor_balances_without_being_asked(self):
        got = self.lines(LONG + "\nI speak Jesus", None, False, monitor=True)
        self.assertEqual(got[0]["text"], "'Cause I know there is\npeace within Your presence")
        off = self.lines(LONG, False, False, monitor=True)
        self.assertNotIn("\n", off[0]["text"])

    def test_both_kinds_of_browser_draw_the_same_breaks(self):
        self.assertEqual(self.lines(LONG, True, False), self.lines(LONG, True, True))

    def test_with_the_option_off_the_line_wraps_the_usual_way(self):
        got = self.lines(LONG, False, False)
        self.assertNotIn("\n", got[0]["text"])
        self.assertEqual(got[0]["rows"], 2)         # it does overflow here, and fills the first line


if __name__ == "__main__":
    unittest.main()
