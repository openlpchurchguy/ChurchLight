# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) ChurchLight Presenter contributors
import dataclasses
import json
import os
import tempfile
import unittest
from pathlib import Path

from churchlight_presenter.core.live import LiveSession
from churchlight_presenter.core.outputs import (
    LAYOUTS, PAYLOAD_SCHEMA, PUBLIC_SLIDE_FIELDS, STAGE_ONLY_SLIDE_FIELDS, Output,
    build_payload, default_outputs, default_settings_path, load_outputs, save_outputs,
    slide_to_dict,
)
from churchlight_presenter.core.slides import Slide

SECRET = "SECRET-SPEAKER-NOTE"


def song_slide():
    return Slide("lyrics", "song", 1, text="la la", label="Chorus", reference="Demo Song")


def deck_slide(n=2):
    return Slide("image", "presentation", 3, label=f"Slide {n} of 3", reference="Deck",
                 image_path=f"p/{n}.png", notes=SECRET)


def verse_slide():
    return Slide("scripture", "scripture", None, text="verse text",
                 segments=((16, "verse text"),), label="DEMO", reference="John 3:16",
                 verse_numbers=(16,))


def state_with(base=None, overlay=None, blank=False, others=()):
    items = [base] if base is not None else []
    session = LiveSession(items + list(others))
    if base is not None:
        session.go_to(0)
    if overlay is not None:
        session.show_overlay([overlay])
    if blank:
        session.set_blank(True)
    return session.state()


class SafetyTests(unittest.TestCase):
    def test_notes_never_reach_any_public_layout(self):
        # Even a presentation slide with notes used as the overlay must stay clean.
        state = state_with(deck_slide(), overlay=deck_slide(3))
        checked = 0
        for name, layout in LAYOUTS.items():
            if layout.audience != "public":
                continue
            checked += 1
            text = json.dumps(build_payload(state, Output("x", name)))
            self.assertNotIn(SECRET, text, name)
            self.assertNotIn('"notes"', text, name)
        self.assertGreaterEqual(checked, 5)

    def test_stage_layouts_do_get_notes_for_the_base_overlay_and_next_slide(self):
        state = state_with(deck_slide(2), others=[deck_slide(3)])
        for name in ("ppt_notes", "stage"):
            payload = build_payload(state, Output("s", name))
            self.assertEqual(payload["base"]["notes"], SECRET)
            self.assertEqual(payload["next"]["notes"], SECRET)

    def test_every_slide_field_is_deliberately_public_or_stage_only(self):
        fields = {f.name for f in dataclasses.fields(Slide)}
        self.assertEqual(fields, set(PUBLIC_SLIDE_FIELDS) | set(STAGE_ONLY_SLIDE_FIELDS),
                         "A Slide field was added or removed: decide whether public "
                         "outputs may receive it, then list it in outputs.py")

    def test_slide_to_dict_leaves_notes_out_unless_asked(self):
        self.assertNotIn("notes", slide_to_dict(deck_slide()))
        self.assertEqual(slide_to_dict(deck_slide(), include_notes=True)["notes"], SECRET)


class PayloadTests(unittest.TestCase):
    def test_shape_and_json_safety(self):
        state = state_with(verse_slide())
        payload = build_payload(state, Output("proj", "projector", kind="native", screen=1))
        self.assertEqual(payload["schema"], PAYLOAD_SCHEMA)
        self.assertEqual((payload["version"], payload["output"], payload["layout"],
                          payload["audience"]), (state.version, "proj", "projector", "public"))
        self.assertEqual(payload["base"]["segments"], [[16, "verse text"]])
        self.assertEqual(payload["base"]["verse_numbers"], [16])
        self.assertEqual(json.loads(json.dumps(payload)), payload)   # plain JSON types only

    def test_next_and_position_are_for_stage_layouts_only(self):
        state = state_with(song_slide(), others=[song_slide()])
        self.assertNotIn("next", build_payload(state, Output("p", "projector")))
        self.assertNotIn("position", build_payload(state, Output("p", "projector")))
        stage = build_payload(state, Output("s", "stage"))
        self.assertIsNotNone(stage["next"])
        self.assertEqual(stage["position"], {"index": 0, "count": 2,
                                             "overlay_index": None, "overlay_count": 0})

    def test_the_projector_shows_the_base_with_the_overlay_on_top(self):
        payload = build_payload(state_with(deck_slide(), overlay=verse_slide()),
                                Output("p", "projector"))
        self.assertEqual(payload["base"]["item_type"], "presentation")
        self.assertEqual(payload["overlay"]["reference"], "John 3:16")

    def test_song_layouts_show_only_songs(self):
        out = Output("s", "Song-Lower")                     # the hyphenated name works
        self.assertEqual(out.layout, "song_lower")
        self.assertEqual(build_payload(state_with(song_slide()), out)["base"]["text"], "la la")
        payload = build_payload(state_with(deck_slide(), overlay=verse_slide()), out)
        self.assertIsNone(payload["base"])
        self.assertIsNone(payload["overlay"])

    def test_verse_layouts_show_a_verse_whether_it_is_live_or_an_overlay(self):
        out = Output("v", "verse_lower")
        live_verse = build_payload(state_with(verse_slide()), out)
        self.assertEqual(live_verse["base"]["reference"], "John 3:16")
        over_deck = build_payload(state_with(deck_slide(), overlay=verse_slide()), out)
        self.assertIsNone(over_deck["base"])                # the deck is not for this layout
        self.assertEqual(over_deck["overlay"]["reference"], "John 3:16")
        self.assertIsNone(build_payload(state_with(song_slide()), out)["base"])

    def test_ppt_verse_pairs_the_deck_with_a_verse(self):
        payload = build_payload(state_with(deck_slide(), overlay=verse_slide()),
                                Output("pv", "ppt_verse"))
        self.assertEqual(payload["base"]["image_path"], "p/2.png")
        self.assertEqual(payload["overlay"]["verse_numbers"], [16])
        self.assertNotIn("notes", payload["base"])          # ppt_verse is a public layout

    def test_a_peek_shows_the_live_slide_through_the_blank_and_says_so(self):
        state = state_with(deck_slide(), overlay=verse_slide(), blank=True)
        peek = build_payload(state, Output("projector", "projector"), peek=True)
        self.assertIsNotNone(peek["base"])
        self.assertFalse(peek["blank"])
        self.assertTrue(peek["peek_blank"])
        self.assertNotIn("home", peek)
        plain = build_payload(state, Output("projector", "projector"))      # the real screens are still blank
        self.assertEqual((plain["base"], plain["blank"]), (None, True))
        self.assertNotIn("peek_blank", plain)
        unblanked = build_payload(state_with(deck_slide()), Output("projector", "projector"), peek=True)
        self.assertNotIn("peek_blank", unblanked)

    def test_a_verse_over_theme_can_keep_the_verse_off_the_projector_and_on_the_lower_third(self):
        state = state_with(deck_slide(), overlay=verse_slide())
        styles = {7: {"projector_hide": True}, 8: {}}
        for over, hidden in ((7, True), (8, False), (None, False)):
            projector = build_payload(state, Output("p", "projector"), styles.get, verse_over_theme_id=over)
            self.assertEqual(projector["overlay"] is None, hidden, over)
            lower = build_payload(state, Output("lt", "verse_lower"), styles.get, verse_over_theme_id=over)
            self.assertIsNotNone(lower["overlay"] or lower["base"], over)
        self.assertIsNotNone(build_payload(state, Output("p", "projector"), styles.get, verse_over_theme_id=7)["base"])

    def test_blank_hides_public_content_but_not_the_stage(self):
        state = state_with(deck_slide(), overlay=verse_slide(), blank=True)
        public = build_payload(state, Output("p", "projector"))
        self.assertEqual((public["base"], public["overlay"], public["blank"]), (None, None, True))
        stage = build_payload(state, Output("s", "stage"))
        self.assertIsNotNone(stage["base"])
        self.assertTrue(stage["blank"])                     # so the page can say "blanked"

    def test_nothing_live_gives_empty_layers(self):
        payload = build_payload(LiveSession().state(), Output("p", "projector"))
        self.assertEqual((payload["base"], payload["overlay"]), (None, None))

    def test_output_theme_is_passed_through(self):
        payload = build_payload(state_with(song_slide()), Output("p", "projector", theme_id=7))
        self.assertEqual(payload["theme_id"], 7)


class OutputValidationTests(unittest.TestCase):
    def test_good_outputs(self):
        Output("lower-third", "lower_third")
        Output("a1_b", "stage")
        Output("projector", "projector", kind="native", screen=0)

    def test_bad_names_are_rejected(self):
        for name in ("", "Has Space", "UPPER", "-lead", "a/b", "x" * 41, None):
            with self.assertRaises(ValueError, msg=repr(name)):
                Output(name, "stage")

    def test_unknown_layout_lists_the_choices(self):
        with self.assertRaisesRegex(ValueError, "song_lower"):
            Output("x", "nonsense")

    def test_native_outputs_need_a_screen_and_virtual_ones_must_not_have_one(self):
        for bad in (None, -1, True, "1"):
            with self.assertRaises(ValueError, msg=repr(bad)):
                Output("p", "projector", kind="native", screen=bad)
        with self.assertRaises(ValueError):
            Output("p", "stage", kind="virtual", screen=1)
        with self.assertRaises(ValueError):
            Output("p", "stage", kind="hologram")

    def test_every_layout_name_is_a_valid_output_layout(self):
        for name in LAYOUTS:
            self.assertEqual(Output("x", name).layout, name)


class SettingsFileTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.path = self.dir / "nested" / "outputs.json"

    def test_round_trip_and_the_folder_is_created(self):
        outputs = [Output("projector", "projector", kind="native", screen=2),
                   Output("lower-third", "verse_lower", theme_id=4),
                   Output("stage", "ppt_notes")]
        save_outputs(outputs, self.path)
        self.assertEqual(load_outputs(self.path), outputs)

    def test_saving_leaves_no_temporary_files_behind(self):
        save_outputs(default_outputs(), self.path)
        save_outputs(default_outputs(), self.path)
        self.assertEqual(os.listdir(self.path.parent), ["outputs.json"])

    def test_a_missing_file_gives_the_defaults(self):
        self.assertEqual(load_outputs(self.path), default_outputs())
        self.assertEqual([o.name for o in default_outputs()], ["projector", "lower-third", "stage", "confidence"])

    def test_a_damaged_file_is_reported_not_overwritten(self):
        self.path.parent.mkdir(parents=True)
        for content in ("{not json", '{"outputs": [{"name": "x"}]}',
                        '{"outputs": [{"name": "x", "layout": "stage", "bogus": 1}]}',
                        '{"nothing": []}'):
            self.path.write_text(content, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "damaged"):
                load_outputs(self.path)
            self.assertEqual(self.path.read_text(encoding="utf-8"), content)

    def test_duplicate_names_are_refused(self):
        twice = [Output("a", "stage"), Output("a", "projector")]
        with self.assertRaisesRegex(ValueError, "unique"):
            save_outputs(twice, self.path)
        self.assertFalse(self.path.exists())
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps({"outputs": [
            {"name": "a", "layout": "stage"}, {"name": "a", "layout": "stage"}]}), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "unique"):
            load_outputs(self.path)

    def test_default_location_per_platform(self):
        home = "/home/pat"
        self.assertEqual(
            default_settings_path("linux", {"XDG_CONFIG_HOME": "/xdg"}, home),
            Path("/xdg/churchlight-presenter/outputs.json"))
        self.assertEqual(
            default_settings_path("linux", {}, home),
            Path(home) / ".config" / "churchlight-presenter" / "outputs.json")
        self.assertEqual(
            default_settings_path("darwin", {}, home),
            Path(home) / "Library" / "Application Support" / "ChurchLight Presenter" / "outputs.json")
        self.assertEqual(
            default_settings_path("win32", {"APPDATA": "/appdata"}, home),
            Path("/appdata/ChurchLight Presenter/outputs.json"))
        self.assertEqual(
            default_settings_path("win32", {}, home),
            Path(home) / "AppData" / "Roaming" / "ChurchLight Presenter" / "outputs.json")


if __name__ == "__main__":
    unittest.main()
