# Bookmark: the state of the project before the operator UI (2026-10-21)

A clean starting point. If the browser-based operator page is later replaced or joined by a PySide6 (Qt)
window, begin from this point: everything below the line "Operator UI" is untouched by that choice.

## State at this bookmark

- **Code:** 330 automated tests pass on Python 3.11, 3.12, 3.13 (Linux) and, apart from one test bug fixed
  afterwards, on Windows 11 with Python 3.15.0. Standard-library core; optional `pypdfium2` for PDF import.
- **Package layout:** `churchlight_presenter/{core,importers,server,ui}`, `tests/`, `tools/`
  (`selftest.py`, `make_sample_data.py`, `license_headers.py`), `PROJECT.md`, `TESTING.md`.
- **Operator layer:** `ui/controller.py` (`OperatorController`) holds every operator action; `ui/console.py`
  is a terminal front end over it. Any operator UI (browser or Qt) should be a thin front end on the controller.
- **Outputs:** `projector`, `lower-third` and `stage` pages at `/view/<name>`; `?preview` for browser testing.

## Verified by a person on a real PC (Windows 11, Python 3.15.0)

- Install from the zip, health check passes, practice service runs from the console.
- Browser pages update live beside the terminal; themes work.
- **XSplit browser sources: projector, stage and lower third all work.**
- PDF import via pypdfium2 5.14.0 on the tiny test PDF (3 pages, valid PNGs).

## Not yet verified

- A real church PDF (image quality), speaker notes from a real deck on the stage page.
- `.pptx` import (needs LibreOffice installed; its finder is tested only with fakes).
- The person's own songs and Bible files. OBS (same mechanism as XSplit, untested).

## Known gaps in the back end

No editing of songs/decks after import; no settings storage (monitor, port, themes are flags/commands);
no change notifications beyond the web server's; no log file; no song credits line; no undo for service edits;
importers limited to OpenLyrics, Zefania/CSV, PDF/PPTX/images. No video.

## Decision recorded

Operator UI starts as a **browser-based page** served by the existing local server (no install weight, testable
in headless Chromium, usable from a tablet). Reasons and trade-offs:
- Qt adds roughly 150-250 MB, cannot be run in the development sandbox, and needs the person to test each slice.
- A browser page keeps the controller as the single source of truth, so a Qt window can be added later as
  another thin front end.
- Choose Qt instead (or in addition) if a native projector window, global keyboard shortcuts or a real
  desktop-program feel for volunteers becomes a requirement.

## If starting the Qt revision from here

1. Check whether PySide6 installs in the working environment (it did not in the original sandbox).
2. Slices, each small: empty window with library search -> service list -> live controls and slide preview ->
   verse lookup (show/hide/next) -> themes dialog -> projector window (embed the existing output page first) ->
   monitor handling -> keyboard shortcuts.
3. Do not duplicate logic: call `OperatorController` and `build_payload`; subscribe to `LiveSession` for redraws.
4. Network or Qt access must not leak stage speaker notes to public outputs: keep using `build_payload`.

## Open decisions still standing

`AGPL-3.0-or-later` vs `-only`; the `ppt_verse` public layout; relative-only deck paths; `pyproject.toml`
needs package-data for `server/static` and an optional `pdf = ["pypdfium2>=4.0"]` group.
