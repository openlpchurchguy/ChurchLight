# Testing ChurchLight Presenter

> **Which steps still apply.** This guide is in the order things were built. Where a later numbered section
> changes or removes something, the later section wins. These are gone from the program, so skip any older
> step that mentions them: the **Broadcast Integration** tab (now **Alerts Settings**), the Screens list and the
> long Keys paragraph on the Service tab, the typed "Show a verse over a slideshow slide" box and its **V** key,
> the banners across the top (the buttons change color instead), the Arrange panels and saved layouts, the
> separate Timer tab, the text-area checkbox in the theme preview, the Next slide box in the Live panel, and the
> Report list on the Service tab (it is on the Song Library tab).

**Read this first.** This is an early baseline, not a finished program. There is no desktop window yet. You
run a service either from a **control page that opens in its own window** (new, Part 3.6) or by typing short
commands at a prompt, while web pages (the ones XSplit or OBS will show) update live. You are helping us find out two things:

1. Can an ordinary volunteer **install and run** it on a church PC?
2. Does it **behave correctly** when a service is run: songs, Bible verses over slides, speaker notes?

You do not need to understand the code. When something confuses you, that is a result. Write it down.

**Time:** about 45 minutes for everything. **Windows or Ubuntu.** Commands below use Windows paths; on Ubuntu
use `/` instead of `\` and `python3` instead of `python`.

---

## Part 1: Install (15 minutes)

### 1.1 Python

1. Install Python 3.12 or 3.13 from python.org (3.10 or newer works; the newest release is the one least tested with other software). **On the first installer screen, tick "Add python.exe to PATH".**
2. Open a command window (Start menu, type `cmd`, Enter) and type `python --version`.
   You should see something like `Python 3.12.4`.
   - If the Microsoft Store opens, or you see "not recognized", try `py --version`. If that works, type `py`
     wherever this guide says `python`.

### 1.2 The program

1. Make a simple folder such as `C:\ChurchLight`. (Not Desktop or Documents: those may sync to OneDrive.)
2. Right-click the zip, **Extract All**, and choose that folder.
3. Open `C:\ChurchLight` in File Explorer. You must see the folders `churchlight_presenter`, `tests` and
   `tools` **directly inside it**. If you see only one folder (e.g. `churchlight_baseline`), move its contents up one level.

### 1.3 Open a command window *inside* that folder

In File Explorer, with the folder open, **click the address bar at the top, type `cmd`, and press Enter.**
A black window opens and its prompt ends with `...\ChurchLight>`.

> This matters. A command window that opens in `C:\Users\yourname` cannot find the program and says
> *"can't open file ... No such file or directory"*. If you see that, you are in the wrong folder.

### 1.4 Extra software (optional)

Only needed to import **PDF** slideshows. The practice slideshow in Part 3 needs nothing extra. Slide pictures need nothing either.

| To import | You need | How |
|---|---|---|
| PDF | the `pypdfium2` package | In the same command window: `python -m pip install pypdfium2` (one line, no other software; it is free and open-source) |

Slideshows from presentation software: export them as a PDF (or as slide pictures) from that program and import that.

---|---|---|
| PDF | poppler (`pdftoppm` on your PATH) | Ubuntu: `sudo apt install poppler-utils`. Windows has no simple installer. |

---

## Part 2: The health check (2 minutes)

```
python tools\selftest.py
```

It checks the computer, runs about 300 automated tests, and saves a report as `selftest-report.txt`.

**Expected:** a long list ending in `OVERALL: PASS`. These are **normal and not failures**:

- Lines saying node is `NOT FOUND`, and `pypdfium2` says NOT INSTALLED until you do 1.4.
- A number of tests "skipped" (they need those tools, or Windows symbolic links).

Near the end is a section **PDF import (a tiny test PDF)**. With pypdfium2 installed it should say `renderer: pypdfium2; 3 pages` and
three `ok` lines. Without it, it says `skipped`, which is fine. A **Log file** section after it should show two `ok` lines.

**Send us the whole `selftest-report.txt`** (open it in Notepad, copy all, paste into the chat). It contains no
song or Bible text. Anything marked `PROBLEM` or `FAIL` is exactly what we want to hear about.

---

## Part 3: Run a pretend service (15 minutes)

### 3.1 Make practice content

```
python tools\make_sample_data.py --db test.db --media media
```

This makes made-up placeholder songs, a small placeholder Bible (called DEMO) and a 3-slide picture slideshow, and
loads them into a practice database called `test.db`. It needs no extra software.
Expected: `Imported -> songs: 3 imported ...; Bible DEMO: 7 verses; slideshow: 3 pages`.

### 3.2 Start the program

```
python -m churchlight_presenter --db test.db --media media
```

Expected: a line like `Browser sources are served at http://127.0.0.1:8765/`, then a `church>` prompt.
Type `help` any time to see the commands.

If it says `Could not start` and mentions the address or port being in use, add `--port 8800` (or any number
from 8000 to 9000) to the command, and use that number in the browser addresses below.
If Windows shows a Firewall popup, **write it down and choose Cancel/Block**. This program should not need one.

### 3.3 Follow this script

Type each line and press Enter. The right-hand column says what you should see.

| Type | What should happen |
|---|---|
| `new Sunday Morning` | `Started service 1.` |
| `find slideshow` | A list with `Placeholder Slideshow` |
| `add 1` | `Added Placeholder Slideshow.` |
| `find chorus` | One result: `Placeholder Song One` |
| `add 1` | `Added Placeholder Song One.` |
| `addverse jn 3:16` | `Added jn 3:16.` (`add verse jn 3:16` with a space works too) |
| `service` | A numbered list of the three things you added |
| `go 1` | `LIVE [1/…]: Slide 1`; the arrow `>` marks the live item |
| `n` | Moves to Slide 2 (press `n` again for Slide 3) |
| `verse jn 3:16` | `Showing John 3:16 in 2 slides`; the slide underneath **does not change** |
| `vn` | The second piece of the verse; it is marked `(continued)` and still says `John 3:16` |
| `hide` | The verse disappears; the slide underneath is still there |
| `again` | The verse comes back |
| `blank` | Public screens go blank (type `blank` again to bring them back) |
| `status` | Shows what is live, what the verse is doing, and what is next |
| `outputs` | Lists the web addresses of each screen |
| `quit` | Leaves the program |

Mistakes are safe. A typo like `verse jn 9:99` should give a plain message starting with `!` and change nothing on screen.
Typing just a reference, like `jn 3:16`, shows a **preview** only: it lists the slides but puts nothing on screen
and adds nothing to the service. If you type a word the program doesn't know, it says so and suggests `help`.

### 3.4 Look at the screens in a browser

While the program is running, open one of the addresses `outputs` printed in Microsoft Edge or Chrome:

- `http://127.0.0.1:8765/view/stage`: the **stage** page (dark): current slide, next slide, position, verse.
- `http://127.0.0.1:8765/view/projector?preview`: the **projector** page on a blue background.
  **Always add `?preview` when looking at a public page in an ordinary browser.** Without it the page is
  transparent, so you see white text on white and it looks broken. That is by design (XSplit/OBS lay it over video).

Keep these pages open and type more commands at the `church>` prompt. The pages should change within about a second.

### 3.5 Does it remember? (2 minutes)

Type `quit`, start the program again (3.2), then type `services` and `open 1`. Your service should still be there.

### 3.6 The operator page (the control window)

This is the page a volunteer would use to run a service with the mouse and a few keys. It is the same program
underneath, so everything you did with typed commands can be done here.

**First make practice content in the database the start file uses** (once):

```
python tools\make_sample_data.py --db churchlight.db --media media
```

**Then start it.** Either double-click **`start_churchlight.bat`** in the folder, or type:

```
python -m churchlight_presenter --db churchlight.db --media media --open --no-console
```

A plain window with no address bar should open on the control page. (If it opens as a normal browser tab
instead, or nothing opens, the black window prints an address ending in `/operator`: open that in Edge or Chrome.
Write down which happened.) The black window stays open while the program runs: leave it. **Closing it stops the program.**
Press Ctrl+C in it to stop it properly.

Follow this script. The XSplit sources and the browser pages from 3.4 keep working at the same time.

| Do this | What should happen |
|---|---|
| Type `Sunday Morning` in "New service name", click **Start new** | The service appears at the top and in the middle column |
| Click **Add** next to the Placeholder Slideshow | It appears under **Service order** |
| Search `chorus`, click **Add** next to the song | The song appears in the order |
| Open "Add a Bible reference…", type `jn 3:16`, click **Add verse** | A scripture item appears |
| Click **Look** next to the song | Its slides are shown; nothing goes on any screen |
| Click **Go** on the slideshow | The slideshow item turns red with LIVE; the Live column shows Slide 1 |
| Click **Next ▶** (or press the right arrow or Space) | Slide 2; the projector page changes |
| Type `jn 3:16` in the verse box, press Enter | The verse shows in the blue box; the slide underneath is still Slide 2 |
| Press **H** (or click Hide verse) | The verse goes; the slide is still there |
| Click **Show again** | The verse is back |
| Press **B** | An amber banner says the public screens are blanked; the projector page goes empty, the stage page keeps showing |
| Press **B** again | Back to normal |
| Click ↑ ↓ on a service item | The order changes; the live slide does not jump |
| Click ✕ on an item | It is removed; nothing on screen changes |
| Click **Live** next to the song in the library | The song goes live by itself (the Live column says "single item") |
| Close the window and start it again | Your service is still there (choose it in the Service box) |

Things to look for and write down: any button that does nothing; any message in the red box at the top; whether
it is clear what to press next; whether the keys feel right; whether the window is readable from where the
operator sits; and whether pressing Space or the arrows ever does something you did not expect.

If the page says **Not connected**, the black window was closed or the program stopped.

**Arranging the panels (removed in section 3.79; the Service tab layout is now fixed).** The Run page was made of panels: Library, Service order, Verse tray, Live (which now includes
the Bible verse box), and Screens. Press **Arrange panels** at the top. Each panel then shows a **Drag** handle and four
small arrows. Drag a panel by its handle to another place, including an empty column, or use the arrows
(◀ ▲ ▼ ▶) if dragging is awkward. Press **Done arranging** when you are happy; the handles go away so nothing
moves by accident during a service. **Reset layout** (shown while arranging) puts everything back. Your layout is
remembered in this browser, so the operator PC keeps its own arrangement. Check: it survives closing and
reopening the window; the verse tray and previews still work after being moved; and a narrow window stacks the
panels in one column.

**The Library tab.** Left: **Add to the library** with slideshows first, then songs, then Bibles. Right: slideshows, Songs and Bibles in fixed containers; each folds to one line naming what is inside ("2 slideshows", "12 songs", "KJV, WEB"). They cannot be moved. Bibles starts folded. Folds are remembered per browser.

**Fonts.** The operator page is set in Atkinson Hyperlegible (text) with Bricolage Grotesque Bold for headings and the ChurchLight name. The font files and their licenses are included in `churchlight_presenter/server/static/fonts`. Check: headings and the name are in Bricolage; body text, buttons and song titles are Atkinson; the song editor's words box stays a fixed-width font; everything fits at all three text sizes and on a half-width window.

**Appearance.** The **Appearance** button in the header opens a small panel: Colors (Auto follows the computer's light/dark setting, or force Light or Dark), Text size (Small, Medium, Large), Accent color (blue, green, purple, orange) and High contrast. Choices are kept in that browser only. Check: switch each option and look at every panel, the song editor window, the Library tab and a folded panel in both Light and Dark; nothing should be hard to read; the live and next-slide boxes stay dark in Light; the screens in XSplit/OBS do not change. Tell me about any text that is hard to see. Reset by clearing the site's data or choosing Auto, Medium, Blue and unticking High contrast.

**The song editor and drafts.** **New song** sits on the title line of the Run page's Library panel and of the Library tab's Songs container, so it is still there when they are folded; **Edit** is beside each song. The editor is a window over the right-hand column (Screens by default), not a blocking popup: Live and the service order stay clickable beside it. Check: with the editor open, Next, Previous and Blank still work with the mouse; typing a space in the words box does not advance the slide; **–** shrinks it to a bar at the bottom ("Song title (unsaved) Resume / Discard"); closing the browser tab and reopening shows the bar again with your text. Three ways to finish: **Save** (a finished song), **Save and add to service** (saved, then added right after the item that is live, or at the end), **Save as draft**. Drafts appear only in the **Drafts** container on the Library tab, never in the Run page search, and cannot be added to a service or sent live; **Publish** turns one into a normal song, and editing a draft then pressing Save also publishes it. A song already in a service cannot be turned back into a draft. Cancel with unsaved changes asks "Discard changes?" first.

**Importing other song formats.** On the Library tab, **Choose song files…** now takes: plain text `.txt` (a CCLI SongSelect lyrics download works: title on the first line, headings like "Verse 1" and "Chorus", the CCLI number and author at the bottom), OpenLyrics `.xml`, OpenSong files (no file extension), and ChordPro `.cho`. Chords are dropped. Check with a few real files from your church or from SongSelect: the title, parts and order should look right in the song editor, a chorus listed twice should appear once and repeat in the order, and the CCLI number and author should be filled in. Lyrics with no headings import as Verse 1, Verse 2 and so on. Send me any file that comes out wrong.

**Book autofill.** In the tray box and the verse box, type any beginning of a book and a chapter: `lev 3` is Leviticus 3, `rev 21` is Revelation 21. A gray "→ Leviticus 3" line under the box shows how it will be read. When a beginning fits several books, the first in Bible order wins (`jo` is Joshua, `ph` is Philippians), so type a little more to reach another (`joh` John, `phile` Philemon). Check: the hint matches what loads.

**The start page.** With no service open, the Run tab shows only a start page: a box to start a new service, a list of earlier services to open, and a button for the Library. The rest of the Run page appears once a service is open. Check: a fresh start shows only this page; starting or opening a service reveals the board.

**Folding panels and half-screen use.** Library, Service order, Verse tray and Screens have a small ▾ button (or click
the title) that folds them to one line; the line then shows a summary (for the tray, e.g. "John 3 (KJV) · 9 verses ·
live: 5, 6"). Live never folds. Folds are remembered per browser; **Reset layout** unfolds everything. The / , T and G
keys open a folded panel first. Check: make the window about half the screen wide. Everything stacks in one column with
Live first, then Verse tray, Service, Library, Screens, and nothing needs sideways scrolling. The library search starts
as just the bar; **Show all** lists everything and **Clear** (or Esc in the box) returns to the bare bar.

**The verse tray.** Under the service order is a **Verse tray** for getting a chapter ready before you need it.

| Do this | You should see |
|---|---|
| Type `John 3` in the tray box and press Enter (use a Bible you imported) | The whole chapter listed, one verse per line. Nothing goes on screen |
| Click the words of one verse | That verse goes over the slide: the title `John 3` on top, then `16) For God so loved...`. The slide underneath does not move, and the verse is outlined in the tray |
| Press **Verse ▶** (or the full stop key) and **◀ Verse** (or the comma key) | The next or previous verse replaces it, with the same title. At the ends a message says so |
| Tick two or three verses (Shift-click ticks a run) and press **Show over slideshow** (only offered while a slideshow slide is live) | They share one screen if they fit, each starting with its number |
| Press **Hide verse** (or H) | The verse goes away; the tray keeps its place |
| After loading, type `16` in **Go to verse** (the cursor is already there; the G key brings you back to it) | Verse 16 is ticked and the tray list scrolls to it. **Nothing** changes on screen or in the service |
| Type `16-18`, or `16, 18`, or a verse the chapter does not have | Those verses are ticked; a missing one is named under the box |
| Press Enter in that box | **Enter** cues: the ticked verses go into the service (one verse adds the rest of the chapter after it) and a "Ready" line appears under the tray. Nothing on screen changes. **Enter again** (same ticks) puts it live in place of what is showing; there is no timer. **Shift+Enter** does both at once. Esc clears Ready. See 3.32 |
| Press **Add to service** (or the **+** on one verse) | The verses are added to the service order, and **nothing changes on screen**, even while something is live. Verses side by side become one item (John 3:16-18); separate ones become separate items |
| Press **Add whole passage to service** | The whole loaded passage is added as one item |
| Run a service item that came from the tray | It looks the same as in the tray: `John 3` above, `16) text` below |
| Type `John 3:16-21` in the tray box | Only those verses are listed |
| Look at the lower-third address in XSplit or OBS | Same title and numbered lines; the stage page shows them too |

Things to write down: whether the title and numbers look right on your real lower third; whether a long verse splits
sensibly (use the small arrows in the verse box to move between the pieces); and whether you ever wanted to hold
verses from two different chapters at once (the tray holds one chapter or range at a time for now, and is emptied when
the program closes).

**Screens and previews.** At the bottom of the Live column is a **Screens** list with one line per output
(projector, lower-third, stage). Each line shows who it is for, what it is doing (On screen, Idle, or Blanked
in orange) and its address. Press **Blank screens** and check the public lines turn orange while the stage line
does not. Press **Preview** on a line to show a small live copy of that screen under the list, and **Hide
preview** to remove it. At most three can be open at once. Your choice is remembered next time. If the window is
minimized the previews are dropped and come back when you return. Write down whether the preview slows the
computer down, especially with big PDF slideshows and XSplit running at the same time.

### 3.7 Adding to the library from the control page

Click the **Library** tab at the top of the control page. From here no command window is needed.

| Do this | What should happen |
|---|---|
| Click **Choose song files…**, pick the song `.xml` files (hold Ctrl or Shift to pick many) | "Uploading 1 of N…", then under **Recent imports** a green DONE line such as "Added 3 songs"; the songs appear under **Songs** |
| Pick the same files again | DONE, "Added 0 songs, 3 already there" (nothing is doubled) |
| Type a short name such as `KJV` in the Bible box, click **Choose a Bible file…**, pick a Bible `.xml` or `.csv` | DONE, "Installed KJV: … verses"; it appears under **Bibles** and in the verse box on the Run service tab |
| Type a name, click **Choose a PDF…**, pick a `.pdf` | DONE, "Added a slideshow of N pages"; it appears under **slideshows** |
| Try to add a presentation file that is not a PDF or a picture (drag one onto the page) | The page says it is not a kind of file this import accepts |
| Click **Choose slide pictures…** and pick several exported slide images | A slideshow of those pages |
| Click **New song**, fill in the title, type or paste words as shown in the gray example, click **Save song** | The green line under the box says how many parts it found; after saving the song is in the list and searchable on the Run service tab |
| Paste lyrics with no `[headings]` | They become Verse 1, Verse 2… at each blank line |
| Type `Order: Z` where there is no part Z | A red line says exactly what is wrong; nothing is saved until it is fixed |
| Click **Edit** on a song, change a word, save | The change shows at once. If that song is in the open service, the live slide updates in place |
| Click **Delete** on a song (click **Sure?** within 4 seconds) | The song is removed |
| Try to delete a song that is in a service | The button is grayed out: "used in 1 service". Remove it from the service first |
| Click **Rename** on a slideshow, type a name, press Enter | The name changes |
| Pick a file of the wrong kind (for example an `.exe`) | A red message says which kinds are accepted; nothing is uploaded |
| Import something that cannot be read | A red PROBLEM line with the reason; click **Details** for more |

The first time a Bible is added, the verse box on the Run service tab shows its short name. Big slideshows take a little
while: the Run service tab keeps working during an import, so you can leave this tab and come back.

Write down anything confusing: wording, which button you expected, whether the example in the song box was clear.

---

### 3.8 Slide transitions (projector only)

A slideshow can change with a **dissolve** or a **circle wipe** instead of just switching. It is chosen per slideshow.

| Do this | You should see |
|---|---|
| Library tab, find the slideshow, and under it choose **Dissolve** | The line now says "Dissolve, 0.5 s", and the seconds box turns on |
| Type `1.3` in the seconds box and press Enter | "Dissolve, 1.3 s". The time goes from 0 to 2 in steps of 0.1 (0 means no transition). A time outside that is refused with a message |
| Run the slideshow and press Next, watching the **projector** address (`/view/projector`) | The new slide fades in over the old one |
| Try **Circle wipe, out** | The new slide grows from a circle in the middle |
| Try **Circle wipe, in** | The old slide closes down to a circle, uncovering the new one |
| Press Next twice quickly | The first transition finishes at once; nothing gets stuck half-way |
| Show a Bible verse over a slide | The verse appears at once; the slide does not redo its transition |
| Look at the lower-third and stage addresses | They change instantly, as before |

The next and previous slide pictures are fetched ahead of time so a transition does not start on an empty frame.
Write down: whether a long transition feels too slow in a real service, whether a big PDF makes the first transition
stutter on the church PC, and whether XSplit shows the circle wipes smoothly (it uses an older web engine than a
browser does).

**Advice for slideshows:** a PDF works best. Export your slides as a PDF (or as slide pictures) from your presentation software and import that. Transitions and
animations set inside that software are not carried over; use the choice here instead. A PDF carries no speaker notes.

### 3.9 The Themes tab

Back up `churchlight.db` first: this version adds a small settings table to it (a database upgrade, the third so far).

1. Open the **Themes** tab. On a first run you should see five starter themes (Classic white on black, Deep blue, Lower third band, Large print, Warm paper).
2. Click one. Change the text size, the color, the alignment. The preview on the right changes straight away, and the state next to the name says "Unsaved changes". The real screens do not change yet.
3. Click the sample buttons (Lyrics, Lyrics lower third, Bible verse, Announcement) and check each looks right.
4. Press **Revert**: your changes go away. Change something again and press **Save**: screens already showing that theme change.
5. Try **New theme**, **Duplicate**, and **Delete** (press twice to confirm). The list says where each theme is used.
6. Under "Where themes are used", pick a **Bible verses on the projector** theme. Add a Bible verse to a service and show it from the verse tray: on the projector page both should use that theme, while the lower-third page keeps the service's theme. Then pick a different theme on that one item in the Run tab: the item's own theme wins.
7. On the Run tab, pick a **Theme for this service**; each item has a small theme drop-down (blank means "follow the service", or the Bible theme for verses).
8. Try to switch to another theme while this one has unsaved changes: you should be told to Save or Revert first.

Not in this version: pictures or GIF backgrounds, per-screen theme overrides in the page, and fine tweaks on the Run tab.

### 3.12 Theme kinds and the confidence monitor

1. Open the Themes tab. The list is grouped: Projector, Overlay (lower third) and Confidence monitor themes. The first run after upgrading adds the overlay and confidence starter themes once; existing themes become projector themes.
2. Press New theme. The first question is "What output is this theme for?". Pick Overlay: the controls change to include "Where the box sits" (up and down, left to right, box width, gap). Pick Confidence monitor: only large-text controls remain. After the first Save the kind is locked.
3. On the Run service tab pick a Projector theme and an Overlay theme for the service. Each song or verse row has two small selects to override either for that item. Slideshows have none.
4. Open `/output/confidence` (or add a screen) on a monitor. A slideshow mirrors the slideshow; a song or verse shows large plain text. When the projector is blanked it keeps showing, with a red "PROJECTOR IS BLANKED" flag.
5. The confidence look is set only in the Themes tab ("Confidence monitor uses").
6. A custom `outputs.json` written before this version has no confidence output; add `{"name": "confidence", "layout": "confidence"}` to it.

### 3.10 Timed slides, looping and endings

Back up `churchlight.db` first (a fourth database upgrade adds two columns to slideshows).

1. **Library tab > slideshows:** under a slideshow, set "Timed advance" to a number of seconds (try 5). 0 means manual, as before. Choose what happens at the end: stay on the last slide, loop back to the first, blank the screens, or move on to the next service item.
2. Put the slideshow in a service and press **Go**. The Run page shows "Timer running" and the slides change by themselves. Pressing Next or Previous yourself starts a fresh delay on the slide you land on.
3. Press **Pause timer**: the slides stop moving. **Resume timer** gives the current slide a full delay again.
4. The countdown also holds while the screens are blanked, while a Bible verse is showing over the slide, and when something else goes live. It starts again by itself when you return to the slideshow.
5. Try each ending. "Loop" stays inside that slideshow even when other slideshows follow it in the service. "Move on to the next service item" carries on into whatever comes next (a song, another slideshow) and stops there if the next item is manual or there is nothing after it.
6. In the service list, a slideshow has a Timing drop-down: "slideshow setting" or "set for this service". The second lets this one service use its own seconds and ending (say, loop the welcome slides here only). Change it back to the slideshow setting to undo.
7. The slide change uses the slideshow's transition from Section 3.8, so test the two together (try Dissolve with a 5 second delay).

For the church's service: the welcome slideshow gets, say, 8 seconds and "Loop"; the offering picture and invitation slideshows stay manual.

### 3.11 Song editor: order box, CCLI numbers, and parts per service

1. **New song** (Library tab or Run page). The window now has a CCLI song number box next to the author, and the order of the parts is its own box under the words. Paste lyrics with `[Verse 1]`, `[Chorus]` headings and no `Order:` line.
2. Under the order box, click the part names in the sequence you want (Verse 1, Chorus, Verse 2, Chorus...). Each click adds one to the box. The green line below shows the order it understood. Type or edit the box by hand if you prefer.
3. Leave the order box empty and each part is sung once, top to bottom. Type a name that does not exist and the line says which one.
4. Save. In the Library the song lists its CCLI number, and the song filter finds it by that number too. Reopen it: the order and number come back.
5. **Church CCLI license number:** in the Songs container on the Library tab, enter the church's number once and Save. It is stored only; nothing appears on screen.
6. **Parts per service:** put a song with four verses and a chorus in a service. Press **Parts** on its row, then untick the parts this service skips (for example verses 2 and 3 and their choruses). The row says "4 of 8 parts", and Go shows only the ticked parts, in order. **Sing the whole song** puts everything back.
7. The choice belongs to that one service item. The same song in another service, or added twice, is unaffected. If you later edit the song so its order has a different length, the choice resets to the whole song instead of guessing.
8. Old unsaved songs kept in the browser and songs saved with an `Order:` line still open correctly.

## Part 4: Try your own files (the most valuable test)

Do this if you have real song, Bible or slideshow files. (To add them to the library itself, use the Library tab
described in 3.7, or the commands at the end of this part.) The health check below uses a throwaway database and
never touches your real one.

```
python tools\selftest.py --songs "C:\path\to\songs-folder" --bible "C:\path\to\bible.xml" --deck "C:\path\to\sermon.pdf"
```

Use any one, two or all three options. Send us the whole report; it contains counts, timings and the names of
files that failed (with the reason), but never lyrics or verses. For songs, look at the "slides per song" line:
a typical song should be a handful of slides, not dozens.

What the program can read right now: songs in **OpenLyrics** `.xml`; Bibles in **Zefania** `.xml` or `.csv`
(`book, chapter, verse, text`); slideshows as `.pdf` or slide pictures (see 1.4 for what to install).

To run a service with your own content, import it instead of the practice data:

```
python -m churchlight_presenter.importers.songs "C:\path\to\songs-folder" --db test.db
python -m churchlight_presenter.importers.bibles "C:\path\to\bible.xml" --abbr KJV --db test.db
python -m churchlight_presenter.importers.decks "C:\path\to\sermon.pdf" --db test.db --media media
```


---

## Part 5: What to check in XSplit or OBS (if installed)

Add a **Browser / Web source** with the address `http://127.0.0.1:8765/view/projector` (no `?preview`), size
1920 x 1080. Keep the program running and type commands. Check:

- The page background is **transparent** over your video.
- Text is a readable size and in the right place for each layout (`projector`, `lower-third`, `stage`).
- A verse shows over a slide and disappears when you type `hide`, with the slide behind it unmoved.
- **Speaker notes appear on `stage` and never on `projector` or `lower-third`.** (Needs a slideshow with notes, see Part 4.)

Try a look: `theme Warm color=#ffeecc font_size=8 align=left`, then `usetheme projector 1`.

---

## Part 6: Keep a log as you go (this becomes the volunteer guide)

For each step, write a few lines. Rough notes are fine:

```
STEP:                  (e.g. "1.3 open the command window in the folder")
WE TYPED / CLICKED:
WE EXPECTED:
WHAT HAPPENED:         (exact message, or a screenshot: Windows key + Shift + S)
WHAT THE TESTER ASKED OR WAS CONFUSED BY:   (her words)
WHAT THE HELPER HAD TO EXPLAIN:
FIX / WORKAROUND:
```

The two "confused" and "had to explain" lines are the most valuable: they become the warning boxes in the guide.
The helper should wait a moment before stepping in, and note what the tester tried first.

### Snags we already expect

| You see | Why | Do this |
|---|---|---|
| `can't open file ... No such file or directory` | Command window is in the wrong folder | Part 1.3: open it from the address bar |
| Microsoft Store opens when typing `python` | Windows's fake shortcut | Use `py` instead |
| `python` or `py` "not recognized" | PATH box not ticked at install | Reinstall Python and tick "Add python.exe to PATH" |
| Projector page looks empty or white-on-white | It is transparent on purpose | Add `?preview` to the address |
| `Could not start: ... Address already in use` (Windows says `WinError 10048` or "only one usage of each socket address") | Another program, or a second copy of this one, holds port 8765 | Add `--port 8800` to the start command |
| "needs a PDF renderer" | pypdfium2 not installed | `python -m pip install pypdfium2` |
| `pip` says "not recognized" | Wrong spelling | Use `python -m pip install pypdfium2` exactly |
| The control window opens as an ordinary browser tab, or not at all | No Edge or Chrome found at the usual place | Open the address ending in `/operator` that the black window printed |
| The control page says "Not connected" | The black window was closed or the program stopped | Start it again |
| Strange characters in the console | Old Windows console font/encoding | Write down the exact line and report it |

---

## Part 7: What to send back

1. The whole `selftest-report.txt`, and `churchlight.log` (it is made beside your database file, for example
   `C:\testing\churchlight.log`; the program prints its location when it starts). The log records what happened, such as
   which service was opened and any error, but not song, verse or announcement text. Glance through it before sending anyway.
2. Your Windows (or Ubuntu) version and Python version (the report shows both).
3. Your filled-in log, or just the steps that went wrong: what you typed, what you expected, what happened.
4. Screenshots of any error, and of the stage and projector pages if they looked wrong.
5. Wishes: what would you want on the screen the operator uses?

## Known limits

The operator control page runs in a browser window; there is no native desktop window or native projector window yet. No video playback. Songs: OpenLyrics only. Bibles: Zefania XML
or CSV only. PDF import needs the pypdfium2 package (one pip command). Tested so far on
Linux (Python 3.11 to 3.13) and Windows 11 (Python 3.15, health check only). See `PROJECT.md` for the design.


## Before calling it finished (to do near the end)

- **Sleep and reconnect:** close the laptop lid mid-service-prep, reopen it, and note whether the operator page reconnects by itself, and whether XSplit/OBS screens recover. Turn off sleep for the service-day PC. Consider a clear "program stopped" message on the page.

- **KJV: DONE.** `content/bibles/kjv.csv` (eBible.org eng-kjv2006, public domain in the US) is bundled with its checksum and `content/NOTICES.txt`; it installs on first run when no Bible exists (`ensure_bundled_bible`). Still to do for the inner circle: keep `NOTICES.txt` in every package, and do not bundle NIV/ESV/NLT/NKJV/NASB. Check every Zefania file's license before using it.
- **Themes:** check each starter theme on the real projector PC; the fonts named in a theme (Arial, Georgia, Calibri...) must be installed on the PC that runs XSplit/OBS. Decide whether to keep the five starters.
- **Fonts:** the font files and `OFL-*.txt` licenses are bundled in `static/fonts`; keep the licenses with the fonts in every package, and check the Library tab and editor at all three text sizes.

### 3.13 Projector background picture and band

1. Themes tab, open a projector theme. Under Backgrounds press Choose picture… and pick a PNG, JPG, GIF or WebP (up to 25 MB). The preview shows it at once; nothing reaches the screens until Save.
2. Try "Picture size" (Fill crops the edges; Fit shows all of it) and "Darken the picture".
3. "Band behind the text" now draws a translucent box behind the words on every full-screen projector slide, so they stay readable over any picture. Uncheck it for plain text. (Verses shown over a slide or slideshow still use the band too.)
4. Remove deletes the picture from the theme; pictures no theme uses are cleaned up automatically (a fresh upload is kept for an hour so unsaved edits are safe).
5. Pictures are for projector themes only; overlay and confidence themes ignore them. Slideshow slides that are pictures are never covered by the band.

### 3.14 Bible title size and verse-number font

1. Themes tab, open any theme, group Bible verses. "Book and chapter size" sets the "John 3" title above a passage (default 1.2 = slightly larger than the verse text). "Verse number font" sets the font of the numbers (default Segoe UI, a sleek one); "Same as the verse text" turns the separate font off.
2. Check the preview with the Bible verse sample, then Save and put a passage live. The reference line shown under a single verse still follows "Reference size".
3. The font must be installed on the projector PC; if it is not, the browser falls back to a plain sans-serif.

### 3.15 Themes tab layout

The Edit theme and Preview panes sit side by side on top (half the width each; the edit pane scrolls inside itself). A fixed panel about a third of the screen tall sits along the bottom. On its left, "Where themes are used" (the global choices; the explanation is under "How these work"). On its right, "Show" chooses Projector, Overlay or Confidence monitor (each with its count) and "Filter by name" narrows the list. The list is compact cards in columns that scroll inside the panel: themes in use first ("In use"), then "Not used yet", each section alphabetical. Pressing a theme edits it; choosing a theme or starting a new one switches "Show" to its kind. New theme is at the top right of the Edit pane. On a narrow window the panes stack.

### 3.16 The new tabs

**Names in older sections:** "Run service tab", "Run tab" and "Run page" now mean the **Service** tab; "Themes tab" means **Theme Library**; "Library tab" means the Song, Slideshow or Bible Library that holds the thing in question (songs and drafts: Song Library; slideshows and their timing: Slideshow Library; Bibles: Bible Library).

The tabs, left to right: **Service, Theme Library, Song Library, Slideshow Library, Bible Library, Broadcast Integration.**

1. **Song Library:** "Add songs" (Choose song files…) and its Recent imports on the left; Songs (with New song, the church CCLI number) and Drafts on the right.
2. **Slideshow Library:** "Add a slideshow" (a PDF or slide pictures, with an optional name) and Recent imports on the left; the slideshows with timing, ending and transitions on the right.
3. **Bible Library:** "Add a Bible" (short name, full name, file) and Recent imports on the left; installed Bibles on the right. Each import list shows only its own kind of import.
4. **Service tab, Screens panel:** one plain line per output saying what it shows now, for example "projector: Amazing Grace, Verse 1, with John 3:16 (KJV) over it", "lower-third: John 3:16 (KJV)", "projector: Blanked (nothing shown)", "stage: Nothing on this screen". The **Broadcast Integration →** button opens the Broadcast page.
5. **Broadcast Integration:** **← Back to Service** at the top; a line for what is live with a Blank / Show screens again button; the full list of screens with their addresses for XSplit/OBS and the Preview buttons. Previews run only while this page is open.
6. With no service open, the start page has Song Library, Slideshow Library and Bible Library buttons.

**Service picker:** the Service drop-down and "Start new" form now sit at the top of the Service order panel on the Service tab, not in the header, so they no longer show on the other tabs.

### 3.17 The calmer Service tab

Three columns: **Service order | Live | Bible** (with the Screens text list under Bible).
1. **Service order:** a slim line says which service is open and its two themes; **Change** opens the service picker, "Start new" and both theme selects, and **Done** closes them. Each item is one clean line: title, Go, up, down, **⋯** and remove. The live item is highlighted and the one after it is marked **NEXT**. **⋯** opens that item's own projector and overlay themes, timing (slideshows) and parts (songs); a dot after the ⋯ means the item has its own theme. An open ⋯ stays open while the service runs.
2. **Bible:** the verse box (with Show, hide, previous and next piece) and the verse tray are together in one panel.
3. **Add from library →** (top of Service order) opens a full page with search, Look, Add, Live, New song, and the forms for adding a Bible reference or an announcement. The service so far is listed on its right, and **← Back to Service** is at the top left. **← Back to Service**, Esc in an empty search box, or Esc elsewhere goes back. The **/** key from the Service tab opens it with the cursor in the search box.
4. Arrange panels still works; the layout is saved afresh (old saved layouts are ignored once).

**Service tab, revised again:** three columns. Left: a small **Songs and slideshows** window (a search bar and a Search button only) above the **Bible** panel (verse box and verse tray). Middle: **Live** with **Screens** under it. Right: **Service order** alone. Type a name in the search bar and press Enter or Search: the Add from library page opens with that search already run. The `/` key puts the cursor in the search bar. The old Add from library button on the service panel is gone. The layout is saved afresh again (old saved layouts are ignored once).

**Verse tray cursor:** type a chapter such as `John 3` in the tray's book-and-chapter line and press Enter: the passage loads and the cursor jumps to "Go to verse" every time, even when the computer is slow. Type verse numbers (`16`, or `16-18`) and press Enter to add them, Enter again to show them.

**Verse over the slide moved:** the box for showing a Bible verse over the current slide is now on the Broadcast Integration tab (with Hide verse, Show again and the previous/next piece buttons). The Bible choice stays on the Service tab, in the Bible panel above the verse tray; the Broadcast tab says which Bible it will use. On the Service tab, **V** opens the Broadcast tab with the cursor in the verse box; **H** hides the verse, and **[** and **]** step through its pieces, from the Service tab. A verse that is showing still appears in the Live panel's "over" box and in the Broadcast "now live" line.

### 3.18 The slideshow editor (Stage A)

On the **Slideshow Library** tab, each slideshow has a blue **Edit slideshow** button. It opens a full page (no tab of its own) with **← Back to Slideshow Library** at the top left; Esc also goes back.
1. **Thumbnail grid:** every slide is numbered. Click selects one, **Ctrl-click** adds or removes one, **Shift-click** selects a range, **Select all** selects everything. The first slide is selected when the editor opens.
2. **Reorder:** **← Earlier** and **Later →** move the selected slides one place (a block stays together). You can also drag the selected slides: a blue bar shows where they will land. Check that a service using the slideshow shows the new order on the Service tab.
3. **Duplicate** copies each selected slide right after the original and selects the copies. **Delete** needs two clicks ("Sure?") and cannot remove every slide. Deleting a slide removes its picture file only if no other slide uses it.
4. **Skip:** a skipped slide is dimmed and marked "Skipped" in the editor, stays in the slideshow, and is passed over when the slideshow runs (Live, Next, the outputs and the service order all leave it out). The button then reads **Put back**. At least one slide must stay un-skipped.
5. **Speaker notes:** select one slide, type notes, press **Save notes** (or Ctrl+Enter, or click away). Notes show in the Live panel when that slide is live. The notes box is off when several slides are selected.
6. **Used in:** under the title it lists the services that use the slideshow and says changes apply to all of them. Edits are made on the slideshow itself (edit in place).
7. **Live lock:** while any slide of the slideshow is on the outputs (even blanked) the editor shows an orange banner and every change button, dragging and the notes box are disabled; the Edit slideshow button in the list is disabled too. Clear the output or go to a different item and it unlocks. Other slideshows can still be edited.
8. Not in Stage A (coming next): adding or replacing pictures, adding slides from another slideshow, splitting a slideshow, and per-slide delay and transition.

### 3.19 The slideshow editor (Stage B): bring slides in, make new slideshows

The second row of buttons in the editor:
1. **Add pictures…** pick one or many pictures (png, jpg, gif, webp, up to 25 MB each). They are added after the selected slide (or at the end if none is selected), in file-name order (`slide2` before `slide10`), and the new slides are selected.
2. **Replace picture…** (one slide selected) pick one picture: the slide keeps its place, notes and Skip setting. The old picture file is deleted unless another slide still uses it.
3. **Add slides from another slideshow…** choose the other slideshow from the list, click the slides you want (or **Select all**), press **Add**. They are copied after the selected slide with their notes. The other slideshow is not changed and may even be live; this slideshow may not.
4. **Make a new slideshow from selected…** (any slides selected) type a name (it starts as "<slideshow> (part)") and press Create. The new slideshow appears in the Slideshow Library. The original is unchanged, and this also works while the slideshow is live.
5. Copies share the picture files with the original. Deleting the original slideshow or slide keeps any picture a copy still uses, and re-importing the same file later does not damage them.
6. While the slideshow is live, Add pictures, Replace and Add slides from another slideshow are disabled (and the editor says why); Make a new slideshow still works.
7. Skipped slides copied into another slideshow arrive un-skipped (you chose them).

### 3.20 The slideshow editor (Stage C): a delay and a transition for each slide

In the editor's side panel, under **Timing** (works on every selected slide at once):
1. **Delay on the selected slides:** *Follow the slideshow* (the default), *Wait until Next is pressed* (this slide stays up even if the slideshow is timed), or *Move on after… N seconds* (1 to 600). A line under the controls says what "follow the slideshow" means for this slideshow.
2. **Transition into the selected slides:** *Follow the slideshow*, *None (cut)*, *Dissolve*, *Circle wipe, out* or *Circle wipe, in*, with a length of 0 to 2 seconds in steps of 0.1. The transition is how the projector changes **to** that slide.
3. If the selected slides differ, the box says **Mixed**; picking anything else sets them all. Setting a slide back to *Follow the slideshow* removes its own setting.
4. The thumbnails show small labels: *Waits*, *8 s*, *Dissolve*, *Cut*, along with *Skipped* and *Notes*.
5. **Which setting wins:** a slide's own setting beats the service's setting for that slideshow (the **⋯** options on a service item), which beats the slideshow's setting. The ending (stop, loop, blank, next item) still comes from the service or slideshow.
6. Try it: make a slideshow timed at 3 s, give slide 2 *Wait until Next is pressed*, and run it from a service. The slideshow should advance by itself to slide 2 and stay there until you press Next; then the 3-second timing carries on. Give one slide a Dissolve in a slideshow with no transition and check only that slide dissolves in on the projector (other outputs always cut).
7. A slideshow that is live cannot be changed, so these controls are off while it is.
8. Duplicate keeps a slide's own settings. Slides copied from another slideshow, or split into a new slideshow, start by following the new slideshow.
9. Skipped slides keep their settings; they come back with them when put back.


### 3.21 Search suggestions and slideshow names

1. **Dropdown while you type:** click in the Songs and slideshows search box on the Service tab (or the search box on the Add page). With the box empty, a list headed **Used recently** shows the songs and slideshows from your latest services. Type, and after a moment a list of names appears: **only the name** of each song or slideshow.
2. **Numbers:** a number at the start of a title counts as the song's number, ignoring leading zeros. Type **55**: "055 …" comes first, then "550 …" to "559 …", then "5500 …" and so on in number order. "155" and "560" are not offered. A title such as "10,000 Reasons" or "55th Anniversary" has no number. Then come names that start with what you typed, names with a word that starts with it, and finally songs found by author or lyrics. At most 8 are shown. Drafts never appear.
3. **Keyboard:** Up and Down move through the list (wrapping round). **Enter** on a highlighted row adds that song or slideshow to the end of the service and clears the box. **Enter with no row highlighted** does what it did before (opens the Add page with your search). **Esc** closes the list first; a second Esc does what Esc did before. Clicking a row adds it too. Clicking elsewhere closes the list.
4. A message says "Added … to the service". On the Add page the box also clears and the list goes back to the bare search.
5. **Slideshow names:** slideshows made by uploading slide pictures are now named after the picture's file name (one picture) or "Slide pictures 2026-10-26" (several), not the random name of the temporary upload folder. A name typed in the Name box still wins.
6. **Rename:** a **Rename** button next to the title in the slideshow editor (and the existing Rename in the Slideshow Library list) changes a slideshow's name. Enter saves, Esc cancels. Renaming is allowed while the slideshow is live because it does not change the slides.

### 3.22 Arrow keys: slides and service items

On the Service tab (not typing in a box):
1. ↓ (or Space / Page Down) goes to the next slide of the live song, verse or slideshow; ↑ (or Page Up) goes back one slide.
2. → goes live on the first slide of the next service item; ← the previous item.
3. With nothing live, → starts at the first item; ← does nothing.
4. At the last item → stays put, and at the first item ← stays put.
5. Typing in a search or text box: arrows do not move the service.

### 3.23 Load and add a whole passage in one step

With a service open, on the Service tab:
1. Press T (focus the Bible tray box), type `John 3`, press Ctrl+Enter (Shift+Enter also works). The chapter loads in the tray and is added to the service as one item; nothing changes on screen.
2. The "Load + add to service" button does the same. Plain Enter / Load still only loads the tray.
3. With no service open, Ctrl+Enter shows an error and the tray is left unchanged.

### 3.24 Default Bible and verses over slideshows only

1. The Service tab no longer has a Bible version box. Open the Bible Library tab (unfold Bibles): each Bible has "Use for verses"; the chosen one shows "Default" and is remembered after a restart. Typed verses and the tray use it.
2. With a song, a verse item or nothing live, the "Show a verse over a slideshow slide" block on the Broadcast tab, the tray's "Show over slideshow" and the tray's Verse ◀ ▶ buttons are not shown at all. They appear when a slideshow slide goes live. The V key then says why it cannot.
3. Put a slideshow slide live: they work. Move to a song while a verse is on screen: the verse comes down by itself and is not brought back over the song.
4. Adding a verse or passage to the service (Add to service, Ctrl+Enter) still works at any time.

### 3.25 Broadcast page keys and customizable shortcuts

1. On the Service or Broadcast Integration tab (click empty space first so no box has the cursor): ↓/Space/Page Down next slide, ↑/Page Up previous, → next service item, ← previous item, B blank, H hide verse, V jumps to the verse box. T, G and / do nothing here (they belong to the Service tab).
2. The four buttons (◀ Item, ◀ Slide, Slide ▶, Item ▶) do the same with the mouse.
3. On the **Shortcuts** tab, under "Keys for running the service", press Change on a row, then a key (try F8). The row shows the new key and it works at once; the old key no longer does.
4. Giving a key that another action uses moves it there and says so; if that other action would be left with no key, the change is refused with a note. Esc, Tab, Enter and Ctrl/Alt combinations are refused; Esc cancels.
5. Reload the page: the choices are kept (per browser). "Reset all shortcuts" restores the standard keys.

### 3.26 Global shortcuts (Windows PC only; not testable on Ubuntu)

The mapping, switching and page are tested with a fake backend. The real key claim (`WindowsBackend`, ctypes `RegisterHotKey`) must be tried on the Windows 11 PC:
1. Shortcuts tab, "Keys that work in any program": the switch is greyed out until a key is chosen. On Ubuntu it says "Windows only".
2. Press Set on "Next slide", then Ctrl+Alt+→. Set "Blank screens" to F9. A bare letter or arrow is refused.
3. Nothing is claimed yet: in Notepad F9 and the arrow keys behave normally.
4. Turn on. A red banner appears on every tab. With XSplit or Notepad focused, Ctrl+Alt+→ advances the slide and F9 blanks the screens. Held keys do not repeat.
5. Turn off: the banner goes, the keys stop working and Notepad gets F9 again.
6. Map a key another program owns (for example one XSplit already uses): that row says "in use by another program" and the other keys still work.
7. Turn on, then close the program (or kill it): the keys are free again. Restart: the mapping is remembered but the switch is Off.
8. If a press arrives with nothing to advance to, nothing visible happens and the program keeps running.

### 3.27 The bundled King James Bible

On a fresh install (delete `churchlight.db`, or use a new folder), start the program:
1. It starts in a second or two longer than usual the first time. Bible Library shows **KJV**, 31102 verses, and "Default".
2. Service tab > Bible tray: `John 3:16` loads "For God so loved the world, that he gave his only begotten Son...".
3. Remove the KJV (Bible Library > Remove) and restart: it does not come back.
4. Start with a database that already has another Bible: the KJV is not added.
5. Look at Matthew 22:21 ("Cæsar’s", with æ and a curly apostrophe) on a slide in each theme font: both must draw properly.

### 3.28 Theme fonts

1. Themes tab, edit a theme: the Font list shows 17 bundled families first (Open Sans, Lato, ... Dancing Script), then the system fonts marked "(system font)".
2. Pick Montserrat and look at the preview and a live output page: the text is Montserrat. Do the same for each family with a hymn verse and with Matthew 22:21 ("Cæsar’s"): æ and the curly apostrophe must draw in every font.
3. On the XSplit/OBS PC, add the projector browser source with a bundled font chosen: it looks the same as on the operator PC, with no font installed there. (System-font choices still need that font installed on the XSplit PC.)
4. Cinzel is capitals only and Dancing Script is a script: use them for short titles, not verses.
5. Package check: `static/fonts` holds the font files and one `OFL-*.txt` per family; `content/NOTICES.txt` lists them.
6. The "Verse number font" list (Bible group) offers the same fonts, with "Same as the verse text" first. Pick a bold font such as Montserrat or Oswald for the numbers and confirm the numbers change on a tray verse ("16) For God...").

### 3.29 The Settings tab (was Shortcuts)

1. A **Settings** tab (it used to be called Shortcuts) sits after Broadcast Integration. It holds the **Screens** options (home screen picture, screen shape; see 3.31 and 3.33), "Keys for running the service" (the ones that work in this window) and "Keys that work in any program" (Windows only). Neither is on the Broadcast Integration tab any more.
2. The page keys do not fire while you are on the Settings tab, so choosing a key never moves the service.
3. The red "GLOBAL SHORTCUTS ARE ON" banner (when on) points to the Settings tab to turn them off.
4. ← Back to Service returns to the Service tab.

### 3.30 New Service tab layout

1. The Service tab has three columns: the **service order** on the left (with the song and slideshow search at its top), **Live** in the middle (with the small Screens panel under it), and the **Bible** on the right. Old saved layouts are ignored once so you start from this one; Arrange panels still moves anything.
2. Type in the search box: results appear under it with Look, Add and Live. Add puts the song at the end of the service list just below; Look opens its slides in place; Clear and Show all work. "Add a Bible reference or an announcement" is in the same panel. There is no separate "Add from library" page any more.
3. Untick **Show results under the search box**: the results list goes away and typing shows the dropdown of names instead (arrows + Enter add the song). The choice is remembered; tick it again to bring the list back.
4. **Live** shows a real picture of one output. Use the dropdowns (section 3.83 has two previews now) to switch between Projector, Lower third, Stage and so on, or "None (text only)". The choice is remembered. The notes line is still there; the Next slide box was removed.
5. "/" focuses the search box (opening the Service panel if it was folded). Esc in the box clears it.
6. Announcements: with a service open, type only text (no title) and press Add announcement: it is added, named after the first line of the text. With both boxes empty you get a message instead of nothing happening. Announcements stand on their own as a service item; they need no song under them.

### 3.31 Screen shape (4:3 projectors)

1. Settings tab, **Screen shape**: the **projector** and the **confidence monitor** (only those two) have a shape dropdown (16:9, 4:3, 16:10). Set the projector to 4:3.
2. The Preview on that tab and the Live panel's picture on the Service tab turn 4:3 at once, so a widescreen slide shows its empty bands. Other screens keep their own shape. It is remembered after a restart.
3. This only changes what the operator window shows. In XSplit/OBS set the browser source to the real projector size (for example 1024x768); the output page fills whatever size it is given. Real-projector check: a 16:9 slideshow image shows bands, a 4:3 image fills the screen, and song and verse text stay centred and readable.

### 3.32 Cue and take, and the verse look

1. Open a service, put a song live, load `John 3` in the tray, type `16` in "Go to verse" and press Enter. The screens do not change. The service gets one new item, "John 3:16-36", and a "Ready" line appears in the tray (there is no Ready box under the Live buttons).
2. Press Enter again (or the X key, or a global key set to "Show the ready verse"). Verse 16 goes live **in place of** the song, shown as "John 3:16" with the verse text under it (no leading number). Down/Space steps to 17, 18, one verse per slide. At the chapter's end Next carries on to the next service item.
3. Type `16-18` (a range) and press Enter: only 16 to 18 is added. Shift+Enter in the box cues and takes at once. Esc clears Ready (the item stays in the service). Changing the ticks after a cue, then Enter, cues again instead of taking.
4. With the screens blanked, Enter (take) keeps them blank (the banner shows) and the verse is waiting.
5. Every verse slide, from the tray, the "Add a Bible reference" form, or a verse over a slideshow, shows its full reference as a title ("John 3:16", or "John 3:16-17" when two verses share a slide) with the text under it and no leading verse number, on the projector and the lower third. Under the reference there is nothing but the verse text, even when two verses share a slide.
6. Global shortcuts (Windows): "Show the ready verse" is in the list on the Settings tab and does nothing when nothing is ready.

### 3.33 Home screen

1. Settings tab, **Screens > Home screen**: Choose picture, pick a PNG/JPG/WebP/GIF. The thumbnail appears. Fit (whole picture, may leave bands) or Fill (covers, may crop) changes how the projector draws it.
2. Press **Home screen (B)** on the Service tab (the Blank button changes its words once a picture is set). The projector output shows the picture; press again ("Back to the service") and the slide returns. The lower third, stage and confidence monitor are unaffected (the confidence monitor keeps showing, with its blanked flag).
3. Untick "Show it when I blank the screens": blanking shows nothing again, and the picture is kept. Remove forgets it.
4. Restart the program: the picture and choices are still there (it lives in the media folder, and is not cleaned up while in use).
5. Real PC check: with XSplit/OBS on the projector browser source, the home screen appears and disappears cleanly, including on a 4:3 projector with a 16:9 picture (bands) and a 4:3 picture (fills).

### 3.34 Lower-third height cap

1. Themes tab, open an **Overlay** theme: under placement there is **Tallest the box may grow** (0 = no limit, up to 60% of the screen height). Set it to about 25 and save; use that theme as the service's overlay theme.
2. Put a long verse over a slideshow (or on the lower third layout). The text shrinks until the box fits inside the cap, but never below 60% of the theme's own text size. The box never grows past the cap.
3. If a verse would not fit even at that smallest size, the **lower third decides where the verse breaks**: the slides split sooner, for every output. The projector then shows the same shorter slides, even though it could fit more.
4. With the cap at 0 nothing changes: the projector's "characters per slide" alone decides.
5. Raise the cap (or widen the box, or use a smaller font) and the verses pack longer again.

### 3.35 Output pages after a restart

1. With XSplit/OBS showing an output page, close and restart ChurchLight (or install a new zip). Once the program is back, the browser source reloads itself and runs the new page code (before, a source left open kept the old code until it was refreshed by hand, so new features such as the home screen did not appear). A source that was open before this version still needs one manual refresh ("Refresh cache of current page" in OBS).

### 3.36 Hide the words

1. Put a song or verse live on the projector (with a themed background colour or picture). Press **Hide words (W)** (the button next to Blank, or the W key). The words disappear at once and the theme's background stays exactly as it was, with nothing moving. The lower third's box disappears too. A banner says the words are hidden. Press W again: the words come back in the same place.
2. The confidence monitor goes quiet too (its plain black screen stays, and its chip reads "Words hidden"); the stage screen keeps showing the words. A slideshow picture stays; a verse over a slideshow is hidden, leaving the picture.
3. The words stay hidden while you step to other slides, until you press W again. Blank (B) wins: with the screens blanked you see the home screen or nothing, and the words are still hidden when you un-blank.
4. Global shortcuts (Windows): "Hide the words (keep the background)" is in the list on the Settings tab. The W key can be changed there too.

### 3.37 Bible theme on the Bible Library tab

1. Bible Library tab: above the list of Bibles, **Bible verses on the projector use** is a dropdown of projector themes. Pick one: verses on the projector use it (their slide length settings too), and the same choice shows on the Themes tab's "Bible verses on the projector use" box. Change it either place and the other follows. "Same as the service" goes back to the service's theme.

### 3.38 Songs / slideshows filter

1. Service tab, left of the search box there is a dropdown: All, Songs, Slideshows. Type a word that matches both a song and a slideshow: All lists both; Songs lists only songs; Slideshows only slideshows. The dropdown under the search box (when "Show results under the search box" is off) follows the same choice.
2. With the box empty, choosing Songs or Slideshows lists everything of that kind. The choice is remembered when the page reloads.

### 3.39 Service rows never overhang

1. Make the Service panel narrow (shrink the window or use Arrange panels). Each service item keeps its Go, up, down, more and remove buttons together inside the panel; when the title is long the buttons drop under it instead of sticking out past the panel's edge.

### 3.40 No blink under the blank

1. Set a home screen picture and press Home screen (B) so the projector shows it. With it showing, double-click different service items (Go) or press Next. The home picture does not flicker, blink or reload at all.
2. Press B again: the slide that is live appears. Blank again: the home picture comes back at once, without a gap.
3. The confidence monitor still follows the live slide while blanked.

### 3.41 Output pages and updates

1. Every output payload now carries a stamp of the page's own files. A browser source left open across an update (even one that never lost its connection) sees the stamp change and reloads itself, so it cannot keep running old page code.
2. If a source still blinks or misbehaves after an update, open `http://localhost:<port>/view/projector?preview` in an ordinary browser tab and repeat the same steps there. If the tab is fine and XSplit is not, the XSplit source is running an old copy: remove and re-add it (or use its refresh).

### 3.42 Transparent theme background (video behind the page)

1. Themes tab, new projector theme: under Background, **Full-screen color** has a **Transparent (a video behind the page shows through)** box. Tick it: the color picker greys out, the band behind the text switches off, and the preview shows only words.
2. Save, make it the service's projector theme and put a song or verse live. In XSplit/OBS put a video source on a layer **below** the projector browser source (with transparent background enabled): the video plays behind the words. Blanking the screens shows the video alone; a home screen picture or a slideshow picture covers it.
3. Untick the box and the color picker works again (a solid color hides the video). The box is only for projector themes.

### 3.43 Trigger URLs

1. Settings tab, **Trigger URLs**: a list of buttons (next/previous slide and item, blank on/off/toggle, hide/show the words, the verse over the slide on/off/toggle (3.100), show the ready verse, verse next/previous part), each with its own address and a Copy button. "Trigger URLs are on" can be switched off; then none of the addresses does anything.
2. Copy "Blank the screens" and open it in an ordinary browser tab on the same PC: the page says `ok: blank_on` and the screens blank. "Bring the screens back" restores them. The toggle versions flip each time.
3. Stream Deck: add a button of type *System > Website* (or *API Ping* if you have the plugin) with an address; or in XSplit use a hotkey/trigger plugin that opens a URL. Press it with something live and watch the slide advance. If the button must not open a browser window, use a plugin that makes a background request (the address answers GET and POST).
4. **Make a new secret** (click twice): the old addresses stop working at once (404); copy the new ones into your tools.
5. Safety: a wrong secret or a made-up button name always gives 404; ten wrong tries in a minute makes every address answer 429 for the rest of that minute; the secret is not written to `churchlight.log`; a link preview (HEAD request) never presses a button. The addresses work only from this computer unless the program was started with `--host`.

### 3.44 Picture size (slideshows fill the screen)

1. A small picture (for example 1280x720 or smaller) in a slideshow now grows to fill the projector instead of sitting in the middle with a border all round. Try the same small 16:9 picture that left a frame before.
2. Slideshow Library tab, each slideshow has a **Picture size** dropdown: **Fit** (the whole picture; bands only where its shape differs from the screen, for example a square Canva design), **Fill** (covers the whole screen and crops the edges that do not fit) and **Stretch** (exactly the screen, which changes the picture's shape). Pick Fill for a Canva design that is not 16:9, and the screen fills with no bands; keep Fit for anything with text near the edges, because Fill cuts those off.
3. The change applies at once, including to a slideshow that is live. It is remembered per slideshow. Slideshows from before this version stay on Fit (but now grow to fill).
4. A 4:3 projector (see Screen shape): a 4:3 picture fills it with Fit; a 16:9 picture shows bands with Fit and fills with Fill.

### 3.45 Verses per slide

1. Add John 3:16-21 to a service. By default each verse is its own slide; the service row says "6 slides" in grey (nothing is shown for a single slide). Open the row's ⋯ to see the list of slides.
2. Service Change menu, **Bible verses on each slide**: *Follow the theme* (default), *One verse per slide*, *Fit as many whole verses as will fit*. Choose the last one: short verses now share a slide and the slide count drops. The live verse stays on screen where possible.
3. Themes tab, a projector theme: **Slide length** has the same two choices; the old "Longest Bible slide" number is gone, replaced by "About N lines fit on the screen with this look" (it changes as you change the font size). Preview buttons **Longest verse** (Esther 8:9) and **Several verses** (Psalm 23) show the effect; the second follows the Slide length choice.
4. A verse so long it had to be split, or text that has to shrink on the lower third, shows a small amber ⚠ and a grey reason on its row. Nothing is shown when everything fits.
5. Themes saved before this version keep their old setting; new and starter themes use one verse per slide. Changing the screen shape (4:3) re-flows the slides.

### 3.46 Preview through the blank

1. Put a verse live, then blank the screens (B). The preview boxes on the Run tab keep showing the verse, with a small red "SCREENS BLANKED" label in the corner. The real projector (and XSplit/OBS sources) stay blank.
2. Go to another item or verse while blanked: the preview follows it, so you can check the next verse before bringing the screens back. Unblank: the label disappears and the preview is the same as the projector again.

### 3.47 Export songs and slideshows

1. Songs tab: above the list, **Export as** XML (OpenLyrics, for other programs) or Text (to email or print). Press **Export** on a song: the browser saves `<title>.xml` or `<title>.txt`. **Export all songs** saves one `.zip` with a file per song.
2. Open the `.txt`: title, each part in the order it is sung (a repeated chorus is written out again), then author, © and CCLI lines. Add it to the library on another computer with the Songs import: it comes back with its parts, order, author and CCLI.
3. Slideshows tab: **Export** on a slideshow saves `<name>.zip`; **Export all slideshows** saves everything in one bundle. Large slideshows take a moment.
4. On the other computer, Slideshows tab, **Add a slideshow → Choose an exported bundle…**. The slideshow arrives with the same page order, speaker notes, skipped pages, per-page timing and transitions, ending, transition and picture size. Importing the same bundle again says it is already in the library.
5. A zip that is not a ChurchLight bundle, or has pictures that are not really pictures, is refused with a message and nothing is added.

### 3.48 The operator window opens where you left it

1. Start the program with the start script (it opens the operator window by itself). Drag the window to another monitor and resize it. Wait a few seconds, then close the window and stop the program.
2. Start it again: the operator window opens on the same monitor, in the same place and at the same size.
3. A minimized window is never saved (it keeps the last normal place). If you unplug the monitor it was on, the browser moves the window onto a screen that exists.
4. Only the window the program opens by itself is remembered. An operator page you open yourself in a browser tab does not change the saved place.

Checking it: `churchlight.log` says "Opening the operator window at x=… y=…" at every start (or "No saved place…" before the first time you move it), and "Operator window is now at …" whenever you move or resize it. The window is moved to its saved place by the page itself as well as by the browser's start-up flags, because a browser that is already running (Edge keeps one alive in the background) ignores the flags.

**Two or more monitors.** The operator window now starts in a browser process of its own (its profile is the `browser-profile` folder next to the database file), so Edge cannot hand it to a copy that is already running and ignore its position. Put the window on the second monitor, close the program, start it again: it should open on the second monitor. The first start after updating also resets the page's own remembered settings (panel layout, key choices, search filter), because the window now has its own browser profile; set them again once.

### 3.49 Text area in the theme builder

1. Themes tab, a **projector** theme: under "Where the box sits" there are four new sliders (space above, below, left of and right of the text), each a share of the screen. The preview shows a dashed orange box: the space the text may use. Drag any edge of the box (the small orange bars), or focus a bar and press the arrow keys (Shift for bigger steps). The sliders follow, and the preview text moves at once. Defaults (4% top and bottom, 6% at the sides) look exactly like before.
2. The margins always leave at least 20% of the screen for the text; the sliders stop there. The "About N lines fit" readout changes with the margins, and so do "fit as many whole verses" slides.
3. An **overlay** theme: the dashed box matches the real lower-third box. The edge next to where the box sits (for example the bottom edge of a bottom box) moves the box (its gap to the screen edge); the other edges resize it (width, or the "tallest the box may grow" cap).
4. "Show the text area" turns the box off; the choice is remembered. Press Save to put the new margins on the real screens.

### 3.50 Song themes, and songs sent straight to live

1. Open a service with a projector theme. In the Song Library (or the search results), send a song straight to live without adding it to the service: it now looks like the service's songs (before, it used no theme). With no service open it uses the theme "New services start with" on the Themes tab.
2. Song Library, edit a song: **Theme for this song** lists every projector theme, plus "Follow the service's theme" (the default). Choose a patriotic theme and save. That song now uses it in every service and when sent straight live, whatever the service's theme is. Other songs are not affected.
3. A theme you pick for one item in the service (its ⋯ options) still beats the song's own theme. Deleting a theme sets the songs that used it back to following the service; the Themes tab lists "N songs" among where a theme is used.
4. Only projector themes are offered (not overlay or confidence themes).

### 3.51 Reference above or below the verse (lower third)

1. Themes tab, open a lower-third (overlay) theme: **Bible verses → Reference position** offers Automatic, Above the verse text, Below the verse text. The preview moves the reference at once. Projector and confidence themes do not show it.
2. Automatic keeps today's look: a single verse has its reference under it, a passage with numbered verses has its title ("John 3") above. Above puts a single verse's reference over the text (reference size, not title size); Below puts a passage's title under the text.
3. Save, use that theme for an output's lower third, and send a verse live: the broadcast shows the reference where you chose.

### 3.52 Balance long lines (songs only)

1. Themes tab, open a projector or lower-third theme: **Songs → Balance long lines**. (Confidence themes do not show it.) Off by default.
2. Choose the Lyrics preview, make the text large enough that a line wraps. Off: a few words sit alone on the second line. On: the line breaks near its middle.
3. The Bible preview is unchanged either way: the setting only affects song lyrics.
4. Slides still split the same way; only where a long line breaks changes. (Edge balances up to about six wrapped lines; longer blocks wrap normally.)

### 3.53 Export and import themes

1. Settings tab, **Move themes to another computer**: choose a theme and press **Export this theme** to save "<name> (theme).zip". **Export all my themes** saves one zip of every theme except the starter themes you have not changed (a starter you edited is included). If you have none of your own, you get a plain message instead.
2. On another ChurchLight computer (or after deleting the theme here), Settings tab, **Import themes…**, choose the zip. The message lists what was added. The themes appear in the list; nothing becomes the default or is attached to a service.
3. A theme with a background picture arrives with the picture. The look, Bible reference position, Balance long lines, the text-area margins and the slide-length settings all arrive as they were.
4. Import the same file again: "Nothing new was added. N already here, skipped." Change a theme's look here and import the file again: the incoming one is added as "Name (2)".
5. A file from a newer ChurchLight with settings this one does not know still imports; the message names what was left out. A file that is not a themes zip (for example a slideshow bundle) is refused in plain words.
6. Fonts are not in the file. On a computer without the font, a similar one is used.

### 3.54 Slideshow pictures fill the screen again

1. Make sure the theme in use for the projector has been saved from the Themes tab at least once (that stores its text-area margins).
2. Send a slideshow page live. With Picture size set to Fit, Fill or Stretch the picture reaches the screen edges (Fit leaves bands only where the picture's shape differs). Before this fix the text-area margins left a border around the picture.

### 3.55 No blink when the words are hidden over a slideshow

1. Send a slideshow page live on the projector (or any picture slide).
2. Press **Hide the words** (button or key) and press it again. The picture stays perfectly steady: no flicker, no reload, in both directions. (The screen is only redrawn when something visible changes.)
3. With a song or verse live, Hide the words still removes the text (and shows it again) as before.

### 3.56 Settings sections fold

1. Settings tab: Screens, Move themes to another computer, Trigger URLs, Keys for running the service and Keys that work in any program each have a heading you can click to fold or open (▸ / ▾). All start open.
2. Fold two of them, reload the page: they stay folded. Open them again: they stay open next time.
3. The Themes tab no longer has the export/import buttons; they live on Settings.

### 3.57 PDF import status, and a bundled PDF renderer

1. Settings tab, **PDF import**: it says "✓ PDF import is ready (pypdfium2 <version>)". When the renderer sits in the program's `vendor` folder it adds ", included with the program". If no renderer is found it shows "⚠ PDF import is not set up…" in a warning color.
2. This download already carries the Windows 64-bit renderer (pypdfium2 5.14.0) in the `vendor` folder. To bundle another build or version: put the Windows file `pypdfium2-<version>-py3-none-win_amd64.whl` next to `tools`, run `python tools/add_vendor_wheel.py <that file>`, and a `vendor` folder appears beside `churchlight_presenter`. Start the program with no pip install of pypdfium2 on that computer: Settings says "included with the program", and importing a PDF works.
3. `python tools/selftest.py` reports "pypdfium2: <version> (from the vendor folder)" in that case.

### 3.58 Imported themes appear at once

1. Settings, Import themes…, choose a themes file. As soon as the "Added…" message shows, open the Themes tab: the new themes are already in the list (no reload needed). Importing a file that adds nothing changes nothing.

### 3.59 Balanced lines look the same in XSplit

1. A song theme with **Balance long lines** on. Put a long lyric line live (big enough to wrap), for example "'Cause I know there is peace within Your presence".
2. The operator preview and the XSplit projector now break it the same way, near the middle ("'Cause I know there is" / "peace within Your presence"). Before, XSplit's older browser filled the first line and left "Your presence" alone.
3. Lines that fit on one row are never changed. With the option off nothing changes.

### 3.60 A song's parts and where the service is (the ⋯ options)

1. Put a song in the service and take it live. Its ⋯ options open by themselves (press ⋯ to close them; your choice is kept for that item). Other items stay closed until you open them.
2. **Parts and where we are** lists every part of the song in singing order, each with its slides. The live slide is highlighted (▶), slides already shown are faded (✓), and the next one is marked (→). As you press next/previous the marks move, and the list scrolls to keep the live slide in view.
3. The tick box beside each part sings or skips it, as before: untick the chorus and its slides disappear from the service and the list shows "left out" (it can be ticked again). You cannot untick every part. **Sing the whole song** puts everything back.
4. **Go** beside a slide shows that slide on the screens at once (for a repeated chorus). Nothing changes unless you press it.
5. A song sent straight to live from the library (not through the service) shows its parts but no marks, since it is not part of the service.

### 3.61 The home screen is the projector's default

1. Settings, Home screen: choose a picture. Make sure "Show it when nothing is live" is ticked. With no service open (or a service loaded but no slide taken yet) the projector shows the picture.
2. Take a slide live: the picture is replaced by the slide. Blank the screens: the picture comes back (if "when I blank" is ticked). Press Blank again to return.
3. Untick "when nothing is live": an idle projector goes back to showing nothing, blanking still shows the picture. Untick both: the picture is never shown. The choice is remembered after a restart.
4. The lower third, song lower third, confidence monitor and stage page never show the picture.

### 3.62 The service list stays inside its column

1. Add a slideshow to the service and open its ⋯ options. The "Timing: …" choice is long, but the item (Go, arrows, ⋯) stays inside the Service order column; nothing is cut off at the right edge, at any window width.

### 3.63 The live verse is highlighted in a Bible item's list

1. Add a long passage (several verses) and take it live. Open its ⋯ options: the numbered list of slides highlights the one on the screen now (coloured bar, bold).
2. Press Next/Previous: the highlight moves with the live slide. When another item is live, nothing in the list is highlighted.

### 3.64 "LAST SLIDE" on the live item

1. Take a song, slideshow or passage live. Its row shows LIVE. Step with Next: when the slide on the screen is that item's last, a **LAST SLIDE** tag appears beside LIVE. The next press goes to the following item.
2. Previous removes the tag again. An item with one slide shows it straight away. Skipped song parts are not counted (the last slide actually sung is the one flagged).

### 3.65 Balanced lines on the confidence monitor

1. Put a long lyric line live that wraps on the confidence monitor, with one or two words left alone on the last row. The monitor now breaks it near the middle, like the projector's "Balance long lines". Bible text with no verse numbers (a single reference) is balanced too.
2. It is on by default, including for the plain "no theme" monitor and for existing monitor themes. To turn it off: Themes tab, a Confidence monitor theme, **Balance long lines**, untick it, and assign that theme to the monitor.
3. The text still shrinks to fit the monitor; balancing is redone at the final size.

### 3.66 No empty screen between slideshow pictures

1. Run a slideshow made of full-screen pictures (for example an imported PDF) and step through it, including jumping with Go to a slide that is not next to the live one. The projector goes straight from one picture to the next with no blink of the video or background behind it.
2. The page keeps the old picture up until the new one is loaded (at most about half a second, then it shows whatever it has), then puts the new picture on top and removes the old one a moment later, so even XSplit's older browser never shows an empty frame in between.

### 3.67 Clear the verse without clearing the live slide

1. Put a slideshow slide live, then show a verse over it (Verse box, or a verse from the tray). A **Clear verse** button appears next to **Clear live** in the Live panel, and on the Broadcast Integration tab beside Blank screens.
2. Press it: the verse goes off the screen and the slideshow slide stays exactly where it is. **Clear live** still takes everything off. The H and Esc keys do the same as Clear verse. The button disappears when no verse is showing.
3. The verse stays loaded, so **Show again** (Verse box) brings it back.

### 3.68 A theme for a verse over a slideshow

1. Themes tab: make an **Overlay** theme with the box you want (position, width, band, font). Open the Bible Library tab: **A verse over a slideshow uses** (under "How verses look") lists your Overlay themes, with "Same as the Bible theme" first. The same choice is on the Themes tab under "Where themes are used".
2. Put a slideshow slide live and show a verse over it (Verse box, or from the tray). On the projector the verse now uses that theme's box and text. The slide underneath, songs, and Bible verses that are service items keep their own look; the lower-third outputs are unchanged.
3. Long verses are split to fit the chosen box. Choosing "Same as the Bible theme" returns to the old look. Deleting the theme does the same. Nothing changes until a theme is chosen.

### 3.69 Slideshow transitions only between its own slides

1. Give a slideshow a transition (Slideshow tab, for example Dissolve 1 s). Put a song before it and another item after it in a service.
2. Go from the song to the slideshow's first slide: it simply appears, with no transition. Step through the slideshow: each slide uses the transition. Go on to the next item: plain change.
3. Going from one slideshow straight to another is a plain change too. The first slide after "Clear live" or from nothing still uses the transition.

### 3.70 Hide the lower third without touching the projector

1. With something live and a lower-third output on (lower_third, song_lower or verse_lower), press **Hide lower third** (Live panel) or **L**. The lower-third outputs go empty; the projector, the confidence monitor and the stage page carry on as before. A banner says the lower thirds are hidden, and the screens list shows "Lower third hidden".
2. The Blank button, "blank to theme/home" and the home screen picture are not affected, either way round: blank the screens and the lower third still follows its own hide setting; showing the lower third again does not unblank anything.
3. The operator's own preview of the lower third still shows what would be on air. Press the button (or L) again to bring them back. Slides can change while it is hidden; the current one appears when you show it again. The setting is not remembered after a restart.

### 3.71 Buttons follow the keys chosen in Settings

1. Settings, Keys: change "Blank screens" from B to F9 and "Hide the words" to F2. The Blank button now reads "Blank screens (F9)" (or "Home screen (F9)"), Hide words reads "Hide words (F2)". The banners ("Press F2 to bring them back") and the verse, tray and jump boxes' hints follow too.
2. Remove a key from an action (a key-less action): its button shows no brackets at all.
3. Change the keys back: the defaults return everywhere. The choice is per browser, as before.

### 3.72 Song parts and order in OpenLyrics (OpenLP and ChurchLight)

1. Export a song with an Intro, Verse 1, Pre-Chorus, Chorus, Bridge, Tag, Interlude and Outro (XML). Open the file: the parts are named `i1 v1 p1 c1 b1 o1 o2 e1` (always a letter and a number, as OpenLP writes them) and `<verseOrder>` lists them in the order sung, repeats included. Each part also carries a `cl:label` with its real name.
2. Import that file into another ChurchLight: every part keeps its name (Tag, Interlude, Outro) and the order is the same.
3. Import an OpenLP export (v1, c1, b1, p1, i1, e1, o1): parts read as Verse 1, Chorus 1, Bridge 1, Pre-Chorus 1, Intro 1, Ending 1, Other 1, in OpenLP's verse order; formatting tags keep their words; a name in the order with no words is skipped with a warning.
4. A file that spells the parts out ("verse1", "Chorus 2", "pre-chorus") reads correctly too.

### 3.73 OpenLP songs whose verses are split into parts

1. Import an OpenLP export where a verse is written as `v1a`, `v1b` and the order says `v1 c1 v2 c1 ...` (for example "Trust In God"). The song arrives with Verse 1, Chorus 1, Verse 2 and Bridge 1, and the order is the full order sung (no "names v1, which has no lyrics" warnings). Each OpenLP part is still its own slide (a blank line separates them inside the part).
2. If an OpenLP order names single parts (`v1a c1 v1b`), the parts stay separate sections (Verse 1a, Verse 1b) in that order.
3. A file that uses one of every part type (v1 c1 b1 p1 i1 e1 o1) reads as Verse 1, Chorus 1, Bridge 1, Pre-Chorus 1, Intro 1, Ending 1, Other 1.

### 3.74 Jump to a verse inside a Bible item

1. Add a passage of several verses (for example John 3:1-6, one verse per slide) to the service. Open its ⋯ options: each verse in the numbered list has a **Go** button, like a song's parts list.
2. Press Go beside the verse in the middle: that slide goes live at once (even if another item is live), the list highlights it, and Next/Previous carry on from there. Nothing changes unless you press it.

### 3.75 Countdown and speaker alert

1. Service tab, Live panel: open **Countdown and speaker alert**. Type "Service begins in" in the words box, set 3 minutes and press the first **Start** beside "or for". The projector shows the words and a big clock (3:00, 2:59 ...); the stage and confidence pages show it small in the top-right corner. The lower-third outputs show nothing (they sit over the camera). The panel says "Counting down: 2:5x left."
2. Pick a clock time (for example five minutes from now) and press the **Start** beside "Count down to". A time that has already passed today shows "That time has already passed today" and nothing starts.
3. Change slides, blank the screens, clear live, open another service: the countdown keeps running and does not blink. (It still shows while the screens are blanked.)
4. At zero the clock turns yellow and reads 0:00 for five seconds, then goes away by itself. **Stop countdown** removes it at any time. Reload a page mid-count: it comes back at the right time. A computer whose clock is wrong still counts correctly (the page uses the program's clock).
5. Type "Wrap up in 2 minutes" in the alert box and press **Send alert** (or Enter): a yellow bar appears at the bottom of the stage and confidence pages only. The projector and lower thirds never show it. **Clear alert** removes it.
6. Neither the countdown nor the alert is remembered after the program restarts.

### 3.76 Slide titles in the slideshow editor

1. Slideshow Library, Edit slideshow: select one slide. Under "Selected slide" a **Slide title** box appears above the speaker notes. Type "Offering" and press Enter (or click away). The thumbnail shows "Offering" under its picture.
2. Add that slideshow to a service and put a slide live: the Live panel and the item's ⋯ list call it "Offering" instead of "Slide 2". Slides without a title still say "Slide 3" and so on (the number is the slide's place in the slideshow, so skipping a slide does not rename the others).
3. Clear the box and press Enter: it goes back to "Slide 2". Titles over 60 characters are not accepted. With several slides selected, or while the slideshow is live, the box is greyed out.
4. Duplicate a titled slide, copy it into another slideshow, or make a new slideshow from it: the title comes along. Export the slideshow (bundle) and import it on another computer: titles arrive too, and bundles from older versions still import.

### 3.77 More slide transitions

1. Slideshow Library, Edit slideshow: the transition list (for the whole slideshow, and for chosen slides) now also offers **Slide** left, right, up and down; **Split** horizontal, vertical, diagonal left and diagonal right; **Wipe** left, right, up and down; **Fade to black** and **Fade to white**. Set a length (0.1 to 2 seconds).
2. Put the slideshow live on the projector and press Next. Slide: the new slide moves in over the old one from the edge named in the list (Slide left comes in from the right). Wipe: an edge sweeps across and uncovers the new slide (Wipe left sweeps from the right edge). Split: the new slide opens outward from the middle line (horizontal opens up and down, vertical opens left and right) or from a diagonal line (the list shows the line's shape: \ or /). Fade to black or white: the old slide darkens (or whitens), the new one arrives at the midpoint, and the screen clears again.
3. As before, a transition is used only between slides of the same slideshow. Arriving from a song or another item is a plain change. Only the projector draws transitions; the lower thirds and speaker screens change instantly.
4. Open a copy of an older database (made by a version before this one) and check it starts normally with every slideshow and its settings unchanged. After starting once, an older program version cannot open it (the program says to update).

### 3.78 The song report (Report button)

1. Open a service with some songs. On the Service tab, the strip above the service list has a **Report** button (Plan side only: it is hidden in Run mode). Press **Report**, then **Sure?** in the same place (it goes back to Report after 4 seconds if you do nothing): a message says "Added the report for <service> (<date>): N songs." Songs are taken in service order, a song used twice is listed once, and scripture, slideshows and announcements are left out.
2. Go to the **Song Library** tab and press **Report list** (beside Export all songs; it is no longer on the Service tab): the panel shows one list with a section headed with the service name and date, and each song with its author and CCLI number (when it has one).
3. Press **Report** again for the same service after adding or removing a song: the message says "Updated", and that section changes. It is not added a second time.
4. Open another service (or start a new one) and press **Report**: a second section appears in the same list. The list is kept in the program's database and is still there after a restart, and it is included when you copy the database file for a backup.
5. **Copy this section** and **Copy the whole list** put plain text on the clipboard ("Service name — date", then "1. Title (Author, CCLI number)" lines), ready to paste while you report on CCLI's website. **Remove** (press twice) takes a section out of the list.
6. A service with no songs shows "This service has no songs to report" and changes nothing. If you rename or edit a song later, the saved section keeps what was reported until you press Report for that service again.

### 3.79 The Service tab layout (Service 40% | Live 60% | tools along the bottom)

1. Open a service. Service order is on the left (about 40% of the width), Live on the right (about 60%), and a panel is fixed along the bottom of the window with three tabs: **Bible**, **Announcements**, **Timer**. The top two boxes scroll inside themselves; the bottom panel scrolls too; the page itself does not need to scroll. The old Arrange panels / Reset layout buttons and the fold arrows are gone.
2. **Bible**: the verse tray as before (Load, Load + add to service, Go to verse, tick verses, Add to service). Pressing the T key or the G key opens this tab and puts the cursor in the box.
3. **Announcements**: type a title and the text, press Add announcement; it is added to the service after the live item (or at the end).
4. **Timer**: the countdown (to a clock time or for N minutes, with words above it) and the speaker alert, exactly as in 3.75.
5. The tab you used last is remembered in this browser. Left and Right arrow keys move between the tabs when one has focus.
6. **Live** shows the preview (smaller than before) with Previous, Next, Blank, Hide words, Hide lower third and Clear live all visible without scrolling at a normal window size. **Screens** is a folded section under the live controls; opening it lists the screens and the Broadcast Integration button.
7. Make the window narrow (or open the page on a phone): one column with Live first, then the tools, then Service order. The bottom panel is no longer fixed to the window then.
8. The "Add a Bible reference" fold in the Service panel still adds a typed reference; it no longer holds the announcement form.

### 3.80 Countdown and alert style (Broadcast Integration) and the theme text area

1. Theme Library: the "Show the text area" checkbox is gone. The dashed text-area guide is always drawn while a theme is being edited.
2. Broadcast Integration tab: a **Countdown and alert style** section with three groups (countdown on the projector, timer on the stage and confidence screens, alert bar) and two preview frames (Projector, Stage and confidence screens) that show a sample countdown and alert.
3. Change any control (font, colors, sizes, position, box color and how solid it is). The previews change while you drag; the setting saves when you let go. Start a real countdown from the Announcements and timer tab: the projector and speaker screens use the new look.
4. Try sizes at both ends of each slider and every position. Check the clock never runs off the screen and the "finished" color shows at 0:00.
5. **Reset to the standard look** puts every control back. Settings survive closing and reopening the program.

### 3.81 The song usage log

1. Start the program, open a service with a few songs and send each one live (or step through with the item buttons). Moving between the slides of one song adds nothing; a song shown again after another song or Clear adds a new row.
2. `song_usage.csv` appears beside the database file. Each line reads `"CCLI number","date","time","title","authors","copyright","songs","display"`, every field in quotes (empty quotes when a song has no CCLI number or copyright).
3. On the Song Library tab press **Report list**, then **Download the usage log**. The browser saves the same file. Check it opens in a spreadsheet with one row per song shown.
4. Bible verses, slideshows and announcements add no rows.

### 3.82 Service tab: smaller gap, no Next slide box

1. Open a service. The Service order and Live boxes now reach closer to the Bible / Announcements and timer panel (about one line of space between them instead of about three). Check at a small and a large window and with Text size Large that the boxes never run behind the bottom panel.
2. The Live box no longer has a "Next slide" preview. Previous and Next still work and there is no Ready box under the Live buttons.

### 3.83 Two previews in the Live box

1. Open a service. The Live box shows two previews side by side, each with its own dropdown above it. The left starts on the first output (usually the projector), the right on the second. With only one output there is one preview.
2. Change either dropdown to any output, or to **None** to hide that preview (the other grows no larger; it keeps its half). Reload the page: both choices are remembered in that browser.
3. Check the pictures are readable at your normal window size, and that Previous / Next / Blank are still visible without scrolling.

### 3.84 A shorter bottom panel

1. On the Service tab the Bible / Announcements and timer panel is two-thirds of its old height (about a quarter of the window), and the Service order and Live boxes grew to fill the space.
2. Check the Bible tab still shows the verse box, the buttons and the verse list (it scrolls inside the panel), and the Announcements and timer tab's fields can all be reached by scrolling.

### 3.85 Clicker helper (needs a real Windows PC with a clicker)

1. Install AutoHotkey v2 on the Windows PC (autohotkey.com). On the Settings tab open **Clicker helper (Windows)**. Three buttons are listed: Page Down = Next slide, Page Up = Previous slide, "." = Blank (toggle).
2. Press **Press the button**, then press a button on the real clicker; the key name changes. Keys the helper cannot use say so; a key already used says so; Esc gives up. Use **Add a button** and **Remove** to change the list, and pick what each does.
3. Download the script and double-click it: a message says the clicker is ready. Open a long web page and press the clicker. The ChurchLight slide moves and the web page does NOT scroll.
4. Close ChurchLight and press the clicker again: the keys work normally (the page scrolls) and a message says ChurchLight did not answer. Start ChurchLight again: the clicker drives it again.
5. Ctrl+Alt+F12 turns the clicker off and on (a message says which). Make a new secret in Trigger URLs: the old script stops working (keys pass through) until the script is downloaded again.
6. Turn Trigger URLs off: the Download button is disabled with a note.
7. Note for the soft launch: the script file contains the secret address; keep it on that PC.

### 3.86 Verse-over-slide forward and back trigger URLs, and which theme each output uses

1. Put a slideshow live and load a chapter in the verse tray (for example John 3). In Settings, Trigger URLs, there are two new addresses: **Verse over the slide: next part of the verse, or the next verse once every part has shown** and its "previous" twin.
2. Open the "next" address in a browser tab with nothing showing: the first tray verse goes over the slide. Open it again: verse 2, and so on.
3. Show a long verse (one that splits into parts, for example by clicking it in the tray). Each time the "next" address is opened it shows the next PART of that verse. It never moves to the next verse until every part has been shown; the open after the last part shows the next verse from its first part.
4. The "previous" address steps back through the parts; from the first part it goes to the previous verse, on that verse's LAST part, so the parts can be walked back one at a time.
5. A verse shown by itself (not from the tray) stops at its last part: the page says so and nothing changes. With no slideshow live or no tray, the page says why.
6. In the Clicker helper add buttons for these two and download the script; check the clicker moves the verse over the slide.
7. Themes: set "verse over a slideshow" (Bible Library, How verses look) to an overlay theme that looks clearly different from your normal lower-third theme. Show a verse over a slide: the projector shows the verse-over-slide look; the lower third output (and the verse lower third) keep the normal lower-third theme.

### 3.87 Enter with nothing typed in "Go to verse", once a chapter is in the verse tray

(Moved: this used to be the book and chapter box. That box now only loads what you type.)
1. Put a slideshow live, make sure a service is open, and load a chapter into the verse tray (type John 3 in the book and chapter box and press Enter). The cursor moves to the **Go to verse** box, whose greyed hint now reads "Enter adds John 3 to the service, Enter again shows verse 1".
2. Leave **Go to verse** empty and press **Enter**: the whole chapter is added to the service as one item. Nothing changes on screen.
3. Press **Enter** again: verse 1 goes over the slide, the same as typing 1 and showing it. A third Enter says verse 1 is already showing and does nothing. From here the verse buttons or the clicker's forward trigger carry on.
4. Two quick Enters in a row do the same two steps, one each (the chapter is added once, not twice).
5. Load a chapter with Ctrl+Enter (or "Load + add to service"): it is already in the service, so the first Enter on the empty Go to verse box shows verse 1 straight away.
6. Typing a verse number in Go to verse (16, 16-18, 16, 18) and pressing Enter still cues it as before; it does not add the whole chapter. Enter on an empty book and chapter box does nothing, and with no chapter loaded Enter does nothing anywhere.

### 3.88 Announcements and timer tab; the clock/bar editor on Broadcast Integration (supersedes the look steps of 3.75 and 3.80)

Service tab
1. The bottom panel has two tabs: **Bible** and **Announcements and timer**. The second shows Announcements on the left and the Timer on the right (stacked on a narrow window). A browser that last had the old Timer tab open lands on the combined one.
2. In the Timer section: start and stop a countdown, send and clear an alert, and **On the projector show: A big clock / A scrolling bar**. Changing it switches the projector at once while a countdown runs. **Change how it looks** opens the editor on Broadcast Integration, already on the one you chose.

Broadcast Integration, "Projector: big clock and scrolling bar" (collapsible)
3. Pick **Big clock** or **Scrolling bar** (this only changes what you are editing). The projector keeps showing the saved choice; **Show this one on the projector** changes it. The preview shows the one you are editing, a looping sample.
4. **Drag the blue box** in the preview to move it; drag a handle on an edge or corner to resize it. It cannot leave the screen or get tiny. The big clock's text is sized from its box (percent of the box height) and shrinks if a long time like 1:30:00 would not fit. The bar's words scroll inside the bar only.
5. Big clock: font, text and finished colors, text size, words size, box color with a "how solid" slider. Scrolling bar: what it says (`{minutes}` becomes "10 minutes" ... "1 minute"), what it says at zero (empty = nothing), how often (every 1, 2, 5, 10 minutes), scroll speed (seconds to cross the screen), font, colors, text size, bar color and solidity, rounded corners.
6. Real run: set the projector to **A scrolling bar**, start a 12 minute countdown. The bar pops up straight away ("12 minutes until service begins") and scrolls once across, then again at 11:00, 10:00 ... 1:00 left ("1 minute until service begins"), then "Service is beginning" once at zero. With "how often" 5 minutes it pops up at the start, then at 10:00, 5:00 and zero. The big clock does not show while the bar is chosen. It keeps working while the screens are blanked (like the big clock). Stopping the countdown takes the bar away at once.
7. Stage and confidence screens fold: the small timer and the alert bar settings and preview are unchanged in meaning (size, corner, box color; alert colors, size, top or bottom). **Reset to the standard look** puts every look setting back, including the box places.

### 3.89 Hide words and the confidence monitor (Settings, Screens)

1. Settings tab, Screens: **Hide words also hides the words on the confidence monitor** is ticked (the way it has always worked).
2. Put a slide live and press **Hide words (W)**: the projector loses its words, and so does the confidence monitor (it keeps its black screen). Press W again to bring them back.
3. Untick the box and press W: the projector hides its words but the confidence monitor keeps showing its words. The stage screens always keep theirs, and the lower thirds follow the projector. The choice is remembered after closing the program.

### 3.90 Service tab: fixed control strip, Plan/Run, foldable and resizable tools panel

1. **Toolbar.** On the Service tab a bar runs across the whole top, under the page tabs: Previous, Next, Blank, Hide words, Hide lower third, Clear verse (only while a verse is over a slide) and Clear live. At its right end it names the live item and shows "Slide 2 of 4". The Live box below now holds just the previews. In the page header, a **Countdown 4:12** chip appears while a countdown runs and an **Alert: ...** chip while an alert is showing; clicking either opens the Announcements and timer tab.
2. **Plan / Run.** Beside the service name, **Plan** shows everything as before. **Run** hides the search box, library results, "Add a Bible reference" and the service settings, so only the service order is left. The choice is remembered after closing the page. Pressing **/** (search) switches back to Plan and puts the cursor in the search box.
3. **Jumping still works in Run.** Open a song's **⋯** and press **Go** on a later part or slide: that slide goes live and its line is marked. Open a Bible item's **⋯** and press Go on a verse's slide. Press **T** or **G** with the panel folded: it opens on the Bible tab with the cursor in the right box. Typing a verse number in "Go to verse" and pressing Enter still shows that verse.
4. **Tools panel.** **Fold ▾** (right of the tabs) shrinks it to the tab row; **Open ▴** brings it back, and clicking a tab or pressing T/G opens it too. **Drag the thin line along its top edge** to make it taller or shorter (between about an eighth and 60% of the window); with that line selected, Up/Down arrows do the same. Height and folded state are remembered. On a narrow window the panel stays in the page flow as before.

### 3.91 Export with nothing to export

1. With no songs in the Song Library, **Export all songs** is grayed out (hover shows "There are no songs to export yet"). Add a song and it turns on. The same for **Export all slideshows** on the Slideshow Library.
2. Every export button now saves its file without leaving the page. If an export is ever refused (for example **Export all my themes** when every theme is still an untouched starter), a message appears at the top and you stay where you were; the page is never replaced by an error.

### 3.92 No Screens list and no keys paragraph on the Service tab

1. The Live box now ends after the two previews and the short notes line: the **Screens** fold (with "Broadcast Integration →") and the long **Keys:** paragraph are gone. The Broadcast Integration tab still has every screen's address and preview buttons; the Settings tab lists and changes the keys.

### 3.93 The clicker helper now comes with ChurchLight (nothing to install)

Windows PC only. This replaces the "install AutoHotkey, download the script, double-click it" steps of 3.85.
1. Settings, **Clicker helper**: there is no instruction to install anything. Turn **Trigger URLs** on (above it) if they are off.
2. Set up the buttons as before (**Add a button**, **Press the button**, then press the clicker's button; choose what each does). Press **Start the clicker helper**. A message says the clicker is ready, the status says "The clicker helper is running", and a **Stop the helper** button appears. The button you pressed now reads "Restart the helper with these buttons".
3. Press the clicker's buttons: the slides move in ChurchLight. Check in another program (Notepad, say) that the clicker's key does not type or scroll there while the helper runs. **Ctrl+Alt+F12** turns the clicker off (the keys work normally again) and on.
4. Press **Stop the helper**: the keys work normally everywhere. Start it, then close ChurchLight: the helper goes away by itself (the AutoHotkey icon leaves the tray).
5. With the helper running, press **New secret** in Trigger URLs: the clicker keeps working (the helper restarted itself with the new secret). Switch Trigger URLs off: the helper stops.
6. Tick **Start the helper whenever ChurchLight starts**, close ChurchLight and start it again: the helper is running without pressing anything.
7. The folder with the database no longer holds a `ChurchLight-clicker.ahk` file while the helper is stopped (it only exists while the helper runs, because it contains the secret).
8. If your antivirus complains about `vendor\autohotkey\AutoHotkey64.exe` or the clicker, tell me which program and what it said. **Download the helper script** is still there for a computer that already has AutoHotkey v2.

### 3.94 Colored buttons instead of banners

1. Press **Blank screens** (or **Home screen**), **Hide words** and **Hide lower third** one at a time: each button turns amber and bold while it is on, and goes back to its normal color when you press it again (or use its key). The old banners across the top ("PUBLIC SCREENS ARE BLANKED" and the others) are gone. The Blank button on the Broadcast Integration tab changes color the same way.
2. Hover a button that is on: it stays amber. Hovering "Hide words" says it hides the words on the public screens and the confidence monitor, with the background staying.

### 3.95 Clicker button on the Service toolbar

1. On Windows, with a service open, the toolbar's right end of the buttons has **Clicker: off**. Press it: the helper starts (it uses the buttons you set in Settings, or the standard Page Down / Page Up / full stop buttons if you set none), the button turns amber and reads **Clicker: on**. Press it again to stop it. Errors (for example Trigger URLs are off) appear in the message line at the top.
2. The same button follows the helper when you start or stop it from Settings, or when a new secret restarts it. On a computer that is not Windows the button is not shown.


### 3.96 No scroll bar on the page itself (Service tab)

1. Open a service on the Service tab and look at the right edge of the window: there is no scroll bar for the whole page, at any window size (try a tall narrow window, a short wide one, and full screen). The Service order and Live boxes and the tools panel at the bottom each show their own scroll bar only when their contents are taller than the box.
2. When a message appears across the top (for example after pressing Report), the boxes shrink a little to make room and grow back when it goes away; the page still does not scroll. On a narrow window (one column) the page scrolls as before.

### 3.97 Alerts Settings tab; leftovers swept out

1. The last page tab is now **Alerts Settings** (it was Broadcast Integration). Opening it shows the title and, straight under it, **Countdown and alert style** (the projector clock/bar editor and the stage and confidence section), then **Reset to the standard look**, and nothing below it (the Screens list was removed; see 3.98). The back button, the "now live" line, Blank, the Item/Slide step buttons and the "Show a verse over a slideshow slide" box are gone from it. The **V** key no longer does anything (use the verse tray: **T** or **G**).
2. Everything else in the program still works as before: the toolbar buttons, the keys for next and previous, the verse tray. If you notice a button, label or help text that still mentions something you had removed, or a key that does nothing, write down where.

### 3.98 No Screens list on Alerts Settings

1. Open **Alerts Settings**. It ends at **Reset to the standard look** and the short note about the Settings tab. There is no **Screens** heading, no list of addresses and no Preview buttons.
2. The two previews in the Live box on the Service tab still work and follow their dropdowns; the **Settings** tab still has the home screen picture and screen shapes.
3. The browser-source addresses are still on the program's own page: open `http://localhost:<port>/` in a browser (the same address printed when the program starts) and each screen is listed there.

### 3.99 Shut down from the toolbar

1. The **Shut down** button is in the top toolbar, right of **Appearance** and next to the **Connected** display, on every tab. Press it once: it changes to **Sure?** (amber) at exactly the same size, so **Appearance** and **Connected** do not move, and goes back by itself after a few seconds if you do nothing. Nothing is closed yet.
2. Start the clicker helper (3.85), then press **Shut down** twice. The page says "ChurchLight has shut down", the black console window closes, and the AutoHotkey "H" icon leaves the tray (check Task Manager: no AutoHotkey64.exe).
3. In Task Manager there is no python or pythonw left from ChurchLight, and the projector browser sources in XSplit/OBS show their error or blank state because the program is gone.
4. Start ChurchLight again from its icon: your songs and services are all there.

### 3.100 Verse over the slide: toggle, on and off triggers

1. Settings tab, Trigger URLs: the list now has **Verse over the slide: show or hide it (toggle)**, **Show the verse over the slide** and **Hide the verse over the slide** (the old "Hide the verse on top" is replaced by the last one). Clicker buttons you set up before to "hide the verse" still work.
2. Put a slideshow slide live and load a passage into the verse tray. Open the **toggle** address in a browser tab: the first verse of the tray appears over the slide. Open it again: the verse goes away. Again: it comes back.
3. Open **Hide** while a verse shows: it goes away. Open **Hide** again: nothing happens and no error. Open **Show**: the same verse comes back. Open **Show** again while it shows: nothing changes.
4. Show verse 3 from the tray, hide it, open **Show**: verse 3 returns (not verse 1).
5. With a song live instead of a slideshow, **Show** does nothing harmful (a message says verses go over slideshows).
6. Give a clicker button each of the three and check they behave the same way as the addresses.

### 3.101 Fold all / Open all on Settings

1. Settings tab: a **Fold all** button sits next to **← Back to Service**. Press it: every section (Screens, Themes, PDF, Trigger URLs, Clicker, Keys, Keys in any program) folds to its heading, and the button now says **Open all**.
2. Press **Open all**: every section opens again.
3. Fold all, then open just one section by hand: the button says **Fold all** (it folds, it does not open, while any section is open).
4. Fold a few sections, switch to another tab and back, then close and reopen ChurchLight: the folded sections stay folded. This includes the **Clicker** section, which did not remember their state before.

### 3.102 The Timer words follow the clock or bar choice

1. Service tab, **Announcements and timer**, Timer: with **On the projector show: A big clock**, the line reads **Words above it** (for example "Service begins in").
2. Change it to **A scrolling bar**: that line becomes **What the bar says**, already filled with the saved words (starting with "{minutes} until service begins"). **Words above it** is hidden.
3. Change the words (for example "{minutes} until we worship together"), press Enter or click elsewhere. Open **Alerts Settings → bar → What it says**: the same words are there. Change them there instead: the Service tab box shows them.
4. Start a countdown as a bar and change the words while it runs: the next time the bar pops up (at the next whole minute that matches "how often") it uses the new words. A bar that is already scrolling finishes its pass first.
5. Switch back to **A big clock**: **Words above it** returns, with whatever you typed there before.

### 3.103 Empty bar words say nothing; the zero words on the Service tab

1. With **A scrolling bar** chosen, the Timer panel shows **What the bar says** and, beside it, **When it reaches zero** (starting with "Service is beginning"). Both are hidden with **A big clock**.
2. Change the zero words, press Enter, and check the same words on Alerts Settings (and the other way round).
3. Clear **What the bar says** completely and press Enter (no error). Start a countdown of 2 minutes as a bar: the bar never pops up at the whole minutes. Put words back and it pops up again at the next minute.
4. Clear **When it reaches zero** too: the countdown ends and the bar says nothing at zero.
5. On Alerts Settings the bar preview with empty words stays hidden instead of scrolling an empty bar.

### 3.104 Slideshow settings fold in the Deck Library

1. Deck Library tab: each slideshow row shows its name, the summary line (pages, uses, transition, autoplay), then **Edit slideshow**, **Rename**, **Export**, **Delete** and a new **Show settings** button. The picture size, transition and autoplay controls are folded away, so the list is short.
2. Press **Show settings** on one slideshow: its controls appear in the row and the button says **Hide settings**. The other slideshows stay folded.
3. Change a setting inside (for example the transition): it still saves, and the summary line updates.
4. Leave the tab and come back, then close and reopen ChurchLight: the slideshows you opened are still open and the rest are folded.

### 3.105 Slideshows come in as a PDF or pictures only

1. Slideshow Library, **Add a slideshow**: the text says "A PDF, or exported slide pictures." and the button says **Choose a PDF…**. Nothing mentions presentation software or extra programs to install.
2. Choose a PDF: it imports as before ("Added a slideshow of N pages"). Choose several slide pictures: they import as one slideshow. Choose a PDF and a picture together: the page says to choose one or the other.
3. The file chooser only offers PDFs and pictures. If you drag any other presentation file onto the page, it says that is not a kind of file this import accepts.
4. Run `python tools\selftest.py`: it no longer has a line about extra software for presentation files.
5. Settings and Songs, Bibles and the rest of the program look the same as before.

### 3.106 The start file runs minimized

1. Double-click `start_churchlight.bat`. A black window may flash for a moment, then the program's window stays **minimized on the taskbar** (titled "ChurchLight Presenter") and the operator window opens as usual.
2. Open the taskbar button: the program's messages are there. Close the black window: ChurchLight stops. Start it again and use **Shut down** on the toolbar: the black window closes by itself.
2b. Press **Shut down** and watch the taskbar: the black window must disappear by itself (nothing stays minimized, nothing waits for a key). If a window stays, open it and read what it says: a line starting "ChurchLight stopped because of a problem (code ...)" means the program ended with an error code, so tell us the code and look at `churchlight.log`.
3. To see a start-up problem: rename the `churchlight_presenter` folder for a moment and start it. The taskbar button flashes; open it to read "ChurchLight stopped because of a problem" and press a key to close it. Rename the folder back.
4. Run it from a folder with a space in its name (for example `C:\My Church\ChurchLight`): it still starts.

### 3.107 Go to any slide of a slideshow in the service

1. Add a slideshow with several slides to a service (give two of its slides titles in the slideshow editor first, for example "Offering" and "Welcome"). Open the item's **⋯**: under **Go to a slide:** every slide is listed, by its title or "Slide 7", each with a **Go** button. No pictures appear.
2. Press **Go** on slide 5: that slide goes live at once, without stepping through the ones before it. The list marks it (▶), fades the earlier ones (✓) and outlines the next one (→). The projector shows the right picture.
3. Use Next and Previous: the marks follow. With a long slideshow (20 or more slides) the list scrolls inside its box and keeps the live slide in view.
4. A slide marked as skipped in the editor is not in the list. A slideshow with only one slide shows no list. Songs and Bible items look as before.
5. Put two slideshows in one service: each item's list jumps within its own slideshow and the numbers do not mix.

### 3.108 Go is first on each service item

1. Service tab, Service order: on every item (a song, a Bible passage, a slideshow) the blue **Go** button is the first thing on the row, before the type tag and the title. The arrows, **⋯** and **✕** stay together on the right.
2. Press **Go** on each kind of item: it goes live as before. Add an item with a very long title and make the window narrower: **Go** stays at the left of the title and the right-hand buttons drop under the title.
3. Tab through the list with the keyboard: **Go** is reached first on each row and Enter presses it.


### 3.109 Verse tray: ready for the next passage

1. Load `John 3` in the tray and click in **Go to verse**. Type `16` and press **Enter**. The verse is added and marked Ready as before, the Bible pane at the bottom scrolls back to its top (scroll it down a little first to see this), and the cursor stays in **Go to verse**.
2. Press **Enter** again: the verse goes live. The cursor is now in the passage box at the top ("John 3 or John 3:1-21") with its text selected, and **Go to verse** is empty. Type `Romans 8`: it replaces whatever was there. Press Enter to load it.
3. With a chapter loaded, click in **Go to verse** and type `Romans 8` by mistake: the first letter and everything after it appear in the passage box, the cursor is there, and **Go to verse** is empty. Nothing is added to the service. Type `1 John 3` the same way: it also ends up in the passage box (the `1` stays in **Go to verse** until the `J` arrives, then both move together).
4. Digits, commas and hyphens (`16`, `16-18`, `16, 18`) stay in **Go to verse** and tick verses as before.
5. Click **Add whole passage to service** (or **Add to service** with verses ticked): the cursor goes to the passage box with its text selected. **Load + add to service** (Ctrl+Enter) still puts the cursor in **Go to verse**, so the next Enter shows verse 1.
6. Single-key shortcuts (Space, the arrows, `,` and `.`) type into the box while the cursor is in a text box. Press **Esc** to release the box.

### 3.110 Slides in the service drop-downs are whole-line buttons

1. Service tab, Service order: open **⋯** on a song, a Bible passage and a slideshow. Every slide line is now a full-width bar with a small ▶ at the left. There are no little **Go** buttons on the lines. The **Go** at the start of the item row is still there.
2. Hover a bar: it brightens and its edge darkens. Click anywhere on it, including the empty space at the right: that slide goes live. Songs, passages and slideshows all behave the same.
3. The slide on the screen is a solid colored bar with a bright ▶. Slides already shown are faded with ✓. The next one has an outline at the left and →. The rest have a faded ▶.
4. Use a slideshow with a very long slide title or a song with a long lyric line: the text stays on one row and ends with "…". Hold the pointer over it to see the full text.
5. A long song or slideshow scrolls inside its own box. A song's part names ("Verse 1") still have their "sing this part" checkboxes above their bars, and clicking a name only toggles the checkbox.
6. Tab to a bar and press Enter or Space: the slide goes live. The Tab focus ring is visible.

### 3.111 Divide songs by: lines in the song or lines on the screen

1. Themes tab, a projector theme: under **Songs** there is **Divide songs by** next to **Lines per slide**. It starts on **Lines in the song**, so every existing song builds exactly as before. There is no number to type.
2. Choose **Lines on the screen** and set **Lines per slide** to 4. Open a song with long lyric lines in a service on that theme and go live. A lyric line that the projector has to wrap counts as the lines it takes, so a slide never shows more drawn rows than **Lines per slide**. Compare with **Lines in the song**: the same song has fewer, fuller slides that can overflow the screen.
3. The width of a line is measured with the theme's own font (the bundled theme fonts are read letter by letter, so wide fonts like Montserrat wrap sooner than narrow ones like Lato), its **Font size** and its side margins. Raise the **Font size** and the song splits into more, smaller slides; lower it and it holds more per slide. The slides of one part are kept as even as possible: five one-row lines become 3 + 2, never 4 + 1, and a part with long lines never ends up as 2 + 1 + 2 when two slides would do.
4. For a font that is not bundled (Georgia, Arial or one installed on the PC) the widths are estimated, a little on the cautious side, so a slide may hold one row fewer than it could. It never goes over **Lines per slide**. Tell me the font and size if a slide still overflows or looks half empty.
5. Choose **Lines in the song** again to go back. (A theme saved earlier with the old **Characters** choice now reads **Lines on the screen**.)

### 3.112 Song title and CCLI slide

1. Settings tab, **Song title and CCLI slide** (a new section after PDF import): **Show it** is **Before the song** on a new install. Change the wording boxes if you like ("Words and music by", "Used by Permission."), press **Save**, and a message confirms it. If your church's CCLI license number is not set, a note says so and tells you where to add it (Library, Songs).
2. Open the song editor (New song or edit one). Two new boxes sit under the author: **Copyright** (type it like `2010 Hillsong Music`) and a **Title slide** choice (follow Settings, before, after, never). Save a song with an author, a CCLI song number and a copyright.
3. Add that song to a service and press its **Go**. The first slide is the notice: the song title large, then in smaller type "Words and music by <author>", "© <copyright>. Used by Permission." and "CCLI Song #… · CCLI License #…". Next goes to the first lyric slide. Previous from the first lyric returns to the notice.
4. Open **⋯** on the song: the list starts with a **Title and CCLI** row (a tick and one clickable bar). Click the bar to show it. Untick it: that slide disappears from this service only and the row says "left out of this service". Tick it again to bring it back.
5. Settings, choose **After the song**: the notice moves to the end of every song. Choose **Off**: no song has one. A song set to **before**, **after** or **never** in its editor ignores the Settings choice.
6. A song with no author, copyright or song number shows only the lines it has (at least the title). The copyright is shown with one © even if you typed one yourself.
7. Lower third: the notice appears there too, with the title once (not twice). Change the church license number in the Library: the slides update at once.
8. Existing databases: nothing is switched on by the upgrade for a test setup, but a first start of the program sets **Before the song**. If you do not want it, choose **Off**.

### 3.113 Replace slides from a new PDF

1. Slideshow Library, **Edit slideshow** on a slideshow that has slides with titles, notes or timing. Above the slide grid there is a new **Replace from a PDF…** button (greyed out while the slideshow is live, which also blocks editing).
2. Press it and choose a PDF that is a newer version of the same slides (re-exported with a few changes, and perhaps a few extra pages). "Uploading…" and "Reading the new pages…" show beside the buttons.
3. A summary appears, for example: "Slides 1–5 are checked: 2 changed, 3 look identical. 2 new pages will be added at the end." Page 1 of the PDF is compared with slide 1, page 2 with slide 2, and so on; a page whose picture is the same as the existing slide counts as identical and is left alone.
3b. Under the summary, **Slides that look different** lists every such slide with its **Old** picture and the **New** one side by side on the left. Click either picture (or its radio button) to choose it; New is the default and the chosen picture has a coloured border. **Use all New** and **Use all Old** set every slide at once. A slide set to Old stays exactly as it is.
3c. If some slides look identical, a separate choice says so ("Slides 1, 3 look identical"): **Old (leave them as they are)** (the default) or **New (replace them with the new pages)**. A slide set to Old is still left alone.
4. If the new PDF is shorter, the summary says the extra slides "will be kept but skipped", and a tick box offers to remove them instead. Left unticked, they stay in the slideshow (with their pictures, titles and notes) but are marked skipped, so a service no longer shows them; un-skip one in the slideshow editor to use it again.
5. Press **Replace the slides**. The changed slides show their new pictures. Titles, notes, skip settings, timing and transitions of every slide are exactly as before, new pages are added at the end, and a service that uses the slideshow shows the new pictures. A message says what was replaced.
6. Start again and press **Cancel** instead: nothing in the slideshow changes. The temporary copy of the new pages is removed from the Slideshow Library.
7. Choosing the very same PDF the slideshow was first made from reports "all look identical" and the button does nothing useful. Choosing a file that is not a PDF is refused with a message.

### 3.114 Operator name for songs

1. Edit any song (or make a new one). The first box is now **Song name (shown on the screens)**, with a new box under it: **Operator name** (optional, only you see it).
2. Type an operator name such as `123 Amazing Grace` and save. In the Library → Songs list the song appears as **123 Amazing Grace**, with "Song name: Amazing Grace" under it. A song with no operator name appears under its song name as before.
3. In the search box above the Service, typing `123`, `grace` or the author finds the song. Either name works, and the suggestions list shows the operator name.
4. Add the song to the service. The service list and the "Ready" line show the operator name.
5. Put it live. The projector, the lower third and the title and CCLI slide show the **song name** (Amazing Grace), never the operator name. Reports and the CCLI log also use the song name.
6. Clear the operator name and save: the song goes back to showing its song name everywhere. Leaving the box alone while editing the words keeps what was there.

### 3.115 Collapse items button

1. On the Live tab's top toolbar, next to **Next ▶**, there is a button the same size as the other toggle buttons. While any item's drop-down (⋯) is open it reads **Collapse items**: press it and every drop-down closes, the live item's too.
2. Once everything is closed it reads **Open live item**. Press it: only the live item's drop-down opens, and it reads **Collapse items** again. With nothing live and everything closed it is greyed out.
3. Open one or two others by hand, then press **Collapse items**: all of them close again.
4. Click **Go** on a different item: it goes live and its drop-down opens by itself.
5. Click **Go** on the item that is **already live**, after collapsing: its drop-down opens and nothing else happens. The slide stays where it was (it does not restart, and the screens do not change).
6. The button is greyed out while the service is empty.
7. Press **C** on the keyboard (not while typing in a box): it does exactly what the button does, and the button's label shows the key, for example **Collapse items (C)**. In the search box or any text box, C just types the letter. The key can be changed on the Settings tab like the others (it is listed there as "Collapse the service items, or open the live one").

### 3.116 Skip ticks and "Sing the whole song" by mode

1. Add a song with two or more parts to the service and open its ⋯ options. In **Plan** mode each part (and the title and CCLI slide) has a tick to leave it out. There is no **Sing the whole song** button in Plan mode.
2. Untick a part. Switch to **Run** mode: the ticks are gone, but nothing moves. A ✕ stands exactly where the tick was on the part that was left out, which also says "left out". Parts that are in the song show no mark.
3. In Run mode, **Sing the whole song** appears, only because a part is left out. Press it: every part comes back and the button disappears. A song with nothing left out never shows the button.
4. A song with nothing left out shows no "Parts and where we are: whole song" line. The line (for example "1 of 2 parts") only appears once a part is left out.
5. Clicking a slide bar still goes to that slide in both modes. Switch back to Plan: the ticks are there again and the ✕ is gone.
5. Plan mode, a long song (8 or more parts) with its list scrolled down: untick or tick a part. The list stays exactly where you scrolled it, and the service pane does not jump back to the top of the item.
6. Run mode: click the name of a left-out part (with the ✕). Nothing changes, so a part cannot be put back by accident while running the service. The same goes for the title and CCLI slide row. Only **Sing the whole song** brings parts back in Run mode.
7. Title and CCLI slide set to "Before the song": in Plan mode untick it. It stays the **first** row (with its ✕ in Run mode), it does not move to the bottom. With "After the song" it stays last.
8. With only the title and CCLI slide left out, the line reads "title and CCLI slide left out" and, in Run mode, **Sing the whole song** is there. Pressing it brings the title slide back (and does nothing else to the song).

### 3.117 Screen addresses (Settings → Screens)

1. Settings tab → **Screens**, under **Screen shape**: a **Screen addresses** list has one row per screen (projector, lower third, stage, and so on), each with its full address, for example `http://127.0.0.1:PORT/view/projector`.
2. Press **Copy** on a row: it says "Copied", and pasting into an OBS or XSplit browser source shows that screen. (If the browser blocks copying, the address is selected so you can press Ctrl+C.)
3. Click in an address box: the whole address is selected.
4. Started the normal way, only the list for this computer shows. Started with `--host 0.0.0.0` (to reach it from another PC), a second list, **For another computer on your network**, appears with the same screens at this PC's network address (like `http://192.168.1.20:PORT/view/projector`). Open one from the other computer to check it loads. Remember: with `--host` widened, the operator page has no login.

### 3.118 Bible verse breaks follow what the screens hold

A long verse is now cut by measuring it with each screen's real font, margins and size (the projector, and the lower third at the smallest size it may shrink to), not by a character count.

1. Use a lower-third theme with a height cap and a projector theme, add a long verse (for example John 3:16-17 in one passage, or Psalm 119:105 with a big font) and step through its slides. Each slide fills its lower third without cutting earlier than it needs to: if the next words would still fit the lower third, they are on the same slide.
2. No slide ends with one lonely word on a last line when the text could have been shared out more evenly. The parts of a verse are close to the same length.
3. A break falls after a comma, semicolon or full stop when there is one nearby, rather than in the middle of a phrase.
4. Change the lower third (a taller box or smaller text): the breaks change to match. The projector never overflows either.
5. "One verse per slide" and "Fit as many whole verses as will fit" both follow this. A short verse stays whole in both.
6. Reload the same service: the breaks are the same every time.

### 3.119 Automatic backups and the start-up check

1. Start ChurchLight. Close it. A **backups** folder now sits beside `churchlight.db`, holding a file named like `churchlight-20261121-130000-v18.db` (the date, the time and the database version). Start it again straight away: no second copy is made (a copy is only made if the last one is over ten minutes old).
2. Start it on different days or after waiting: new copies appear, and only the newest 10 are kept.
3. A copy is a whole database. Close ChurchLight, copy one over `churchlight.db`, start it: your songs and services from that time are back.
4. **Damaged file (careful, use a copy of your folder):** close ChurchLight and damage `churchlight.db` (open it in Notepad and type over the start, then save). Start ChurchLight: it does not open, and the black window says the church database is damaged and names the newest copy. Run `python -m churchlight_presenter --db churchlight.db --restore-backup`: it says it restored from a copy and keeps the damaged file as `churchlight.db.damaged`. Start normally: everything is back.
5. The backups hold the same secret Trigger URL address as the database. Keep that folder on this computer and do not share it.

### 3.120 The setup guide

1. Start ChurchLight with a **new, empty folder** (no songs, services or slideshows yet). A window opens over the page: **Welcome to ChurchLight**, "Step 1 of 7". The keyboard keys do not touch the screens while it is open. A **Before you start** note says to place the program window where it will be used to run the program during the church service (step 3 uses where the window is to know which monitor that is).
2. **Start**, then **Check this computer**: a list with a ✓ or ! for Python (with its version; on Windows it also warns if the start file could not find Python), the browser, PDF import, the clicker helper (Windows), a Bible and a place to save files, each in plain words. **Check again** repeats it.
3. **Your church and screens**: **What does your church use?** (four choices, plus ticks for the scenes), and **Which monitor shows each room screen?** with a drop-down of this computer's monitors for the projector, stage and confidence screens. Nothing opens on a monitor here. If the monitors cannot be listed (not Windows), a line says you will choose them in the next step. Choosing the monitor this window is on shows a warning. The step names the monitor the window is on ("This program window is on Monitor 1 (main)…"; move the window and press **Check again** to see it change), and that monitor is marked "this window is here" in the drop-downs. Each room screen has a **Test** button, greyed out until a monitor is chosen (and for the monitor holding this window): it shows a white screen with a big black **TEST** full screen on that monitor with no frame (the same for every screen) and the button becomes **Stop test**. There is no timer: it stays until you press **Stop test**, change the monitor, press **Next** or **Back**, or close the guide. Alt+F4 in the test window also closes it, and the button goes back to **Test** within a couple of seconds. Try it on the projector's monitor, then on the stage monitor at the same time. **The projector's shape is not asked:** choosing a monitor for the Projector sets the shape from that monitor's size (1920×1080 gives 16:9, 1024×768 gives 4:3, 1920×1200 gives 16:10) and says so under the drop-down; check Settings → Screens to see it. Changing the monitor changes the shape. Settings → Screens still lets you set it by hand.
4. **Set up OBS**: the port and password, **Connect and make the scenes**, and a line naming the scenes it will make from your step 3 answers. See 3.121. Under "Add the screens by hand instead" each screen's address is listed with **Copy**. There is no step that opens a ChurchLight window on a monitor: OBS does that.
5. **Add your content**: **Make a practice service** closes the guide and opens a service with a practice song and John 3:16. The buttons for songs, slideshows and Bibles take you to those tabs.
6. **Look, clicker and Stream Deck**: the buttons open the Appearance panel, the Theme Library, and the Settings sections for the home picture, the clicker and the Trigger URLs.
7. **You are ready** has **Finish**. After Finish (or **Skip setup** at any step) the guide does not open by itself again, even after a restart.
8. **Esc** closes the guide without marking it done: with an empty ChurchLight it opens again at the next start.
9. A ChurchLight that already has songs, services or slideshows never opens the guide by itself. Settings has **Run the setup guide again**, which opens it from step 1 at any time.
10. Back works on every step after the first, and Tab stays inside the guide.

### 3.121 The setup guide makes the OBS scenes and projects the screens (needs OBS 28 or newer)

1. Open OBS. Choose **Tools > WebSocket Server Settings**, tick **Enable WebSocket server**, and note the port (usually 4455). If a password is set, press **Show Connect Info** to see it.
2. ChurchLight: **Settings > Run the setup guide again**, go to step 4, **Set up OBS** (first choose what your church uses and the monitors on step 3). Type the port and password. Leave all four scenes ticked and press **Connect and make the scenes**.
3. **Show the password** under the Password box lets you see what you typed. With a wrong password it says OBS refused the password (this appears only when OBS itself says the password failed; if OBS hangs up for another reason, the message gives OBS's own reason and code, or says OBS did not answer, and the details are also written to churchlight.log). With OBS closed (or the WebSocket server off) it says OBS did not answer and how to turn it on. Neither changes anything in OBS.
4. With the right details, a list says what was made. In OBS you now have the scenes **ChurchLight Projector**, **ChurchLight Livestream**, **ChurchLight Stage**, **ChurchLight Confidence** and **ChurchLight Home**. Each browser source (named like "ChurchLight projector") shows its screen's address and is the size of your OBS canvas. Livestream holds **ChurchLight Camera** (below) and the lower third on a layer above it; open the camera's properties and choose your camera. If you press **Make the scenes again** after dragging the lower third under the camera in OBS, it is moved back above it and the list says so. Home has a black background.
5. Your own scenes and sources were not changed or removed.
5a. On step 3, **What does your church use?** has four choices. Choose **Livestream only**: the ticks below change to just Livestream, the projector shape picker and the monitor choices disappear, and after you press Next and **Connect and make the scenes** on step 4 OBS has only **ChurchLight Livestream** (camera with the lower third above it) and the guide shows no monitor choices. The other choices (**Room projector only**, **Projector and livestream**, **Everything**) tick the matching scenes; you can still change the ticks by hand.
5b. **Changing the OBS password:** in OBS press **Generate Password** and **Apply**. In ChurchLight step 4, paste the new password into the Password box and press **Open the projectors now** (without pressing Make the scenes again): it works with the new password, and from then on the new one is the one remembered (if **Remember** is ticked). It never needs the old password.
6. Press **Make the scenes again**: nothing is duplicated; the list says things were "already there".
7. **The shape follows the OBS monitor too:** when you press **Open the projectors now**, the projector screen's shape is set from the size of the monitor you gave the Projector scene.
7a. **Put the room screens on your monitors**: a monitor you chose on step 3 is already selected here (matched by where the monitor sits, so it is right even if OBS numbers the monitors differently; if no match is found, the same list position is used, and you can change any of them). Each room screen (Projector, Stage, Confidence) has a drop-down of your monitors (name and size). The projector is pre-set to your last monitor; the others to "Do not project this one". Do not choose the monitor holding the operator page. Press **Open the projectors now**: OBS opens a full-screen view of that scene on each chosen monitor, with no extra browser window.
8. Run a service: the projector monitor follows the live slide, the stage monitor shows notes, and the lower third (in the Livestream scene) appears over the camera.
9. Tick **Open them by themselves whenever ChurchLight starts**. Close both programs, open OBS first, then start ChurchLight: the projectors open on their own within about 30 seconds. If OBS is not open, ChurchLight starts normally and says nothing.
10. The OBS password is kept in the church database (and so in its backups) only when **Remember the OBS password on this computer** is ticked. Untick it to have it asked each time.
11. XSplit users: use **Add the screens by hand instead** (the addresses with Copy).

### 3.122 The Test window (setup guide step 3)

The setup guide's **Test** is the only thing that opens a ChurchLight window on a monitor. It shows the white **TEST** page (3.130). It is refused on the monitor the operator window is on, stays until **Stop test**, Esc on that screen, or leaving the step, and any leftover Test window of that screen is closed before a new one opens (3.131). Nothing else in the program opens a full-screen window: OBS puts the room screens on the monitors (3.121).

### 3.123 Python: bundled copy and a clear message when it is missing (Windows)

1. **Safety net (do this first):** on a PC with no Python (or temporarily rename your Python install, or test with a folder copy and PATH cleared), double-click `start_churchlight.bat`. A black window says ChurchLight needs Python, with three numbered steps (choose the 64-bit installer, tick **Add python.exe to PATH**, run the file again), and the python.org download page opens. Press a key: it closes.
2. **Make the bundled copy:** on a PC with internet, right-click `tools\Get-BundledPython.ps1`, **Run with PowerShell**. It downloads the embeddable Python, prints its SHA-256 (compare it with the number on that version's python.org page; or run it again with `-Sha256 <number>` to refuse a mismatch), makes a `python` folder next to `start_churchlight.bat`, and ends with "Python 3.12.x is ready" and "ChurchLight found".
3. Double-click `start_churchlight.bat` with that folder present on a PC that has no Python: ChurchLight starts and the guide opens using the bundled copy.
4. On a PC that has Python 3.10 or newer, the installed one is used and the bundled copy is left alone. Delete (or rename) the `python` folder there: nothing changes. With Python older than 3.10 and the folder present, the bundled copy is used; with neither you get the message from step 1.
5. Check that PDF import, the clicker helper (Windows) and a backup (close and restart) still work when started with the bundled Python.

### 3.124 Delete several songs or slideshows at once

1. **Song Library**, Songs section: press **Select several** (beside New song). A bar appears with **Select all shown**, **Clear**, a count ("0 selected") and **Delete selected**, and each song shows a tick box with its name (the other buttons are hidden while you choose). The button now says **Done**.
2. Tick two or three songs. The count follows. Type in the filter box: only the songs shown can stay chosen (the count drops if a chosen song is filtered out), so what you see is what is deleted.
3. A song that is in a service has a greyed-out tick box (hover: take it out of those services first), and **Select all shown** skips it.
4. Press **Delete selected**: it changes to **Sure? Delete 3** and goes back by itself after 4 seconds if you do nothing. Press it again within that time: a message says "Deleted 3 songs." and, if any were skipped, why, and that a backup was saved first. A new file is in the **backups** folder beside churchlight.db, even if a backup was made a minute ago.
5. The list returns to normal. **Done** (or **Select several** again) leaves choosing mode without deleting anything.
6. **Slideshow Library**: the same, with **Select several** beside **Export all slideshows**. Deleting a slideshow also removes its pictures if nothing else uses them; one used in a service cannot be chosen.
7. With nothing chosen, **Delete selected** is greyed out. Drafts are not part of this list (delete them from the Drafts section as before).

### 3.125 A verse over a slideshow: its look is for the projector only

1. **Bibles** (or Themes) tab: set **A verse over a slideshow uses** to an overlay theme with a clearly different look from your lower-third theme (for example, a box at the top right).
2. Put a slideshow slide live, then show a verse over it from the tray (or type one). On the **projector**, the verse appears in the verse-over look (the top-right box).
3. On the **lower-third** output (and the verse-lower-third output), the same verse appears in the service's chosen **lower-third theme** (its own position, size and colours), not the verse-over look.
4. A long verse still splits so it fits both boxes: the projector's verse-over box and the lower third. Neither is cut off.
5. Set **A verse over a slideshow uses** back to "Same as the Bible theme": the projector goes back to the Bible look, the lower third is unchanged.

### 3.126 Keep a verse over a slideshow off the projector (livestream shows it on the lower third only)

1. **Themes** tab: make (or open) an **Overlay** theme. In **Bible verses** there is a tick box, **Lower third only (for a verse over a slideshow: keep it off the projector)**. Projector and confidence themes do not have it.
2. Tick it and save. On the **Bibles** tab (or Themes tab), choose that theme under **A verse over a slideshow uses**.
3. Put a slideshow slide live and show a verse over it. The projector (and a projector browser source in OBS) shows only the slide. The lower-third outputs show the verse in the lower-third theme.
4. Show a verse by itself (nothing under it): the projector shows it as before.
5. Untick the box (or choose a different theme under **A verse over a slideshow uses**): the verse appears over the slide on the projector again.

### 3.127 The clicker helper (AutoHotkey) closes with ChurchLight

1. Start the clicker helper from **Settings** (the green H icon appears in the tray). Press **Shut down** (then **Sure?**): ChurchLight closes and the H icon is gone from the tray within a second or two. In Task Manager there is no AutoHotkey64.exe left.
2. Start it again, then close ChurchLight a different way (close the black window, or end it from Task Manager). The H icon goes away by itself within about 15 seconds.
3. If you run the **downloaded** helper script by hand, it also closes by itself within about 15 seconds after ChurchLight is closed.
4. While ChurchLight stays open, the helper keeps working for hours: the clicker keeps moving slides.

### 3.128 Shut down closes ChurchLight's own browser windows (Windows)

1. Start ChurchLight with start_churchlight.bat. The operator window opens. Open **Task Manager** → **Details** and note the `msedge.exe` entries (your own Edge windows, if any, are in this list too).
2. Open a **Test** of a room screen (setup guide step 3, or Settings), and while it shows, press **Shut down** and then **Sure?**.
3. Within about 5 seconds the operator window closes by itself, the Test window is gone, and the black ChurchLight window closes.
4. In Task Manager, no `msedge.exe` from ChurchLight is left. To check which belong to ChurchLight: before Shut down, right-click the columns header → **Select columns** → **Command line**; the ones with `browser-profile` in the command line are ChurchLight's. After Shut down none of those remain.
5. **Your own Edge must be untouched.** Before step 2, open a normal Edge window with a page or two of your own. After Shut down it is still open and still has its pages.
6. Start ChurchLight again: the operator window opens in its remembered place and nothing complains about a profile in use.
7. Close ChurchLight the other way (Ctrl+C in the black window, or the window's X) and check the operator window also closes.

### 3.129 Setup guide step 3: note for a Test that shows nothing

1. In the setup guide, step 3 ("Your church and screens"), the note under the monitor list ends with: "If nothing appears, another program may be covering that monitor: close any full-screen projector already open there (for example from OBS or XSplit), then press Test again."
2. With an OBS or XSplit projector open full screen on the monitor you picked, **Test** shows nothing; close that projector and press **Test** again: the screen shows.

### 3.130 The Test button shows a big TEST

1. Setup guide step 3: choose a monitor and press **Test** for any room screen (projector, confidence monitor, stage). The log line for it ends with `?kiosk=1&test=1`.
2. That monitor goes completely white with a very large black **TEST**, whatever the screen is for (not the real slides). Nothing else is drawn.
3. Press **Stop test** (or Esc on that screen, or leave the step): it closes.
4. A normal screen opened another way (not Test) still shows its real content.

### 3.131 Test opens a fresh window every time (leftover windows are closed first)

1. Setup guide step 3: press **Test** on a monitor: the white **TEST** screen shows. Press **Stop test**.
2. Press **Test** again, several times (also on a different monitor, and for a second room screen): the white **TEST** screen shows each time, on the monitor you chose.
3. Close ChurchLight by force (End task on the black window) while a Test is showing, start it again and press **Test**: the TEST screen shows (the old window is closed first, nothing stays behind).
4. The log file (`churchlight.log`) says, for each Test, "Screen projector opened full screen on monitor N: http://127.0.0.1:PORT/view/projector?kiosk=1&test=1". If a Test ever stays blank, send me that line and what the window shows.

### 3.132 Which copy is running (build label)

1. **Settings** tab, at the very bottom: "This copy of ChurchLight is build zt231." The black ChurchLight window also prints "This is ChurchLight build zt231", and the first line of `churchlight.log` for each start says "Starting ChurchLight build zt231".
2. If the label is older than the zip you just unzipped, ChurchLight was started from an older folder or was never closed. Close it completely (Shut down), then start it again from the new folder.

## Video and sound: stress-test checklist (zt220, still current)

What is new: MP4 (H.264) video clips and MP3/WAV sound files. They now live in the **Media Library** tab (new in zt221). A video or sound file goes into a service like a song, or goes live straight away. A sound file can also play as **music under the slides**. The **projector page** plays them; the program only streams the file and keeps the position. Only **one** projector screen makes sound (the first projector screen in your list); other projector pages show the picture silently, and the small previews in the operator window only show a label.

Not built yet (do not test): looping video behind songs, the setup guide setting up OBS sound for you, and a saved "go to the next item when it ends" choice (it starts ON each time ChurchLight starts).

**Before you start**
- Have: an MP4 of about 20-30 seconds, one long MP4 (10 minutes or more, ideally 500 MB or more), a short MP3 (about 1 minute), a long MP3 or WAV (10 minutes or more), and a **WAV**.
- Open **Task Manager** → **Details** and keep it where you can see it. Note `python.exe`, `msedge.exe` (ChurchLight's windows only, see 3.128) and `obs64.exe`.
- In OBS: **View → Stats** open. Note CPU, "Skipped frames", "Missed frames", "Dropped frames" at the start.
- Start a **service** first. The Service tab only shows the video and sound controls while a service is open.

### 3.133 Add video and sound to the library

1. **Slideshow Library** tab → **Video and sound** → **Choose a video or sound file…**: choose the short MP4. The list shows its name, a length like `0:24`, its size in MB. It takes a moment on a big file: the status line says **Reading**, then **Uploading**.
2. Add the short MP3 and the WAV the same way. The MP3 and WAV rows have a **Play as music** button; the MP4 does not.
3. Choose a file ending in `.mov`, `.avi`, `.mkv` or `.txt`: a message says it is not one of the allowed kinds. Nothing is added.
4. Rename a row: the new name shows. Rename to an empty name: it refuses.
5. Add the long MP4 (500 MB or more is best). It uploads without freezing the operator page (you can click other tabs while it uploads). Note how long it took and send it to me.
6. Restart ChurchLight (Shut down, start again): every file is still listed with its length.

### 3.134 A video as a service item

1. In a service, add the short MP4 with **Add to service** (it appears as an item). Put it between two other items (a song, a slideshow).
2. **Go** on the video item. On the **projector** the video plays from the start, with sound, full screen (black bars if its shape differs). The operator's **Live** area shows a **Video playing now** panel with Pause, Start again, a position bar with the time (counting up), Volume, Mute, and the two tick boxes.
3. Let it play to the end with **Go to the next item when it ends** ticked. About a quarter of a second after it ends, the next slide comes up by itself. The video's last frame is not replaced early.
4. Run it again with that box **unticked**: it stops on its last frame and stays; **Next** moves on.
5. Press **Pause** while it plays: picture and sound freeze. **Play** continues from the same spot. Press **Start again**: it begins from the top. After it ended, the button says **Play again** and plays from the top.
6. Drag the position bar to the middle: the video jumps there and carries on (or stays paused if it was paused).
7. Tick **Play it again and again**: at the end it starts over with no gap you can see, and the program does not move on. Untick it: it ends normally.
8. **Volume** slider and **Mute**: the sound changes right away; Mute turns the sound off without pausing the video.
9. While the video plays, press **Blank**: the projector shows its blank/home screen and the sound stops. **Blank** again: the video is back **at the right place** (not from the start).
10. Press **Next** or click another item while it plays: the video goes away and the other item shows. The sound stops.

### 3.135 Music under the slides

1. In the library, **Play as music** on the MP3. The **Music under the slides** panel shows on the Service page with the name and a time counting up. The music is heard on the projector.
2. Go through songs and slides (Next, next item, a slideshow, a verse): the music **keeps playing without a break** the whole time.
3. Put the **video** from 3.134 live while music plays: both are heard together (turn the music down with its own volume to hear the video). Go on to another item: music still plays.
4. Music **Pause / Play**, **Start again**, **Stop the music**, its position bar, its **Volume**, **Mute** and **Play it again and again** all work. When the music ends (not looping) it stops and the panel stays with **Play again** until you stop it.
5. **Blank**: the slides go but the **music keeps playing**.
6. **Stop the music**: the panel goes away.
7. Delete: a file that is playing, or used in a service, cannot be deleted (a message says so). After removing it from the service and stopping it, **Delete** works and the file is really gone from the `media` folder.

### 3.136 Only one screen makes sound, and the small previews never play

1. Settings: you need two projector screens (for example "projector" and a second projector output). If you only have one, skip step 2.
2. Open both screens' pages in two browser tabs (`/view/projector` and `/view/<second>`), play music: sound comes from **one** tab only (the first projector screen), not as an echo from both.
3. Turn on the previews in the operator window and put a video live: the preview frames show the words "Video: <name>" (or "Sound: …" in a sound slide), they do **not** play the video, and you hear nothing doubled.
4. The lower-third and stage / confidence screens never play anything.
5. In an ordinary browser tab (not OBS), if the browser refuses to play sound, the tab shows **Click this page once to turn the sound on**; clicking turns it on.

### 3.137 In OBS (the sound path)

1. In OBS the projector's Browser source: tick **Control audio via OBS**. (In the setup guide this is not done for you yet.) Right-click the source → **Properties** and confirm.
2. Put the video live. The video shows in OBS. In the OBS **Audio Mixer** the browser source has a meter that moves when the video or music plays. Mute / unmute in OBS works.
3. **Lip-sync:** play a video with clear speech or a clap. Record 30 seconds in OBS, play it back: is the sound in time with the picture? If not, note how far off (use the source's **Advanced Audio Properties → Sync offset**).
4. The program's own **Volume** and **Mute** change what OBS hears (the OBS meter follows).
5. Also try the manual test I asked for earlier: add a Browser source with `file:///C:/path/clip.mp4` in OBS, and the same in XSplit. Does the video play? Is there sound in the mixer? Any green/black picture? Send the answers.
6. OBS **Stats** during the video: CPU, dropped frames, missed frames. Compare to the numbers you noted at the start.

### 3.138 In XSplit

1. Same as 3.137 with the projector as an XSplit web page source. Does the video show? Does the sound reach XSplit's audio mixer or the stream? If sound only comes out of the PC speakers, note it.
2. If sound does not reach XSplit, tell me how you hear it (speakers? nothing?). I will add an OBS-only or Windows-audio route for XSplit based on what you find.

### 3.139 Stress test: speed and how the machine copes

Do these in OBS with **Stats** open and **Task Manager** visible. For each, write down what you see.

1. **Resource use while idle with a video playing:** play a 1080p MP4 on loop. After 2 minutes: `python.exe` CPU and memory; `msedge.exe` (the projector window, if any) or OBS CPU; OBS dropped frames. Python should be nearly idle (it only sends file pieces).
2. **The long video (500 MB+):** put it live, drag the position bar to the start, middle, and end several times. Each jump shows the picture within about 1-2 seconds. Python's memory does not grow with the file's size (it should stay about the same as before).
3. **Soak:** loop the long video, or play the long MP3/WAV as music with looping, for **45-60 minutes** while ChurchLight also runs a normal service (Next through songs, blank, verses). At the end: no stutter, no sound drift between picture and sound, Python memory about the same as at the start (note both), OBS dropped frames still near zero.
4. **Rapid controls:** hit Pause/Play 30 times quickly, Start again 20 times, drag the position bar back and forth, move Volume quickly, tick/untick Loop. Nothing crashes, the panel always shows the real state, and the sound/picture follow within a second.
5. **Quick changes:** go live on the video, press Next/Previous quickly through items before it starts, go to the video and straight to another item 20 times. No leftover sound; no video stuck on screen.
6. **Several at once:** one video + music playing + a countdown timer + a verse over a slide + Blank on and off. All still behave.
7. **Browser/page restarts:** with a video playing, reload the projector page (F5 in a test tab, or restart the OBS browser source with **Refresh cache of current page**): it comes back to the right position within a second or two, not the start.
8. **Closing ChurchLight while it plays:** Shut down. Nothing is left in Task Manager (python, msedge with `browser-profile`, AutoHotkey).

### 3.140 Things that should fail politely

1. A file named `.mp4` that is really something else (rename a `.txt` to `.mp4`): refused with a plain message about MP4 (H.264) / MP3 / WAV. Nothing is added.
2. An MP4 that is **not** H.264 (for example a phone video saved as H.265/HEVC, or a `.mov` renamed): it may be added, but when you put it live the projector shows no picture, and the operator shows a message. Tell me which file and what the page showed. The advice "re-save as MP4 with HandBrake" should be enough to fix it.
3. A file larger than 1 GB: refused with the size message.
4. Move or delete a video file from the `media` folder by hand, then put it live: nothing crashes; the page shows no video; other screens keep working.
5. Stop the ChurchLight program while the OBS browser source is showing a video: OBS shows nothing/an error and **recovers** by itself when ChurchLight starts again.
6. The long video on a slow USB drive or network folder is not part of this test (only the `media` folder).

### 3.141 Clicker and trigger buttons (optional)

1. **Settings → Trigger URLs** now lists **Video or sound slide: play or pause**, **start again from the beginning**, and **Music under the slides: play or pause**. Open each address in a browser tab while a video or music is live: it does the thing.
2. Assign one of them to a clicker button (Settings → clicker): the button toggles the video.

### What to send me

- **"works" or "needs work"** for each numbered item above.
- For any "needs work": what you pressed, what happened, what you expected. A phone photo of the screen is fine.
- The **numbers** from 3.139 (Python CPU/memory at start and at the end of the soak; OBS dropped/missed frames at start and end; upload time of the big file).
- The answers to 3.137 step 5 (OBS and XSplit `file:///` test) and 3.138 (XSplit sound).
- If something goes wrong, the file `churchlight.log` (it is in the ChurchLight folder) right after it happens.


## Media Library, video and sound in slideshows (zt221)

What is new since zt220: a **Media Library** tab for pictures, videos and sound (the video and sound list moved there). The **Slideshow Library** still adds pictures its own way. In the **slideshow editor**, **Add from Media Library…** puts library pictures and videos into a slideshow without uploading them again. A page can play its video without its own sound, and any page can carry a sound file that plays while the page is on screen. Slideshows with video pages cannot be exported yet.

Test zt220's video and sound list (3.133–3.141) first as written, but find the files under the **Media Library** tab.

### 3.142 The Media Library tab

1. A new tab, **Media Library**, sits between **Slideshow Library** and **Bible Library**.
2. **Choose pictures, videos or sound…** accepts several files at once: PNG, JPG, GIF, WEBP pictures (up to 25 MB each), MP4 videos and MP3/WAV sound. Pictures show a small thumbnail; videos show ▶ and sound shows ♪; each row shows its kind, length (video/sound), size and how many services and slideshows use it.
3. The **Show** drop-down narrows the list to Everything, Pictures, Videos or Sound.
4. A picture has **Add to service** and **Show now**; a video has **Add to service** and **Play now**; a sound has **Play as music** too. Rename and Delete work. A file that a service or a slideshow uses cannot be deleted (the row says "in 1 slideshow" and Delete is greyed out).
5. Add a `.txt`, a picture over 25 MB, or a fake `.png`: each is refused with a plain message and nothing is added.
6. Add a picture to a service with **Add to service**, then **Go** on it: it shows full screen like a slide picture.

### 3.143 "From slideshows and themes"

1. On the same tab, the second section lists pictures that did not come through the Media Library: each slideshow (with up to four small pictures and its slide count), each theme that has a background picture, and the home screen picture if you set one.
2. They are read-only: there is no Delete or Rename here. **Open slideshow** opens that slideshow's editor.
3. Pictures added through the Media Library are not repeated in this section.

### 3.144 Add library files to a slideshow

1. Open a slideshow in the editor (**Slideshow Library** → **Edit slideshow**). Click **Add from Media Library…**. A panel shows the pictures and videos from the library. Videos show a ▶ tile.
2. Click several to choose them (they get a coloured border), then **Add 3 files**. They appear as new slides after the slide that was selected (or at the end), and they become selected.
3. A video slide shows a ▶ Video tile in the grid and the words "Video page" in the preview. Its flags say "Video".
4. The same library picture can be added to a second slideshow. Delete the page in one slideshow: the other still shows it, and the file is still in the Media Library.
5. Delete the whole slideshow: the pictures it took from the library are still in the Media Library.
6. In the Media Library, a picture used in a slideshow says "in 1 slideshow" and cannot be deleted until it is taken out.
7. **Replace picture…** on a library slide makes it an ordinary slide again.
8. Adding a sound file, or nothing chosen, is not possible from this panel (a message or a greyed-out Add).

### 3.145 A video page in a slideshow

1. Put the slideshow in a service and **Go** on it. Click through the slides: on the video slide the video plays on the projector with sound, and the **Playing now** panel shows its controls (as in 3.134).
2. When the video ends, the slideshow moves to the next slide by itself, **even if you gave that slide a delay in seconds** (the video's end decides, not the delay). With **Go to the next item when it ends** unticked it stays on the last frame.
3. A slideshow that ends on a video: the last frame stays.
4. **Blank** and **Next** act as in 3.134.

### 3.146 Mute a video page, and sound for any page

1. In the slideshow editor, select the video slide. The side panel has a **Sound** section: **Play the video without its own sound**. Tick it. In the service, that page plays picture only, with no sound from the video. (The tick box only appears when a video slide is selected.)
2. Select one or more slides, picture or video. **Sound file that plays with the selected slides** lists the sound files from the Media Library. Choose one. The slide card shows "Sound".
3. With a few slides selected that have different sounds, the list shows **Mixed**. Choosing a file sets it for all of them.
4. **Play it again and again** makes the sound repeat while the page is on screen. It is greyed out when there is no sound chosen.
5. In the service: when the slide comes up, its sound starts at once, from the start. When you move to a different slide, the sound stops. A different slide with the same sound starts it again from the top.
6. A **Sound with this slide** panel appears on the Service page with Pause/Play, Start again, loop, volume and Mute, and a time counter.
7. A video page with its own sound on **and** a separate sound file plays both together. Mute the video's sound to hear only the file.
8. The music under the slides (3.135), a page's sound and a video can all play together. Turning the volume down on the page's panel also turns down the video (they share the volume and mute).
9. **Blank** silences the page's sound; bringing the screens back starts it again at the right place.
10. Choose **No extra sound** to take it off a slide: the "Sound" flag goes away.
11. A sound file used by a slideshow cannot be deleted from the Media Library.
12. A slideshow that is **live** cannot be edited: the sound controls are greyed out, as for all slideshow edits.

### 3.147 Exporting

1. A slideshow with only pictures (library or not) exports and imports as before. Sound files and "no sound" settings are not part of an export yet.
2. A slideshow with a **video** page cannot be exported: the message says it has a video page and cannot be exported yet. Note: send me if you want that built.

### What to send me for 3.142–3.147

"Works" or "needs work" for each item. For problems: what you did, what you saw, and a photo if it helps.

## Setup guide steps 5 and 6 (zt222)

Steps 5 and 6 of the setup guide no longer send you to another tab. Everything is done inside the guide window. Open the guide from **Settings** → **Run the setup guide** (or use a fresh copy).

### 3.148 Step 5, Add your content

1. **Make a practice service**: the guide stays open and says "A practice service is ready. You will find it on the Service tab when you finish." After **Finish**, the Service tab has the practice service.
2. **Songs → Choose song files…** : pick one or more song files. The line under it says how it is going ("Uploading…", then the import's own line, ending in **Done**). The guide stays on step 5. Afterwards the songs are in the Song Library.
3. **A slideshow**: type a name if you like, then **Choose a PDF…** (or **Choose slide pictures…**). It shows progress and ends in **Done**. The slideshow is in the Slideshow Library afterwards.
4. **Another Bible**: type the short name (for example KJV2), choose the file. Without the short name, a clear message appears on the page. The Bible is in the Bible Library afterwards.
5. **Pictures, videos and sound**: choose files (a picture, an MP4, an MP3). The line says "Added …" for each; they appear in the Media Library tab afterwards.
6. A wrong file (for example a `.exe`) gives a plain message and nothing is added. Nothing in this step takes you to another tab.

### 3.149 Step 6, Look, clicker and Stream Deck

1. **Light or dark, text size**: the buttons change the whole page at once. The one in use looks pressed.
2. **Theme**: a drop-down for the projector theme and one for the lower-third theme (only if you have more than one choice). Choosing one changes the program's starting theme, as in the Theme Library.
3. **Home screen picture**: **Choose picture…** uploads it and shows a small preview; **Change picture…** and **Remove** work. Nothing else in the guide moves.
4. **Presentation clicker (Windows)**: **Start the clicker (usual buttons)** turns Trigger URLs on if needed and starts the helper with Page Down = next, Page Up = back, full stop = blank. The green H icon shows in the tray; the clicker works. **Stop the clicker** stops it. The tick box starts it with ChurchLight. (On a computer where the helper is not available, a short note says so.)
5. **Stream Deck and Trigger URLs**: tick **Turn Trigger URLs on**. Addresses for next slide, previous slide and blank appear with **Copy**. Paste one into a browser tab: it does that. Untick: the addresses disappear.
6. After all of this, **Finish** closes the guide and the service tab opens as normal. Nothing in steps 5 and 6 closes the guide by itself.

### 3.150 Sound plays from ChurchLight's own window (zt223)

1. Close the OBS "ChurchLight projector" sound setting if you ticked **Control audio via OBS** by hand: untick it (or run the OBS step again; ChurchLight no longer sets it).
2. In ChurchLight, play a video or music. You hear it from this computer's speakers, from the ChurchLight window itself, with no OBS settings needed. The Playing now panel says "The sound plays from this ChurchLight window".
3. Open Settings → **Sound**. Untick **Play video and music sound from this window**: the sound stops. Tick it again: it plays again from the right place.
4. In OBS, add **Audio Output Capture** or use the default **Desktop Audio**. The mixer bar moves when a video plays and the sound is on the stream and in a recording.
5. With the OBS projector source open, the sound is not heard twice (the OBS browser source is silent).
6. Only if you want OBS itself to carry the sound: add `?sound=on` to the end of the source's address and tick **Control audio via OBS**; then untick the Settings → Sound box so it is not heard twice.

### 3.151 Home picture shows on the first upload (zt224)

1. Setup guide, step 6: with no home picture set, **Choose picture…** and pick a picture. The small preview appears straight away, without choosing the picture a second time. The button changes to **Change picture…** and **Remove** appears.
2. **Remove** takes the preview away at once.
3. The same goes for the Trigger URL addresses (tick the box and they appear) and the clicker's Start/Stop note: step 6 redraws itself whenever the program reports a change.

### 3.152 Several PDFs at once (zt225)

1. Setup guide step 5 → **A slideshow** → **Choose a PDF…**, then select three different PDFs together (Ctrl-click). The line says "Uploaded 3 of 3 slideshows". Each one appears in the **Slideshow Library**, named after its file (the name box is only used for a single PDF).
2. The same in the Slideshow Library tab (**Choose a PDF…** with several PDFs).
3. A PDF that is exactly the same file as one already in the library is skipped (it is the same slideshow); a mix of PDFs and pictures is refused with a plain message.

### 3.153 Search bar finds media (zt226)

1. Service tab, in the search box above the service order: type part of the name of a picture, video or sound file from the Media Library. It is listed with a small tag (PICTURE, VIDEO or SOUND) and its type and length ("Video 1:30"). Songs and slideshows with that word are listed too.
2. The drop-down beside the box now has **All, Songs, Slideshows, Pictures, Videos, Sound**. Each one narrows both the list and the names that pop up under the box while you type. With no words typed, choosing a kind lists everything of that kind. The choice is remembered.
3. **Add** puts a found file at the end of the service; **Live** shows it on its own; **Look** shows what it would look like. A video or sound shows its clip controls after **Live**.
4. Pick a file from the pop-up names with the arrow keys and Enter: it is added to the service, as for songs.

### 3.154 Jumbled or doubled sound on a long video (zt227)

1. Play a long video (a few minutes or more) on the projector with XSplit (or OBS) showing the ChurchLight projector page as a web page source. The sound is clean: one copy, no echo, no pieces of the sound over each other, for the whole video.
2. The XSplit/OBS web page is now silent. Only the ChurchLight window makes the sound; XSplit picks it up from the computer's sound (a "System sound" source). If you hear it twice, check whether XSplit's own sound source for the web page is on, and tell me.
3. Open ChurchLight in two windows on this computer (for example the app window and a browser tab). Play a video: only one window plays it. The other's Playing now panel says "Another ChurchLight window on this computer is playing the sound".
4. While a long video plays, drag the position bar several times and refresh the XSplit source. The sound never doubles up afterwards.
5. An address that should make the sound itself (OBS "Control audio via OBS") ends with `?sound=on`; every other address stays silent.

### 3.155 Several uploads in a row (zt228)

1. Media Library tab: choose two or three big videos, and straight after that choose another one while the first are still going. The page stays usable (tabs switch, buttons answer) the whole time. They upload one after the other and all appear in the list with their lengths.
2. Do the same from the setup guide (step 5) and with several slideshows at once. Nothing freezes.
3. While a video plays on the projector, upload another video: the page still answers.
4. If it ever stops answering again, note: what you were doing, whether the page or the whole program stopped, whether it came back by itself and how long it took, Task Manager's CPU and memory for `python.exe` and Edge, and send `churchlight.log`.

### 3.156 First play shows the picture; no "Click this page" on a silent page (zt229)

1. Restart ChurchLight (close everything, start the batch file), refresh the XSplit projector source once, load the service and play a **new** video for the first time. The picture appears at once, with sound from the house, the same as on the second play.
2. The XSplit projector page never shows "Click this page once to turn the sound on". (Only a page that is meant to make sound can show it, and only if the browser will not allow sound.)
3. If the first play ever shows no picture again: add `?debug` to the end of the XSplit projector's address, refresh it, play the video and read the small line of text at the bottom ("Loading the video…", "The video is slow to load…" or an error). Send that wording and `churchlight.log`.

### 3.157 Video freezing, lag and scrubbing; guide messages (zt230)

1. **Quick starts.** Play a video, press Clear live, and straight away play another video. Do this 10–20 times fast, then leave one playing. The picture is on the XSplit projector every time and keeps playing, with the sound in step.
2. **Jumping between videos.** Jump quickly between several different videos and the service items around them. The picture never freezes while the sound carries on. Leave it on a video for a minute: it still plays.
3. **Lag.** Play the long 1080p video for a few minutes. The picture keeps up with the sound. A little lag in the picture is fixed gently, not by jumping again and again.
4. **Scrubbing.** Drag the position bar quickly back and forth, then let go. The picture and the sound both end where the bar was left, and stay together.
5. **If it still happens:** add `?debug` to the end of the XSplit projector's address and refresh it. A small block of text at the bottom of the picture shows, for each clip, where the picture is against where it should be, how many frames it has shown and how many were dropped. Photograph or copy it at the moment the picture lags or freezes, and send it with `churchlight.log`.
6. **Setup guide errors.** In step 5, choose a file that cannot be used (a `.txt`, or a picture over 25 MB). The explanation appears inside the guide window, under the steps, not behind it. It goes away after a few seconds or when you press Next or Back.

### 3.158 H.265 (HEVC) videos are refused (zt231)

1. Media Library (or the setup guide's content step): choose `green-rays.mp4` (H.265). It is refused with a plain message that says it is an H.265 (HEVC) video, that most browsers, OBS and XSplit cannot show it, and to re-save it as an MP4 with H.264 (HandBrake). Nothing is added to the library. The message appears inside the guide when you are in the guide.
2. Choose `green-rays-h264.mp4` (the converted copy): it is accepted, shows 0:30, plays on the XSplit projector with a steady picture, and starting it, clearing it and starting another quickly does not freeze anything.
3. If an H.265 file was added to the Media Library by an earlier build, delete it there (it is not used in a slideshow) and add the H.264 copy instead.

### 3.159 Bad videos can no longer cause trouble, and how to fix one (zt232)

1. **Look inside before accepting.** Media Library: choose `green-rays.mp4` (H.265). The message names the file, says what is wrong, and gives the fix: install HandBrake (handbrake.fr), choose the "Fast 1080p30" preset, check Format says MP4, press Start, add the new file. Nothing is added. Inside the setup guide (step 5) the same message appears inside the guide.
2. **Good files still go in.** Choose `green-rays-h264.mp4`: accepted, plays cleanly, no warning. A normal MP3/WAV/picture is accepted as before.
3. **Warnings.** If you have a 4K video or one at 60 frames a second (a phone video, say), it is added but a message says it may stutter and to re-save it with the "Fast 1080p30" preset. Re-save it, add it and the message does not appear.
4. **Help in the program.** Media Library tab: open "How to prepare a video (and what to do if one will not play)". The steps are readable and match HandBrake's real screens. In the setup guide's media row the hint mentions where to find the same steps.
5. **A bad file already in the library.** If you still have an H.265 file in the Media Library from an earlier build, put it on the projector. After a few seconds the Run page's "Playing now" box shows a red message that the screen could not play it and what to do. Press Clear live, delete it from the Media Library, and add the re-saved copy. The message goes away when the video is cleared and does not come back for a good video.
6. The program itself never freezes because of the file: the rest of the page keeps answering the whole time.

### 3.160 Long videos up to 8 GB (zt233)

1. Media Library: choose your youth camp video (over 1 GB, H.264). It uploads while the status line counts up: "Uploading Camp… 37%". The page stays usable. When it finishes it appears in the list with its length and plays on the projector, and the position bar jumps around in it quickly.
2. While it uploads, switch tabs and press Next/Previous on the live service: nothing lags.
3. A file over 8 GB is refused straight away with "too large (over 8 GB)".
4. If the drive is nearly full, the upload is refused before it starts: "…is 5.0 GB but this computer's disk has only 2.0 GB free…". (Only test this if you can do it safely, or skip.)
5. Close the browser tab halfway through an upload: no half-copied file is left in the media folder.
6. A normal small video, sound file and picture upload as before.

### 3.161 Flag stays on the video in the Media Library (zt234)

1. Media Library: the 4K or 60 fps video you added earlier now shows a "⚠ May stutter" tag beside its name, with the explanation underneath, every time you open the list (not only when it is added).
2. A normal H.264 1080p video shows no tag.
3. Re-save the flagged video with HandBrake ("Fast 1080p30"), add it: the new copy has no tag. Delete the old one.
4. (Cannot be tried unless an unplayable file is already in the library) such a video shows "⚠ Will not play well" with the HandBrake steps.

### 3.162 Jumping around in a long video no longer freezes it (zt235)

1. Put the long camp video on the projector (in XSplit) with the operator page open as usual. Drag the position bar to a far-off point and release. The picture and sound should be at the new place within a couple of seconds and keep playing.
2. Do it six or seven times in a row at different places, quickly. It should never stay frozen.
3. Press Pause and Play, Restart, and Next/Previous between the jumps: all still answer at once.
4. The sound still comes out of the ChurchLight window (the hidden sound frame now uses the other of `localhost` / `127.0.0.1`; you will not see a difference). If you used the address `http://127.0.0.1:...` to open the operator page, that is fine; so is `http://localhost:...`.
5. Settings → Sound: untick and tick "Play sound in this window"; sound stops and returns.
6. If it still freezes, note: how long it stays frozen, whether the picture, the sound or both stop, whether the operator buttons still work, and add `?debug` to the projector address in XSplit and send a screenshot of the line at the bottom.

### 3.163 What the library says about each video, and a warning for heavy ones (zt236)

1. Media Library: every video row now shows its details next to the length, such as "1920×1080 · 30 fps · H.264 · 8 Mbit/s". **Please read this line for the long camp video and tell me exactly what it says** (picture size, frames per second, Mbit/s). This is the most useful thing for finding why it stutters.
2. A video over 20 Mbit/s gets the "⚠ May stutter" tag and a note that re-saving it with HandBrake's "Fast 1080p30" preset usually makes it several times lighter.
3. Re-save the camp video that way (HandBrake, Fast 1080p30, Format MP4), add the new copy, and play both on the projector: is the new one smoother? Tell me both Mbit/s numbers.
4. While the video plays, open Task Manager (Ctrl+Shift+Esc) → Details: which of these is highest in CPU and in Memory: XSplit, msedge, python? Tell me the numbers.

### 3.164 Changing the service no longer restarts the playing video; big song imports are gentler (zt237)

1. Put a long video live (play it a minute in, or drag the bar to the middle). Now add another item to the service, in any place (a song, a video, an announcement), or move or remove an item that is not the video. The video must keep playing from where it was, with no restart and no flicker, on the projector and in the sound window.
2. Do the same with the video paused: it must stay paused at the same place.
3. Remove the video's own item from the service while it is live: the live video goes away (nothing odd).
4. Import the large batch of songs again (delete them first, or use new ones) while the long video plays on the projector. Note whether the picture lags or freezes at the moment the songs appear. The import now rests a few thousandths of a second after each song, so it takes a little longer (about 4 seconds more for 1000 songs) but should leave much more processor time for the video. Tell me whether the lag is gone, smaller or the same.
5. If it still lags, tell me what the long video's details line says in the Media Library (size, fps, Mbit/s). A very heavy video is the likely reason, and re-saving it (3.163) is the real cure.

### 3.165 The red "could not play" box no longer appears for a slow jump (zt238)

1. Play the camp video, jump around with the bar. The red box must not appear just because the picture took a while to catch up after a jump.
2. If the picture really does take many seconds after a jump, tell me how many, and what the Media Library details line says for the camp video (size, fps, Mbit/s). Also open Task Manager and tell me the CPU of XSplit while it catches up.
3. The red box now appears only when the screen reports that it cannot decode the file, or the video never showed a picture from the start. Its wording depends: for a real wrong format it says so (and gives the HandBrake steps); for a file that looks fine it says the computer may be busy or the video heavy, and to press Clear live and try again.

### 3.166 ChurchLight's own projector windows (zt239)

Why: video froze only inside XSplit's browser source, never in Edge. ChurchLight can now open the screens itself, as full-screen Edge windows, so Edge plays the video.

1. Settings → **Projector windows**. Each screen (projector, stage, confidence…) has a monitor list. Choose your projector's monitor for **projector**.
2. Press **Open the screens**. A full-screen window should appear on that monitor showing the real projector screen (not the white TEST page). Put a song up: it must show there. Press **Esc** on that window: it closes and the list stops saying "(open)" within a few seconds.
3. If you pick the monitor this window is on, you get a plain message and nothing opens (it would cover the program).
4. Play the camp video (20 min). Jump around with the bar. Does the picture on the projector window keep up? Tell me if it still freezes, and how long.
5. Sound: the video's sound should still come from the operator window, once. The projector window itself is silent.
6. XSplit/OBS: add a **Window capture** (or Display capture) of the projector window when you need the video on the stream. Tell me whether capture shows the picture and whether it freezes.
7. Tick **Open the screens whenever ChurchLight starts**, close ChurchLight, start it again: the screens open by themselves a few seconds after the program window. **Close the screens** closes them all. Closing ChurchLight closes them too.

### 3.167 Screens are ChurchLight's own windows; OBS only captures them (zt241)

This replaces the OBS projectors and the Test button. Please try it on the church PC with OBS (and XSplit if you like).

1. Setup guide, step 3 ("Your church and screens"). Choose a monitor for the projector. The screen opens full screen on that monitor straight away (no TEST page) and the row says "Open on that monitor". There is no Test or Stop test button now.
2. Choosing the monitor this window is on is refused with a plain message. Choosing "Not decided yet" closes that screen.
3. Move on to the next steps. The screen must stay open. Esc on it does nothing. Close ChurchLight: the screens close with it. Start it again: the screens open by themselves a few seconds later (no setup needed).
4. Step 4 (OBS): "Connect and make the scenes". The Livestream scene has your camera with the lower third (browser source) above it. The Projector, Stage and Confidence scenes each hold a Display Capture of the monitor you chose, filling the canvas. There is no "Put the room screens on your monitors" part any more.
5. In OBS, look at the Projector scene: does it show your projector screen live, with video that plays smoothly? Does it still freeze after scrubbing the camp video? If the capture shows the wrong monitor, tell me what OBS lists in the capture's Display box.
6. A screen with no monitor chosen is skipped with a line saying so; choose its monitor and make the scenes again.

### 3.168 Screen windows come back if closed, and have no taskbar button (zt243)

1. With the screens open, close the projector window (Alt+F4 on it, or right-click its taskbar button and Close). It must open again on the same monitor within a few seconds, with the same picture.
2. Look at the taskbar: the screen windows should have **no button** there (the operator window keeps its own). Tell me if a button still shows, or if the screen flashed or stopped being full screen when ChurchLight opened it.
3. Choosing "Not decided yet" for a screen in step 3, or **Close the screens** in Settings, closes it for good (it does not come back) until you open it again or restart ChurchLight.
4. Closing ChurchLight closes the screens and they do not come back.
5. Task Manager can still end a window; ChurchLight will open it again after a couple of seconds.

### 3.169 Screens name themselves in step 3; the operator's monitor can't be chosen (zt244)

1. Step 3: choose a monitor for the projector. That monitor shows a big white screen with **PROJECTOR** (and **STAGE**, **CONFIDENCE** for the others), so you can see which is which. A long word like CONFIDENCE must fit across the screen.
2. The monitor this program window is on is greyed out in every list (it says "this window is here") and cannot be picked.
3. Press Next (or close the guide): each screen changes from its name to the real screen on the same monitor, and stays open.

### 3.170 Media Library: list on the left, preview and options on the right (zt246)

1. Open the Media Library tab. The files are a list on the left; the right side says "Choose a file on the left".
2. Click a picture: it shows large on the right with its size and where it is used, and the buttons **Add to service**, **Show now**, **Rename** and **Delete**. The row you chose is outlined.
3. Click a video: a player appears (press play to look at it on this computer only; nothing goes to the screens). The details line (size, fps, Mbit/s) and any warning are on the right. **Play now** puts it on the screens. Click a sound: the same, plus **Play as music**.
4. **Rename** changes the name in place on the right (Enter saves, Esc cancels). **Delete** asks you to press twice, and is greyed out while a service or slideshow uses the file.
5. At the bottom of the left list, **From slideshows and themes** is folded. Open it: click a slideshow to see its pictures and an **Open slideshow** button; click a theme or the home picture to see it. These cannot be deleted here.
6. Choose another file while a video is playing in the preview: the old one stops.

### 3.171 The program starts itself again if it seizes up (zt247)

1. If ChurchLight stops answering (the operator page stops responding), it now checks itself every 3 seconds. After about 15 seconds of silence it starts a fresh copy by itself: the console window keeps going, the screens close and open again, and the operator page reconnects. Nothing on the church's side needs to be pressed.
2. **Shut down** now works even while the program is seized up (it no longer waits for the program's lock) and closes within a few seconds.
3. If you can make it seize up again, tell me exactly what you pressed (for example: Play now on a video from the Media Library, or the preview player), whether the screens, the operator page or the whole computer froze, and send `churchlight.log` (beside the database). It now records "did not answer 5 checks in a row" when the watchdog acts.

### 3.172 After a self-restart, Shut down leaves nothing behind (zt249)

1. If ChurchLight restarts itself, the black terminal window now closes at the end like normal (before, it stayed open on "ChurchLight stopped because of a problem, code 3"). Press **Shut down** afterwards: the screens, the operator window and the terminal all close.
2. Shut down also ends the program within about 15 seconds even if something refuses to close.

### 3.173 The freeze is fixed: a deadlock between the page updates and the operator's buttons (zt250)

The log you sent showed it exactly: pressing a button that makes a slide live (Go on a service item, Blank and similar) held the program's slide lock while it waited for the web server's lock, and a screen waiting for changes held the web server's lock while it waited for the slide lock. Each waited for the other, so everything stopped.

1. Repeat what froze before: play the camp video, scrub quickly, press Go on other service items, blank and unblank, many times, with both screens open. It must not stop answering.
2. Let it run through a long video while you press things. Look in `churchlight.log` afterwards: there should be no "did not answer" line.
3. If the log ever shows "did not answer" again, send me the block after "is not answering".

### 3.174 Settings starts folded (zt251)

1. Open the Settings tab on a fresh browser (or after clearing the page's saved choices): every section is folded, and the button at the top says **Open all**.
2. Open any section; reload. What you opened or folded is remembered from then on. **Open all** / **Fold all** still work.

### 3.175 Wizard welcome says what you need (zt252)

1. Open Settings, then "Run setup guide" (or a fresh database). The first screen says it takes about 10 minutes and lists **What you will need**: this computer, a monitor per room screen (one is enough), OBS (or another broadcast software) only if you livestream, and your songs/slideshows/Bible if handy.
2. The sentence about placing this window where it will be used during the service is still there. Read it as a brand-new volunteer: is anything confusing or scary?

### 3.176 Each wizard step says why it matters (zt253)

1. Walk the setup guide. Steps 2 to 6 each start with one plain sentence saying why the step matters. The OBS, content and look/clicker steps say "Optional" and what to press to leave them.
2. Read them as a first-time volunteer: any word you would not understand?

### 3.177 Wizard: broadcast wording, subheading lines, "I don't livestream" (zt254)

1. Step 1 lists "OBS (or another broadcast software), only if you livestream. If you do not, you can skip that step."
2. On steps 2 to 6 the "why" sentence now sits right under the step title like a subheading (larger, muted, close to the title). Step 1 and the last step have none.
3. Step 4 (Set up OBS) starts with a tick box, **I don't livestream (skip this step)**. Tick it: the OBS form disappears and a note says OBS is skipped. Press Next on the screens step: it goes straight to "Add your content". Press Back from there: you land on the OBS step, where you can untick it.
4. The tick is kept until you reload the page; opening the guide again later from Settings shows the OBS step normally if you reloaded.

### 3.178 Wizard revisions: fixed window, step 3 and 4 redesign, practice service at the end (zt255)

1. **Fixed window.** Walk all 7 steps: the window is the same size every time (longer steps scroll inside), and Skip setup (left), Back and Next (right) never move. On step 1 Back is invisible but keeps its place, so Next does not jump. On the last step Skip setup is invisible but keeps its place.
2. **Step 3.** No OBS wording any more. Each scene tick says Recommended or Optional (Projector recommended; Livestream recommended if you livestream; Stage, Confidence and Home optional). Under each monitor choice: "Recommended: the monitor or projector the congregation sees" for the projector, "Optional: only if you have a screen for them" for the others.
3. **Step 4.** Reads in this order: *What your broadcast software needs* (livestream scene = camera plus the lower third as a browser source; projector, stage and confidence = capture that monitor), the one **Lower third address** with Copy, the **Tested issue in XSplit** note (videos in a browser source can freeze or stay black), the **Check that each scene shows the right monitor** note (XSplit monitor numbers did not match the Windows numbers; judge by the picture in the scene preview), then *OBS: make the scenes automatically*. The projector, stage and confidence addresses are inside the closed fold at the bottom. Is the monitor note clear to someone who has never seen the problem?
4. "Remember the OBS password" is now OFF by default and says why.
5. **Step 5 (Add your content)** starts with the Home screen picture; step 6 no longer has it. Choose a picture, see it appear, then Remove it.
6. **Step 6** marks Theme "Recommended to begin with" and the clicker, Stream Deck and home picture "Optional".
7. **Last step ("You are ready")** has the *Make a practice service* button. The content step no longer has it. Press it: the note says the practice service is ready, and it is on the Service tab.

### 3.179 One monitor per screen, KJV note, imports from an earlier ChurchLight (zt256)

1. **Two screens, one monitor.** In step 3 choose the same monitor for the Projector and for Stage (or Confidence). The second choice is refused with a note such as "The projector is already on Monitor 2, so the Stage screen cannot go there too. Choose a different monitor, or leave one of them unset." The dropdown goes back to what it was and no window opens. Do the same in Settings, Projector windows: the message appears at the top and the dropdown goes back.
2. A different monitor for each screen still works, and choosing a screen's own monitor again is fine.
3. **At start-up (hard to try):** if an older saved setup somehow has two screens on one monitor, the first opens, the second does not, and "Open the screens now" in Settings lists why.
4. **Step 5** now says ChurchLight comes with the King James Version (KJV) Bible, already added.
5. At the very bottom of step 5 is a closed fold, **Moving from an earlier ChurchLight? (optional)**, with two rows. *An exported slideshow bundle*: choose a .zip made by Export on another ChurchLight computer; the line under the row says how the import goes, and the slideshow appears in the Slideshow Library. *Themes from a previous version*: choose a themes .zip made by Export in the Theme Library; the line says "Added N themes: …" (or "Nothing new was added" if you already have them). Both stay inside the guide.

### 3.180 Settings groups, captions and help, clickable bars, your own accent colour (zt257)

1. **Bars.** Open the Settings tab. Every section is a full-width bar with a hover colour and a chevron at the far right (it turns when open). Click far to the right of the words: it opens. Does the bar look like a button to you?
2. **Groups.** Under **Everyday**: Projector windows, Screens, Song title and CCLI slide, Move themes to another computer. Then one bar called **Advanced**; open it to find PDF import, Trigger URLs, Clicker helper, Keys for running the service, Keys that work in any program. **Open all** / **Fold all** include Advanced.
3. **Captions.** Each bar has one muted line under its title saying what is inside. Are all nine accurate and easy to understand?
4. **"?"** Press the round **?** on a bar: a longer sentence appears under the caption and the bar does not open. Press it again, or press Esc, to hide it.
5. **Your own accent colour.** Appearance, then "Or choose your own": pick any colour. Buttons, tabs and highlights follow it, and a line says whether it was "Adjusted slightly so words stay readable" (try a very pale and a very dark colour, in both Light and Dark). Reload: it is kept. Press one of the four preset swatches: the preset comes back.
6. **Step 5 of the guide:** the KJV note is now in the Bible row ("ChurchLight already comes with the King James Version (KJV)…"), not at the top.

### 3.181 Plain words, messages that stay, "Saved ✓" (zt258)

1. **Plain words.** Look through Settings (Remote button links, Clicker helper, Screens) and the setup guide. Is anything still jargon? The before/after list is in chat.
2. **Errors stay.** Cause a problem (for example give two outputs the same monitor, or press a button that needs OBS while OBS is off). A message appears with an **✕**. Wait 15 seconds: it is still there. Press a normal button that works (Next): it is still there. Press **✕**: it goes. Cause two problems in a row: the newer message replaces the older one.
3. **Notices fade.** Add a song to the service: "Added…" appears and fades by itself in about 8 seconds. It never has an ✕ requirement and does not hide an error that was already showing.
4. **Inside the setup guide.** Open the setup guide and cause a problem there: the message appears inside the guide above the buttons with an ✕.
5. **Saved ✓.** Edit a song and save it, change a theme, or reorder slideshow pages: the "Connected" pill reads **Saved ✓** for about 2 seconds, then returns to Connected. Pressing Next, Blank, or Play never shows it.
6. **Connection problems win.** Stop the program while the page is open: the pill goes red and stays red; it never says Saved ✓ while disconnected.

### 3.182 Ready check, friendly empty lists, clear confirmations, Undo (zt259)

1. **Ready to start?** Close any open service so the Service tab shows "Start". At the top is a list: Screens, Screen windows open, A Bible installed, A recent backup, This page is connected, OBS. Each problem row has a one-sentence reason and a button (Open Settings, Add a Bible, Back up now, Open setup guide). Press **Back up now**: that row turns to a tick. Press **Check again**.
2. **Screens row.** With the real monitors set up and the screens open, it should say "Projector on Monitor 2" (and the others) and "All screens are open." Close the screens: the row says which are not open.
3. **OBS row.** With OBS running and its connection set up, it reads "OBS is connected". With OBS closed it says it is not connected, with a button to the setup guide.
4. **I don't livestream.** In the setup guide, step 4, tick "I don't livestream". Open the Service tab: there is no OBS row. Reopen the guide, step 4: the box is still ticked. Untick it: the OBS row comes back.
5. **Practice service.** Under the Start box: "Just want to try it out? Make a practice service". Press it: a practice service opens.
6. **Empty lists.** On a fresh copy (or after deleting everything) read the empty text on Song Library, Slideshow Library, Bible Library and Media Library: each says what to do next. The slideshow page also says "Have a PowerPoint? Export it to PDF first".
7. **Delete confirmations.** Press Delete on a song, a draft song, a slideshow, a media file, a theme, and Remove on a Bible. The first press shows a sentence naming it and what is lost, and the button reads "Yes, delete" (Yes, remove for a Bible). Wait 8 seconds: it goes back. Press Discard in the song editor and Shut down in the toolbar: each also names what happens.
8. **Make a new private code** (Settings, Advanced, Remote button links): the second press says your old remote button links and clicker scripts will stop working.
9. **Undo.** Press the ✕ on a service item: "Removed “…” from the service. Undo". Press Undo within 10 seconds: it comes back in the same place. In the song report, press Remove on a section: it goes at once, with Undo; press Undo: it is back.

### 3.183 Monitor layout remembered (zt260)

1. Set up the screens on the real monitors and press **Open screens**. Go to the Service tab with no service open: the check has a row "Monitors: arranged the same as the last time the screens were opened".
2. Change the arrangement: unplug the projector (or switch Windows to "PC screen only"), then plug it back in, or drag a monitor to the other side in Windows display settings. Come back to the Service tab and press **Check again**: a row says "The monitors changed since last time" and says what differs (a different count, size, or a moved monitor).
3. Check Settings, Screens, then press **This layout is correct**. The row turns to a tick and stays quiet next time.
4. Nothing warns before you have ever opened the screens once (there is nothing to compare with).

### 3.184 Import lists, stage timer look, folded ready check (zt261)

1. **Several batches (setup guide, step 5).** Add songs three times in a row (pick one file each time). The "Songs" row lists three lines, top to bottom, numbered 1., 2., 3. in the order you added them, each with its own status (Working, then Done). Do the same for slideshows (PDFs and an exported bundle) and a Bible: each row lists every batch, none hidden. For themes from an earlier install and for media files, each finished file adds one line ("Added …") under the row instead of replacing the last one.
2. **Stage timer look.** Settings (the countdown/timer settings), section "Stage and confidence screens: timer and alert": the first controls are now Font, Text color and Color when it reaches zero. Change the stage text color and start a countdown: the stage and confidence screens use the new color while the projector keeps its own. Press **Copy the projector's font and colors here**: the stage look matches the projector again. An older saved look starts with the stage timer matching the projector, nothing jumps.
3. **Folded ready check.** Close any open service. On the Service tab the "Ready to start?" bar is folded. Its line says "✓ Everything is good to go" (green) when all is well, or "2 things to check: Screens, OBS. Open to fix." with a stronger border when something is wrong, or "Checking…" for a moment. Open it: rows and fix buttons are as before, with Check again. Fix a problem (for example press Back up now): the bar's line updates. Leave the tab and come back: it is folded again.

### 3.185 Fixes found while checking zt261 (zt262)

1. **Monitor warning survives a restart.** Set up and open the screens (layout remembered). Close ChurchLight, change the monitor arrangement (replug the projector or move a monitor in Windows display settings), start ChurchLight again (the screens may open by themselves). On the Service tab the "Ready to start?" bar still says the monitors changed. Only **This layout is correct** clears it.
2. **A notice never covers a problem.** Cause an error (for example give two outputs the same monitor), then add a song: the error is still showing, not replaced by "Added…". Removing a service item still shows "Removed … Undo" (it replaces the error because you need the Undo), and pressing a delete button still shows its question.
3. **OBS row.** With OBS closed or refusing the connection, the OBS row now says why (OBS's own reason) before telling you to open the setup guide.


### 3.186 Folded Settings, slideshow filter and the slides guide (zt263)

1. **Settings always starts folded.** Open the Settings tab: every section is folded and the button says "Open all". Open two sections, go to another tab and come back: all folded again. Open one, reload the page: folded again. Opening sections while you stay on the tab keeps them open.
2. **Jumps open only the target.** On the Service tab, with a problem in the "Ready to start?" bar, press its "Open Settings" fix button: only that section opens (and Advanced around it if it lives there), the others stay folded.
3. **Alerts Settings starts folded too.** Open the Alerts Settings tab: "Projector" and "Stage" are both folded. Open one, leave and return: folded again. On the Service tab press "Change how it looks": Alerts Settings opens with only the projector part open and the preview still draws at the right size.
4. **Filter slideshows.** On the Slideshow Library with several slideshows, type part of a name (any capitals): the list narrows as you type. Type something that matches nothing: "No slideshows match". Add or rename a slideshow while text is typed: the text stays. Clear the box: everything returns. With no slideshows at all, the box is hidden.
5. **The slides guide.** On the Slideshow Library press "How do I get my slides in?". A window opens with tabs PowerPoint, Google Slides, Keynote, LibreOffice Impress; each shows numbered steps. Below is "What does not come across, and what to do". Esc, Close, or clicking outside it closes the window. It also opens from the setup guide's slideshow row and from the empty slideshow list. Please follow the PowerPoint steps with a real file and tell me if any menu name differs on your computer.

### 3.187 Slideshow editor toolbar, Add to the Media Library, video pages (zt264)

1. **Toolbar.** Open a slideshow in the editor. Row 1: a blue **Add pictures…**, **Add from ▾** (Media Library…, Another slideshow…), **Replace ▾** (A picture…, From a PDF…), and **Select all** at the far right. Menus open on click, close when you pick something, click elsewhere or press Esc. Narrow the window: the buttons wrap and nothing runs off the edge.
2. **Selection bar.** With nothing selected it says "Selected slides: none yet. Click a slide to select it." with a dashed look and dimmed buttons. Click a slide: "1 slide selected", blue border, buttons live: ← → (hover says Move earlier / Move later), Duplicate, Skip, Add to the Media Library, Make a new slideshow from selected…, and a red Delete set apart at the right (still asks first).
3. **Add to the Media Library.** Select two slides, press it: notice "Added 2 pictures to the Media Library". Open the Media Library: two pictures named "<slideshow> - slide N" (or the slide's title). Do it again: names get (2). The slideshow is unchanged. It also works while that slideshow is live.
4. **Video pages.** Add a short MP4 from the Media Library into a slideshow ("Add from ▾", Media Library…). Make it live: it plays on the projector, sound unless set to no sound, it moves on at its end if the slideshow is timed. Back/Next move off it. Try the Media Library delete on that video: it refuses and says it is in a slideshow. Exporting that slideshow as a bundle is refused plainly ("slideshows with video cannot be exported yet"), which is what I ask you to confirm is acceptable for now.

### 3.188 Owner feedback round (zt265)

1. **Screens row goes to Projector windows.** With a screen problem in the "Ready to start?" bar (for example no screen set up), press the Screens row's fix button: Settings opens with only **Projector windows** open (not Screens). The wording says "Settings, Projector windows".
2. **Toolbar row 1.** Left to right, all packed at the left: **Add pictures** (no dots), **Select all**, **Add from ▾**, **Replace ▾**, all blue. The options that drop down from the two menus are white. Row 2 is as before.
3. **Click empty space to deselect.** In the slide editor click the empty area below or between the slides: nothing is selected, the bar says "Selected slides: none yet. Click a slide to select it." and its buttons dim. Click a slide: selected again. (This is a trial: tell me if you want it removed.)
4. **Double-press buttons disengage.** Press a Delete button once (it says "Yes, delete" or "Sure?"), then click anywhere else (empty space, another button, another tab): it goes back to its normal name at once and nothing is deleted. Pressing it twice in a row still deletes. Try a few: slideshow Delete, song Delete, Shut down.
5. **Filter in Add from Media Library.** In the editor open Add from ▾, Media Library…. A "Filter files" box sits above the pictures. Typing narrows the files by name; "No files match" when nothing fits. Files you already ticked stay ticked while you filter, and the Add button keeps counting them.
6. **Export all with video slideshows.** With no video slideshows, Export all downloads straight away. Add a video slideshow, then press Export all: the notice names the slideshows that have video, and the button says "Yes, export the other N". Press it again to download a bundle without them. Pressing anywhere else cancels. The Export button on a video slideshow itself is refused and says to add the videos to the Media Library on the other computer and put them in the slideshow again.

### 3.189 Toolbar alignment (zt266)

1. **Row 1 lines up.** In the slide editor, Add pictures, Select all, Add from ▾ and Replace ▾ sit on one line with the same top and the same height (the two menu buttons are no longer lower than the first two). Open each menu: the options still drop down in white.

### 3.190 Deselect area and filter spacing (zt267)

1. **Deselect anywhere in the Slides box.** In the slide editor, click empty space anywhere inside the Slides box: beside or below the slides, the hint line, or the "N slides selected" text. Everything deselects. Clicking a slide, a button, a menu or a text box does not.
2. **Filter box spacing.** Open Add from ▾, Media Library…. The "Filter files" box has a clear gap above the pictures; nothing touches or covers it. Filtering still works.

### 3.191 A video starts after the slide is on screen (zt268)

1. **Video waits for the screen.** Make a slideshow live and move to a video slide (first with no transition set). The projector shows the slide's first frame, and the video begins about half a second later, from its very beginning (nothing missed, no sound before the picture).
2. **With a transition.** Give the slideshow a transition (for example Dissolve, 1 second, in the slideshow's settings). Move from the previous slide to the video slide: the transition finishes first, then the video starts from the top.
3. **Sound pages.** A slide that carries its own sound file starts that sound at the same moment as the screen change finishes, not before.
4. **Controls stay quick.** On a playing video, Pause, Play, Restart and the progress bar react at once (no half-second wait).
5. **Moving on.** A timed slideshow still moves on right after the video ends (the wait does not add up wrongly).
6. **Other screens.** Stage, confidence and lower-third screens are unchanged. If you have two projector screens, both start the video together.
7. **Media Library "Play now".** Playing a video straight from the Media Library also begins about half a second after you press it. Tell me if that feels slow.

### 3.192 OBS wording and video-page transitions (zt269)

1. **OBS checkbox wording.** In the setup guide, on the OBS step, the tick box reads "I don't need the OBS connection (I don't livestream, or I use XSplit or other software)". Tick it: the note says "OK, the OBS connection is skipped…" and mentions capturing the projector and stage windows and adding the lower third by its address for XSplit. Next goes past the OBS step.
2. **Ready bar.** With it ticked, the "Ready to start?" bar has no OBS row. Untick it and leave OBS closed: the OBS row says OBS is not connected and its hint reads "If you do not use OBS, tick "I don't need the OBS connection" there."
3. **No transition onto a video page.** Give a slideshow a transition (for example Dissolve, 1 second) and move onto a video slide, and off it again: the screen changes plainly (no flash of white). The video then starts about half a second later from the top. Moving between picture slides still uses the transition.

### 3.193 The Ready bar follows the setup guide at once (zt270)

1. **Tick takes effect at once.** On the empty Service tab, open the setup guide (Settings, Run setup) and go to the OBS step. Tick "I don't need the OBS connection": the "Ready to start?" bar behind the guide drops its OBS row right away, without pressing Finish. Untick it and the row comes back.
2. **Leaving the guide any way.** Close the guide with Skip setup, Finish, or by leaving it open and pressing Esc where it allows: the bar always shows the state it was left in. Anything else the guide changed (a monitor chosen, a Bible added) shows too.
